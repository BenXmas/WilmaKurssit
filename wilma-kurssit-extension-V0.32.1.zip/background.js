// Opens extra Wilma tabs for the retry loop, and lets a finished extra tab close itself.
chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m) return;
  if (m.type === 'open' && m.url) {
    const k = Math.min(10, +m.n || 0);
    // with win: all the loop tabs go into one new window, which is not focused and does not take the user's page away
    if (m.win && k) chrome.windows.create({ url: Array(k).fill(m.url), focused: false });
    else for (let i = 0; i < k; i++) chrome.tabs.create({ url: m.url, active: false });
  }
  if (m.type === 'close' && sender && sender.tab) chrome.tabs.remove(sender.tab.id);
  if (m.type === 'closeExtra') chrome.tabs.query({ url: 'https://*.inschool.fi/*' }, tabs => tabs.filter(t => /#wk-loop\b/.test(t.url || '') && !(sender && sender.tab && sender.tab.id === t.id)).forEach(t => chrome.tabs.remove(t.id)));
});
