// Connects the panel to the toolbar popup: where the panel appears (on the Wilma page / separate full-page tab).
(() => {
  const api = () => window.__wilmaKurssit;
  
  try {
    // remember a Wilma address the popup can open in a new tab
    const base = (/^\/![^/]+/.exec(location.pathname) || [''])[0];
    chrome.storage.local.set({ wkUrl: location.origin + base + '/selection/view' });
  } catch (_) { /* ignore */ }
  window.__wkOpenTabs = (n, u, win) => { try { chrome.runtime.sendMessage({ type: 'open', n, url: u, win: !!win }); } catch (_) { /* ignore */ } };
  window.__wkCloseExtra = () => { try { chrome.runtime.sendMessage({ type: 'closeExtra' }); } catch (_) { /* ignore */ } };
  window.__wkCloseTab = () => { try { chrome.runtime.sendMessage({ type: 'close' }); } catch (_) { /* ignore */ } };
  const apply = mode => {
    try { localStorage.setItem('wilmaKurssit.off', mode === 'off' ? '1' : '0'); } catch (_) { /* ignore */ }
    const a = api();
    if (mode === 'off' && !/#wk-/.test(location.hash)) { if (a) a.unload(); return; }
    if (!a) return;
    if (/^#wk-full/.test(location.hash)) { a.setFull(true, (/^#wk-full-(dash|loop|con|set|dev|exp)$/.exec(location.hash) || [0, 'sel'])[1]); a.setHidden(false); return; }
    a.setHidden(mode === 'tab');
  };
  try {
    chrome.storage.local.get({ mode: 'panel' }, r => apply(r.mode));
    chrome.storage.onChanged.addListener(c => { if (c.mode) { apply(c.mode.newValue); if (c.mode.oldValue === 'off' && c.mode.newValue !== 'off' && !api() && !/#wk-/.test(location.hash)) location.reload(); } });
    chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'show' && api()) api().openPanel(); if (m && m.type === 'stop' && api() && api().stopLoop) api().stopLoop(); });
  } catch (_) { /* ignore */ }
})();
