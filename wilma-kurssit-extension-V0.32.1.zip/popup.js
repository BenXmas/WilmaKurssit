const lng = /^fi/i.test(navigator.language) ? 'fi' : /^sv/i.test(navigator.language) ? 'sv' : 'en', fi = lng === 'fi';
const SV = {
  title: 'Wilma Kurssit', panel: 'Panel på Wilma-sidan', tab: 'Separat flik', go: 'Öppna nu', dash: '\u{1F4CA} Dashboard',
  tpanel: 'Verktyget visas som en liten panel i kanten av Wilma-sidan. Du kan dra den och krympa den till en bubbla.',
  ttab: 'Panelen döljs på Wilma-sidorna och verktyget öppnas i en egen flik i fönsterstorlek. Du ser allt på en gång och inställningarna är desamma som i panelen.',
  tdash: 'Öppnar dashboarden i en egen flik: översikt över avklarade, valda och saknade obligatoriska kurser.',
  tgo: 'I panelläge visas panelen på den öppna Wilma-fliken. I fliksläge öppnas en ny flik.',
  stop: '\u23F9 Stoppa försöken och stäng extra flikar', tstop: 'Stoppar försöksslingan i alla Wilma-flikar och stänger de extra flikar som tillägget öppnade.',
  noUrl: 'Öppna Wilma en gång i den här webbläsaren först så att adressen sparas.', done: 'Öppnad.', noTab: 'Öppna en Wilma-flik först.', off: 'Av (sparar resurser)', toff: 'Tillägget bygger ingen panel på Wilma-sidorna alls, så det belastar inte webbläsaren. Dashboarden och Öppna-knapparna fungerar ändå.', offMsg: 'Tillägget är av. Välj Panel eller Separat flik först.'
};
const L = lng === 'sv' ? SV : fi ? {
  title: 'Wilma Kurssit', panel: 'Paneeli Wilma-sivulla', tab: 'Erillinen välilehti', go: 'Avaa nyt', dash: '\u{1F4CA} Dashboard',
  tpanel: 'Työkalu näkyy pienenä paneelina Wilman sivun reunassa. Voit raahata sen ja pienentää kuplaksi.',
  ttab: 'Paneeli piilotetaan Wilma-sivuilta ja työkalu avataan erilliseen välilehteen koko ikkunan kokoisena. Kaikki näkyy kerralla, ja asetukset ovat samat kuin paneelissa.',
  tdash: 'Avaa dashboardin: yhteenveto suoritetuista, valituista ja puuttuvista pakollisista kursseista, erilliseen välilehteen.',
  tgo: 'Paneelitilassa tuo paneelin näkyviin avoimelle Wilma-välilehdelle. Välilehtitilassa avaa uuden välilehden.',
  stop: '\u23F9 Lopeta yrittäminen ja sulje lisävälilehdet', tstop: 'Pysäyttää uudelleenyrityssilmukan kaikissa Wilma-välilehdissä ja sulkee laajennuksen avaamat lisävälilehdet.',
  noUrl: 'Avaa Wilma ensin kerran tässä selaimessa, niin osoite tallentuu.', done: 'Avattu.', noTab: 'Avaa Wilma-välilehti ensin.', off: 'Pois päältä (säästää resursseja)', toff: 'Laajennus ei rakenna paneelia Wilma-sivuille lainkaan, joten se ei kuormita selainta. Dashboard ja avauspainikkeet toimivat silti.', offMsg: 'Laajennus on pois päältä. Valitse ensin Paneeli tai Erillinen välilehti.'
} : {
  title: 'Wilma Kurssit', panel: 'Panel on the Wilma page', tab: 'Separate tab', go: 'Open now', dash: '\u{1F4CA} Dashboard',
  tpanel: 'The tool shows as a small panel at the edge of the Wilma page. You can drag it and shrink it to a bubble.',
  ttab: 'The panel is hidden on Wilma pages and the tool opens in its own full-window tab. You see everything at once, and the settings are the same as in the panel.',
  tdash: 'Opens the dashboard in its own tab: overview of completed, selected and missing compulsory courses.',
  tgo: 'In panel mode it brings the panel up on the open Wilma tab. In tab mode it opens a new tab.',
  stop: '\u23F9 Stop retrying and close extra tabs', tstop: 'Stops the retry loop in every Wilma tab and closes the extra tabs the extension opened.',
  noUrl: 'Open Wilma once in this browser first so the address gets saved.', done: 'Opened.', noTab: 'Open a Wilma tab first.', off: 'Off (saves resources)', toff: 'The extension builds no panel on Wilma pages at all, so it puts no load on the browser. The dashboard and the open buttons still work.', offMsg: 'The extension is off. Pick Panel or Separate tab first.'
};
const $ = s => document.querySelector(s);
document.documentElement.lang = lng;
$('#title').textContent = L.title; $('#t-panel').textContent = L.panel; $('#t-tab').textContent = L.tab; $('#go').textContent = L.go;
$('#t-off').textContent = L.off; $('#tip-off').textContent = L.toff; $('#tip-panel').textContent = L.tpanel; $('#tip-tab').textContent = L.ttab; $('#tip-go').textContent = L.tgo; $('#tip-dash').textContent = L.tdash; $('#tip-stop').textContent = L.tstop; $('#stopall').textContent = L.stop; $('#dash').textContent = L.dash;
document.querySelectorAll('button.q').forEach(b => b.addEventListener('click', e => {
  e.preventDefault(); const t = $('#tip-' + b.dataset.k), on = !t.classList.contains('on');
  document.querySelectorAll('.tip').forEach(x => x.classList.remove('on')); document.querySelectorAll('button.q').forEach(x => x.classList.remove('on'));
  if (on) { t.classList.add('on'); b.classList.add('on'); }
}));
let mode = 'panel';
const paint = () => { document.querySelectorAll('input[name=mode]').forEach(r => { r.checked = r.value === mode; r.closest('.opt').classList.toggle('sel', r.checked); }); };
chrome.storage.local.get({ mode: 'panel' }, r => { mode = r.mode; paint(); });
document.querySelectorAll('input[name=mode]').forEach(r => r.addEventListener('change', () => { mode = r.value; chrome.storage.local.set({ mode }); paint(); }));
$('#go').addEventListener('click', async () => {
  if (mode === 'off') { $('#msg').textContent = L.offMsg; return; }
  if (mode === 'tab') {
    const { wkUrl } = await chrome.storage.local.get('wkUrl');
    if (!wkUrl) { $('#msg').textContent = L.noUrl; return; }
    chrome.tabs.create({ url: wkUrl + '#wk-full' }); window.close();
  } else {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    try { await chrome.tabs.sendMessage(tabs[0].id, { type: 'show' }); $('#msg').textContent = L.done; setTimeout(() => window.close(), 400); }
    catch (_) { $('#msg').textContent = L.noTab; }
  }
});

$('#dash').addEventListener('click', async () => {
  const { wkUrl } = await chrome.storage.local.get('wkUrl');
  if (!wkUrl) { $('#msg').textContent = L.noUrl; return; }
  chrome.tabs.create({ url: wkUrl + '#wk-full-dash' }); window.close();
});

$('#stopall').addEventListener('click', async () => {
  const tabs = await chrome.tabs.query({ url: 'https://*.inschool.fi/*' });
  for (const t of tabs) { try { await chrome.tabs.sendMessage(t.id, { type: 'stop' }); } catch (_) { /* tab without the script */ } }
  const extra = tabs.filter(t => /#wk-loop\b/.test(t.url || ''));
  for (const t of extra) { try { await chrome.tabs.remove(t.id); } catch (_) { /* already closed */ } }
  $('#msg').textContent = '\u2713 ' + tabs.length + (extra.length ? ' (\u2212' + extra.length + ')' : '');
});
