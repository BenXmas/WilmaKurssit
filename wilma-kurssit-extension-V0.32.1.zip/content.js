// ==UserScript==
// @name         Wilma Kurssit (course picker)
// @namespace    local.wilma.kurssit
// @version      0.32.1
// @description  Paste course codes, find them in Wilma's kurssitarjotin and pick them all at once (optionally at an exact time)
// @match        https://*.inschool.fi/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

/*
 * USAGE (Chrome): open Wilma, F12 -> Console, type "allow pasting" if asked, paste this file, Enter.
 * Works from any Wilma page while you are logged in; it does not need the tray to be open.
 *
 * HOW IT TALKS TO WILMA (taken from the public repo drstuggels/kurssit, written in 2021):
 *   GET  <base>/selection/view          -> #own-schools: <h4> year titles, each followed by <ul> of period links
 *   GET  <base>/selection/<period>      -> course groups are <a> elements: text = course code, href = target id
 *   POST <base>/selection/postback      -> message=pick-group & target=<href> & formkey=<token>
 * Wilma may have changed since then, so use "Find courses" (dry run, sends nothing) first.
 *
 * THE LOOP ("Yritä kunnes"): picks are sent first, straight from the latest scan of the course pages (kept in localStorage, shared by every
 * tab); the scan runs beside them, every 1.5-5 s and right after Wilma accepted a pick. A pick is never in the air twice (Web Locks) and an
 * accepted pick is not repeated before a scan has seen it. Timers come from a Worker so a background window keeps its pace.
 *
 * Console API:  __wilmaKurssit.unload()
 */

(() => {
  'use strict';

  const ID = 'wk-host';
  const KEY = 'wilmaKurssit.v1';
  const DEFAULTS = { list: '', year: '', syear: 0, conc: 4, at: '', lang: (l => (/^fi/i.test(l) ? 'fi' : /^sv/i.test(l) ? 'sv' : 'en'))(document.documentElement.lang || navigator.language), open: true, arm: false, always: false, wq: true, req: null, reqV: 0, manual: {}, seen: {}, summary: [], ltabs: 3, lkeep: false, auto: { home: '', others: [], want: '', other: '', maxper: 0, lock: true }, ldelay: 2, lmax: 30, unstable: false, lmode: 'reload', lworkers: 6, lite: false, help: false, w: 0, h: 0, gapMs: 0, cauto: false, cremember: false, cka: true, lwin: true, hiddenReq: [], earned: {}, hops: {}, hopsAt: 0, theme: 'auto', ignore: {}, pickMode: false, opPer: 2, dopen: {}, per: [], choices: {}, filters: {}, refresh: true, fast: false, rt: 0, x: null, y: null };

  // Compulsory studies, from the lukio tuntijako (valtioneuvoston asetus 810/2018, used by the 2021 curriculum):
  // credits (op) / 2 = courses. Prefixes match the start of a course code (the longest prefix wins). Everything is editable.
  const DEFAULT_REQ = [
    { id: 'ai', name: 'Äidinkieli ja kirjallisuus', p: ['ÄI', 'S2'], need: 6 },
    { id: 'a', name: 'A-kieli (englanti ym.)', p: ['ENA', 'RAA', 'SAA', 'VEA', 'ESA', 'ITA', 'RUA'], need: 6 },
    { id: 'b1', name: 'B1-kieli (ruotsi)', p: ['RUB', 'RUB1'], need: 5 },
    { id: 'may', name: 'Matematiikan yhteiset opinnot', p: ['MAY'], need: 1 },
    { id: 'maa', name: 'Pitkä matematiikka', p: ['MAA'], need: 9, alt: 'mat' },
    { id: 'mab', name: 'Lyhyt matematiikka', p: ['MAB'], need: 5, alt: 'mat' },
    { id: 'bi', name: 'Biologia', p: ['BI'], need: 2 }, { id: 'ge', name: 'Maantiede', p: ['GE'], need: 1 },
    { id: 'fy', name: 'Fysiikka', p: ['FY'], need: 1 }, { id: 'ke', name: 'Kemia', p: ['KE'], need: 1 },
    { id: 'fi', name: 'Filosofia', p: ['FI'], need: 2 }, { id: 'ps', name: 'Psykologia', p: ['PS'], need: 1 },
    { id: 'hi', name: 'Historia', p: ['HI'], need: 3 }, { id: 'yh', name: 'Yhteiskuntaoppi', p: ['YH'], need: 3 },
    { id: 'uk', name: 'Uskonto / elämänkatsomustieto', p: ['UE', 'UO', 'UK', 'UI', 'UJ', 'ET'], need: 2 },
    { id: 'te', name: 'Terveystieto', p: ['TE'], need: 1 }, { id: 'li', name: 'Liikunta', p: ['LI'], need: 2 },
    { id: 'mk', name: 'Musiikki ja kuvataide', p: ['MU', 'KU'], need: 3 },
    { id: 'op', name: 'Opinto-ohjaus', p: ['OP'], need: 2 },
  ];


  // the extension's "off" mode: do not even build the panel (saves work on a slow computer) unless a full view was asked for
  try { if (localStorage.getItem('wilmaKurssit.off') === '1' && !/#wk-/.test(location.hash)) return; } catch (_) { /* ignore */ }
  if (window.__wilmaKurssit) { try { window.__wilmaKurssit.unload(); } catch (_) { /* ignore */ } }

  let state;
  try { state = { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch (_) { state = { ...DEFAULTS }; }
  if (!Array.isArray(state.req) || state.reqV !== 2) { state.req = JSON.parse(JSON.stringify(DEFAULT_REQ)); state.reqV = 2; }
  state.at = ''; // a start time is never restored: a stale one could fire (or wait) when you did not expect it
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify({ ...state, at: '' })); } catch (_) { /* ignore */ } };

  // ---------- text ----------
  const T = {
    fi: {
      tabSel: 'Valinta', tabDash: 'Dashboard', dashOpen: 'Dashboard',
      title: 'Wilma Kurssit', year: 'Lukuvuosi', reload: 'Hae uudelleen', list: 'Kurssit',
      ph: 'MAY01.1, ÄI05.2\nENA04\nFY01', find: 'Etsi', pick: 'Valitse', at: 'Kellonaika (hh:mm:ss, ei pakollinen)',
      conc: 'Samanaikaisia pyyntöjä', cancel: 'Peruuta', loadingYears: 'Haetaan lukuvuosia…', noYears: 'Lukuvuosia ei löytynyt valintasivulta (otsikko + jaksolista). Onko sivu muuttunut?',
      always: 'Valitse automaattisesti jokaisen latauksen jälkeen', wq: 'Kytke Wilman "Käytä pikavalintaa" päälle automaattisesti', arm: 'Valitse automaattisesti seuraavan latauksen jälkeen (kerran)', armHint: 'Päivitä Wilman valintasivu: 3 s kuluttua haetaan ja valitaan tallennetut kurssit. Peruuta pysäyttää.', autoIn: n => `Automaattinen valinta alkaa ${n} s kuluttua… (Peruuta pysäyttää)`,
      clearAll: 'Tyhjennä kaikki', allCleared: 'Kaikki tyhjennetty (lista, jaksot, valinnat ja tallennettu tila).',
      pfAll: 'Kaikki jaksot', pfTitle: 'Rajaa kurssi yhteen jaksoon', missingIn: 'Ei tässä jaksossa', refresh: 'Päivitä sivu', refreshHint: 'Kellonaikana sivu päivitetään ja valinta tehdään heti latauksen jälkeen', reloadAt: s => `Päivitetään sivu ${s} kuluttua… (Peruuta pysäyttää)`, more: 'Lisää asetuksia',
      selSummary: 'Valittu', clear: 'tyhjennä', save: 'Tallenna tiedostoon', load: 'Lataa tiedostosta', saved: 'Tallennettu tiedostoon.',
      loaded: (a, b) => `Ladattu: ${a}/${b} jaksoa löytyi tältä sivulta.`, badFile: 'Tiedosto ei kelpaa.',
      periods: 'Jaksot', noPeriods: 'Valitse vähintään yksi jakso.', otherSchool: 'Muut',
      scanning: n => `Haetaan jaksoja (${n})…`, found: (a, b) => `${a}/${b} kurssia löytyi.`, missing: 'Ei löytynyt', choose: 'Valitse ryhmä',
      nothing: 'Ei kursseja, joita yrittää.', noKey: 'formkey-tunnistetta ei löytynyt. Oletko kirjautunut sisään?', waiting: s => `Odotetaan… ${s}`,
      sending: n => `Valitaan ${n} kurssia…`, done: (ok, bad) => `Valmis: ${ok} pyyntöä OK, ${bad} virhettä. Tarkista tulos Wilmasta!`,
      badTime: 'Kellonaika ei kelpaa (esim. 16:00 tai 16:00:00).', cancelled: 'Peruutettu.', status: 'Tila', course: 'Kurssi', period: 'Jakso',
      hint: 'Esim. MAY01 tai MAY01.1. Vain yhteen jaksoon: MAY01@1a. Päällekkäisyyksiä ei tarkisteta.',
      dry: 'Ei vielä lähetetty mitään.', unload: 'Sulje', min: 'Pienennä', lang: 'SV',
      dbg: 'Vianetsintätiedot', dbgDone: 'Kopioitu leikepöydälle. Se ei sisällä salasanaa tai tunnisteita; tarkista silti ennen jakamista.', dbgShown: 'Kopiointi ei onnistunut, valitse teksti alta käsin.',
      fSel: 'valittu', fDone: 'suoritettu', fFull: 'täynnä', fOff: 'ei valittavissa', fClosed: 'päättynyt',
      skipClosed: 'ohitettu: ilmoittautuminen on päättynyt', skipSel: 'ohitettu: jo valittu',
    },
    en: {
      tabSel: 'Selection', tabDash: 'Dashboard', dashOpen: 'Dashboard',
      title: 'Wilma Kurssit', year: 'School year', reload: 'Reload', list: 'Courses',
      ph: 'MAY01.1, ÄI05.2\nENA04\nFY01', find: 'Find', pick: 'Pick', at: 'Time (hh:mm:ss, optional)',
      conc: 'Parallel requests', cancel: 'Cancel', loadingYears: 'Loading school years…', noYears: 'No school years found on the selection page (heading + period list). Has the page changed?',
      always: 'Pick automatically after every page load', wq: 'Tick Wilma\'s own "Käytä pikavalintaa" (quick select) automatically', arm: 'Pick automatically after the next page load (once)', armHint: 'Refresh the Wilma selection page: after 3 s the saved courses are found and picked. Cancel stops it.', autoIn: n => `Automatic pick starts in ${n} s… (Cancel stops it)`,
      clearAll: 'Clear everything', allCleared: 'Everything cleared (list, periods, choices and saved state).',
      pfAll: 'All periods', pfTitle: 'Limit this course to one period', missingIn: 'Not in this period', refresh: 'Refresh page', refreshHint: 'At the set time the page is refreshed and the pick happens right after it loads', reloadAt: s => `Refreshing the page in ${s}… (Cancel stops it)`, more: 'More',
      selSummary: 'Selected', clear: 'clear', save: 'Save to file', load: 'Load from file', saved: 'Saved to a file.',
      loaded: (a, b) => `Loaded: ${a}/${b} periods found on this page.`, badFile: 'Invalid file.',
      periods: 'Periods', noPeriods: 'Tick at least one period.', otherSchool: 'Other',
      scanning: n => `Scanning periods (${n})…`, found: (a, b) => `${a}/${b} courses found.`, missing: 'Not found', choose: 'Choose group',
      nothing: 'No courses to pick.', noKey: 'Could not find the formkey token. Are you logged in?', waiting: s => `Waiting… ${s}`,
      sending: n => `Picking ${n} courses…`, done: (ok, bad) => `Done: ${ok} requests OK, ${bad} failed. Check the result in Wilma!`,
      badTime: 'Invalid time (e.g. 16:00 or 16:00:00).', cancelled: 'Cancelled.', status: 'Status', course: 'Course', period: 'Period',
      hint: 'E.g. MAY01 or MAY01.1. One period only: MAY01@1a. Overlaps are not checked.',
      dry: 'Nothing has been sent yet.', unload: 'Close', min: 'Minimize', lang: 'FI',
      dbg: 'Debug info', dbgDone: 'Copied to clipboard. It contains no password or tokens; still check it before sharing.', dbgShown: 'Could not copy; select the text below by hand.',
      fSel: 'selected', fDone: 'completed', fFull: 'full', fOff: 'unavailable', fClosed: 'closed',
      skipClosed: 'skipped: registration has ended', skipSel: 'skipped: already selected',
    },
    sv: {
      tabSel: 'Val', tabDash: 'Dashboard', dashOpen: 'Dashboard',
      title: 'Wilma Kurssit', year: 'Läsår', reload: 'Hämta igen', list: 'Kurser',
      ph: 'MAY01.1, ÄI05.2\nENA04\nFY01', find: 'Sök', pick: 'Välj', at: 'Klockslag (tt:mm:ss, valfritt)',
      conc: 'Samtidiga förfrågningar', cancel: 'Avbryt', loadingYears: 'Hämtar läsår…', noYears: 'Inga läsår hittades på valsidan (rubrik + periodlista). Har sidan ändrats?',
      always: 'Välj automatiskt efter varje sidladdning', wq: 'Kryssa Wilmas egna "Käytä pikavalintaa" (snabbval) automatiskt', arm: 'Välj automatiskt efter nästa sidladdning (en gång)', armHint: 'Uppdatera Wilmas valsida: efter 3 s söks och väljs de sparade kurserna. Avbryt stoppar.', autoIn: n => `Automatiskt val startar om ${n} s… (Avbryt stoppar)`,
      clearAll: 'Töm allt', allCleared: 'Allt tömt (lista, perioder, val och sparat tillstånd).',
      pfAll: 'Alla perioder', pfTitle: 'Begränsa kursen till en period', missingIn: 'Finns inte i denna period', refresh: 'Uppdatera sidan', refreshHint: 'Vid det angivna klockslaget uppdateras sidan och valet görs direkt efter laddningen', reloadAt: s => `Uppdaterar sidan om ${s}… (Avbryt stoppar)`, more: 'Mer',
      selSummary: 'Valda', clear: 'töm', save: 'Spara till fil', load: 'Ladda från fil', saved: 'Sparat till fil.',
      loaded: (a, b) => `Laddat: ${a}/${b} perioder hittades på denna sida.`, badFile: 'Ogiltig fil.',
      periods: 'Perioder', noPeriods: 'Kryssa minst en period.', otherSchool: 'Övriga',
      scanning: n => `Söker perioder (${n})…`, found: (a, b) => `${a}/${b} kurser hittades.`, missing: 'Hittades inte', choose: 'Välj grupp',
      nothing: 'Inga kurser att välja.', noKey: 'Hittade inte formkey-koden. Är du inloggad?', waiting: s => `Väntar… ${s}`,
      sending: n => `Väljer ${n} kurser…`, done: (ok, bad) => `Klart: ${ok} förfrågningar OK, ${bad} fel. Kontrollera resultatet i Wilma!`,
      badTime: 'Ogiltigt klockslag (t.ex. 16:00 eller 16:00:00).', cancelled: 'Avbrutet.', status: 'Status', course: 'Kurs', period: 'Period',
      hint: 'T.ex. MAY01 eller MAY01.1. Bara en period: MAY01@1a. Överlappningar kontrolleras inte.',
      dry: 'Inget har skickats ännu.', unload: 'Stäng', min: 'Minimera', lang: 'EN',
      dbg: 'Felsökningsinfo', dbgDone: 'Kopierat till urklipp. Det innehåller inget lösenord eller koder; kontrollera ändå innan du delar.', dbgShown: 'Kopieringen lyckades inte, markera texten nedan för hand.',
      fSel: 'vald', fDone: 'avklarad', fFull: 'full', fOff: 'ej valbar', fClosed: 'avslutad',
      skipClosed: 'hoppades över: anmälan har avslutats', skipSel: 'hoppades över: redan vald',
    },
  };
  const tr = () => T[state.lang] || T.en;

  const H = {
    fi: {
      head: 'FI/SV/EN vaihtaa kielen, – pienentää paneelin, ✕ sulkee. Paneelin voi vetää otsikosta.',
      year: 'Valitse lukuvuosi ja koulu. Jaksoja voi valita useammalta vuodelta.',
      reload: 'Hakee lukuvuodet ja jaksot uudelleen.',
      periods: 'Kursseja haetaan ja valitaan ruksatuista jaksoista. Avoimet jaksot ruksataan itse.',
      list: 'Kirjoita kurssikoodit (esim. MAY01 tai MAY01.1), erota välilyönnillä tai rivinvaihdolla. Vain tiettyyn jaksoon: MAY01@1a.',
      plan: 'Kullekin koodille näytetään löytynyt ryhmä. Jos ryhmiä on monta, valitse oikea.',
      at: 'Kellonaika, jolloin valinta tehdään. Tyhjänä heti.',
      refresh: 'Päällä: sivu päivitetään kellonaikana ja valinta tehdään heti. Pidä välilehti auki.',
      find: 'Näyttää, mistä ryhmästä kukin kurssi löytyy. Ei valitse vielä mitään.',
      pick: 'Lähettää valinnat Wilmaan (tai odottaa kellonaikaa). Jo valitut ohitetaan.',
      cancel: 'Pysäyttää haun, odotuksen tai automaattivalinnan.',
      save: 'Tallentaa listan ja valinnat tekstitiedostoon.',
      load: 'Lataa tallennetun tiedoston.',
      clearall: 'Tyhjentää kaiken: listan, jaksot, valinnat, ajastukset ja tallennetun tilan.',
      debug: 'Kokoaa vianetsintäraportin (ei salasanoja) leikepöydälle. Liitä se kehittäjälle, jos jokin ei toimi.',
      conc: 'Montako pyyntöä lähetetään yhtä aikaa (1–10). Pienempi on varovaisempi.',
      always: 'Etsii ja valitsee kurssit itse 3 s jokaisen sivun latauksen jälkeen.',
      arm: 'Sama kuin yllä, mutta vain seuraavalla latauksella.',
      wq: 'Ruksaa Wilman "Käytä pikavalintaa" automaattisesti.',
    },
    en: {
      head: 'FI/SV/EN switches language, – shrinks the panel, ✕ closes it. Drag the panel by its title.',
      year: 'Choose the school year and school. You can tick periods from several years.',
      reload: 'Loads the school years and periods again.',
      periods: 'Courses are searched and picked from the ticked periods. Open periods are ticked automatically.',
      list: 'Type course codes (e.g. MAY01 or MAY01.1), separated by spaces or new lines. One period only: MAY01@1a.',
      plan: 'Shows the group found for each code. If there are several, choose the right one.',
      at: 'The time at which the pick is made. Empty means right away.',
      refresh: 'On: the page is refreshed at that time and the pick is made right away. Keep the tab open.',
      find: 'Shows which group each course is in. Picks nothing yet.',
      pick: 'Sends the picks to Wilma (or waits for the set time). Already selected ones are skipped.',
      cancel: 'Stops the search, the wait or the automatic pick.',
      save: 'Saves the list and choices to a text file.',
      load: 'Loads a saved file.',
      clearall: 'Clears everything: list, periods, choices, timers and saved state.',
      debug: 'Copies a debug report (no passwords) to the clipboard. Share it if something does not work.',
      conc: 'How many requests are sent at once (1–10). Lower is gentler.',
      always: 'Finds and picks the courses 3 s after every page load.',
      arm: 'Same as above, but only for the next page load.',
      wq: 'Ticks Wilma\'s "Käytä pikavalintaa" automatically.',
    },
  };
  Object.assign(H.fi, {
    tabs: 'Valinta: kurssien valinta. Dashboard: yhteenveto suoritetuista, valituista ja puuttuvista pakollisista kursseista.',
    dashopen: 'Avaa dashboardin erilliseen välilehteen, jossa näet kaikki kurssit kerralla.',
    dscan: 'Hakee Wilmasta kaikkien lukuvuosien jaksot ja päivittää, mitkä kurssit on merkitty suoritetuiksi tai valituiksi.',
    dreset: 'Palauttaa pakollisten kurssien listan oletukseksi (tuntijako). Käsin tekemäsi poistot ja muutokset häviävät.',
    dadd: 'Lisää oman oppiaineen tai kurssiryhmän: nimi, koodin alku (esim. KE tai KEA, erotettuna pilkulla) ja montako kurssia vaaditaan.',
    dmanual: 'Wilma merkitsee suoritetuiksi vain ne, jotka näkyvät kurssitarjottimessa. Kirjoita tähän loput kurssikoodit (esim. ÄI01, ENA02), niin ne lasketaan suoritetuiksi.',
    dchip: 'Vihreä = suoritettu, sininen = valittu, harmaa = ei suoritettu. Klikkaa kurssia merkitäksesi sen suoritetuksi käsin (katkoviivareunus), klikkaa uudelleen poistaaksesi merkinnän. Hiiren oikea painike avaa valikon: kurssin voi ignoorata (musta, yliviivattu), jolloin sitä ei lasketa mukaan.',
    dopen: 'Jokainen oppiaine on avattava valikko: näytä tai piilota sen kurssit. Napeilla voit avata tai sulkea kaikki kerralla. Tila säilyy.',
    dpick: 'Uusien kurssien valintamoodi: piilottaa suoritetut ja valitut kurssit valittavista. Jäljelle jäävät pakolliset, joita et ole vielä valinnut (keltainen). Suoritetut ja valitut näkyvät sinisinä. Klikkaa keltaista kurssia lisätäksesi sen valintalistaan.',
    dfold: 'Avaa tai sulkee kaikki oppiainekortit kerralla.',
    dtools: 'Lisätyökalut: merkitse suoritetuksi koodeilla, lisää oma oppiaine, palauta oletuslista, muuta opintopisteitä per kurssi ja palauta ohitetut kurssit.',
    dop: 'Montako opintopistettä yksi Wilman kurssi on. Lukiossa 1 kurssi = 2 op, joten 150 op = 75 kurssia.',
    dlist: 'Lisää kaikki keltaiset (tarjolla olevat pakolliset) kurssit valintalistaan. Siirry sitten Valinta-välilehdelle.',
    dgo: 'Siirtyy Valinta-välilehdelle, jossa lista on valmiina.',
    tileop: 'Kaikkien suoritettujen ja valittujen kurssien opintopisteet yhteensä. Lukion oppimäärä vaatii vähintään 150 op (LOPS).',
    tilereq: 'Pakollisten opintojen opintopisteet: kertyneet / vaaditut. LOPS: 94 op (lyhyt matematiikka) tai 102 op (pitkä).',
    tilemiss: 'Pakollisia kursseja, joita ei ole suoritettu eikä valittu.',
    tilecnt: 'Suoritettuja / valittuja kursseja (ohitetut eivät lasketa).',
    ddel: '✕ piilottaa koko oppiaineen pakollisten listalta (se jää Työkalut-valikon Piilotetut-listaan, josta sen saa takaisin). Rivin numerokenttä muuttaa vaadittujen kurssien määrää, esim. 0 poistaa vaatimuksen.',
  });
  Object.assign(H.en, {
    tabs: 'Selection: choosing courses. Dashboard: overview of completed, selected and missing compulsory courses.',
    dashopen: 'Opens the dashboard in its own tab so you see all courses at once.',
    dscan: 'Fetches the periods of all school years from Wilma and refreshes which courses are marked completed or selected.',
    dreset: 'Restores the compulsory list to the default (tuntijako). Your own removals and edits are lost.',
    dadd: 'Adds your own subject or course group: name, start of the code (e.g. KE or KEA, comma separated) and how many courses are required.',
    dmanual: 'Wilma only marks completed courses that appear in the course tray. Type the rest of the codes here (e.g. ÄI01, ENA02) and they count as completed.',
    dchip: 'Green = completed, blue = selected, grey = not taken. Click a course to mark it completed by hand (dotted outline), click again to remove the mark. Right-click opens a menu: a course can be ignored (black, struck through) so it is not counted.',
    dopen: 'Every subject is a dropdown: show or hide its courses. The buttons open or close all of them at once. The state is remembered.',
    dpick: 'New-course picking mode: hides completed and selected courses from the pickable ones. What is left are compulsory courses you have not selected yet (yellow). Completed and selected ones show in blue. Click a yellow course to add it to the pick list.',
    dfold: 'Opens or closes all subject cards at once.',
    dtools: 'More tools: mark completed by codes, add your own subject, restore the default list, change credits per course and restore ignored courses.',
    dop: 'How many credits one Wilma course is. In lukio 1 course = 2 op, so 150 op = 75 courses.',
    dlist: 'Adds all yellow (offered compulsory) courses to the pick list. Then go to the Selection tab.',
    dgo: 'Goes to the Selection tab, where the list is ready.',
    tileop: 'Credits of all completed and selected courses together. The lukio syllabus requires at least 150 op (LOPS).',
    tilereq: 'Credits of the compulsory studies: earned / required. LOPS: 94 op (short maths) or 102 op (long).',
    tilemiss: 'Compulsory courses that are neither completed nor selected.',
    tilecnt: 'Completed / selected courses (ignored ones are not counted).',
    ddel: '✕ hides the whole subject from the compulsory list (it stays in the Hidden list in the Tools menu, where you can bring it back). The number field on a row changes how many courses are required, e.g. 0 removes the requirement.',
  });
  const D = {
    fi: { head: 'Kurssiyhteenveto', done: 'Suoritettu', sel: 'Valittu', miss: 'Puuttuu', need: 'Pakollisia', scan: 'Päivitä tiedot', reset: 'Palauta oletuslista', add: 'Lisää oppiaine', addName: 'Nimi', addPref: 'Koodin alku (esim. KE,KEA)', addBtn: 'Lisää', manual: 'Merkitse suoritetuksi (koodit)', manualBtn: 'Merkitse', del: 'Poista pakollisista', alt: 'vaihtoehto, ei lasketa', other: 'Muut kurssit', empty: 'Ei tietoja vielä. Paina "Päivitä tiedot".', scanning: (a, b) => `Haetaan jaksoja ${a}/${b}…`, scanned: n => `Valmis: ${n} kurssia löytyi.`, nothing: 'ei kursseja', req: 'pakolliset', cnt: 'kpl',
      pick: 'Uusien kurssien valinta', pickOn: 'Valintamoodi päällä', fold: 'Avaa/sulje kaikki', tools: 'Työkalut', op: 'op / kurssi', ignored: 'Ohitetut', total: 'Opintopisteet yhteensä', reqOp: 'Pakolliset', cntT: 'Suoritettu / valittu', ign: 'Ohita kurssi (ei lasketa)', unign: 'Palauta ohitettu kurssi', mark: 'Merkitse suoritetuksi', unmark: 'Poista suoritusmerkintä',
      lopsOk: n => `✓ vastaa LOPSia (${n} op)`, lopsDiff: (a, b) => `⚠ oma lista ${a} op, LOPS ${b} op`,
      pickHelp: 'Keltainen: pakollinen, ei vielä valittu (klikkaa lisätäksesi valintalistaan). Sininen: suoritettu tai valittu.', todo: 'Valittavana', have: 'Suoritettu tai valittu', notOffered: n => `ei tarjolla (${n} puuttuu)`, addAll: n => `Lisää kaikki keltaiset listaan (${n})`, go: 'Siirry valintaan →', added: n => `${n} kurssia lisätty valintalistaan.`, done2: 'Valmiit oppiaineet', inList: 'listalla', yellowNone: 'Ei valittavia pakollisia kursseja.',
      chipTip: (c, st) => `${c} – ${st}`, stDone: 'suoritettu', stSel: 'valittu', stNone: 'ei suoritettu', stIgn: 'ohitettu', stManual: 'merkitty käsin', stTodo: 'pakollinen, ei valittu' },
    en: { head: 'Course overview', done: 'Completed', sel: 'Selected', miss: 'Missing', need: 'Required', scan: 'Refresh', reset: 'Restore defaults', add: 'Add subject', addName: 'Name', addPref: 'Code start (e.g. KE,KEA)', addBtn: 'Add', manual: 'Mark as completed (codes)', manualBtn: 'Mark', del: 'Remove from compulsory', alt: 'alternative, not counted', other: 'Other courses', empty: 'No data yet. Press "Refresh".', scanning: (a, b) => `Scanning periods ${a}/${b}…`, scanned: n => `Done: ${n} courses found.`, nothing: 'no courses', req: 'compulsory', cnt: 'pcs',
      pick: 'Pick new courses', pickOn: 'Picking mode on', fold: 'Open/close all', tools: 'Tools', op: 'op / course', ignored: 'Ignored', total: 'Total credits', reqOp: 'Compulsory', cntT: 'Completed / selected', ign: 'Ignore course (not counted)', unign: 'Restore ignored course', mark: 'Mark as completed', unmark: 'Remove completion mark',
      lopsOk: n => `✓ matches LOPS (${n} op)`, lopsDiff: (a, b) => `⚠ own list ${a} op, LOPS ${b} op`,
      pickHelp: 'Yellow: compulsory, not selected yet (click to add to the pick list). Blue: completed or selected.', todo: 'To pick', have: 'Completed or selected', notOffered: n => `not offered (${n} missing)`, addAll: n => `Add all yellow to the list (${n})`, go: 'Go to selection →', added: n => `${n} courses added to the pick list.`, done2: 'Finished subjects', inList: 'in list', yellowNone: 'No compulsory courses left to pick.',
      chipTip: (c, st) => `${c} – ${st}`, stDone: 'completed', stSel: 'selected', stNone: 'not completed', stIgn: 'ignored', stManual: 'marked by hand', stTodo: 'compulsory, not selected' },
  };
  H.sv = {
    head: 'FI/SV/EN byter språk, – krymper panelen, ✕ stänger. Dra panelen i rubriken.',
    year: 'Välj läsår och skola. Du kan kryssa perioder från flera läsår.',
    reload: 'Hämtar läsår och perioder igen.',
    periods: 'Kurser söks och väljs från de kryssade perioderna. Öppna perioder kryssas automatiskt.',
    list: 'Skriv kurskoder (t.ex. MAY01 eller MAY01.1), avgränsade med mellanslag eller radbrytning. Bara en period: MAY01@1a.',
    plan: 'Visar gruppen som hittades för varje kod. Finns flera, välj rätt.',
    at: 'Klockslaget då valet görs. Tomt betyder genast.',
    refresh: 'På: sidan uppdateras vid klockslaget och valet görs genast. Håll fliken öppen.',
    find: 'Visar i vilken grupp varje kurs finns. Väljer inget ännu.',
    pick: 'Skickar valen till Wilma (eller väntar till klockslaget). Redan valda hoppas över.',
    cancel: 'Stoppar sökningen, väntan eller automatiskt val.',
    save: 'Sparar listan och valen i en textfil.',
    load: 'Laddar en sparad fil.',
    clearall: 'Tömmer allt: lista, perioder, val, timers och sparat tillstånd.',
    debug: 'Samlar en felsökningsrapport (inga lösenord) i urklipp. Dela den om något inte fungerar.',
    conc: 'Hur många förfrågningar som skickas samtidigt (1–10). Lägre är försiktigare.',
    always: 'Söker och väljer kurserna 3 s efter varje sidladdning.',
    arm: 'Som ovan, men bara vid nästa sidladdning.',
    wq: 'Kryssar Wilmas "Käytä pikavalintaa" automatiskt.',
    tabs: 'Val: välja kurser. Dashboard: översikt över avklarade, valda och saknade obligatoriska kurser.',
    dashopen: 'Öppnar dashboarden i en egen flik så att du ser alla kurser på en gång.',
    dscan: 'Hämtar perioderna för alla läsår, dina avlagda kurser och din HOPS från Wilma.',
    dreset: 'Återställer listan över obligatoriska kurser till standard (timfördelning). Dina egna ändringar går förlorade.',
    dadd: 'Lägger till ett eget ämne eller en kursgrupp: namn, början av koden (t.ex. KE eller KEA, kommaseparerat) och hur många kurser som krävs.',
    dmanual: 'Wilma markerar bara avklarade kurser som syns i kurserbjudandet. Skriv övriga kurskoder här (t.ex. ÄI01, ENA02) så räknas de som avklarade.',
    dchip: 'Grön = avklarad, blå = vald, grå = inte avklarad. Klicka på en kurs för att markera den avklarad för hand (prickad kant). Högerklick: ignorera kursen (räknas inte). Kantfärg: lila = obligatorisk, rosa = valfri.',
    dopen: 'Varje ämne är en rullgardin: visa eller dölj dess kurser.',
    dpick: 'Läge för val av nya kurser: döljer avklarade och valda kurser bland de valbara. Kvar blir obligatoriska kurser du inte valt ännu (gula). Avklarade och valda syns blå. Klicka på en gul kurs för att lägga den i vallistan.',
    dfold: 'Öppnar eller stänger alla ämneskort på en gång.',
    dtools: 'Fler verktyg: markera avklarade med koder, lägg till eget ämne, återställ standardlistan, ändra poäng per kurs och återställ ignorerade kurser.',
    dop: 'Hur många studiepoäng en Wilma-kurs är. I gymnasiet är 1 kurs = 2 sp, så 150 sp = 75 kurser.',
    dlist: 'Lägger alla gula (erbjudna obligatoriska) kurser i vallistan. Gå sedan till fliken Val.',
    dgo: 'Går till fliken Val där listan är klar.',
    tileop: 'Studiepoäng för kurser som är avlagda enligt Wilma (Studier → Prestationer). Utöver dem visas poängen för valda kurser separat. Gymnasiets lärokurs kräver minst 150 sp.',
    tilereq: 'Studiepoäng för de obligatoriska studierna: avlagda / krävda. Timfördelningen: 94 sp (kort matematik) eller 102 sp (lång).',
    tilemiss: 'Obligatoriska kurser som varken är avlagda eller valda.',
    tilecnt: 'Avlagda / valda kurser (ignorerade räknas inte).',
    ddel: '✕ döljer hela ämnet från listan över obligatoriska (det finns kvar i listan Dolda i verktygsmenyn, där du kan ta tillbaka det). Sifferfältet ändrar hur många kurser som krävs, t.ex. 0 tar bort kravet.',
    theme: 'Ljust eller mörkt tema. Följer systemet tills du själv byter.',
    dprest: 'Hämtar dina avlagda kurser och studiepoäng från Wilmas sida Studier → Prestationer. Då räknas avlagda poäng enligt Wilma, inte enligt gissning.',
    dhops: 'Hämtar din HOPS (Studier → HOPS) från Wilma: poängen för varje kurs och vilka valda kurser som ännu inte finns i den.',
    dhopscopy: 'Kopierar kurskoderna som är valda men inte i HOPS till urklipp.',
  };
  D.sv = { head: 'Kursöversikt', done: 'Avklarad', sel: 'Vald', miss: 'Saknas', need: 'Obligatoriska', scan: 'Uppdatera', reset: 'Återställ standard', add: 'Lägg till ämne', addName: 'Namn', addPref: 'Kodens början (t.ex. KE,KEA)', addBtn: 'Lägg till', manual: 'Markera som avklarad (koder)', manualBtn: 'Markera', del: 'Ta bort från obligatoriska', alt: 'alternativ, räknas inte', other: 'Övriga kurser', empty: 'Inga uppgifter ännu. Tryck "Uppdatera".', scanning: (a, b) => `Söker perioder ${a}/${b}…`, scanned: n => `Klart: ${n} kurser hittades.`, nothing: 'inga kurser', req: 'obligatoriska', cnt: 'st',
    pick: 'Välj nya kurser', pickOn: 'Valläge på', fold: 'Öppna/stäng alla', tools: 'Verktyg', op: 'sp / kurs', ignored: 'Ignorerade', total: 'Studiepoäng', reqOp: 'Obligatoriska', cntT: 'Avklarad / vald', ign: 'Ignorera kurs (räknas inte)', unign: 'Återställ ignorerad kurs', mark: 'Markera som avklarad', unmark: 'Ta bort markeringen',
    lopsOk: n => `✓ stämmer med läroplanen (${n} sp)`, lopsDiff: (a, b) => `⚠ egen lista ${a} sp, läroplan ${b} sp`,
    pickHelp: 'Gul: obligatorisk, inte vald ännu (klicka för att lägga i vallistan). Blå: avklarad eller vald.', todo: 'Att välja', have: 'Avklarad eller vald', notOffered: n => `inte erbjuden (${n} saknas)`, addAll: n => `Lägg alla gula i listan (${n})`, go: 'Gå till val →', added: n => `${n} kurser lades till i vallistan.`, done2: 'Färdiga ämnen', inList: 'i listan', yellowNone: 'Inga obligatoriska kurser kvar att välja.',
    chipTip: (c, st) => `${c} – ${st}`, stDone: 'avklarad', stSel: 'vald', stNone: 'inte avklarad', stIgn: 'ignorerad', stManual: 'markerad för hand', stTodo: 'obligatorisk, inte vald' };
  Object.assign(D.fi, { wsum: 'Wilman yhteenveto', calc: 'kurssien summa', man: 'Pakollinen', opt: 'Valinnainen', earned: 'Saadut op (Suoritukset)', planned: 'valittu', getDone: 'Hae suoritukset', getHops: 'Hae HOPS', hopsMissing: 'Valittu, mutta ei HOPSissa', copy: 'Kopioi lista', copied: 'Kopioitu leikepöydälle.',
    linkNone: n => `Linkkiä ei löytynyt: ${n}. Paina Vianetsintätiedot (Valinta-välilehti, Lisää) ja lähetä raportti.`, doneRes: (n, k) => `Suorituksia luettu: ${n} kurssia, joista ${k} op tiedossa.`, noRows: n => `Sivulta ${n} ei tunnistettu kursseja. Paina Vianetsintätiedot.`, hopsRes: n => `HOPSista luettu ${n} kurssia.`, estimate: 'op arvio', legend: 'Reunaväri: pakollinen / valinnainen', projected: 'jos valitut suoritetaan', prest: 'Suoritukset', hops: 'HOPS', inHops: 'HOPSissa' });
  Object.assign(D.en, { wsum: 'Wilma summary', calc: 'sum of courses', man: 'Compulsory', opt: 'Elective', earned: 'Earned op (Suoritukset)', planned: 'selected', getDone: 'Fetch completions', getHops: 'Fetch HOPS', hopsMissing: 'Selected but not in HOPS', copy: 'Copy list', copied: 'Copied to clipboard.',
    linkNone: n => `Link not found: ${n}. Press Debug info (Selection tab, More) and send the report.`, doneRes: (n, k) => `Completions read: ${n} courses, ${k} op known.`, noRows: n => `No courses recognised on the ${n} page. Press Debug info.`, hopsRes: n => `${n} courses read from HOPS.`, estimate: 'op estimated', legend: 'Edge colour: compulsory / elective', projected: 'if the selected are completed', prest: 'Completions', hops: 'HOPS', inHops: 'in HOPS' });
  Object.assign(D.sv, { wsum: 'Wilmas sammanfattning', calc: 'summa av kurser', man: 'Obligatorisk', opt: 'Valfri', earned: 'Avlagda sp (Prestationer)', planned: 'vald', getDone: 'Hämta prestationer', getHops: 'Hämta HOPS', hopsMissing: 'Vald men inte i HOPS', copy: 'Kopiera lista', copied: 'Kopierat till urklipp.',
    linkNone: n => `Länken hittades inte: ${n}. Tryck Felsökningsinfo (fliken Val, Mer) och skicka rapporten.`, doneRes: (n, k) => `Prestationer lästa: ${n} kurser, ${k} sp kända.`, noRows: n => `Inga kurser kändes igen på sidan ${n}. Tryck Felsökningsinfo.`, hopsRes: n => `${n} kurser lästa från HOPS.`, estimate: 'sp uppskattade', legend: 'Kantfärg: obligatorisk / valfri', projected: 'om de valda avklaras', prest: 'Prestationer', hops: 'HOPS', inHops: 'i HOPS' });
  Object.assign(H.fi, {
    theme: 'Vaalea tai tumma teema. Seuraa järjestelmää, kunnes vaihdat itse.',
    dprest: 'Hakee suoritetut kurssit ja opintopisteet Wilman sivulta Opinnot → Suoritukset. Silloin saadut op lasketaan Wilman mukaan, ei arvauksena.',
    dhops: 'Hakee HOPSisi (Opinnot → HOPS) Wilmasta: kurssikohtaiset opintopisteet ja se, mitkä valitut kurssit eivät ole vielä siinä.',
    dhopscopy: 'Kopioi leikepöydälle kurssikoodit, jotka on valittu mutta eivät ole HOPSissa.',
    tileop: 'Wilman mukaan suoritettujen kurssien opintopisteet (Opinnot → Suoritukset). Valittujen kurssien pisteet näytetään erikseen, eikä niitä lasketa saatuihin. Lukion oppimäärä vaatii vähintään 150 op.',
    dscan: 'Hakee Wilmasta kaikkien lukuvuosien jaksot, suoritukset ja HOPSin.',
    dchip: 'Vihreä = suoritettu, sininen = valittu, harmaa = ei suoritettu. Klikkaa kurssia merkitäksesi sen suoritetuksi käsin (katkoviivareunus). Oikea klikkaus: ohita kurssi (ei lasketa). Reunaväri: violetti = pakollinen, pinkki = valinnainen.',
  });
  Object.assign(H.en, {
    theme: 'Light or dark theme. Follows the system until you change it yourself.',
    dprest: 'Fetches your completed courses and credits from Wilma\'s Opinnot → Suoritukset page, so earned credits come from Wilma, not from a guess.',
    dhops: 'Fetches your HOPS (Opinnot → HOPS) from Wilma: the credits of each course and which selected courses are not in it yet.',
    dhopscopy: 'Copies the course codes that are selected but not in HOPS to the clipboard.',
    tileop: 'Credits of the courses completed according to Wilma (Opinnot → Suoritukset). Credits of selected courses are shown separately and are not counted as earned. The lukio syllabus requires at least 150 op.',
    dscan: 'Fetches the periods of all school years, your completions and your HOPS from Wilma.',
    dchip: 'Green = completed, blue = selected, grey = not taken. Click a course to mark it completed by hand (dotted outline). Right-click: ignore the course (not counted). Edge colour: purple = compulsory, pink = elective.',
  });
  Object.assign(T.fi, { loop: 'Yritä kunnes kaikki valittu', ltabs: 'Välilehtiä', ldelay: 'Odotus kierrosten välillä (s)', lmax: 'Enimmäisaika (min)',
    loopRound: (r, p, n, s, b) => `Kierros ${r}: ${p}/${n} kurssia vielä valitsematta, ${s} pyyntöä lähetetty${b ? ', ' + b + ' virhettä' : ''}. Päivitetään sivu…`,
    loopDone: n => `\u2705 Kaikki ${n} kurssia on valittu. Silmukka pysäytetty.`, loopOff: 'Silmukka ei ole käynnissä.', loopStopped: 'Silmukka pysäytetty.',
    openedTabs: n => `Avattu ${n} lisävälilehteä.`, noTabs: 'Selain esti lisävälilehtien avaamisen. Sallitse ponnahdusikkunat tälle sivulle tai käytä laajennusta.' });
  Object.assign(T.en, { loop: 'Retry until all selected', ltabs: 'Tabs', ldelay: 'Wait between rounds (s)', lmax: 'Time limit (min)',
    loopRound: (r, p, n, s, b) => `Round ${r}: ${p}/${n} courses still not selected, ${s} requests sent${b ? ', ' + b + ' failed' : ''}. Refreshing…`,
    loopDone: n => `\u2705 All ${n} courses are selected. Loop stopped.`, loopOff: 'The loop is not running.', loopStopped: 'Loop stopped.',
    openedTabs: n => `Opened ${n} more tabs.`, noTabs: 'The browser blocked opening more tabs. Allow pop-ups for this page or use the extension.' });
  Object.assign(T.sv, { loop: 'Försök tills allt är valt', ltabs: 'Flikar', ldelay: 'Väntan mellan rundor (s)', lmax: 'Tidsgräns (min)',
    loopRound: (r, p, n, s, b) => `Runda ${r}: ${p}/${n} kurser ännu inte valda, ${s} förfrågningar skickade${b ? ', ' + b + ' fel' : ''}. Uppdaterar sidan…`,
    loopDone: n => `\u2705 Alla ${n} kurser är valda. Slingan stoppad.`, loopOff: 'Slingan körs inte.', loopStopped: 'Slingan stoppad.',
    openedTabs: n => `Öppnade ${n} flikar till.`, noTabs: 'Webbläsaren blockerade fler flikar. Tillåt popup-fönster för sidan eller använd tillägget.' });
  Object.assign(T.fi, { yearLbl: 'Vuositaso', yearOpts: ['Kaikki vuodet', '1. vuosi', '2. vuosi', '3. vuosi (abi)', '4. vuosi (yli-abi)'], yearAbove: 'myöhemmän vuositason kurssi' });
  Object.assign(T.en, { yearLbl: 'Year level', yearOpts: ['All years', 'Year 1', 'Year 2', 'Year 3 (matriculation)', 'Year 4 (extra)'], yearAbove: 'course of a later year level' });
  Object.assign(T.sv, { yearLbl: 'Årsnivå', yearOpts: ['Alla år', 'År 1', 'År 2', 'År 3 (studentskrivningar)', 'År 4 (extra)'], yearAbove: 'kurs på en senare årsnivå' });
  Object.assign(H.fi, { syear: 'Harmaannuttaa kurssit, jotka kuuluvat Tapiolan lukion valintakortin (2026–2027) mukaan myöhemmälle vuositasolle kuin valittu. Harmaita kursseja voi silti valita. Sama valinta on dashboardilla.' });
  Object.assign(H.en, { syear: 'Greys out courses that the Tapiolan lukio subject selection card (2026–2027) puts at a later year level than the chosen one. Greyed courses can still be picked. The same choice is on the dashboard.' });
  Object.assign(H.sv, { syear: 'Gråar ut kurser som Tapiolan lukios ämnesvalskort (2026–2027) placerar på en senare årsnivå än den valda. Gråade kurser kan ändå väljas. Samma val finns på översikten.' });
  Object.assign(T.fi, { pdfBtn: 'Vie PDF', pdfTitle: 'Kurssivalinnat', pdfDone: 'Suoritettu', pdfSel: 'Valittu', pdfMiss: 'Puuttuu', pdfOthers: 'Muut kurssit', pdfPlan: 'Kurssilista ja ryhmät', pdfNotFound: 'ei löytynyt', pdfYear: 'Vuositaso', pdfSaved: 'PDF tallennettu.', pdfCount: (a, b) => `Suoritettu ${a} kurssia, valittu ${b} kurssia`, pdfNeed: n => `pakollisia puuttuu ${n}`,
    catN: { ai: 'Äidinkieli', a: 'A-kielet', b1: 'B1-kieli (ruotsi)', b2: 'B2-kielet', b3: 'B3-kielet (lukiossa alkavat)', mat: 'Matematiikka', sci: 'Luonnontieteet', soc: 'Yhteiskunta- ja humanistiset aineet', art: 'Taito- ja taideaineet' } });
  Object.assign(T.en, { pdfBtn: 'Export PDF', pdfTitle: 'Course choices', pdfDone: 'Completed', pdfSel: 'Selected', pdfMiss: 'Missing', pdfOthers: 'Other courses', pdfPlan: 'Course list and groups', pdfNotFound: 'not found', pdfYear: 'Year level', pdfSaved: 'PDF saved.', pdfCount: (a, b) => `Completed ${a} courses, selected ${b} courses`, pdfNeed: n => `compulsory missing ${n}`,
    catN: { ai: 'Mother tongue', a: 'A languages', b1: 'B1 language (Swedish)', b2: 'B2 languages', b3: 'B3 languages (started in upper secondary)', mat: 'Mathematics', sci: 'Natural sciences', soc: 'Social studies and humanities', art: 'Arts and physical education' } });
  Object.assign(T.sv, { pdfBtn: 'Exportera PDF', pdfTitle: 'Kursval', pdfDone: 'Avklarad', pdfSel: 'Vald', pdfMiss: 'Saknas', pdfOthers: 'Övriga kurser', pdfPlan: 'Kurslista och grupper', pdfNotFound: 'hittades inte', pdfYear: 'Årsnivå', pdfSaved: 'PDF sparad.', pdfCount: (a, b) => `Avklarat ${a} kurser, valt ${b} kurser`, pdfNeed: n => `obligatoriska saknas ${n}`,
    catN: { ai: 'Modersmål', a: 'A-språk', b1: 'B1-språk (svenska)', b2: 'B2-språk', b3: 'B3-språk (påbörjade i gymnasiet)', mat: 'Matematik', sci: 'Naturvetenskaper', soc: 'Samhälls- och humanistiska ämnen', art: 'Konst- och färdighetsämnen' } });
  Object.assign(H.fi, { pdf: 'Tallentaa suoritetut ja valitut kurssit sekä kurssilistan ryhmävalintoineen PDF-tiedostoksi.' });
  Object.assign(H.en, { pdf: 'Saves the completed and selected courses and the course list with its group choices as a PDF file.' });
  Object.assign(H.sv, { pdf: 'Sparar avklarade och valda kurser samt kurslistan med gruppval som en PDF-fil.' });
  Object.assign(T.fi, { tabExp: 'Vienti', expHead: 'Vie tiedot', expImp: 'Tuo takaisin', csvBtn: 'Vie CSV (Excel)', copyBtn: 'Kopioi kurssilista', pdfPage: 'Sivu',
    expPdfD: 'Selkeä, värillinen yhteenveto: suoritetut ja valitut kurssit oppiaineittain sekä kurssilista ryhmineen.', expCsvD: 'Kaikki kurssit ja niiden tila taulukkona, jonka voi avata Excelissä.', expTxtD: 'Kurssilista ja ryhmävalinnat tekstitiedostona. Voi ladata takaisin.', expCfgD: 'Kaikki asetukset ja tila varmuuskopioksi (.json).', expCopyD: 'Kurssikoodit leikepöydälle.', expDbgD: 'Raportti ongelmatilanteisiin (ei salasanoja).', expLoadD: 'Lataa aiemmin tallennettu tekstitiedosto.', expLoadCfgD: '', expCfgLoadD: 'Palauta asetukset ja tila .json-tiedostosta.',
    csvSaved: 'CSV tallennettu.', copied2: 'Kurssilista kopioitu.', copyNone: 'Kurssilista on tyhjä.', copyFail: 'Kopiointi ei onnistunut.', csvHead: ['Koodi', 'Oppiaine', 'Tyyppi', 'Tila', 'Vuositaso', 'Pakollisuus'], csvIgn: 'Ohitettu', csvOpen: 'Tarjolla', csvMan: 'Pakollinen', csvOpt: 'Valinnainen' });
  Object.assign(T.en, { tabExp: 'Export', expHead: 'Export data', expImp: 'Import', csvBtn: 'Export CSV (Excel)', copyBtn: 'Copy course list', pdfPage: 'Page',
    expPdfD: 'A clear, coloured summary: completed and selected courses by subject and the course list with groups.', expCsvD: 'All courses and their status as a table you can open in Excel.', expTxtD: 'The course list and group choices as a text file. Can be loaded back.', expCfgD: 'All settings and state as a backup (.json).', expCopyD: 'The course codes to the clipboard.', expDbgD: 'A report for problems (no passwords).', expLoadD: 'Load a text file saved earlier.', expLoadCfgD: '', expCfgLoadD: 'Restore settings and state from a .json file.',
    csvSaved: 'CSV saved.', copied2: 'Course list copied.', copyNone: 'The course list is empty.', copyFail: 'Copying failed.', csvHead: ['Code', 'Subject', 'Type', 'Status', 'Year level', 'Compulsory'], csvIgn: 'Ignored', csvOpen: 'Offered', csvMan: 'Compulsory', csvOpt: 'Elective' });
  Object.assign(T.sv, { tabExp: 'Export', expHead: 'Exportera data', expImp: 'Importera', csvBtn: 'Exportera CSV (Excel)', copyBtn: 'Kopiera kurslistan', pdfPage: 'Sida',
    expPdfD: 'En tydlig, färgad sammanfattning: avklarade och valda kurser per ämne samt kurslistan med grupper.', expCsvD: 'Alla kurser och deras status som en tabell som kan öppnas i Excel.', expTxtD: 'Kurslistan och gruppvalen som textfil. Kan läsas in igen.', expCfgD: 'Alla inställningar och allt tillstånd som säkerhetskopia (.json).', expCopyD: 'Kurskoderna till urklipp.', expDbgD: 'En rapport för problem (inga lösenord).', expLoadD: 'Läs in en tidigare sparad textfil.', expLoadCfgD: '', expCfgLoadD: 'Återställ inställningar och tillstånd från en .json-fil.',
    csvSaved: 'CSV sparad.', copied2: 'Kurslistan kopierad.', copyNone: 'Kurslistan är tom.', copyFail: 'Kopieringen lyckades inte.', csvHead: ['Kod', 'Ämne', 'Typ', 'Status', 'Årsnivå', 'Obligatorisk'], csvIgn: 'Ignorerad', csvOpen: 'Erbjuds', csvMan: 'Obligatorisk', csvOpt: 'Valfri' });
  Object.assign(T.fi, { loopStop: 'Pysäytä silmukka (kaikki välilehdet)', lkeep: 'Jatka onnistumisen jälkeenkin, kunnes pysäytän', loopWatch: n => `Kaikki ${n} kurssia valittu. Seurataan edelleen, kunnes pysäytät silmukan…` });
  Object.assign(T.en, { loopStop: 'Stop the loop (all tabs)', lkeep: 'Keep going after success, until I stop it', loopWatch: n => `All ${n} courses selected. Still watching until you stop the loop…` });
  Object.assign(T.sv, { loopStop: 'Stoppa slingan (alla flikar)', lkeep: 'Fortsätt efter lyckat val tills jag stoppar', loopWatch: n => `Alla ${n} kurser valda. Fortsätter bevaka tills du stoppar slingan…` });
  Object.assign(H.fi, { lkeep: 'Päällä: silmukka ei lopu, kun kaikki on valittu, vaan välilehdet jatkavat päivittämistä ja tarkistavat, että valinnat pysyvät, ja valitsevat uudelleen jos jokin katoaa. Pysäytät sen napista tai Peruuta-napista.' });
  Object.assign(H.en, { lkeep: 'On: the loop does not end when everything is selected. The tabs keep refreshing, check that the picks stay, and pick again if something disappears. You stop it with the button or Cancel.' });
  Object.assign(H.sv, { lkeep: 'På: slingan tar inte slut när allt är valt. Flikarna fortsätter uppdatera, kontrollerar att valen består och väljer igen om något försvinner. Du stoppar den med knappen eller Avbryt.' });
  Object.assign(H.fi, {
    loop: 'Yrittää valita kurssit uudestaan ja uudestaan, kunnes kaikki listan kurssit on valittu tai painat Peruuta.',
    ltabs: 'Montako Wilma-välilehteä ajetaan yhtä aikaa (1–10). Useampi yrittää tiheämmin, mutta ei lisää paikkoja.',
    ldelay: 'Odotus kierrosten välillä sekunteina. Liian pieni arvo voi johtaa estoon.',
    lmax: 'Yritys loppuu itsestään tämän ajan jälkeen.' });
  Object.assign(H.en, {
    loop: 'Tries to pick the courses again and again until every course in the list is selected or you press Cancel.',
    ltabs: 'How many Wilma tabs run at once (1–10). More tabs try more often but do not add places.',
    ldelay: 'Seconds to wait between rounds. A value that is too small may get you blocked.',
    lmax: 'The attempt stops by itself after this time.' });
  Object.assign(H.sv, {
    loop: 'Försöker välja kurserna om och om igen tills alla kurser i listan är valda eller du trycker Avbryt.',
    ltabs: 'Hur många Wilma-flikar som körs samtidigt (1–10). Fler flikar försöker oftare men ger inga fler platser.',
    ldelay: 'Sekunder att vänta mellan rundorna. Ett för litet värde kan leda till spärr.',
    lmax: 'Försöket stoppar sig självt efter denna tid.' });
  Object.assign(D.fi, { lsOn: 'Silmukka käynnissä', lsFetch: n => `kevyt, ${n} virtuaalivälilehteä`, lsReload: 'sivun päivitys', lsRound: 'kierros', lsLeft: 'aikaa jäljellä', lsOff: 'Silmukka pysäytetty', conCopy: 'Kopioi',
    why: { done: 'kaikki valittu', stop: 'pysäytetty', cancel: 'peruttu', rate: 'Wilma rajoitti pyyntöjä (429)', login: 'kirjautuminen vanhentui', nothing: 'lista on tyhjä', none: 'kursseja ei löytynyt', key: 'lomaketunnusta ei löytynyt' }, con: 'Konsoli: pyynnöt Wilmalle', conClear: 'Tyhjennä', conPause: 'Tauko', conResume: 'Jatka', conPost: 'vain valintapyynnöt (POST)', conEmpty: 'Ei vielä pyyntöjä. Ne näkyvät tässä heti, kun skripti hakee tai lähettää jotain Wilmalle (myös muista välilehdistä).', dev: 'Kehittäjäasetukset (epävakaat)', devWarn: '⚠ VAROITUS: Alle 0,3 sekunnin päivitysväli kuormittaa Wilmaa kovasti. Wilma voi rajoittaa pyyntöjäsi tai estää IP-osoitteesi (jolloin myös muut samassa verkossa voivat jäädä ulos), ja tunnuksesi voidaan lukita. Käytät tätä täysin omalla vastuullasi. Silmukka pysähtyy itse, jos Wilma vastaa 429.',
    devUnlock: 'Ymmärrän riskin: avaa 5–200 ms:n arvot', devDelay: 'Odotus yhtä virtuaalivälilehteä kohti (s)', devMode: 'Silmukan tapa', devReload: 'Päivitä sivu joka kierroksella (perinteinen)', devFetch: 'Kevyt: ei sivun päivityksiä, virtuaalivälilehdet vuorotellen',
    devWorkers: 'Virtuaalivälilehtiä (1–6)', devLite: 'Kevyt käyttöliittymä (ei animaatioita, harvempi piirto)', devNow: 'Nopeus nyt',
    legend: 'Värien selitykset', legBar: 'Palkit: vihreä = suoritettu, sininen = valittu (osuus pakollisista tai 150 op:sta).',
    legRows: [['done', 'Suoritettu'], ['sel', 'Valittu, ei vielä suoritettu'], ['', 'Ei suoritettu eikä valittu'], ['todo', 'Uusien kurssien tilassa: pakollinen, ei vielä valittu'], ['todo inl', 'Keltainen täytettynä: lisätty valintalistaan'], ['blue', 'Uusien kurssien tilassa: suoritettu tai valittu'], ['kvm', 'Violetti reuna: pakollinen kurssi (LOPS)'], ['kvv', 'Pinkki reuna: valinnainen kurssi'], ['man', 'Pisteviivareunus: merkitty suoritetuksi käsin'], ['ign', 'Musta ja yliviivattu: ohitettu, ei lasketa'], ['hp', 'Tähti: kurssi on HOPSissa']],
    progReq: (a, b, p) => `Pakolliset kurssit suoritettu tai valittu: ${a} / ${b} (${p} %)` });
  Object.assign(D.en, { lsOn: 'Loop running', lsFetch: n => `light, ${n} virtual tabs`, lsReload: 'page refresh', lsRound: 'round', lsLeft: 'time left', lsOff: 'Loop stopped', conCopy: 'Copy',
    why: { done: 'everything selected', stop: 'stopped', cancel: 'cancelled', rate: 'Wilma rate-limited (429)', login: 'login expired', nothing: 'list is empty', none: 'no courses found', key: 'form key not found' }, con: 'Console: requests to Wilma', conClear: 'Clear', conPause: 'Pause', conResume: 'Resume', conPost: 'only pick requests (POST)', conEmpty: 'No requests yet. They show up here as soon as the script fetches or sends anything to Wilma (also from other tabs).', dev: 'Developer options (unstable)', devWarn: '⚠ WARNING: A refresh interval below 0.3 seconds puts heavy load on Wilma. Wilma may rate-limit you or block your IP address (which can also lock out others on the same network), and your account can be locked. You use this entirely at your own risk. The loop stops by itself if Wilma answers 429.',
    devUnlock: 'I understand the risk: unlock 5–200 ms values', devDelay: 'Wait per virtual tab (s)', devMode: 'Loop style', devReload: 'Refresh the page every round (classic)', devFetch: 'Light: no page refreshes, virtual tabs take turns',
    devWorkers: 'Virtual tabs (1–6)', devLite: 'Light interface (no animations, fewer redraws)', devNow: 'Speed now',
    legend: 'Colour guide', legBar: 'Bars: green = completed, blue = selected (share of compulsory courses or of 150 op).',
    legRows: [['done', 'Completed'], ['sel', 'Selected, not completed yet'], ['', 'Not completed and not selected'], ['todo', 'New-courses mode: compulsory, not selected yet'], ['todo inl', 'Filled yellow: added to the pick list'], ['blue', 'New-courses mode: completed or selected'], ['kvm', 'Purple edge: compulsory course (LOPS)'], ['kvv', 'Pink edge: elective course'], ['man', 'Dotted outline: marked completed by hand'], ['ign', 'Black and struck through: ignored, not counted'], ['hp', 'Star: the course is in HOPS']],
    progReq: (a, b, p) => `Compulsory courses completed or selected: ${a} / ${b} (${p}%)` });
  Object.assign(D.sv, { lsOn: 'Slingan körs', lsFetch: n => `lätt, ${n} virtuella flikar`, lsReload: 'sidomladdning', lsRound: 'runda', lsLeft: 'tid kvar', lsOff: 'Slingan stoppad', conCopy: 'Kopiera',
    why: { done: 'allt valt', stop: 'stoppad', cancel: 'avbruten', rate: 'Wilma begränsade (429)', login: 'inloggningen gick ut', nothing: 'listan är tom', none: 'inga kurser hittades', key: 'formulärnyckel saknas' }, con: 'Konsol: förfrågningar till Wilma', conClear: 'Rensa', conPause: 'Paus', conResume: 'Fortsätt', conPost: 'bara valförfrågningar (POST)', conEmpty: 'Inga förfrågningar än. De visas här så fort skriptet hämtar eller skickar något till Wilma (även från andra flikar).', dev: 'Utvecklaralternativ (instabila)', devWarn: '⚠ VARNING: Ett uppdateringsintervall under 0,3 sekunder belastar Wilma hårt. Wilma kan begränsa dig eller blockera din IP-adress (vilket kan stänga ute andra i samma nätverk), och ditt konto kan låsas. Du använder detta helt på egen risk. Slingan stoppar sig själv om Wilma svarar 429.',
    devUnlock: 'Jag förstår risken: lås upp 5–200 ms', devDelay: 'Väntan per virtuell flik (s)', devMode: 'Slingans sätt', devReload: 'Uppdatera sidan varje runda (klassiskt)', devFetch: 'Lätt: inga sidomladdningar, virtuella flikar turas om',
    devWorkers: 'Virtuella flikar (1–6)', devLite: 'Lätt gränssnitt (inga animationer, färre omritningar)', devNow: 'Hastighet nu',
    legend: 'Färgförklaring', legBar: 'Staplar: grön = avklarad, blå = vald (andel av obligatoriska eller av 150 sp).',
    legRows: [['done', 'Avklarad'], ['sel', 'Vald, inte avklarad än'], ['', 'Inte avklarad och inte vald'], ['todo', 'Nya kurser-läge: obligatorisk, inte vald än'], ['todo inl', 'Fylld gul: tillagd i vallistan'], ['blue', 'Nya kurser-läge: avklarad eller vald'], ['kvm', 'Lila kant: obligatorisk kurs (LOPS)'], ['kvv', 'Rosa kant: valfri kurs'], ['man', 'Prickad kant: markerad avklarad för hand'], ['ign', 'Svart och överstruken: ignorerad, räknas inte'], ['hp', 'Stjärna: kursen finns i HOPS']],
    progReq: (a, b, p) => `Obligatoriska kurser avklarade eller valda: ${a} / ${b} (${p} %)` });
  Object.assign(T.fi, { login: '\u26D4 Kirjautuminen Wilmaan on vanhentunut. Kirjaudu uudelleen ja käynnistä silmukka.', rzTip: 'Vedä kulmasta muuttaaksesi kokoa, kaksoisklikkaa palauttaaksesi', loopRetry: 'Tietoja ei saatu haettua, yritetään uudelleen\u2026', helpTip: 'Näytä tai piilota ohjeet (?)', prog: (s, n, p) => `Valittu ${s} / ${n} kurssia (${p} %)`, progNone: 'Ei kurssilistaa', fetchTurn: (w, N, r, p, n, s, b) => `Virtuaalivälilehti ${w}/${N} (vuoro ${r}): ${p}/${n} kurssia vielä valitsematta, ${s} pyyntöä${b ? ', ' + b + ' virhettä' : ''}.`,
    rate: '⛔ Wilma rajoitti pyyntöjä (429). Silmukka pysäytettiin suojaksi. Odota hetki ja kasvata odotusaikaa.', lite: 'Kevyt tila', liteTip: 'Kevyt tila päälle/pois: ei animaatioita, harvempi piirto' });
  Object.assign(T.en, { login: '\u26D4 Your Wilma login has expired. Sign in again and restart the loop.', rzTip: 'Drag the corner to resize, double-click to reset', loopRetry: 'Could not fetch the data, trying again\u2026', helpTip: 'Show or hide the help (?) buttons', prog: (s, n, p) => `Selected ${s} / ${n} courses (${p}%)`, progNone: 'No course list', fetchTurn: (w, N, r, p, n, s, b) => `Virtual tab ${w}/${N} (turn ${r}): ${p}/${n} courses still not selected, ${s} requests${b ? ', ' + b + ' failed' : ''}.`,
    rate: '⛔ Wilma is limiting requests (429). The loop was stopped as a precaution. Wait a moment and increase the delay.', lite: 'Light mode', liteTip: 'Light mode on/off: no animations, fewer redraws' });
  Object.assign(T.sv, { login: '\u26D4 Din Wilma-inloggning har gått ut. Logga in igen och starta slingan på nytt.', rzTip: 'Dra i hörnet för att ändra storlek, dubbelklicka för att återställa', loopRetry: 'Kunde inte hämta data, försöker igen\u2026', helpTip: 'Visa eller dölj hjälpen (?)', prog: (s, n, p) => `Valda ${s} / ${n} kurser (${p} %)`, progNone: 'Ingen kurslista', fetchTurn: (w, N, r, p, n, s, b) => `Virtuell flik ${w}/${N} (tur ${r}): ${p}/${n} kurser ännu inte valda, ${s} förfrågningar${b ? ', ' + b + ' fel' : ''}.`,
    rate: '⛔ Wilma begränsar förfrågningar (429). Slingan stoppades som skydd. Vänta en stund och öka väntetiden.', lite: 'Lätt läge', liteTip: 'Lätt läge på/av: inga animationer, färre omritningar' });
  Object.assign(H.fi, { con: 'Näyttää jokaisen pyynnön, jonka skripti lähettää Wilmalle: kellonaika, kuka lähetti (\u25CF = tämä välilehti, \u25CB = toinen), GET = tietojen haku, POST = kurssin valintapyyntö, tilakoodi ja kesto. Vihreä = valintapyyntö, punainen = virhe (esim. HTTP 4xx/5xx tai Wilman srvError). Näet myös muiden välilehtien pyynnöt, kun tämä sivu on auki.', lite: 'Kevyt tila: poistaa animaatiot ja varjot ja piirtää näkymän harvemmin. Auta, jos selain tai tietokone laahaa. Täysin pois päältä laajennuksen saa kuvakkeen valikosta (Pois päältä).',
    devunlock: 'Ilman tätä rastia odotusaika on vähintään 0,3 s. Rastilla alarajaksi tulee 0,005 s (5 ms). Se voi johtaa estoon Wilmassa.', devdelay: 'Odotus yhtä virtuaalivälilehteä kohti. Kun virtuaalivälilehtiä on N, uusi yritys lähtee noin joka (odotus / N) sekunti.',
    devmode: 'Perinteinen päivittää koko Wilma-sivun joka kierroksella (raskas). Kevyt hakee vain tarvittavat tiedot ja lähettää valinnat ilman sivun uudelleenlatausta, joten se kuluttaa selaimessa paljon vähemmän.',
    devworkers: 'Virtuaalivälilehti = yksi vuorollaan toimiva "työläinen" samassa välilehdessä. Oikeaa headless-välilehteä selainlaajennus ei voi avata, tämä on lähin ja kevein vastine.', devlite: 'Sama kuin otsikon ⚡-nappi.',
    legend: 'Selitys kaikille dashboardin väreille ja merkeille.' });
  Object.assign(H.en, { con: 'Shows every request the script sends to Wilma: time, who sent it (\u25CF = this tab, \u25CB = another tab), GET = fetching data, POST = a course pick request, status code and duration. Green = pick request, red = error (e.g. HTTP 4xx/5xx or a Wilma srvError). Requests from other tabs show up here too while this page is open.', lite: 'Light mode: removes animations and shadows and redraws less often. Helps if the browser or computer is lagging. To switch the extension off completely use the toolbar icon menu (Off).',
    devunlock: 'Without this tick the wait is at least 0.3 s. With it the minimum becomes 0.005 s (5 ms). It can get you blocked by Wilma.', devdelay: 'Wait per virtual tab. With N virtual tabs a new attempt goes out about every (wait / N) seconds.',
    devmode: 'Classic reloads the whole Wilma page every round (heavy). Light fetches only what is needed and sends the picks without reloading the page, so it uses far less of the browser.',
    devworkers: 'A virtual tab is one "worker" taking its turn inside the same tab. A browser extension cannot open a real headless tab; this is the closest and lightest equivalent.', devlite: 'Same as the ⚡ button in the header.',
    legend: 'Explains every colour and mark on the dashboard.' });
  Object.assign(H.sv, { con: 'Visar varje förfrågan skriptet skickar till Wilma: tid, vem som skickade (\u25CF = denna flik, \u25CB = annan flik), GET = hämtning, POST = valförfrågan, statuskod och tid. Grön = valförfrågan, röd = fel (t.ex. HTTP 4xx/5xx eller Wilmas srvError). Förfrågningar från andra flikar visas också medan sidan är öppen.', lite: 'Lätt läge: tar bort animationer och skuggor och ritar om mer sällan. Hjälper om webbläsaren eller datorn laggar. För att stänga av tillägget helt, använd ikonens meny (Av).',
    devunlock: 'Utan denna ruta är väntan minst 0,3 s. Med den blir minimum 0,005 s (5 ms). Det kan ge spärr hos Wilma.', devdelay: 'Väntan per virtuell flik. Med N virtuella flikar går ett nytt försök ut ungefär varje (väntan / N) sekund.',
    devmode: 'Klassiskt laddar om hela Wilma-sidan varje runda (tungt). Lätt hämtar bara det som behövs och skickar valen utan omladdning, så det belastar webbläsaren mycket mindre.',
    devworkers: 'En virtuell flik är en "arbetare" som turas om i samma flik. Ett webbläsartillägg kan inte öppna en riktig headless-flik; detta är det närmaste och lättaste alternativet.', devlite: 'Samma som ⚡-knappen i huvudet.',
    legend: 'Förklarar alla färger och märken på dashboarden.' });
  Object.assign(D.fi, { aTitle: 'Automaattinen ryhmien kokoaja', aHelp: 'Valitse oma lukiosi ja kurssit, jotka haluat suorittaa. Skripti hakee kaikki ryhmät, välttää päällekkäiset palkit (sama aika) ja kokoaa parhaan järjestyksen. Voit ottaa kursseja myös muista lukioista: ne valitaan ensin (käsin tai lukittuna), loput kootaan automaattisesti.',
    aHome: 'Oma lukio ja lukuvuosi', aOthers: 'Muut lukiot, joista saa ottaa kursseja', aWant: 'Kurssit oman lukion tarjottimelta (koodi tai alku)', aFill: 'Lisää keltaiset + valintalista', aOther: 'Kurssit muista lukioista (valitaan ensin)',
    aMax: 'Enintään kursseja / jakso (0 = ei rajaa)', aLock: 'Pidä muiden lukioiden jo valitut ryhmät lukittuina (manuaalinen valinta ensin)', aBuild: 'Kokoa paras järjestys', aApply: 'Käytä valinnassa',
    aNoHome: 'Valitse oma lukio ja lukuvuosi.', aNoCourses: 'Lisää ainakin yksi kurssi.', aScanning: 'Haetaan ryhmiä…', aDone: (p, t) => `Valmis: ${p}/${t} kurssia sijoitettu. Tarkista tulos ja paina "Käytä valinnassa".`,
    aNoGroup: 'ei avointa ryhmää valituissa lukioissa (tai jo suoritettu)', aConflict: 'jokainen ryhmä on päällekkäin muiden valintojen kanssa', aColCourse: 'Kurssi', aColGroup: 'Ryhmä', aColPeriod: 'Jakso', aColTeacher: 'Opettaja', aFixed: 'lukittu', aFull: 'täynnä', aByPeriod: 'Kursseja jaksoittain', aApplied: n => `Siirretty valintaan: ${n} kurssia.` });
  Object.assign(D.en, { aTitle: 'Automatic group builder', aHelp: 'Pick your school and the courses you want to take. The script fetches every group, avoids overlapping bars (same time slot) and builds the best arrangement. You can take courses from other schools too: those are chosen first (by hand or locked), the rest is built automatically.',
    aHome: 'Home school and year', aOthers: 'Other schools you may take courses from', aWant: 'Courses from your school’s tray (code or start)', aFill: 'Add yellow + selection list', aOther: 'Courses from other schools (chosen first)',
    aMax: 'Max courses / period (0 = no limit)', aLock: 'Keep already chosen groups of other schools locked (manual choice first)', aBuild: 'Build best arrangement', aApply: 'Use in selection',
    aNoHome: 'Choose your school and year.', aNoCourses: 'Add at least one course.', aScanning: 'Fetching groups…', aDone: (p, t) => `Done: ${p}/${t} courses placed. Check the result and press "Use in selection".`,
    aNoGroup: 'no open group in the chosen schools (or already completed)', aConflict: 'every group overlaps with other choices', aColCourse: 'Course', aColGroup: 'Group', aColPeriod: 'Period', aColTeacher: 'Teacher', aFixed: 'locked', aFull: 'full', aByPeriod: 'Courses per period', aApplied: n => `Moved to selection: ${n} courses.` });
  Object.assign(D.sv, { aTitle: 'Automatisk gruppbyggare', aHelp: 'Välj din skola och de kurser du vill läsa. Skriptet hämtar alla grupper, undviker överlappande block (samma tid) och bygger det bästa upplägget. Du kan ta kurser från andra skolor också: de väljs först (för hand eller låsta), resten byggs automatiskt.',
    aHome: 'Egen skola och läsår', aOthers: 'Andra skolor du får ta kurser från', aWant: 'Kurser från din skolas tablå (kod eller början)', aFill: 'Lägg till gula + vallistan', aOther: 'Kurser från andra skolor (väljs först)',
    aMax: 'Högst kurser / period (0 = ingen gräns)', aLock: 'Håll redan valda grupper från andra skolor låsta (manuellt val först)', aBuild: 'Bygg bästa upplägg', aApply: 'Använd i valet',
    aNoHome: 'Välj din skola och ditt läsår.', aNoCourses: 'Lägg till minst en kurs.', aScanning: 'Hämtar grupper…', aDone: (p, t) => `Klart: ${p}/${t} kurser placerade. Kontrollera och tryck "Använd i valet".`,
    aNoGroup: 'ingen öppen grupp i de valda skolorna (eller redan avklarad)', aConflict: 'varje grupp överlappar med andra val', aColCourse: 'Kurs', aColGroup: 'Grupp', aColPeriod: 'Period', aColTeacher: 'Lärare', aFixed: 'låst', aFull: 'full', aByPeriod: 'Kurser per period', aApplied: n => `Flyttat till valet: ${n} kurser.` });
  Object.assign(H.fi, { ahome: 'Lukio ja lukuvuosi, jossa opiskelet. Sen jaksot haetaan ja kurssit kootaan sen tarjottimelta.', aothers: 'Valitse lukiot, joiden tarjottimelta voit ottaa yksittäisiä kursseja. Niiden jaksot haetaan mukaan.', awant: 'Kurssit, jotka haluat suorittaa oman lukiosi tarjottimelta. Koodi (MAA05) tai alku (MAA). Tyhjänä käytetään valintalistaa.',
    aother: 'Kurssit, jotka haluat ottaa muista lukioista. Ne sijoitetaan ensin, ja loput kootaan niiden ympärille. Voit valita ryhmän käsin Valinta-näkymässä ja lukita sen.', amax: 'Kuinka monta kurssia saa sijoittaa samaan jaksoon. 0 = ei rajaa. Pienempi arvo tasaa kuormaa.',
    abuild: 'Hakee kaikki ryhmät ja kokoaa järjestyksen: yksi ryhmä per kurssi, ei kahta ryhmää samassa palkissa (sama aika), vältetään täynnä olevia ryhmiä ja tasataan kuorma jaksojen kesken. Wilma tarkistaa päällekkäisyydet itse, tämä perustuu ryhmien palkkitunnisteisiin.', aapply: 'Siirtää kootun järjestyksen valintaan: kurssilista ja ryhmävalinnat. Sen jälkeen voit painaa Valitse tai Yritä kunnes.', cfgsave: 'Tallentaa kaikki asetukset (lista, jaksot, pakolliset kurssit, merkinnät, kieli, silmukan asetukset jne.) yhteen tiedostoon.', cfgload: 'Lataa aiemmin tallennetun asetustiedoston ja palauttaa kaikki asetukset.' });
  Object.assign(H.en, { ahome: 'The school and year you study in. Its periods are fetched and the courses are built from its tray.', aothers: 'Choose schools whose tray you may take single courses from. Their periods are included.', awant: 'Courses you want from your own school’s tray. Code (MAA05) or start (MAA). If empty the selection list is used.',
    aother: 'Courses you want from other schools. They are placed first and the rest is built around them. You can pick the group by hand in the Selection view and lock it.', amax: 'How many courses may be placed in the same period. 0 = no limit. A lower value evens out the load.',
    abuild: 'Fetches every group and builds the arrangement: one group per course, never two groups in the same bar (same time), avoiding full groups and balancing the load across periods. Wilma checks overlaps itself; this is based on the groups’ bar ids.', aapply: 'Moves the arrangement into the selection: the course list and group choices. Then you can press Pick or Retry until.', cfgsave: 'Saves all settings (list, periods, compulsory courses, marks, language, loop settings etc.) into one file.', cfgload: 'Loads a previously saved settings file and restores every setting.' });
  Object.assign(H.sv, { ahome: 'Skolan och läsåret du studerar i. Dess perioder hämtas och kurserna byggs från dess tablå.', aothers: 'Välj skolor du får ta enstaka kurser från. Deras perioder tas med.', awant: 'Kurser du vill ta från din egen skolas tablå. Kod (MAA05) eller början (MAA). Tomt = vallistan används.',
    aother: 'Kurser du vill ta från andra skolor. De placeras först och resten byggs runt dem. Du kan välja grupp för hand i Val-vyn och låsa den.', amax: 'Hur många kurser som får placeras i samma period. 0 = ingen gräns. Ett lägre värde jämnar ut belastningen.',
    abuild: 'Hämtar alla grupper och bygger upplägget: en grupp per kurs, aldrig två grupper i samma block (samma tid), undviker fulla grupper och jämnar ut belastningen mellan perioder. Wilma kontrollerar överlapp själv; detta bygger på gruppernas block-id.', aapply: 'Flyttar upplägget till valet: kurslistan och gruppvalen. Sedan kan du trycka Välj eller Försök tills.', cfgsave: 'Sparar alla inställningar (lista, perioder, obligatoriska kurser, markeringar, språk, slingans inställningar osv.) i en fil.', cfgload: 'Laddar en tidigare sparad inställningsfil och återställer alla inställningar.' });
  Object.assign(T.fi, { cfgsave: 'Kaikki asetukset', cfgload: 'Lataa asetukset', cfgSaved: 'Kaikki asetukset tallennettu tiedostoon.', cfgLoaded: 'Asetukset ladattu.' });
  Object.assign(T.en, { cfgsave: 'All settings', cfgload: 'Load settings', cfgSaved: 'All settings saved to a file.', cfgLoaded: 'Settings loaded.' });
  Object.assign(T.sv, { cfgsave: 'Alla inställningar', cfgload: 'Ladda inställningar', cfgSaved: 'Alla inställningar sparade i en fil.', cfgLoaded: 'Inställningar laddade.' });
  Object.assign(D.fi, { devHybrid: 'Hybridi: 2 lisävälilehteä, kussakin 3 virtuaalivalitsijaa, päivitys kierroksen jälkeen', lsHybrid: 'hybridi (3 + 3 + 3 valitsijaa, päivitys kierroksen jälkeen)', hybridRefresh: 'Hybridi: kierros valmis, päivitetään tämä välilehti.' });
  Object.assign(D.en, { devHybrid: 'Hybrid: 2 extra tabs, each with 3 virtual handlers, refresh after each round', lsHybrid: 'hybrid (3 + 3 + 3 handlers, refresh after each round)', hybridRefresh: 'Hybrid: round done, refreshing this tab.' });
  Object.assign(D.sv, { devHybrid: 'Hybrid: 2 extra flikar, var och en med 3 virtuella hanterare, uppdatering efter varje runda', lsHybrid: 'hybrid (3 + 3 + 3 hanterare, uppdatering efter varje runda)', hybridRefresh: 'Hybrid: runda klar, uppdaterar denna flik.' });
  Object.assign(H.fi, { devmode: H.fi.devmode + ' Hybridi: tämä ja 2 lisävälilehteä tekevät kukin 3 virtuaalipyyntöä kierroksessa, sen jälkeen välilehti päivittää itsensä ja sykli toistuu. Ainoa tila, jossa lisävälilehdet avataan kevyessä tilassa. Kojelautatabi jatkaa kierroksia mutta ei koskaan päivity.' });
  Object.assign(H.en, { devmode: H.en.devmode + ' Hybrid: this tab and 2 extra tabs each make 3 virtual requests per round, then the tab refreshes itself and the cycle repeats. The only light mode that opens extra tabs. The dashboard tab keeps going but never refreshes.' });
  Object.assign(H.sv, { devmode: H.sv.devmode + ' Hybrid: denna flik och 2 extra flikar gör var och en 3 virtuella förfrågningar per runda, sedan uppdaterar fliken sig själv och cykeln upprepas. Instrumentpanelens flik fortsätter men uppdateras aldrig.' });
  Object.assign(D.fi, { devGap: 'Väli käsittelijöiden välillä (ms, 0 = automaattinen)' });
  Object.assign(H.fi, { devgap: 'Suora aikaväli pyyntöjen välille. 0 = lasketaan viiveestä. Esim. 6000 tarkoittaa 6 sekuntia, 300 = 0,3 s. Alle 5 ms ei ole mahdollista.' });
  Object.assign(D.en, { devGap: 'Gap between handlers (ms, 0 = automatic)' });
  Object.assign(H.en, { devgap: 'Direct time gap between requests. 0 = computed from the delay. E.g. 6000 is 6 seconds, 300 is 0.3 s. Below 5 ms is not possible.' });
  Object.assign(D.sv, { devGap: 'Avstånd mellan hanterare (ms, 0 = automatiskt)' });
  Object.assign(H.sv, { devgap: 'Direkt tidsavstånd mellan förfrågningar. 0 = beräknas från väntetiden. T.ex. 6000 är 6 sekunder, 300 är 0,3 s. Under 5 ms går inte.' });
  Object.assign(T.fi, { lwin: 'Lisävälilehdet erilliseen ikkunaan (tämä sivu ei päivity)' });
  Object.assign(T.en, { lwin: 'Loop tabs in their own window (this page does not refresh)' });
  Object.assign(T.sv, { lwin: 'Loop-flikar i eget fönster (denna sida uppdateras inte)' });
  Object.assign(H.fi, { lwin: 'Päällä: kaikki silmukan välilehdet (hybridissä kolme) avautuvat omaan ikkunaansa ja kierrokset ajetaan siellä. Tämä sivu, jolla konsoli on, vain käynnistää ja seuraa silmukkaa eikä koskaan päivity. Pois: vanha tapa, jossa tämä sivu on yksi kierroksen välilehdistä.' });
  Object.assign(H.en, { lwin: 'On: all loop tabs (three in hybrid) open in their own window and the rounds run there. This page, with the console, only starts and watches the loop and never refreshes. Off: the old way, where this page is one of the round tabs.' });
  Object.assign(H.sv, { lwin: 'På: alla loop-flikar (tre i hybrid) öppnas i ett eget fönster och rundorna körs där. Denna sida med konsolen startar och följer bara loopen och uppdateras aldrig. Av: det gamla sättet, där denna sida är en av rundflikarna.' });
  Object.assign(D.fi, { hidden: 'Piilotetut aineet', hidNone: 'ei piilotettuja', unhide: 'Palauta valittu', unhideAll: 'Palauta kaikki' });
  Object.assign(D.en, { hidden: 'Hidden subjects', hidNone: 'none hidden', unhide: 'Restore selected', unhideAll: 'Restore all' });
  Object.assign(D.sv, { hidden: 'Dolda ämnen', hidNone: 'inga dolda', unhide: 'Återställ valt', unhideAll: 'Återställ alla' });
  Object.assign(H.fi, { dhidden: 'Kun painat oppiaineen ✕-nappia, aine piilotetaan eikä poisteta. Tästä valikosta näet piilotetut aineet. Valitse aine ja paina "Palauta valittu", tai "Palauta kaikki" tuo kaikki takaisin entiselle paikalleen ja omine vaatimusmäärineen.' });
  Object.assign(H.en, { dhidden: 'The ✕ button on a subject hides it, it does not delete it. This menu lists the hidden subjects. Pick one and press "Restore selected", or "Restore all" brings every one back to its old place with its own required count.' });
  Object.assign(H.sv, { dhidden: 'Knappen ✕ på ett ämne döljer det, det tas inte bort. Den här menyn listar de dolda ämnena. Välj ett och tryck "Återställ valt", eller "Återställ alla" tar tillbaka alla på sin gamla plats med eget antal krävda kurser.' });
  Object.assign(T.fi, { tabLoop: 'Silmukka', tabCon: 'Konsoli', tabSet: 'Asetukset', tabDev: 'Kehittäjä' });
  Object.assign(T.en, { tabLoop: 'Loop', tabCon: 'Console', tabSet: 'Settings', tabDev: 'Developer' });
  Object.assign(T.sv, { tabLoop: 'Loop', tabCon: 'Konsol', tabSet: 'Inställningar', tabDev: 'Utvecklare' });
  Object.assign(T.fi, { authKeep: 'Pidä istunto auki (tarkistus 4 min välein)' });
  Object.assign(T.en, { authKeep: 'Keep the session alive (check every 4 min)' });
  Object.assign(T.sv, { authKeep: 'Håll sessionen igång (kontroll var 4:e min)' });
  Object.assign(T.fi, { authTitle: 'Tunnukset ja automaattinen kirjautuminen', authWarn: 'Tunnus ja salasana tallennetaan vain tähän selaimeen. Ne lähetetään vain Wilman omaan kirjautumislomakkeeseen. Ne eivät ole mukana asetustiedostossa. Vältä liian tiheitä yrityksiä.', authUser: 'Käyttäjätunnus', authPass: 'Salasana', authAuto: 'Kirjaudu automaattisesti uudelleen, kun istunto päättyy', authRemember: 'Muista tässä selaimessa (muuten vain tämä välilehti)', authClear: 'Poista tunnukset', authStatus: 'Tila',
    authWhere: (none, rem) => none ? 'ei tallennettu' : rem ? 'muistissa tässä selaimessa' : 'vain tässä välilehdessä', authAutoOn: on => on ? 'automaattinen kirjautuminen päällä' : 'automaattinen kirjautuminen pois' });
  Object.assign(T.en, { authTitle: 'Login and automatic sign-in', authWarn: 'The user name and password are kept only in this browser. They are sent only to Wilma\'s own sign-in form and are not part of the settings file. Avoid trying too often.', authUser: 'User name', authPass: 'Password', authAuto: 'Sign in again automatically when the session ends', authRemember: 'Remember in this browser (otherwise this tab only)', authClear: 'Clear credentials', authStatus: 'Status',
    authWhere: (none, rem) => none ? 'not saved' : rem ? 'remembered in this browser' : 'this tab only', authAutoOn: on => on ? 'automatic sign-in on' : 'automatic sign-in off' });
  Object.assign(T.sv, { authTitle: 'Inloggning och automatisk inloggning', authWarn: 'Användarnamn och lösenord sparas bara i den här webbläsaren. De skickas bara till Wilmas egna inloggningsformulär och ingår inte i inställningsfilen. Undvik för täta försök.', authUser: 'Användarnamn', authPass: 'Lösenord', authAuto: 'Logga in igen automatiskt när sessionen går ut', authRemember: 'Kom ihåg i den här webbläsaren (annars bara denna flik)', authClear: 'Ta bort uppgifter', authStatus: 'Status',
    authWhere: (none, rem) => none ? 'inte sparad' : rem ? 'sparad i den här webbläsaren' : 'bara i denna flik', authAutoOn: on => on ? 'automatisk inloggning på' : 'automatisk inloggning av' });
  Object.assign(H.fi, { authkeep: 'Wilma lopettaa passiivisen istunnon noin 20 minuutin jälkeen. Tämä lukee valintasivun 4 minuutin välein, jotta istunto pysyy auki. Jos istunto silti päättyy ja automaattinen kirjautuminen on päällä, kirjaudutaan uudelleen.' });
  Object.assign(H.en, { authkeep: 'Wilma ends an idle session after about 20 minutes. This reads the selection page every 4 minutes so the session stays open. If it still ends and automatic sign-in is on, it signs in again.' });
  Object.assign(H.sv, { authkeep: 'Wilma avslutar en inaktiv session efter cirka 20 minuter. Detta läser valsidan var 4:e minut så att sessionen hålls öppen. Om den ändå går ut och automatisk inloggning är på loggas man in igen.' });
  Object.assign(H.fi, { auth: 'Tunnus ja salasana tallennetaan vain tähän selaimeen. Oletuksena vain tähän välilehteen. Kun tämä on päällä ja Wilma vaatii uuden kirjautumisen, laajennus täyttää Wilman oman kirjautumislomakkeen ja lähettää sen. Kaksi epäonnistunutta yritystä peräkkäin pysäyttää automaattisen kirjautumisen 15 minuutiksi, ettei tili lukittuisi.', authauto: 'Päällä: silmukka ei pysähdy istunnon vanhetessa, vaan kirjautuu uudelleen. Pois: silmukka pysähtyy ja kertoo syyn.', authremember: 'Päällä: salasana säilyy selaimen muistissa myös uuden välilehden ja käynnistyksen jälkeen. Tallennettu salasana on luettavissa selaimen tallennuksesta, joten jaa tietokone vain luotettavien kanssa.' });
  Object.assign(H.en, { auth: 'The user name and password are kept only in this browser. By default only in this tab. When this is on and Wilma asks for a new sign-in, the extension fills Wilma\'s own sign-in form and sends it. Two failed attempts in a row stop the automatic sign-in for 15 minutes, so the account is not locked.', authauto: 'On: the loop does not stop when the session ends, it signs in again. Off: the loop stops and says why.', authremember: 'On: the password stays in the browser storage, also for new tabs and after a restart. A remembered password is readable from the browser storage, so only keep it on a computer you trust.' });
  Object.assign(H.sv, { auth: 'Användarnamn och lösenord sparas bara i den här webbläsaren. Som standard bara i denna flik. När detta är på och Wilma begär ny inloggning fyller tillägget i Wilmas egna inloggningsformulär och skickar det. Två misslyckade försök i rad stoppar automatisk inloggning i 15 minuter, så kontot inte låses.', authauto: 'På: slingan stannar inte när sessionen går ut, utan loggar in igen. Av: slingan stoppar och säger varför.', authremember: 'På: lösenordet finns kvar i webbläsarens lagring, även för nya flikar och efter omstart. Ett sparat lösenord går att läsa i webbläsarens lagring, så behåll det bara på en dator du litar på.' });
  const tipOf = k => (H[state.lang] || H.en)[k] || '';

  // ---------- pure helpers ----------
  const norm = s => String(s).normalize('NFC').trim().toLowerCase();

  // Split on whitespace, commas, semicolons and bullets. Codes such as ENA_7.2K or MAY01.1 stay intact.
  function parseCodes(text) {
    const seen = new Set(), out = [];
    for (let tok of String(text).split(/[\s,;|•]+/)) {
      tok = tok.replace(/^[("'\[]+|[)"'\].:]+$/g, ''); // strip wrapping punctuation, trailing "." or ":"
      if (!tok) continue;
      const k = norm(tok);
      if (!seen.has(k)) { seen.add(k); out.push(tok); }
    }
    return out;
  }

  // An exact code wins; then all groups of that course ("MAY01" -> MAY01.1, MAY01.2); then any code starting with the text.
  function matchCourse(token, index) {
    const t = norm(token), exact = [], course = [], prefix = [];
    for (const c of index) {
      const k = norm(c.code);
      if (k === t) exact.push(c);
      else if (!t.includes('.') && k.split('.')[0] === t) course.push(c);
      else if (k.startsWith(t)) prefix.push(c);
    }
    return exact.length ? exact : course.length ? course : prefix;
  }

  function parseTime(text, now = new Date()) {
    const m = /^\s*(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?\s*$/.exec(text || '');
    if (!m) return null;
    const [h, mi, s] = [+m[1], +m[2], +(m[3] || 0)];
    if (h > 23 || mi > 59 || s > 59) return null;
    const d = new Date(now); d.setHours(h, mi, s, 0);
    return d;
  }

  // ---------- talking to Wilma ----------
  const basePath = () => (/^\/![^/]+/.exec(location.pathname) || [''])[0];
  const url = p => location.origin + basePath() + '/' + p.replace(/^\//, '');
  const parseHtml = html => new DOMParser().parseFromString(html, 'text/html');

  // every request the script sends is logged (and shown in the dashboard's console, also from other tabs)
  let loginLost = false;
  const netBuf = []; let netTotal = 0, netPosts = 0, netBad = 0, netPaused = false, netOnlyPost = false, netTimer = 0, netBc = null;
  const tabId = () => { try { let id = sessionStorage.getItem('wilmaKurssit.tab'); if (!id) { id = Math.random().toString(36).slice(2); sessionStorage.setItem('wilmaKurssit.tab', id); } return id; } catch (_) { return 'x'; } };
  const shortUrl = u => String(u).replace(location.origin, '').replace(/\/![^/]+/, '');
  function netLog(m, u, status, t0, note) {
    const x = { t: Date.now(), id: tabId(), m, u: shortUrl(u), s: status, ms: Math.round(performance.now() - t0), n: note || '' };
    x.bad = status === 0 || status >= 400 || /^\u26A0/.test(x.n);
    pushNet(x, false);
    try { if (netBc) netBc.postMessage(x); } catch (_) { /* ignore */ }
  }
  // events: what the script decides (rounds, refreshes, stops, limits), shown in the same console as the requests
  function evLog(kind, text) {
    const x = { t: Date.now(), id: tabId(), m: 'EV', k: kind, u: shortUrl(location.href), s: '', ms: 0, n: text, bad: kind === 'LIMIT' || kind === 'LOGIN' };
    pushNet(x, false);
    try { if (netBc) netBc.postMessage(x); } catch (_) { /* ignore */ }
  }
  function refresh(why) { evLog('REFRESH', why); location.reload(); }
  function pushNet(x, remote) {
    if (netPaused || (remote && !onDash())) return;
    netBuf.push(x); if (netBuf.length > 400) netBuf.splice(0, 150);
    if (x.m !== 'EV') netTotal++; if (x.m === 'POST') netPosts++; if (x.bad) netBad++;
    schedNet();
  }
  function schedNet() { if (netTimer || !onDash()) return; netTimer = setTimeout(() => { netTimer = 0; drawNet(); }, state.lite ? 1000 : 250); }
  function drawNet() {
    const pre = $('.ncon'); if (!pre) return;
    const d = D[state.lang] || D.en, me = tabId(), p2 = n => String(n).padStart(2, '0');
    const fmt = x => { const t = new Date(x.t); if (x.m === 'EV') return `${p2(t.getHours())}:${p2(t.getMinutes())}:${p2(t.getSeconds())}.${String(t.getMilliseconds()).padStart(3, '0')}  ${x.id === me ? '\u25CF' : '\u25CB'}${x.id.slice(0, 3)}  ${x.k.padEnd(8)}  ${x.n}`; return `${p2(t.getHours())}:${p2(t.getMinutes())}:${p2(t.getSeconds())}.${String(t.getMilliseconds()).padStart(3, '0')}  ${x.id === me ? '\u25CF' : '\u25CB'}${x.id.slice(0, 3)}  ${x.m.padEnd(4)}  ${x.s || 'ERR'}  ${String(x.ms).padStart(4)} ms  ${x.u}${x.n ? '  ' + x.n : ''}`; };
    const lines = netBuf.filter(x => !netOnlyPost || x.m === 'POST').slice(-150);
    const stick = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 12;
    pre.innerHTML = lines.map(x => `<div class="nl ${x.m === 'POST' ? 'np' : x.m === 'EV' ? 'ne' : 'ng'}${x.bad ? ' nb' : ''}">${esc(fmt(x))}</div>`).join('') || `<span class="dnote">${d.conEmpty}</span>`;
    if (stick) pre.scrollTop = pre.scrollHeight;
    const now = Date.now(); let n5 = 0; for (let i = netBuf.length - 1; i >= 0 && now - netBuf[i].t < 5000; i--) n5++;
    const c = $('.ncnt'); if (c) c.textContent = `${netTotal} \u00B7 POST ${netPosts} \u00B7 \u2717 ${netBad} \u00B7 ${(n5 / 5).toFixed(1)}/s`;
  }
  try { if (typeof BroadcastChannel !== 'undefined') { netBc = new BroadcastChannel('wilmaKurssit.net'); netBc.onmessage = e => { if (e.data && e.data.m) pushNet(e.data, true); }; } } catch (_) { /* ignore */ }

  // ---------- sign-in: your own user name and password, typed into Wilma's own login form when the session ends ----------
  // The password is kept only in this browser: for this tab only (default) or, if "remember" is ticked, in the browser's storage.
  // It is never part of the settings file and never sent anywhere except Wilma's login form.
  const CK = 'wilmaKurssit.cred', CS = 'wilmaKurssit.credS', AUTHK = 'wilmaKurssit.auth';
  function credGet() {
    let c = null;
    try { c = JSON.parse(sessionStorage.getItem(CS) || 'null'); } catch (_) { c = null; }
    if (!c) { try { c = JSON.parse(localStorage.getItem(CK) || 'null'); } catch (_) { c = null; } }
    return c && c.u && c.p ? c : null;
  }
  function saveCreds() {
    const u = ($('.cuser') || {}).value || '', p = ($('.cpass') || {}).value || '';
    try {
      sessionStorage.removeItem(CS); localStorage.removeItem(CK);
      if (u || p) (state.cremember ? localStorage : sessionStorage).setItem(state.cremember ? CK : CS, JSON.stringify({ u, p }));
    } catch (_) { /* ignore */ }
    loadCredsUI();
  }
  function loadCredsUI() {
    const c = credGet(), st = $('.cstat'); if (!st) return;
    const t = tr();
    st.textContent = t.authWhere(!c, !!state.cremember) + ' \u00B7 ' + t.authAutoOn(!!state.cauto);
    const u = $('.cuser'), p = $('.cpass');
    if (u && c && root.activeElement !== u) u.value = c.u;
    if (p && c && root.activeElement !== p) p.value = c.p;
  }
  // Wilma ends an idle session after about 20 minutes. Every 4 minutes one tab (shared through localStorage) reads the selection page,
  // which keeps the session alive. If the session has already ended, the sign-in above takes over.
  const KA = 'wilmaKurssit.ka', KA_EVERY = 240000;
  async function keepAliveTick() {
    if (state.cka === false || state.off) return;
    const m = /^\/![^/]+/.exec(location.pathname) || [''];
    let last = 0; try { last = +localStorage.getItem(KA) || 0; } catch (_) { /* ignore */ }
    if (Date.now() - last < KA_EVERY) return;
    try { localStorage.setItem(KA, String(Date.now())); } catch (_) { /* ignore */ }
    try { await getDoc(location.origin + m[0] + '/selection/view'); evLog('KEEP', 'istunto virkistetty'); }
    catch (_) { evLog('LOGIN', 'istunto on päättynyt, kirjautuminen tarvitaan'); }
  }
  // at most one automatic attempt every two minutes; after two failures in a row, wait 15 minutes (never lock the account)
  const authRec = () => { try { return JSON.parse(localStorage.getItem(AUTHK) || '{}') || {}; } catch (_) { return {}; } };
  const authWrite = o => { try { localStorage.setItem(AUTHK, JSON.stringify(o)); } catch (_) { /* ignore */ } };
  function authAllowed() {
    const a = authRec(), now = Date.now();
    if (now - (a.t || 0) < 120000) return false;
    if ((a.f || 0) >= 2 && now - (a.t || 0) < 900000) return false;
    return true;
  }
  function pickUserField(form) {
    const texts = [...form.querySelectorAll('input')].filter(i => /^(text|email|)$/i.test(i.getAttribute('type') || ''));
    return texts.find(i => /user|login|tunnus|kayttaja|uid|id/i.test(i.name || '')) || texts[0] || null;
  }
  // Wilma answered with its sign-in form: fill that form with the stored user name and password, and send it
  async function autoLogin(html, base) {
    const c = credGet(); if (!state.cauto || !c || !authAllowed()) return false;
    const pw = parseHtml(html).querySelector('input[type=password]'), form = pw && pw.form; if (!form) return false;
    const body = new URLSearchParams(); let userSet = false;
    const uf = pickUserField(form), uname = uf ? uf.name : '';
    form.querySelectorAll('input[name]').forEach(i => {
      const type = (i.getAttribute('type') || 'text').toLowerCase();
      if (type === 'password') body.set(i.name, c.p);
      else if (type === 'hidden' || (type === 'checkbox' && i.checked)) body.set(i.name, i.value);
      else if (!userSet && i.name === uname) { body.set(i.name, c.u); userSet = true; }
    });
    if (!userSet || !body.has(pw.name)) return false;
    const act = new URL(form.getAttribute('action') || base, base).href, method = (form.getAttribute('method') || 'post').toUpperCase();
    const a0 = authRec(); authWrite({ f: a0.f || 0, t: Date.now() }); // the attempt is recorded before it is sent
    evLog('LOGIN', 'automaattinen kirjautuminen: lähetetään Wilman kirjautumislomake');
    const t0 = performance.now(); let r, txt = '';
    try { r = await fetch(act, { method, body, credentials: 'same-origin' }); txt = await r.text(); } catch (_) { evLog('LOGIN', 'kirjautuminen: verkkovirhe'); return false; }
    const ok = r.ok && !/type=["']password["']/i.test(txt); // Wilma shows the sign-in form again when the login failed
    netLog(method, act, r.status, t0, ok ? 'kirjautuminen onnistui' : 'kirjautuminen ei onnistunut'); // the body is never logged
    if (ok) { authWrite({ f: 0, t: Date.now() }); loginLost = false; evLog('LOGIN', 'kirjautuminen onnistui, jatketaan'); return true; }
    const f = (a0.f || 0) + 1; authWrite({ f, t: Date.now() });
    evLog('LOGIN', 'kirjautuminen ei onnistunut' + (f >= 2 ? ' (kaksi kertaa peräkkäin: automaattinen yritys pysäytetty 15 minuutiksi, ettei tili lukittuisi)' : ''));
    return false;
  }
  // the page itself is the sign-in form (e.g. after the session ended): fill it and send it
  function autoLoginPage() {
    const c = credGet(); if (!state.cauto || !c || !authAllowed()) return;
    const pw = document.querySelector('input[type=password]'), form = pw && pw.form; if (!form) return;
    const uf = pickUserField(form); if (uf) uf.value = c.u; pw.value = c.p;
    authWrite({ f: authRec().f || 0, t: Date.now() });
    evLog('LOGIN', 'sivun kirjautumislomake täytetty automaattisesti');
    form.requestSubmit ? form.requestSubmit() : form.submit();
  }

  // GET a page as text. cache: 'no-store' so a stale copy is never read; the timeout keeps one stuck request from stalling the loop.
  async function getHtml(u, retried, o) {
    const t0 = performance.now(), ac = typeof AbortController === 'undefined' ? null : new AbortController(), to = ac ? setTimeout(() => ac.abort(), 9000) : 0;
    let r, html;
    try {
      r = await fetch(u, { credentials: 'same-origin', cache: 'no-store', priority: (o && o.priority) || 'auto', signal: ac ? ac.signal : undefined });
      html = await r.text();
    } catch (e) { netLog('GET', u, r ? r.status : 0, t0, String(e && e.message || e)); throw e; } finally { clearTimeout(to); }
    netLog('GET', u, r.status, t0, '');
    let went = '', here = ''; try { went = new URL(r.url || u, location.href).pathname; here = new URL(u, location.href).pathname; } catch (_) { /* ignore */ }
    if ((/\/login\b/i.test(went) && !/\/login\b/i.test(here)) || /type=["']password["']/i.test(html)) { // Wilma served its sign-in form instead of the page
      if (!retried && await autoLogin(html, r.url || u)) return getHtml(u, true, o); // signed in again: read the page once more
      loginLost = true; throw new Error('LOGIN ' + u);
    }
    if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + u);
    return { html, url: r.url || u };
  }
  async function getDoc(u, retried) { const r = await getHtml(u, retried); return { doc: parseHtml(r.html), url: r.url }; }

  // Period labels look like "1. periodi a Tapiolan lukio": the words every label of a year ends with, minus the
  // period designator ("a", "1.", "periodi"), are the school name.
  const DESIGNATOR = /^(\d+\.?|[a-z]|periodi|jakso|period)$/i;
  const isPeriodHref = h => /^(?=.*\d)[A-Za-z0-9_-]+$/.test(h || ''); // bare ids like 19221C2A_32086; menu links have no digits
  function schoolOf(labels) {
    if (labels.length < 2) return '';
    const w = labels.map(l => l.split(' ')), min = Math.min(...w.map(x => x.length));
    let n = 0;
    while (n < min && w.every(x => x[x.length - 1 - n] === w[0][w[0].length - 1 - n])) n++;
    const words = w[0].slice(w[0].length - n);
    while (words.length && DESIGNATOR.test(words[0])) words.shift();
    return words.join(' ');
  }

  // A year is an <h4> heading followed by a <ul> of period links. Every such pair on the page counts, so other schools'
  // years show up too (not only #own-schools). They are paired in document order: a real Wilma had 13 headings but 12 lists.
  async function loadYears() {
    const { doc, url: viewUrl } = await getDoc(url('selection/view'));
    const all = []; let cur = null, taken = true;
    doc.body.querySelectorAll('h4, ul').forEach(el => {
      if (el.tagName === 'H4') { cur = { title: el.textContent.replace(/\s+/g, ' ').trim(), periods: [], section: (el.closest('[id]') || {}).id || '' }; all.push(cur); taken = false; return; }
      if (!cur || taken) return;
      const links = [...el.querySelectorAll('a[href]')].filter(a => isPeriodHref(a.getAttribute('href')));
      if (!links.length) return;
      taken = true; // only the first period list after a heading belongs to it
      links.forEach(a => {
        const note = (a.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
        cur.periods.push({ label: a.textContent.replace(/\s+/g, ' ').trim(), href: a.getAttribute('href'), note, closed: /päättynyt/i.test(note) });
      });
    });
    const list = all.filter(y => y.periods.length);
    list.forEach(y => { y.school = schoolOf(y.periods.map(p => p.label)); });
    // a year with a single period cannot reveal its school, so it borrows one that other years ended with
    const known = [...new Set(list.map(y => y.school).filter(Boolean))].sort((a, b) => b.length - a.length);
    list.forEach(y => { if (!y.school) y.school = known.find(s => y.periods.every(p => p.label.endsWith(' ' + s))) || ''; });
    list.forEach(y => y.periods.forEach(p => {
      p.short = y.school && p.label.endsWith(' ' + y.school) ? (p.label.slice(0, -(y.school.length + 1)).trim() || p.label) : p.label;
    }));
    return { years: list, viewUrl };
  }

  const isCourseCode = s => !!s && s.length <= 40 && !/\s/.test(s) && /\d/.test(s);

  // What the tray markup says about one course group (seen on a real Wilma, Oct 2026):
  //   class "disa" = not selectable (title says "Ryhmä on jo täynnä." when full), "ksuor-on" = already completed,
  //   "k<id>-on" / "k<id>-off" = a state flag whose <id> is shared by several groups.
  function describe(a, code, target, p) {
    const cls = ' ' + (a.getAttribute('class') || '') + ' ';
    const title = (a.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
    const key = /\sk(?!suor)(\S+)-(on|off)\s/.exec(cls);
    const who = /Opettaja:\s*(.*?)(?:\s+(?:Ryhmä on|Tämä kurssi)|$)/.exec(title);
    return {
      code, target, period: p.short || p.label, closed: !!p.closed, title, school: p.school || '', year: p.year || '', ph: p.href,
      teacher: who ? who[1].replace(/^[A-ZÅÄÖ]{2,4}\s+/, '').trim() : '',
      full: /täynnä/i.test(title), off: /\sdisa\s/.test(cls),
      done: /\sksuor-on\s/.test(cls) || /suoritettu/i.test(title),
      selected: !!key && key[2] === 'on', block: key ? key[1] : '',
    };
  }

  // Collect the course links (text = code, href = target) from every period page of the year.
  const scanMemo = new Map(); // period link -> the page text of the last scan and what was read from it: an identical page is not parsed again
  async function scanPeriods(periods, viewUrl, onProgress, o) {
    const errors = []; let done = 0;
    const perPeriod = await Promise.all(periods.map(async p => {
      let list = [];
      try {
        const { html } = await getHtml(new URL(p.href, viewUrl).href, false, o);
        const sig = [p.short, p.label, p.school, p.year, p.closed ? 1 : 0].join('\u0001'), m = scanMemo.get(p.href);
        if (m && m.html === html && m.sig === sig) list = m.list.map(x => ({ ...x }));
        else {
          const seen = new Set();
          parseHtml(html).querySelectorAll('a[href]').forEach(a => {
            const code = a.textContent.trim(), href = a.getAttribute('href');
            if (isCourseCode(code) && !seen.has(href)) { seen.add(href); list.push(describe(a, code, href, p)); }
          });
          if (scanMemo.size >= 24) scanMemo.delete(scanMemo.keys().next().value);
          scanMemo.set(p.href, { html, sig, list: list.map(x => ({ ...x })) });
        }
      } catch (e) { errors.push(String(e.message || e)); }
      onProgress && onProgress(++done, periods.length);
      return list;
    }));
    const index = perPeriod.flat(); // period order, so results do not depend on which request finished first
    if (errors.length) index.errors = errors;
    return index;
  }

  async function getFormkey(fresh) {
    const here = fresh ? null : document.querySelector('input[name=formkey]');
    if (here && here.value) return here.value;
    for (const p of ['', 'selection/view']) {
      try {
        const { doc } = await getDoc(url(p));
        const el = doc.querySelector('input[name=formkey]');
        if (el && el.value) return el.value;
      } catch (_) { /* try next */ }
    }
    return null;
  }

  async function pickGroup(target, formkey) {
    const t0 = performance.now(), pu = url('selection/postback'), ac = typeof AbortController === 'undefined' ? null : new AbortController(), to = ac ? setTimeout(() => ac.abort(), 8000) : 0;
    let r, text;
    try {
      r = await fetch(pu, {
        method: 'POST', credentials: 'same-origin', priority: 'high', signal: ac ? ac.signal : undefined,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams({ message: 'pick-group', target, formkey }).toString(),
      });
      text = await r.text();
    } catch (e) { netLog('POST', pu + ' ' + target, r ? r.status : 0, t0, String(e && e.message || e)); throw e; } finally { clearTimeout(to); }
    // the session has ended: Wilma answers with its sign-in page, which is not a pick that went through
    let went = ''; try { went = new URL(r.url || pu, location.href).pathname; } catch (_) { /* ignore */ }
    if (/\/login\b/i.test(went) || /type=["']password["']/i.test(text)) {
      loginLost = true; netLog('POST', pu + ' ' + target, r.status, t0, '⚠ kirjautuminen puuttuu');
      return { ok: false, status: r.status, login: true, text: '⚠ kirjautuminen puuttuu' };
    }
    // Wilma answers HTTP 200 even when it refuses: the body then holds srvError("title", "message")
    const e = /srvError\(\s*(["'])(.*?)\1\s*(?:,\s*(["'])(.*?)\3)?/.exec(text);
    netLog('POST', pu + ' ' + target, r.status, t0, e ? '⚠ ' + e[2] : r.ok ? 'OK' : '');
    return { ok: r.ok && !e, status: r.status, text: e ? '⚠ ' + e[2] + (e[4] ? ' – ' + e[4] : '') : text.replace(/\s+/g, ' ').trim().slice(0, 140) };
  }

  // Run async jobs with a concurrency limit; returns results in input order.
  async function pool(items, limit, fn) {
    const res = new Array(items.length); let next = 0;
    await Promise.all(Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
      while (next < items.length) { const i = next++; res[i] = await fn(items[i], i); }
    }));
    return res;
  }

  // ---------- panel (Shadow DOM) ----------
  const host = document.createElement('div');
  host.id = ID;
  host.style.cssText = 'position:fixed;z-index:2147483646;right:16px;bottom:72px;';
  if (state.x != null && state.y != null) Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
  const root = host.attachShadow({ mode: 'open' });
  const CSS = `
    .wrap { font: 13px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: var(--fg) }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --bg:#1e2024; --bg2:#2a2d33; --fg:#eceef1; --mut:#9aa1ab; --line:#3a3e45; --pri:#3fae6c; --prifg:#08130c; --warn:#e0a040; --bad:#ff8a80; } }
    [hidden] { display: none !important; }
    button, select, input, textarea { font: inherit; color: inherit; }
    button { cursor: pointer; }
    button:disabled { opacity: .45; cursor: default; }
    .fab { border-radius: 50%; border: 0; color: var(--prifg); font-size: 20px; touch-action: none }
    .panel { max-height: calc(100vh - 96px); display: flex; flex-direction: column; background: var(--bg); border: 1px solid var(--line); overflow: hidden }
    .head { display: flex; justify-content: space-between; align-items: center; cursor: move; user-select: none; touch-action: none; border-bottom: 1px solid var(--line) }
    .head button { background: none; border: 0; color: var(--mut) }
    .body { display: grid; overflow: auto }
    label.field { display: grid; gap: 4px; }
    select, input:not([type]), input[type=number], textarea { box-sizing: border-box; width: 100% }
    select:focus, input:focus, textarea:focus { outline-offset: -1px }
    textarea { height: 64px; resize: vertical }
    .card { display: grid; gap: 8px; }
    .row { display: flex; gap: 8px; }
    .row > button { flex: 1; padding: 8px 10px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); }
    .row > button.icon { flex: 0 0 38px; padding: 0; }
    .periods { display: flex; flex-wrap: wrap; gap: 6px; }
    .periods .lbl { flex: 1 0 calc(100% - 30px); }
    .chk { display: inline-flex; align-items: center; gap: 6px; border: 1px solid var(--line); font-size: 12px; cursor: pointer }
    .chk input { width: auto; margin: 0; accent-color: var(--pri); }
    .chk i { color: var(--warn); font-style: normal; }
    .timebar { display: flex; gap: 10px; align-items: end; }
    .timebar .grow { flex: 1; }
    .timebar .chk { height: 32px; box-sizing: border-box; }
    table { border-collapse: collapse; width: 100%; font-size: 12px; }
    td, th { border-bottom: 1px solid var(--line); text-align: left; vertical-align: middle }
    th { color: var(--mut); font-weight: 600 }
    td select { padding: 3px 6px; border-radius: 8px; }
    .cell { display: flex; gap: 6px; align-items: center; }
    .cell > select:first-child { flex: 1; min-width: 0; }
    .cell select.pf { width: auto; max-width: 44%; }
    .ok { color: var(--pri); font-weight: 600; } .bad { color: var(--bad); font-weight: 600; } .warn { color: var(--warn); font-weight: 600; }
    .log { min-height: 2.6em; max-height: 110px; overflow: auto; padding: 8px 10px; border-radius: 10px; background: var(--bg2); font-size: 12px; white-space: pre-wrap; word-break: break-word; }
    .hint { color: var(--mut); font-size: 11px; }
    details summary { cursor: pointer; color: var(--mut); font-size: 12px; padding: 2px 0; }
    .more { display: grid; gap: 10px; padding-top: 8px; }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --b-find:#8ab4f8; --b-findbg:#1f2c42; --b-cancel:#ff8a80; --b-cancelbg:#40201e; --b-save:#5fd3cc; --b-savebg:#18332f; --b-load:#c3a5f5; --b-loadbg:#2c2340; } }
    .row > button, .bq > button:first-child { font-weight: 600; }
    .bq > button.b-find:first-child { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .bq > button.b-loop.on:first-child { border-color: var(--bad) }
    .bq > button.b-cancel:first-child { color: var(--b-cancel) }
    .bq > button.b-save:first-child { color: var(--b-save) }
    .bq > button.b-load:first-child { color: var(--b-load) }
    .bq > button.b-clear:first-child { background: transparent; color: var(--b-cancel); border: 1px dashed var(--b-cancel); }
    .bq > button.b-debug:first-child { background: transparent; color: var(--mut); border: 1px dashed var(--mut); font-weight: 500; }
    .bq { flex: 1; display: flex; gap: 4px; min-width: 0; }
    .bq > button:first-child { flex: 1; padding: 8px 10px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); min-width: 0; }
    .bq > button.b-pick:first-child { background: var(--pri); border-color: var(--pri); color: var(--prifg); }
    button.q { flex: 0 0 20px; width: 20px; height: 20px; align-self: center; padding: 0; border-radius: 50%; border: 1px solid var(--mut); background: transparent; color: var(--mut); font-size: 11px; font-weight: 700; line-height: 1; }
    button.q:hover, button.q.on { background: var(--pri); border-color: var(--pri); color: var(--prifg); }
    .tip { padding: 8px 10px; font-size: 12px }
    .qrow { display: flex; gap: 8px; align-items: center; justify-content: space-between; }
    .qrow .field { flex: 1; }
    .head .q { margin-left: 4px; }
    .head > span { display: inline-flex; align-items: center; }
    .o0{order:0}.o1{order:1}.o2{order:2}.o3{order:3}.o4{order:4}.o5{order:5}.o6{order:6}
    .col1, .col2 { display: contents; }
    .full .panel { position: fixed; inset: 0; width: auto; max-height: none; border: 0; box-shadow: none }
    .full .head { cursor: default } .full .head strong { font-size: 17px; }
    .full .body { grid-template-columns: minmax(340px, 440px) minmax(0, 1fr); align-items: start; font-size: 14px }
    .full .col1, .full .col2 { display: grid; gap: 14px; }
    .full [data-act=min], .full .fab { display: none; }
    .full .log { max-height: 240px; }
    @media (max-width: 800px) { .full .body { grid-template-columns: 1fr; } .full .col1, .full .col2 { display: contents; } }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --c-man:#a99bff; --c-opt:#ff7aa8; } }
    .kd { display: inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 6px; vertical-align: baseline; }
    .kd.km { background: var(--c-man); } .kd.kv { background: var(--c-opt); }
    .dchip.km { border-left: 5px solid var(--c-man); } .dchip.kv { border-left: 5px solid var(--c-opt); }
    .dchip.hp::after { content: ' ★'; font-size: 10px; opacity: .8; }
    .sw { display: inline-flex; align-items: center; gap: 4px; cursor: pointer; font-size: 13px; user-select: none }
    .sw input { position: absolute; opacity: 0; width: 0; height: 0; }
    .sw i { border-radius: 99px; background: var(--line); position: relative; transition: background .15s }
    .sw i::after { content: ''; position: absolute; top: 2px; left: 2px; border-radius: 50%; background: var(--fg); transition: transform .15s }
    .sw input:checked + i { background: var(--pri); } .sw input:checked + i::after { background: var(--prifg) }
    .sw input:focus-visible + i { outline: 2px solid var(--pri); outline-offset: 2px; }
    .tabs { display: none; align-items: center }
    .full .tabs { display: inline-flex; }
    .head .tab { font-weight: 600 }
    .full [data-act=dashopen], .full [data-act=dashopen] + .q { display: none; }
    .head > span > button[data-act=dashopen] { color: var(--b-find); }
    .panel { position: relative; }
    .rz { position: absolute; right: 0; bottom: 0; width: 20px; height: 20px; cursor: nwse-resize; touch-action: none; z-index: 3;
          background: linear-gradient(135deg, transparent 0 55%, var(--mut) 55% 62%, transparent 62% 72%, var(--mut) 72% 79%, transparent 79%); border-bottom-right-radius: 16px; opacity: .7; }
    .rz:hover { opacity: 1; }
    .full .rz { display: none; }
    .lstat { padding: 8px 12px; font-size: 12.5px }
    .ncon { height: 240px; min-height: 90px; overflow: auto; resize: vertical; margin-top: 6px; padding: 8px 10px; font: 11.5px/1.5 ui-monospace, Consolas, monospace; white-space: pre }
    .dtools button.act.on { background: var(--warn); color: #fff; }
    .wrap:not(.help) button.q { display: none; }
    .helpbtn.on { background: var(--pri) !important; color: var(--prifg) !important; }
    .pbar { flex: 0 0 auto; display: grid; font-size: 12px }
    .pbar .pt { display: flex; justify-content: space-between; gap: 8px; font-weight: 600 }
    .pbar .pb { overflow: hidden }
    .pbar .pb i { display: block; height: 100%; transition: width .3s }
    .wrap.lite *, .wrap.lite *::before, .wrap.lite *::after { transition: none !important; animation: none !important; box-shadow: none !important; }
    .dtoolbox.dev .devwarn { margin: 6px 0; padding: 9px 11px; border-radius: 10px; border: 1px solid var(--b-cancel); background: color-mix(in srgb, var(--b-cancel) 12%, var(--bg)); font-size: 12px; }
    .dtoolbox.dev .dtools label.dnote { display: inline-flex; gap: 6px; align-items: center; }
    .dtoolbox.dev select { width: auto; }
    .dtoolbox.dev .dtools input[type=checkbox] { min-width: 0; width: auto; flex: none; margin: 0; }
    .legend .lrows { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 6px 14px; padding-top: 6px; }
    .legend .lrow { display: flex; align-items: center; gap: 8px; font-size: 12px; }
    .legend .dchip { cursor: default; margin: 0; flex: 0 0 auto; min-width: 46px; text-align: center; }
    .dash { display: none; padding: 20px 24px; overflow: auto; gap: 16px; flex: 1; }
    .full.view-dash .dash { display: grid; align-content: start; } .full.view-dash .body { display: none; }
    .dtiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; }
    .tile b { display: block; line-height: 1.1 } .tile span { color: var(--mut); font-size: 12px; }
    .tile.d b { color: var(--pri); } .tile.s b { color: var(--b-find); } .tile.m b { color: var(--bad); }
    .dtools { display: flex; flex-wrap: wrap; align-items: center }
    .dtools button.act { padding: 7px 12px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); font-weight: 600; }
    .dtools button.scan { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .dtools button.rst { background: transparent; color: var(--b-cancel); border: 1px dashed var(--b-cancel); }
    .dtools input { width: auto; min-width: 150px; flex: 0 1 220px; } .dtools input.nn { min-width: 0 }
    .dash > .dexp { display: none; } .full.view-exp .dash { display: grid; align-content: start; } .full.view-exp .body { display: none; }
    .full.view-exp .dash > :not(.dexp):not(.lstat) { display: none; } .full.view-exp .dash > .dexp { display: block; }
    .dexp .xh { margin: 14px 0 4px; font-size: 14px; font-weight: 600; } .xrow { gap: 8px 14px; padding: 9px 0; border-bottom: 1px solid rgba(128,128,128,.22); } .xrow button.act { flex: 0 1 230px; min-width: 190px; text-align: left; } .xrow .dnote { flex: 1 1 200px; color: var(--mut); } .xmsg { min-height: 22px; padding-top: 10px; }
    .dcat { margin-top: 10px; }
    .dcat > summary { list-style: none; display: flex; gap: 8px; align-items: center; cursor: pointer; color: var(--fg); font-size: 14px; font-weight: 600; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(128,128,128,.25)); }
    .dcat > summary::-webkit-details-marker { display: none; }
    .dcat > summary::before { content: '▸'; color: var(--mut); }
    .dcat[open] > summary::before { content: '▾'; }
    .dcat > summary .dnums { margin-left: auto; color: var(--mut); font-weight: 400; }
    .dchip.above, tr.above td { opacity: .38; filter: grayscale(1); }
    .dgrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(330px, 1fr)); gap: 12px; }
    .dcard { display: grid; align-content: start }
    .dcard.off { opacity: .55; }
    .dcard h4 { margin: 0; font-size: 14px; display: flex; gap: 8px; align-items: center; }
    .dcard h4 span { flex: 1; }
    .dcard h4 input { width: 54px; padding: 3px 6px; text-align: center; }
    .dcard h4 .x { background: none; border: 0; color: var(--mut); font-size: 14px; padding: 0 4px; }
    .dcard h4 .x:hover { color: var(--bad); }
    .bar { border-radius: 99px; overflow: hidden; display: flex }
    .bar i { display: block; height: 100%; }    .dnums { font-size: 12px; color: var(--mut); }
    .dchip { display: inline-block; margin: 2px 4px 2px 0; border: 1px solid var(--line); background: var(--bg2); font-size: 12px; cursor: pointer; color: var(--fg) }
    .dchip.done { color: var(--prifg) }
    .dchip.sel { background: var(--b-findbg); border-color: var(--b-find); color: var(--b-find); }
    .dchip.man { outline: 2px dotted var(--warn); outline-offset: 1px; }
    .dlog { padding: 8px 10px; border-radius: 10px; background: var(--bg2); font-size: 12px; white-space: pre-wrap }
    .dchip.ign { background: #1a1a1a; border-color: #000; color: #8a8a8a; text-decoration: line-through; }
    .dd > summary { cursor: pointer; color: var(--mut); font-size: 12px; padding: 2px 0 6px; }
    .ctx { position: fixed; z-index: 10; min-width: 190px; padding: 4px; border-radius: 10px; background: var(--bg); border: 1px solid var(--line); box-shadow: 0 8px 24px rgba(0,0,0,.3) }
    .ctx { display: grid; } .ctx .ctxh { padding: 4px 10px; color: var(--mut); font-size: 11px; font-weight: 700; }
    .tile small { font-size: 13px; font-weight: 500; color: var(--mut); }
    .dtop h3 { margin: 0; }
    .dtools .act.pick { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .dtools .act.pick.on { background: var(--warn); color: #fff; border-color: var(--warn); }
    .dtools.yel { padding: 8px 10px }
    .dtools .act.go { background: var(--pri); color: var(--prifg); border-color: var(--pri); }
    .dtoolbox, .dash details > summary { cursor: pointer; color: var(--mut); font-size: 13px; }
    .dtoolbox { display: grid }
    .dtoolbox > summary { padding: 4px 0; }
    .dcard { gap: 6px; }
    .dcard > summary { list-style: none; display: flex; gap: 8px; align-items: center; cursor: pointer; color: var(--fg); font-size: 14px; }
    .dcard > summary::-webkit-details-marker { display: none; }
    .dcard > summary::before { content: '▸'; color: var(--mut); }
    .dcard[open] > summary::before { content: '▾'; }
    .dcard .dname { flex: 1; font-weight: 600; }
    .dcard .dnums { color: var(--mut); font-size: 12px; }
    .dcard > summary input { width: 50px; padding: 2px 6px; text-align: center; }
    .dcard > summary .x { background: none; border: 0; color: var(--mut); padding: 0 4px; }
    .dcard > summary .x:hover { color: var(--bad); }
    .dbody { padding-top: 4px; }
    .dsub { font-size: 11px; font-weight: 700; color: var(--mut); text-transform: uppercase; letter-spacing: .02em; margin: 6px 0 2px; }
    .dchip.blue { background: var(--b-findbg); border-color: var(--b-find); color: var(--b-find); cursor: default; }
    .dchip.todo { background: color-mix(in srgb, var(--warn) 22%, var(--bg)); border-color: var(--warn); color: var(--fg); font-weight: 600; }
    .dchip.todo.inl { background: var(--warn); color: #fff; }
    .ctx button { text-align: left; padding: 7px 10px; border: 0; border-radius: 7px; background: none; }
    .ctx button:hover { background: var(--bg2); }
    .ctx b { padding: 4px 10px; color: var(--mut); font-size: 11px; }
    .dnote { color: var(--mut); font-size: 12px; }
    .lnk { background: none; border: 0; color: var(--pri); text-decoration: underline; padding: 0; font-size: 11px; }
    /* ---- modern skin (overrides) ---- */
    .wrap { -webkit-font-smoothing: antialiased }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --bg:#15171c; --bg2:#1e2128; --fg:#eef0f4; --mut:#98a1b0; --line:#2b2f38; --pri:#34c38a; --prifg:#04130c; --sh1: 0 1px 2px rgba(0,0,0,.4); --sh2: 0 1px 2px rgba(0,0,0,.4), 0 16px 40px -12px rgba(0,0,0,.7), 0 32px 64px -24px rgba(0,0,0,.6); } }
    .wrap * { scrollbar-width: thin; scrollbar-color: color-mix(in srgb, var(--mut) 45%, transparent) transparent; }
    @keyframes wkIn { from { opacity: 0; transform: translateY(6px) scale(.985); } to { opacity: 1; transform: none; } }
    .panel { width: 360px }
    .fab { width: 50px; height: 50px; background: linear-gradient(135deg, color-mix(in srgb, var(--pri) 80%, #fff), var(--pri)); box-shadow: var(--sh2); transition: transform .12s; }
    .fab:hover { transform: scale(1.06); }
    .head strong { font-size: 14.5px; font-weight: 700; letter-spacing: -.01em; }
    .head > span { gap: 2px; }
    .head button { width: 28px; height: 28px; padding: 0; display: inline-grid; place-items: center; border-radius: 9px; font-size: 14px; transition: background .12s, color .12s; }
    .head button:hover { color: var(--fg) }
    .head [data-act=lang] { width: auto; padding: 0 8px; font-size: 11.5px; font-weight: 700; letter-spacing: .04em; }
    .tabs { border-radius: 12px; flex: 0 0 auto; margin-left: 18px }
    .head .tab { width: auto; height: auto; font-size: 13px }
    .head .tab:hover { background: transparent; color: var(--fg); }
    .full .head > strong { margin-right: 0; } .full .head { gap: 8px; }
    .sw { margin-right: 4px; } .sw i { width: 36px; height: 20px; } .sw i::after { width: 16px; height: 16px; } .sw input:checked + i::after { transform: translateX(16px); }
    .field > span, .lbl { text-transform: none; letter-spacing: 0 }
    select, input:not([type]), input[type=number], textarea { padding: 8px 11px; transition: box-shadow .12s, border-color .12s }
    select:focus, input:focus, textarea:focus { outline: none }
    .chk { padding: 5px 12px; transition: background .12s, border-color .12s; }
    .chk:hover { border-color: color-mix(in srgb, var(--pri) 45%, var(--line)); }
    .bq > button:first-child, .row > button, .dtools button.act { min-height: 36px }
    .bq > button.b-find:first-child, .dtools button.scan, .dtools .act.pick { border-color: color-mix(in srgb, var(--b-find) 40%, var(--line)); }
    .bq > button.b-clear:first-child, .bq > button.b-debug:first-child { box-shadow: none; }
    td, th { padding: 8px 6px; border-bottom-color: color-mix(in srgb, var(--line) 70%, transparent); }
    tr:last-child td { border-bottom: 0; }
    th { text-transform: none; letter-spacing: 0; font-size: 11.5px; }
    td select { background: var(--bg2); }
    .tip { border-left: 1px solid color-mix(in srgb, var(--pri) 30%, var(--line)) }
    details:not(.dcard) > summary { list-style: none; } details:not(.dcard) > summary::-webkit-details-marker { display: none; }
    .pbar { padding: 10px 18px 12px; gap: 6px; }
    .pbar .pt { color: var(--fg); font-variant-numeric: tabular-nums; }
    .pbar .pb { height: 8px }
    .pbar .pb i { border-radius: 99px }
    .dtop h3 { font-weight: 700; letter-spacing: -.02em }
    .tile { position: relative; overflow: hidden }
    .tile::before { content: ''; position: absolute; inset: 0 0 auto 0; background: var(--pri) }
    .tile.m::before { background: var(--bad); } .tile.s::before { background: var(--b-find); }
    .tile b { letter-spacing: -.02em; font-variant-numeric: tabular-nums }
    .tile span { display: block; margin-top: 4px; }
    .dcard { padding: 14px; transition: border-color .15s, box-shadow .15s }
 .bar.big { height: 10px; }
    .dchip { padding: 3px 10px; transition: transform .08s, box-shadow .12s }
    .lstat, .dtoolbox.dev .devwarn, .tip, .ncon { border-radius: 12px; }
    .full .panel { border-radius: 0; animation: none; }
    table, td, th { color: inherit; }
    .dtools { gap: 10px; }
    .dtools input:not([type=checkbox]) { height: 36px; box-sizing: border-box; padding: 0 12px; }
    .dtools input.nn { flex: 0 0 64px; width: 64px; text-align: center; padding: 0 6px; }
    .dtools input.dmanual, .dtools input.dnname { flex: 1 1 200px; }
    .dtools select { height: 36px; }
    .dtools label.dnote { display: inline-flex; gap: 8px; align-items: center; }
    .ncnt { margin-left: 10px; font-weight: 500; font-variant-numeric: tabular-nums; }
    details:not(.dcard) > summary { display: flex; align-items: center; gap: 8px; }
    details:not(.dcard) > summary::before { content: ''; flex: 0 0 auto; width: 6px; height: 6px; margin: 0 4px 0 2px; border-right: 2px solid currentColor; border-bottom: 2px solid currentColor; transform: rotate(-45deg); transition: transform .15s; }
    details[open]:not(.dcard) > summary::before { transform: rotate(45deg); }
    .dtoolbox { gap: 12px; }
    .dash { grid-template-columns: minmax(0, 1fr); grid-auto-rows: max-content; }
    .dtools textarea { flex: 1 1 320px; min-height: 56px; height: 56px; padding: 8px 12px; }
    .dtools label.grow { flex: 1 1 320px; display: grid; gap: 4px; }
    .ares { margin-top: 4px; } .ares td, .ares th { padding: 6px 8px; }
    .dtools input.dmanual { flex: 1 1 240px; max-width: 460px; }
    .dtools input.dnname, .dtools input.dnpref { flex: 1 1 200px; max-width: 280px; }
    .dlog { min-height: 0; line-height: 1.5; }
    .dtools input[type=checkbox] { min-width: 0; width: auto; flex: none; margin: 0; }
    .sw > span:first-child { display: none; }
    .head strong { white-space: nowrap; margin-right: 6px; }
    .full .dash > * { width: 100%; max-width: 1240px; margin-inline: auto; box-sizing: border-box; }
    /* ---- lo-fi calm skin (overrides the modern skin) ---- */
    .wrap { --bg:#f7f2e8; --bg2:#efe7d7; --fg:#3f3a31; --mut:#8c8473; --line:#e4dac7; --pri:#7f9c7b; --prifg:#fbf8f1; --warn:#c4915a; --bad:#b56b55;
            --sh1: 0 1px 0 rgba(90,70,40,.06); --sh2: 0 1px 2px rgba(90,70,40,.08), 0 18px 40px -18px rgba(90,70,40,.28);
            --b-find:#6f8ea3; --b-findbg:#e7edf0; --b-cancel:#b56b55; --b-cancelbg:#f6e8e2; --b-save:#6c9a90; --b-savebg:#e4eee9; --b-load:#8a79a3; --b-loadbg:#ede8f2;
            --c-man:#8a7ab3; --c-opt:#c08585;
            font-family: "Nunito", "Quicksand", "Segoe UI", system-ui, sans-serif; font-weight: 450; line-height: 1.55; letter-spacing: .005em; }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --bg:#25221e; --bg2:#2e2a25; --fg:#e7dfcf; --mut:#9d947f; --line:#3b362e; --pri:#8fae8a; --prifg:#1f2a1d; --warn:#d6a46c; --bad:#e09a85;
            --sh1: 0 1px 0 rgba(0,0,0,.25); --sh2: 0 1px 2px rgba(0,0,0,.3), 0 18px 40px -18px rgba(0,0,0,.6);
            --b-find:#9bb6c8; --b-findbg:#2a3238; --b-cancel:#e09a85; --b-cancelbg:#3a2c27; --b-save:#8fc2b6; --b-savebg:#263630; --b-load:#b6a6d1; --b-loadbg:#302a3a; --c-man:#b5a6dc; --c-opt:#dca5a5; } }
    .wrap.dark { --bg:#25221e; --bg2:#2e2a25; --fg:#e7dfcf; --mut:#9d947f; --line:#3b362e; --pri:#8fae8a; --prifg:#1f2a1d; --warn:#d6a46c; --bad:#e09a85;
            --sh1: 0 1px 0 rgba(0,0,0,.25); --sh2: 0 1px 2px rgba(0,0,0,.3), 0 18px 40px -18px rgba(0,0,0,.6);
            --b-find:#9bb6c8; --b-findbg:#2a3238; --b-cancel:#e09a85; --b-cancelbg:#3a2c27; --b-save:#8fc2b6; --b-savebg:#263630; --b-load:#b6a6d1; --b-loadbg:#302a3a; --c-man:#b5a6dc; --c-opt:#dca5a5; }
    .wrap.light { --bg:#f7f2e8; --bg2:#efe7d7; --fg:#3f3a31; --mut:#8c8473; --line:#e4dac7; --pri:#7f9c7b; --prifg:#fbf8f1; --warn:#c4915a; --bad:#b56b55; }
    .panel { border-radius: 22px; background-color: var(--bg); background-image: radial-gradient(rgba(110,90,60,.035) 1px, transparent 1px); background-size: 5px 5px; box-shadow: var(--sh2); animation: wkIn .35s ease-out; }
    .head { border-bottom-color: var(--line); padding: 14px 14px 12px 20px; }
    .head strong, .dtop h3, .full .head strong { font-family: Georgia, "Iowan Old Style", "Palatino Linotype", serif; font-weight: 400; font-size: 17px; letter-spacing: .01em; }
    .dtop h3 { font-size: 24px; }
    .tabs { background: transparent; padding: 0; gap: 4px; }
    .head .tab { background: transparent; color: var(--mut); border-radius: 999px; padding: 5px 14px; }
    .head .tab.on { background: var(--bg2); color: var(--fg); box-shadow: none; border: 1px solid var(--line); }
    .head button:hover { background: var(--bg2); }
    .body { gap: 16px; padding: 16px 20px 18px; }
    .field > span, .lbl { color: var(--mut); font-weight: 600; font-size: 11.5px; }
    select, input:not([type]), input[type=number], textarea { background: var(--bg2); border: 1px solid transparent; border-radius: 14px; font-family: inherit; }
    select:hover, input:hover, textarea:hover { border-color: var(--line); }
    select:focus, input:focus, textarea:focus { border-color: var(--line); box-shadow: 0 0 0 2px color-mix(in srgb, var(--pri) 35%, transparent); }
    textarea { font-family: ui-monospace, Consolas, monospace; font-size: 12.5px; }
    .chk { background: transparent; border-radius: 999px; border-color: var(--line); color: var(--fg); }
    .chk:has(input:checked) { background: color-mix(in srgb, var(--pri) 16%, transparent); border-color: color-mix(in srgb, var(--pri) 50%, var(--line)); }
    .bq > button:first-child, .row > button, .dtools button.act { border-radius: 14px; box-shadow: none; border-color: var(--line); background: var(--bg2); font-weight: 600; transition: background .25s, border-color .25s; }
    .bq > button:first-child:hover:not(:disabled), .row > button:hover:not(:disabled), .dtools button.act:hover:not(:disabled) { filter: none; background: color-mix(in srgb, var(--bg2) 75%, var(--pri) 25%); }
    .bq > button:first-child:active:not(:disabled), .row > button:active:not(:disabled), .dtools button.act:active:not(:disabled) { transform: none; }
    .bq > button.b-pick:first-child, .dtools .act.go { background: var(--pri); border-color: var(--pri); color: var(--prifg); box-shadow: none; }
    .bq > button.b-loop:first-child { background: color-mix(in srgb, var(--warn) 85%, var(--bg)); border-color: transparent; color: var(--prifg); box-shadow: none; }
    .bq > button.b-loop.on:first-child { background: color-mix(in srgb, var(--bad) 85%, var(--bg)); }
    .bq > button.b-find:first-child, .dtools button.scan { background: var(--b-findbg); border-color: transparent; }
    .bq > button.b-cancel:first-child { background: var(--b-cancelbg); border-color: transparent; }
    .bq > button.b-save:first-child { background: var(--b-savebg); border-color: transparent; }
    .bq > button.b-load:first-child { background: var(--b-loadbg); border-color: transparent; }
    .bq > button.b-clear:first-child, .bq > button.b-debug:first-child { background: transparent; border: 1px dashed var(--line); }
    .tip { background: transparent; border: 1px dashed var(--line); border-radius: 14px; font-style: italic; color: var(--mut); }
    .pbar { background: transparent; border-top: 1px solid var(--line); }
    .pbar .pb { border-radius: 99px; background: var(--bg2); box-shadow: none; border: 0; }
    .pbar .pb i { background: color-mix(in srgb, var(--pri) 80%, var(--bg)); }
    .pbar.full100 .pb i { background: var(--pri); }
    .tile { background: var(--bg2); border: 0; border-radius: 20px; box-shadow: none; padding: 18px 20px 16px; }
    .tile::before { height: 2px; opacity: .55; }
    .tile b { font-family: Georgia, serif; font-weight: 400; font-size: 30px; }
    .dcard { background: transparent; border: 1px solid var(--line); border-radius: 20px; box-shadow: none; }
    .dcard:hover { border-color: color-mix(in srgb, var(--pri) 40%, var(--line)); }
    .dcard.complete { background: color-mix(in srgb, var(--pri) 8%, transparent); border-color: color-mix(in srgb, var(--pri) 45%, var(--line)); }
    .dcard > summary .dname { font-family: Georgia, serif; font-weight: 400; font-size: 15px; }
    .bar { background: var(--bg2); box-shadow: none; height: 5px; }
    .bar .d { background: color-mix(in srgb, var(--pri) 85%, var(--bg)); }
    .bar .s { background: color-mix(in srgb, var(--b-find) 80%, var(--bg)); }
    .dchip { border-radius: 999px; font-weight: 500; box-shadow: none; }
    .dchip:hover { transform: none; box-shadow: none; }
    .dchip.done { background: color-mix(in srgb, var(--pri) 80%, var(--bg)); border-color: transparent; }
    .dtools.yel { background: color-mix(in srgb, var(--warn) 12%, transparent); border-radius: 16px; }
    .lstat { background: transparent; border: 1px dashed var(--line); border-radius: 16px; }
    .lstat.on { background: color-mix(in srgb, var(--warn) 10%, transparent); border-color: color-mix(in srgb, var(--warn) 45%, var(--line)); }
    .ncon { background: var(--bg2); color: var(--fg); border: 1px solid var(--line); border-radius: 16px; font-size: 11.5px; }
    .ncon .nl.ne { color: var(--warn); }
    .ncon .nl.np { color: color-mix(in srgb, var(--pri) 70%, var(--fg)); } .ncon .nl.ng { color: var(--mut); } .ncon .nl.nb { color: var(--bad); }
    .full .head { padding: 16px 30px; }
    .full .body { padding: 32px 36px; gap: 30px; }
    .full .dash { padding: 32px 36px 40px; gap: 22px; }
    .full .pbar { padding: 14px 36px 16px; }
    details:not(.dcard) > summary { color: var(--mut); font-family: inherit; }
    .dtop h3, .dash h3 { color: var(--fg); }
    .log, .dlog { background: var(--bg2); border: 0; border-radius: 16px; color: var(--fg); }
    .devwarn { background: color-mix(in srgb, var(--bad) 10%, transparent); border-style: dashed; }
    .dtoolbox.dev .devwarn { border-color: color-mix(in srgb, var(--bad) 60%, var(--line)); }
    .wrap .sw i { background: var(--line); }
    .wrap .sw input:checked + i { background: var(--pri); }

    /* ---- full-window tabs: selection / dashboard / loop / console / settings / developer ---- */
    .grp { display: contents; }
    .tabs { flex-wrap: wrap; }
    .full.view-sel .o6, .full.view-dash .o6, .full.view-con .o6, .full.view-dev .o6 { display: none; }
    .full.view-set .col1, .full.view-loop .col1, .full.view-set .col2 > :not(.o6), .full.view-loop .col2 > :not(.o6) { display: none; }
    .full.view-set .body, .full.view-loop .body { grid-template-columns: minmax(0, 760px); }
    .full.view-set .o6 > summary, .full.view-loop .o6 > summary { display: none; }
    .full.view-set .grp.g-loop, .full.view-loop .grp.g-set { display: none; }
    .full.view-con .dash, .full.view-dev .dash { display: grid; align-content: start; }
    .full.view-con .body, .full.view-dev .body { display: none; }
    .full.view-dash .dash > .dtoolbox.con, .full.view-dash .dash > .dtoolbox.dev { display: none; }
    .full.view-con .dash > :not(.dtoolbox.con):not(.lstat), .full.view-dev .dash > :not(.dtoolbox.dev):not(.lstat) { display: none; }
    .full.view-con .dtoolbox.con > summary, .full.view-dev .dtoolbox.dev > summary { display: none; }
    .full.view-con .ncon { height: calc(100vh - 250px); max-height: none; resize: none; }
`;
  const sheetCleanup = (() => {
    try { const s = new CSSStyleSheet(); s.replaceSync(CSS); root.adoptedStyleSheets = [s]; return () => {}; }
    catch (_) { const el = document.createElement('style'); el.textContent = CSS; root.appendChild(el); return () => el.remove(); }
  })();
  const shell = document.createElement('div');
  shell.className = 'wrap';
  root.appendChild(shell);
  const $ = s => root.querySelector(s);

  const ACT = { find: 'find', pick: 'pick', cancel: 'cancel', save: 'save', load: 'load', clearall: 'clearall', debug: 'debug' };
  const q = k => `<button type="button" class="q" data-help="${k}" aria-label="?" title="?">?</button>`;
  const bq = (k, label, cls, extra = '') => `<span class="bq"><button data-act="${k}" class="${cls}"${extra}>${label}</button>${q(k)}</span>`;

  function buildUi() {
    const t = tr();
    shell.innerHTML = `
      <button class="fab" title="${t.title}" aria-label="${t.title}">\u{1F4D8}</button>
      <section class="panel">
        <header class="head" data-hb><strong>${t.title}</strong><nav class="tabs"><button data-act="vsel" class="tab">${t.tabSel}</button><button data-act="vdash" class="tab">${t.tabDash}</button><button data-act="vloop" class="tab">${t.tabLoop}</button><button data-act="vcon" class="tab">${t.tabCon}</button><button data-act="vexp" class="tab">${t.tabExp}</button><button data-act="vset" class="tab">${t.tabSet}</button><button data-act="vdev" class="tab">${t.tabDev}</button></nav><span><label class="sw" data-hb-skip><span>\u2600</span><input type="checkbox" class="thm"><i></i><span>\u{1F319}</span></label><button data-act="dashopen" title="${t.dashOpen}" aria-label="${t.dashOpen}">\u{1F4CA}</button><button data-act="lang">${t.lang}</button><button data-act="help" class="helpbtn" title="${t.helpTip}" aria-label="${t.helpTip}">?</button><button data-act="min" title="${t.min}" aria-label="${t.min}">\u2013</button><button data-act="unload" title="${t.unload}" aria-label="${t.unload}">\u2715</button></span></header>
        <div class="body">
          <div class="col1">
            <div class="card o0">
              <div class="row" data-hb><select class="year" aria-label="${t.year}"></select>${q('year')}<button data-act="reload" class="icon" title="${t.reload}" aria-label="${t.reload}">\u21BB</button>${q('reload')}</div>
              <div class="periods" data-hb></div>
              <div class="sum hint"></div>
              <div class="row" data-hb><label class="dnote">${t.yearLbl} ${yearSel('syear')}</label>${q('syear')}</div>
            </div>
            <div class="field o1" data-hb><div class="qrow"><span class="lbl">${t.list}</span>${q('list')}</div><textarea class="list" placeholder="${t.ph}" spellcheck="false"></textarea></div>
            <div class="row o4" data-hb>${bq('find', '\u{1F50D} ' + t.find, 'b-find')}${bq('pick', '\u2714 ' + t.pick, 'b-pick')}${bq('cancel', '\u2716 ' + t.cancel, 'b-cancel', ' disabled')}</div>
            <div class="row o4" data-hb>${bq('loop', '\u{1F501} ' + t.loop, 'b-loop')}</div>
            <div class="log o5" aria-live="polite">${t.dry}</div>
          </div>
          <div class="col2">
            <div class="o2"><div class="qrow" data-hb><span class="lbl">${t.course} \u2192 ${t.period}</span>${q('plan')}</div><div class="plan"></div></div>
            <details class="o6"><summary>${t.more}</summary>
              <div class="more">
                <div class="grp g-set">
                <div class="timebar o3" data-hb>
              <label class="field grow"><span>${t.at}</span><input class="at" placeholder="16:00:00"></label>${q('at')}
              <label class="chk" title="${t.refreshHint}"><input type="checkbox" class="rf" data-opt="refresh"> ${t.refresh}</label>${q('refresh')}
            </div>
                <div class="row" data-hb>${bq('save', '\u{1F4BE} ' + t.save, 'b-save')}${bq('load', '\u{1F4C2} ' + t.load, 'b-load')}</div>
                <div class="row" data-hb>${bq('cfgsave', '\u2699 ' + t.cfgsave, 'b-save')}${bq('cfgload', '\u{1F4E5} ' + t.cfgload, 'b-load')}</div>
                <div class="row" data-hb>${bq('pdf', '\u{1F4C4} ' + t.pdfBtn, 'b-save')}</div>
                <div class="row" data-hb>${bq('clearall', '\u{1F5D1} ' + t.clearAll, 'b-clear')}${bq('debug', '\u{1F41E} ' + t.dbg, 'b-debug')}</div>
                <div class="qrow" data-hb><label class="field"><span>${t.conc}</span><input class="conc" type="number" min="1" max="10"></label>${q('conc')}</div>
                </div>
                <div class="grp g-loop">
                <div class="qrow" data-hb><label class="field"><span>${t.ltabs}</span><input class="ltabs" type="number" min="1" max="10"></label>${q('ltabs')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="lwin" data-opt="lwin"> ${t.lwin}</label>${q('lwin')}</div>
                <div class="qrow" data-hb><label class="field"><span>${t.ldelay}</span><input class="ldelay" type="number" min="0.3" max="60" step="0.1"></label>${q('ldelay')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="lkeep" data-opt="lkeep"> ${t.lkeep}</label>${q('lkeep')}</div>
                <div class="qrow" data-hb><label class="field"><span>${t.lmax}</span><input class="lmax" type="number" min="1" max="240"></label>${q('lmax')}</div>
                </div>
                <div class="grp g-set">
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="lite" data-opt="lite"> ${t.lite}</label>${q('lite')}</div>
                <details class="authbox" data-rid="auth"${state.dopen.auth ? ' open' : ''}><summary>\u{1F511} ${t.authTitle}</summary>
                  <div class="hint">${t.authWarn}</div>
                  <div class="qrow" data-hb><label class="field"><span>${t.authUser}</span><input class="cuser" autocomplete="username" spellcheck="false"></label></div>
                  <div class="qrow" data-hb><label class="field"><span>${t.authPass}</span><input class="cpass" type="password" autocomplete="current-password"></label>${q('auth')}</div>
                  <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="cauto" data-opt="cauto"> ${t.authAuto}</label>${q('authauto')}</div>
                  <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="cremember" data-opt="cremember"> ${t.authRemember}</label>${q('authremember')}</div>
                  <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="cka" data-opt="cka"> ${t.authKeep}</label>${q('authkeep')}</div>
                  <div class="row" data-hb><button type="button" class="b-clear" data-act="cclear">${t.authClear}</button></div>
                  <div class="hint">${t.authStatus}: <span class="cstat"></span></div>
                </details>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="wq" data-opt="wq"> ${t.wq}</label>${q('wq')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="always" data-opt="always"> ${t.always}</label>${q('always')}</div>
                <div class="qrow" data-hb><label class="chk" title="${t.armHint}"><input type="checkbox" class="arm" data-opt="arm"> ${t.arm}</label>${q('arm')}</div>
                <div class="hint">${t.hint}</div>
                </div>
              </div>
            </details>
          </div>
          <input class="file" type="file" accept=".txt,.json,text/plain,application/json" hidden>
          <input class="cfile" type="file" accept=".json,application/json" hidden>
        </div>
        <div class="dash"></div>
        <footer class="pbar" aria-live="polite"></footer>
        <div class="rz" title="${t.rzTip}" aria-label="${t.rzTip}"></div>
      </section>`;
    $('.list').value = state.list; $('.at').value = state.at; $('.conc').value = state.conc; $('.ltabs').value = state.ltabs; $('.lkeep').checked = !!state.lkeep; paintLoop(); $('.ldelay').value = state.ldelay; $('.lmax').value = state.lmax; $('.arm').checked = !!state.arm; $('.always').checked = !!state.always; $('.wq').checked = !!state.wq; $('.rf').checked = !!state.refresh; $('.cauto').checked = !!state.cauto; $('.cremember').checked = !!state.cremember; $('.cka').checked = state.cka !== false; $('.lwin').checked = state.lwin !== false; loadCredsUI();
    $('.panel').hidden = !state.open; $('.fab').hidden = state.open;
    fillYears(true); renderPlan(); renderDash(); applyLite(); applyTitles(); applyTheme(); shell.classList.toggle('full', full); paintView();
    makeDraggable($('.fab'), () => { state.open = true; save(); $('.panel').hidden = false; $('.fab').hidden = true; });
    makeDraggable($('.head'));
    applySize();
    const rz = $('.rz');
    rz.addEventListener('pointerdown', e => {
      if (full || e.button !== 0) return;
      e.preventDefault();
      const r = $('.panel').getBoundingClientRect(), hr = host.getBoundingClientRect();
      state.x = Math.round(hr.left); state.y = Math.round(hr.top); // anchor top-left so the panel grows right and down
      Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
      const sx = e.clientX, sy = e.clientY, w0 = r.width, h0 = r.height, x0 = state.x, y0 = state.y;
      rz.setPointerCapture(e.pointerId);
      const mv = ev => {
        state.w = Math.round(Math.max(300, Math.min(innerWidth - 8, w0 + ev.clientX - sx)));
        state.h = Math.round(Math.max(220, Math.min(innerHeight - 8, h0 + ev.clientY - sy)));
        state.x = Math.max(4, Math.min(x0, innerWidth - state.w - 4)); state.y = Math.max(4, Math.min(y0, innerHeight - state.h - 4)); // at the screen edge it grows the other way
        Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px' });
        applySize();
      };
      const up = () => { rz.removeEventListener('pointermove', mv); rz.removeEventListener('pointerup', up); save(); };
      rz.addEventListener('pointermove', mv); rz.addEventListener('pointerup', up);
    });
    rz.addEventListener('dblclick', () => { state.w = 0; state.h = 0; applySize(); save(); });
  }
  function applySize() {
    const p = $('.panel'); if (!p) return;
    if (full || !state.w) { p.style.width = ''; p.style.height = ''; p.style.maxHeight = ''; return; }
    p.style.width = state.w + 'px'; p.style.height = state.h ? state.h + 'px' : ''; p.style.maxHeight = state.h ? 'none' : '';
  }

  // ---------- state ----------
  let years = [], viewUrl = '', plan = [], busy = false, cancelled = false, periodSel = new Set(), savedChoices = new Map(), savedCodes = new Map(), savedFilters = new Map(), restored = false, autoDone = false, full = false, wqTimer = 0, view = 'sel';
  const log = (msg, append) => { const el = $('.log'); el.textContent = append ? el.textContent + '\n' + msg : msg; el.scrollTop = el.scrollHeight; const xm = $('.xmsg'); if (xm) xm.textContent = String(msg).split('\n')[0]; };
  // Timers that keep their pace in a background window: a hidden page's own timers are slowed to about one a second (one a minute after
  // five minutes), a Worker's are not. If the page does not allow a Worker, plain timers are used and nothing else changes.
  const tick = (() => {
    let w = null, off = false, seq = 0; const cb = new Map();
    const stop = () => {
      off = true; try { if (w) w.terminate(); } catch (_) { /* ignore */ } w = null;
      cb.forEach(e => setTimeout(e.fin, Math.max(0, e.until - Date.now()))); cb.clear(); // whoever is waiting still waits the rest of the time
    };
    const make = () => {
      try {
        w = new Worker(URL.createObjectURL(new Blob(['onmessage=function(e){var d=e.data;setTimeout(function(){postMessage(d[0])},d[1])}'], { type: 'text/javascript' })));
        w.onmessage = e => { const x = cb.get(e.data); if (x) x.fin(); };
        w.onerror = stop;
      } catch (_) { off = true; w = null; }
    };
    const run = ms => new Promise(res => {
      if (!off && !w) make();
      if (off || !w) { setTimeout(res, ms); return; }
      const id = ++seq; let tm = 0;
      const fin = () => { cb.delete(id); clearTimeout(tm); res(); };
      cb.set(id, { fin, until: Date.now() + ms });
      tm = setTimeout(stop, ms + 1500); // the Worker never answered (the page may forbid it): stop relying on it
      try { w.postMessage([id, ms]); } catch (_) { stop(); }
    });
    run.info = () => ({ worker: !!w, off });
    run.stop = stop;
    return run;
  })();
  const sleep = ms => (ms >= 4 ? tick(ms) : new Promise(r => setTimeout(r, ms)));
  const setBusy = b => { busy = b; cancelled = false; root.querySelectorAll('[data-act=find],[data-act=pick],[data-act=reload]').forEach(x => { x.disabled = b; }); $('[data-act=cancel]').disabled = !b; };

  // "MAA02@1a" (or the period dropdown of a row) limits a course to periods whose label contains "1a".
  const pnorm = s => norm(s).replace(/periodi|jakso|period|[\s.]/g, '');
  function makeRow(token, index, prev, onlyPrev) {
    const [code, tail] = token.split('@');
    const only = tail ? tail.trim() : onlyPrev;
    const all = matchCourse(code, index);
    const cands = only ? all.filter(c => pnorm(c.period).includes(pnorm(only))) : all;
    const i = cands.findIndex(c => c.target === prev.get(norm(token)));
    return { token, all, only, cands, choice: i >= 0 ? i : best(cands) };
  }

  // Lower rank = better default when a short code matches several groups.
  const rank = c => (c.selected ? -1 : 0) + (c.closed ? 8 : 0) + (c.done ? 4 : 0) + (c.full || c.off ? 2 : 0);
  const best = cands => cands.reduce((b, c, i) => (rank(c) < rank(cands[b]) ? i : b), 0);
  const flagsOf = c => { const t = tr(); return [c.selected && t.fSel, c.done && t.fDone, c.full && t.fFull, !c.full && c.off && t.fOff, c.closed && t.fClosed].filter(Boolean); };

  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const yearKey = y => y.school + '|' + y.title;
  const curYear = () => years[+$('.year').value];

  // Selected periods are kept across years and schools. The first time a year is shown, its open periods are ticked
  // automatically (all of them if none is open, so Find still works); after that your own ticks are left alone.
  const visited = new Set();
  // remember the period ticks and group choices, so they survive a page refresh
  const persist = () => { state.per = [...periodSel]; state.choices = Object.fromEntries(plan.filter(p => p.cands.length).map(p => [p.token, p.cands[p.choice].target]));
    state.filters = Object.fromEntries(plan.filter(p => p.only).map(p => [p.token, p.only])); save(); };
  const disarm = () => { state.arm = false; state.fast = false; state.rt = 0; save(); const a = $('.arm'); if (a) a.checked = false; };
  function autoPeriods() {
    const y = curYear();
    if (y && !visited.has(yearKey(y))) {
      visited.add(yearKey(y));
      const open = y.periods.filter(p => !p.closed);
      (open.length ? open : y.periods).forEach(p => periodSel.add(p.href));
      persist();
    }
    renderPeriods();
  }
  const selectedYears = () => years.filter(z => z.periods.some(p => periodSel.has(p.href)));
  function renderPeriods() {
    const y = curYear(), t = tr();
    const sum = selectedYears().map(z => `${z.school ? z.school + ' ' : ''}${z.title} (${z.periods.filter(p => periodSel.has(p.href)).length})`).join(', ');
    $('.sum').innerHTML = `${t.selSummary}: ${esc(sum || '–')} ${sum ? `<button data-act="clearper" class="lnk">${t.clear}</button>` : ''}`;
    $('.periods').innerHTML = y ? `<span class="lbl">${t.periods}</span>${q('periods')}` + y.periods.map((p, i) =>
      `<label class="chk" title="${esc(p.note)}"><input type="checkbox" data-per="${i}"${periodSel.has(p.href) ? ' checked' : ''}>${esc(p.short)}${p.closed ? ` <i>(${t.fClosed})</i>` : ''}</label>`).join('') : '';
    applyTitles($('.periods'));
  }

  // Years grouped by school. The remembered year wins; otherwise the first year that still has an open period.
  function fillYears(keep) {
    const sel = $('.year'), groups = new Map();
    years.forEach((y, i) => {
      const g = y.school || tr().otherSchool;
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(`<option value="${i}">${esc(y.title)}</option>`);
    });
    sel.innerHTML = [...groups].map(([g, opts]) => `<optgroup label="${esc(g)}">${opts.join('')}</optgroup>`).join('');
    let i = years.findIndex(y => yearKey(y) === state.year);
    if (i < 0) i = years.findIndex(y => y.title === state.year); // older saved format: title only
    if (i < 0) i = years.findIndex(y => y.periods.some(p => !p.closed));
    if (i < 0 && years.length) i = 0;
    if (i >= 0) sel.value = String(i);
    if (keep) renderPeriods(); else autoPeriods();
  }
  // one load at a time: whoever asks while a load is under way gets that same one
  let yearsP = null;
  function reloadYears() { return yearsP || (yearsP = loadYearsUi().finally(() => { yearsP = null; })); }
  async function loadYearsUi() {
    log(tr().loadingYears);
    try {
      const r = await loadYears();
      years = r.years; viewUrl = r.viewUrl;
      if (!restored) { // first load after a refresh: bring back the saved periods and group choices
        restored = true;
        const known = new Set(years.flatMap(z => z.periods.map(p => p.href))), keep = (state.per || []).filter(h => known.has(h));
        if (keep.length) { periodSel = new Set(keep); years.forEach(z => visited.add(yearKey(z))); savedChoices = new Map(Object.entries(state.choices || {})); savedFilters = new Map(Object.entries(state.filters || {})); }
      }
      fillYears();
      if (!years.length) log(tr().noYears); else if ($('.log').textContent === tr().loadingYears) log('');
      if (!autoDone) {
        autoDone = true;
        if (state.fast && state.rt && Date.now() - state.rt > 600000) disarm(); // a stale timed refresh is dropped
        if (!state.arm && state.always && state.list.trim() && years.length && /selection/.test(location.pathname)) setTimeout(() => actions.auto(), 0);
        if (/#wk-loop/.test(location.hash) && !loopActive() && !readLoop().why) loopBegin(false);
        if (loopActive() && years.length && /selection/.test(location.pathname)) { setTimeout(loopRun, 0); return; }
        if (state.arm && years.length && (state.fast || /selection/.test(location.pathname))) setTimeout(() => (state.fast && state.rt > Date.now() ? actions.resume() : actions.auto()), 0);
      }
    } catch (e) { log(String(e.message || e)); if (loopActive()) setTimeout(() => { if (loopActive() && !busy) refresh('virhe, yritetään uudelleen'); }, Math.max(2000, (+readLoop().delay || 2) * 1000)); }
  }

  function renderPlan() {
    paintProg();
    const t = tr(), box = $('.plan');
    if (!plan.length) { box.innerHTML = ''; return; }
    const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const kd = p => { const r = rowOf(baseOf(String(p.token).split('@')[0]), state.req); return `<i class="kd k${r ? 'm' : 'v'}" title="${esc((D[state.lang] || D.en)[r ? 'man' : 'opt'])}"></i>`; };
    box.innerHTML = `<table><tr><th>${t.course}</th><th>${t.status}</th></tr>${plan.map((p, i) => {
      const ab = aboveYear(baseOf(String(p.token).split('@')[0])) ? ' class="above"' : '';
      if (!p.cands.length) return `<tr${ab}><td>${kd(p)}${esc(p.token)}</td><td class="bad">${p.all.length ? t.missingIn : t.missing}</td></tr>`;
      const multiPeriod = new Set(p.cands.map(c => c.period)).size > 1;
      const label = (c, withTeacher) => [c.code, withTeacher && c.teacher, (multiPeriod || !withTeacher) && c.period, flagsOf(c).join(', ')].filter(Boolean).join(' \u00B7 ');
      const periodsAll = [...new Set(p.all.map(c => c.period))];
      const sel = periodsAll.find(x => p.only && pnorm(x).includes(pnorm(p.only))) || '';
      const pf = periodsAll.length > 1 ? `<select class="pf" data-pf="${i}" title="${t.pfTitle}"><option value="">${t.pfAll}</option>${periodsAll.map(x => `<option value="${esc(x)}"${x === sel ? ' selected' : ''}>${esc(x)}</option>`).join('')}</select>` : '';
      if (p.cands.length === 1) return `<tr${ab}><td>${kd(p)}${esc(p.token)}</td><td class="${rank(p.cands[0]) > 1 ? 'warn' : 'ok'}" title="${esc(p.cands[0].title)}"><div class="cell"><span>${esc(label(p.cands[0], false))}</span>${pf}</div></td></tr>`;
      return `<tr${ab}><td>${kd(p)}${esc(p.token)}</td><td><div class="cell"><select data-row="${i}" title="${t.choose}">${p.cands.map((c, j) =>
        `<option value="${j}" title="${esc(c.title)}"${j === p.choice ? ' selected' : ''}>${esc(label(c, true))}</option>`).join('')}</select>${pf}</div></td></tr>`;
    }).join('')}</table>`;
  }

  // Build the plan: scan every period of the chosen year and match the typed codes.
  async function find(quiet, o) {
    const t = tr();
    const tokens = parseCodes($('.list').value);
    if (!tokens.length) { plan = []; renderPlan(); log(t.nothing); return false; }
    if (!years.length) await reloadYears();
    const y = curYear();
    if (!y) { log(t.noYears); return false; }
    if (state.year !== yearKey(y)) { state.year = yearKey(y); save(); }
    const multi = selectedYears().length > 1; // periods of several schools/years: say which one each course is in
    const periods = years.flatMap(z => z.periods.filter(p => periodSel.has(p.href)).map(p => ({ ...p, short: multi ? [z.school, z.title, p.short].filter(Boolean).join(' · ') : p.short, school: z.school, year: z.title })));
    if (!periods.length) { log(t.noPeriods); return false; }
    if (!quiet) log(t.scanning(periods.length));
    const index = await scanPeriods(periods, viewUrl, quiet ? null : (a, b) => log(t.scanning(b) + ' ' + a + '/' + b), o);
    lastScanErrors = index.errors || [];
    // keep the group the user already chose in a dropdown when the list is re-scanned
    const prev = new Map(plan.map(p => [norm(p.token), p.cands[p.choice] && p.cands[p.choice].target]));
    savedChoices.forEach((target, tok) => { if (!prev.has(norm(tok))) prev.set(norm(tok), target); }); // choices loaded from a file
    const prevOnly = new Map(plan.map(p => [norm(p.token), p.only]));
    savedFilters.forEach((v, k) => { if (!prevOnly.has(norm(k))) prevOnly.set(norm(k), v); });
    plan = tokens.map(token => makeRow(token, index, prev, prevOnly.get(norm(token)) || ''));
    if (savedCodes.size) plan.forEach(p => { // group choices from a text file: by group code (and period, when the same code exists in several)
      const g = savedCodes.get(norm(p.token)); if (!g) return;
      let i = p.cands.findIndex(c => norm(c.code) === norm(g.code) && g.period && norm(c.period) === norm(g.period));
      if (i < 0) i = p.cands.findIndex(c => norm(c.code) === norm(g.code));
      if (i >= 0) { p.choice = i; savedCodes.delete(norm(p.token)); }
    });
    if (quiet) { paintProg(); return true; }
    renderPlan(); persist();
    const hit = plan.filter(p => p.cands.length).length;
    log(t.found(hit, plan.length) + (index.errors ? '\n' + index.errors.join('\n') : '') + (index.length ? '' : '\n(0 course links on those pages)'));
    return true;
  }

  async function waitUntil(when, skipLines, label) {
    const t = tr();
    while (Date.now() < when.getTime()) {
      if (cancelled) return false;
      const s = Math.ceil((when.getTime() - Date.now()) / 1000);
      log([...skipLines, (label || t.waiting)(`${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`)].join('\n'));
      await sleep(Math.min(100, Math.max(1, when.getTime() - Date.now())));
    }
    return !cancelled;
  }

  async function pick() {
    const t = tr();
    if (!await find()) return;
    const chosen = [...new Map(plan.filter(p => p.cands.length).map(p => [p.cands[p.choice].target, p.cands[p.choice]])).values()];
    const targets = [], skipLines = [];
    for (const c of chosen) {
      const why = c.closed ? t.skipClosed : c.selected ? t.skipSel : '';
      if (why) skipLines.push(`– ${c.code}  ${why}`); else targets.push(c);
    }
    if (!targets.length) { log([...skipLines, t.nothing].join('\n'), true); return; }
    const key = await getFormkey();
    if (!key) { log(t.noKey, true); return; }
    const when = state.at.trim() ? parseTime(state.at) : null;
    if (state.at.trim() && !when) { log(t.badTime, true); return; }
    if (when && state.refresh && when.getTime() > Date.now()) { // refresh the page at that time; the saved setup then picks right after the load
      state.arm = true; state.fast = true; state.rt = when.getTime(); persist();
      if (!(await waitUntil(when, skipLines, t.reloadAt))) { disarm(); log(t.cancelled, true); return; }
      refresh('ajastettu päivitys'); return;
    }
    if (when && !(await waitUntil(when, skipLines))) { log(t.cancelled, true); return; }
    log([...skipLines, t.sending(targets.length)].join('\n'));
    const t0 = performance.now();
    const res = await pool(targets, state.conc, async c => {
      if (cancelled) return { ok: false, status: 0, text: t.cancelled };
      try { return await pickGroup(c.target, key); } catch (e) { return { ok: false, status: 0, text: String(e.message || e) }; }
    });
    res.forEach((r, i) => log(`${r.ok ? '✓' : '✗'} ${targets[i].code}  HTTP ${r.status}  ${r.text}`, true));
    const ok = res.filter(r => r.ok).length;
    log(t.done(ok, res.length - ok) + ` (${((performance.now() - t0) / 1000).toFixed(1)} s)`, true);
  }

  // Read-only structure report for checking the selectors against the real site. Sends no POST,
  // never prints the formkey value, and strips the "!slug" from paths.
  async function debug() {
    const t = tr(), out = [];
    const clean = (s, n = 260) => String(s).replace(/\s+/g, ' ').replace(/\/![^/"'\s]+/g, '/!SLUG')
      .replace(/Opettaja:[^"]*?(?=\s*(?:Ryhmä on|Tämä kurssi)|")/g, 'Opettaja: … ').replace(/Arvosana:\s*[^\s"]+/g, 'Arvosana: …').slice(0, n);
    const chain = el => { const r = []; for (let e = el, i = 0; e && i < 5; e = e.parentElement, i++) r.push(e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (typeof e.className === 'string' && e.className.trim() ? '.' + e.className.trim().split(/\s+/).join('.') : '')); return r.join(' < '); };
    const courseLinks = doc => [...doc.querySelectorAll('a[href]')].filter(a => isCourseCode(a.textContent.trim()));
    // Compact tag/class skeleton of an element (repeated siblings collapsed as *n), to see how the tray is nested.
    const skel = (el, d) => {
      const cls = typeof el.className === 'string' ? el.className.trim().split(/\s+/).filter(c => c && !/^k\S+-(on|off)$/.test(c)) : [];
      const name = el.tagName.toLowerCase() + (cls.length ? '.' + cls.join('.') : '');
      const kids = [...el.children];
      if (!kids.length) return name + (el.tagName !== 'A' && el.textContent.trim() ? '"' + el.textContent.trim().slice(0, 18) + '"' : '');
      if (d === 0) return name + '[…]';
      const groups = [];
      kids.forEach(k => { const s = skel(k, d - 1), last = groups[groups.length - 1]; if (last && last.s === s) last.n++; else groups.push({ s, n: 1 }); });
      return name + '[' + groups.map(g => g.s + (g.n > 1 ? '*' + g.n : '')).join(', ') + ']';
    };
    const stateCls = a => ' ' + (a.getAttribute('class') || '') + ' ';
    out.push('wilma-kurssit debug ' + new Date().toISOString(), 'page: ' + clean(location.pathname), 'formkey input on this page: ' + (document.querySelector('input[name=formkey]') ? 'yes' : 'no'));
    let view = null;
    try {
      view = await getDoc(url('selection/view'));
      const d = view.doc, own = d.querySelector('#own-schools');
      out.push('selection/view: OK (' + clean(view.url) + ')', '  title: ' + clean(d.title), '  #own-schools: ' + (own ? 'yes' : 'NO'),
        '  h4: ' + d.querySelectorAll('h4').length + ', ul: ' + d.querySelectorAll('ul').length + ', links containing "selection": ' + d.querySelectorAll('a[href*="selection"]').length,
        '  formkey input: ' + (d.querySelector('input[name=formkey]') ? 'yes' : 'no'));
      [...(own || d).querySelectorAll('a[href]')].slice(0, 4).forEach(a => out.push('  link: ' + clean(a.outerHTML)));
    } catch (e) { out.push('selection/view: FAILED ' + clean(e.message || e)); }
    const y = curYear() || years[0];
    const per0 = y && (y.periods.find(p => periodSel.has(p.href)) || y.periods[0]);
    out.push('parsed years: ' + years.length + '; schools: ' + ([...new Set(years.map(z => z.school || '(unknown)'))].join(' | ') || '-'),
      '  year containers (id x count): ' + [...years.reduce((m, z) => m.set(z.section || '(no id)', (m.get(z.section || '(no id)') || 0) + 1), new Map())].map(([k, n]) => k + 'x' + n).join(', '),
      '  selects on selection/view: ' + ([...(view ? view.doc : document).querySelectorAll('select')].slice(0, 6).map(s => (s.id || s.name || '?') + '(' + s.options.length + ')').join(', ') || 'none'));
    if (y) out.push('year "' + clean(y.title) + '": ' + y.periods.length + ' periods, ' + y.periods.filter(p => p.closed).length + ' closed');
    if (view && y && per0) {
      try {
        const { doc } = await getDoc(new URL(per0.href, view.url).href), links = courseLinks(doc);
        out.push('period page "' + clean(per0.label) + '": OK', '  all links: ' + doc.querySelectorAll('a[href]').length + ', course-like links: ' + links.length,
          '  formkey input: ' + (doc.querySelector('input[name=formkey]') ? 'yes' : 'no'));
        links.slice(0, 5).forEach(a => out.push('  course: ' + clean(a.outerHTML)));
        if (links[0]) out.push('  first course parents: ' + clean(chain(links[0])));
        // What is a "palkki"? Group the links by their class key and by their <li class="palkki"> container.
        const keyOf = a => { const m = /\sk(?!suor)(\S+)-(?:on|off)\s/.exec(stateCls(a)); return m ? m[1] : '(none)'; };
        const byKey = new Map();
        links.forEach(a => { const k = keyOf(a); if (!byKey.has(k)) byKey.set(k, []); byKey.get(k).push(a.textContent.trim()); });
        out.push('  distinct class keys: ' + byKey.size);
        [...byKey].sort((x, z) => z[1].length - x[1].length).slice(0, 14).forEach(([k, v]) => out.push('    key ' + k + ' (' + v.length + '): ' + v.slice(0, 12).join(' ')));
        const pat = new Map();
        links.forEach(a => {
          const p = (a.getAttribute('class') || '').trim().split(/\s+/).filter(Boolean).map(c => (/^k(?!suor)\S+-(on|off)$/.test(c) ? 'k*-' + c.slice(c.lastIndexOf('-') + 1) : c)).sort().join(' ') || '(no class)';
          pat.set(p, (pat.get(p) || 0) + 1);
        });
        out.push('  class patterns: ' + [...pat].map(([p, n]) => n + 'x "' + p + '"').join(' | '));
        const pal = [...doc.querySelectorAll('li.palkki')];
        out.push('  li.palkki: ' + pal.length + '; course links inside each (first 12): ' + pal.slice(0, 12).map(p => courseLinks(p).length).join(','));
        const sel = links.filter(a => /\sk(?!suor)\S+-on\s/.test(stateCls(a)));
        out.push('  selected-looking links (k*-on): ' + sel.length);
        sel.slice(0, 3).forEach(a => out.push('    ' + clean(a.outerHTML)));
        const top = doc.querySelector('ul.tray-topmost');
        out.push('  ul.tray-topmost: ' + (top ? top.children.length + ' items' : 'NOT FOUND'));
        if (top) [...top.children].slice(0, 2).forEach((li, i) => out.push('  tray item ' + i + ': ' + clean(skel(li, 6), 600)));
      } catch (e) { out.push('period page: FAILED ' + clean(e.message || e)); }
    } else out.push('period page: skipped (no year/period found)');
    try {
      const links = await findLinks();
      out.push('nav links: suoritukset=' + clean(links.done || '-') + ' hops=' + clean(links.hops || '-'));
      for (const [name, u] of [['suoritukset', links.done], ['hops', links.hops]]) {
        if (!u) continue;
        try {
          const { doc } = await getDoc(u);
          out.push(name + ' page: OK title=' + clean(doc.title) + '; tables ' + doc.querySelectorAll('table').length + ', forms ' + doc.querySelectorAll('form').length + ', rows ' + doc.querySelectorAll('tr').length);
          [...doc.querySelectorAll('table')].slice(0, 3).forEach((tb, i) => {
            out.push('  table ' + i + ' head: ' + [...tb.querySelectorAll('th')].slice(0, 10).map(x => clean(x.textContent, 24)).join(' | '));
            [...tb.querySelectorAll('tr')].filter(r => !r.querySelector('th')).slice(0, 3).forEach(r => out.push('    row: ' + [...r.children].slice(0, 10).map(c => clean(c.textContent, 24)).join(' | ')));
          });
          out.push('  forms: ' + ([...doc.querySelectorAll('form')].slice(0, 3).map(f => clean(f.outerHTML, 220)).join(' || ') || '-'));
          out.push('  add/remove controls: ' + ([...doc.querySelectorAll('a[href],button,input[type=submit]')].filter(x => /lisää|lisaa|add|poista|tallenna|spara/i.test(x.textContent + (x.value || ''))).slice(0, 6).map(x => clean(x.outerHTML, 200)).join(' || ') || '-'));
          if (name === 'hops') [...doc.querySelectorAll('table')].filter(tb => CODE_RE.test(tb.textContent.replace(/\s+/g, ' ').trim())).filter((_, i) => i < 2 || i === 40).forEach((tb, i) => out.push('  course table ' + i + ' html: ' + clean(tb.outerHTML, 900)));
          out.push('  skeleton: ' + clean(skel(doc.body, 5), 500));
        } catch (e) { out.push(name + ' page: FAILED ' + clean(e.message || e)); }
      }
      out.push('link texts on this page: ' + [...document.querySelectorAll('a[href]')].map(a => a.textContent.replace(/\s+/g, ' ').trim()).filter(x => x && x.length < 24).slice(0, 60).join(' | '));
    } catch (e) { out.push('links: FAILED ' + clean(e.message || e)); }
    const text = out.join('\n');
    log(text);
    let copied = false;
    try { await navigator.clipboard.writeText(text); copied = true; } catch (_) { /* fall through */ }
    log('\n' + (copied ? t.dbgDone : t.dbgShown), true);
  }

  // One-shot: after a refresh on a selection page, count down 3 s (Cancel stops it), then Find + Pick with the saved setup.
  async function autoRun() {
    const t = tr();
    if (!state.fast) for (let n = 3; n > 0; n--) { if (cancelled) { log(t.cancelled); return; } log(t.autoIn(n)); await sleep(1000); } // a timed refresh starts at once
    if (cancelled) { log(t.cancelled); return; }
    disarm(); // never fires twice
    await pick();
  }

  const run = fn => async () => { if (busy) return; setBusy(true); try { await fn(); } catch (e) { log(String(e && e.message || e), true); } finally { setBusy(false); } };

  // ---------- events ----------
  const actions = {
    pdf: exportPdf, csv: exportCsv, copylist: copyList, vexp: () => setView('exp'),
    find: run(find), pick: run(pick), reload: run(reloadYears), debug: run(debug),
    clearper: () => { periodSel.clear(); years.forEach(z => visited.add(yearKey(z))); plan = []; renderPlan(); renderPeriods(); persist(); },
    auto: run(autoRun), dscan: run(dashScan),
    dprest: run(async () => { const e = $('.dlog'); const msg = await fetchDone(await findLinks()); renderDash(); const l = $('.dlog'); if (l) { l.hidden = false; l.textContent = msg; } }),
    dhops: run(async () => { const msg = await fetchHops(await findLinks()); renderDash(); const l = $('.dlog'); if (l) { l.hidden = false; l.textContent = msg; } }),
    vsel: () => setView('sel'), vdash: () => setView('dash'), vloop: () => setView('loop'), vcon: () => setView('con'), vset: () => setView('set'), vdev: () => setView('dev'),
    dashopen: () => { window.open(location.origin + basePath() + '/selection/view#wk-full-dash', '_blank'); },
    resume: run(async () => { if (!(await waitUntil(new Date(state.rt), [], tr().reloadAt))) { disarm(); log(tr().cancelled); return; } refresh('ajastettu päivitys'); }),
    clearall: () => { // wipe everything the tool remembers; language and window position stay
      cancelled = true; plan = []; savedChoices = new Map(); savedCodes = new Map(); periodSel.clear(); years.forEach(z => visited.add(yearKey(z)));
      savedFilters = new Map(); state.list = ''; state.arm = false; state.fast = false; state.rt = 0; state.per = []; state.choices = {}; state.filters = {}; state.year = ''; state.manual = {}; state.ignore = {}; state.dopen = {}; state.seen = {}; state.req = JSON.parse(JSON.stringify(DEFAULT_REQ)); state.hiddenReq = []; save(); renderDash();
      $('.list').value = ''; $('.at').value = ''; $('.arm').checked = false; $('.file').value = '';
      renderPlan(); renderPeriods(); log(tr().allCleared);
    },
    save: () => {
      const L = ({ fi: ['Jaksot', 'Kurssit', 'rajaus', 'valittu', 'Wilma-kurssivalinnat', 'Tallennettu', 'Voit muokata tätä tiedostoa käsin. Rivit, jotka alkavat #-merkillä, ohitetaan.', 'Kurssirivi: koodi | rajaus: jakso, johon haku rajataan | valittu: ryhmä (jakso)'],
        en: ['Periods', 'Courses', 'only', 'chosen', 'Wilma course selection', 'Saved', 'You can edit this file by hand. Lines starting with # are ignored.', 'Course line: code | only: period to limit the search to | chosen: group (period)'],
        sv: ['Perioder', 'Kurser', 'endast', 'vald', 'Wilma-kursval', 'Sparad', 'Du kan redigera filen för hand. Rader som börjar med # ignoreras.', 'Kursrad: kod | endast: period att begränsa till | vald: grupp (period)'] })[state.lang] || [];
      const d = new Date(), p2 = n => String(n).padStart(2, '0'), stamp = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
      const periods = years.flatMap(z => z.periods.filter(p => periodSel.has(p.href)).map(p => `  - ${z.title} / ${p.label}`));
      const byTok = new Map(plan.map(p => [norm(p.token), p]));
      const courses = parseCodes($('.list').value).map(tok => {
        const p = byTok.get(norm(tok)), c = p && p.cands[p.choice];
        return '  ' + [tok, p && p.only && !tok.includes('@') ? `${L[2]}: ${p.only}` : '', c && p.cands.length > 1 ? `${L[3]}: ${c.code} (${c.period})` : c ? `${L[3]}: ${c.code} (${c.period})` : ''].filter(Boolean).join('  |  ');
      });
      const txt = [`# ${L[4]}`, `# ${L[5]}: ${stamp} ${p2(d.getHours())}:${p2(d.getMinutes())}`, `# ${L[6]}`, `# ${L[7]}`, '', `${L[0]}:`, ...(periods.length ? periods : ['  -']), '', `${L[1]}:`, ...courses, ''].join('\r\n');
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob(['﻿' + txt], { type: 'text/plain;charset=utf-8' }));
      a.download = 'wilma-kurssit-' + stamp + '.txt';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      log(tr().saved);
    },
    cfgsave: () => {
      const d = new Date(), p2 = n => String(n).padStart(2, '0'), stamp = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
      state.list = $('.list').value;
      const out = {}; Object.keys(DEFAULTS).forEach(k => { if (!['at', 'x', 'y', 'w', 'h', 'open'].includes(k)) out[k] = state[k]; });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify({ kind: 'wilma-kurssit-config', v: 2, savedAt: d.toISOString(), state: out }, null, 2)], { type: 'application/json' }));
      a.download = 'wilma-kurssit-asetukset-' + stamp + '.json';
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      log(tr().cfgSaved);
    },
    cfgload: () => $('.cfile').click(),
    load: () => $('.file').click(),
    cancel: () => { cancelled = true; if (loopActive()) { loopStop('cancel'); if (window.__wkCloseExtra) window.__wkCloseExtra(); } },
    loop: () => { if (loopActive()) { loopStop('stop'); cancelled = true; if (window.__wkCloseExtra) window.__wkCloseExtra(); log(tr().loopStopped); return; } state.list = $('.list').value; save(); loopBegin(true); paintLoop(); loopRun(); },
    help: () => { state.help = !state.help; if (!state.help) root.querySelectorAll('.tip').forEach(x => x.remove()); save(); applyLite(); },
    cclear: () => { try { sessionStorage.removeItem(CS); localStorage.removeItem(CK); localStorage.removeItem(AUTHK); } catch (_) { /* ignore */ } $('.cuser').value = ''; $('.cpass').value = ''; loadCredsUI(); evLog('LOGIN', 'tunnukset poistettu'); },
    lite: () => { state.lite = !state.lite; save(); applyLite(); renderDash(); },
    min: () => { state.open = false; save(); $('.panel').hidden = true; $('.fab').hidden = false; },
    lang: () => { state.list = $('.list').value; state.lang = ({ fi: 'sv', sv: 'en', en: 'fi' })[state.lang] || 'fi'; save(); buildUi(); },
    unload: () => { if (full) { try { history.replaceState(null, '', location.pathname + location.search); } catch (_) { /* ignore */ } setFull(false); } else unload(); },
  };
  root.addEventListener('click', e => {
    const h = e.target.closest && e.target.closest('button.q');
    if (h) { toggleTip(h); return; }
    const had = root.querySelector('.ctx'); if (had) had.remove();
    const dd = e.target.closest && e.target.closest('button[data-dact]'); if (dd) { dashClick(dd); return; }
    const b = e.target.closest && e.target.closest('[data-act]'); if (b && actions[b.dataset.act]) actions[b.dataset.act]();
  });
  root.addEventListener('change', e => {
    const n = e.target;
    if (n.classList && (n.classList.contains('syear') || n.classList.contains('syear2'))) { state.syear = Math.max(0, Math.min(4, +n.value || 0)); save(); const s1 = $('.syear'); if (s1) s1.value = String(state.syear); renderPlan(); renderDash(); return; }
    if (n.dataset && n.dataset.aopt) {
      const A = state.auto, k = n.dataset.aopt;
      if (k === 'maxper') A.maxper = Math.max(0, Math.min(12, Math.round(+n.value || 0))); else if (k === 'lock') A.lock = n.checked; else A[k] = n.value;
      save(); if (k === 'home' || k === 'lock') renderDash(); return; // text boxes are not redrawn, so a click on a button right after typing still lands
    }
    if (n.dataset && n.dataset.aoth) { const A = state.auto, o = new Set(A.others || []); if (n.checked) o.add(n.dataset.aoth); else o.delete(n.dataset.aoth); A.others = [...o]; save(); renderDash(); return; }
    if (n.dataset && n.dataset.dopt) {
      const k = n.dataset.dopt;
      if (k === 'unstable') { state.unstable = n.checked; if (!n.checked) state.ldelay = Math.max(0.3, state.ldelay); }
      else if (k === 'ldelay') state.ldelay = Math.max(minDelay(), Math.min(60, +n.value || 2));
      else if (k === 'lmode') state.lmode = ['fetch', 'hybrid'].includes(n.value) ? n.value : 'reload';
      else if (k === 'lworkers') state.lworkers = Math.max(1, Math.min(6, Math.round(+n.value || 6)));
      else if (k === 'gapms') state.gapMs = Math.max(0, Math.min(60000, Math.round(+n.value || 0)));
      else if (k === 'lite') state.lite = n.checked;
      else if (k === 'nonlypost') { netOnlyPost = n.checked; drawNet(); return; }
      save(); applyLite(); renderDash(); return;
    }
    if (n.dataset && n.dataset.dact === 'op') { state.opPer = Math.max(1, Math.min(6, +n.value || 2)); save(); renderDash(); return; }
    if (n.dataset && n.dataset.dact === 'need') { const r = state.req.find(x => x.id === n.dataset.id); if (r) { r.need = Math.max(0, Math.min(40, +n.value || 0)); save(); renderDash(); } }
  });
  root.addEventListener('change', async e => {
    const input = e.target; // e.target is reset after the first await
    if (input.classList && input.classList.contains('cfile') && input.files[0]) {
      try {
        const c = JSON.parse((await input.files[0].text()).replace(/^\uFEFF/, ''));
        if (c.kind !== 'wilma-kurssit-config' || !c.state || typeof c.state !== 'object') throw new Error('format');
        for (const k of Object.keys(DEFAULTS)) if (!['at', 'x', 'y', 'w', 'h', 'open'].includes(k) && k in c.state) state[k] = c.state[k];
        save(); periodSel = new Set(state.per || []); plan = []; buildUi(); log(tr().cfgLoaded);
      } catch (_) { log(tr().badFile); }
      input.value = ''; return;
    }
    if (!input.classList.contains('file') || !input.files[0]) return;
    try {
      const raw = (await input.files[0].text()).replace(/^﻿/, '');
      let d;
      if (/^\s*\{/.test(raw)) { // older .json files
        d = JSON.parse(raw);
        if (d.v !== 1 || typeof d.list !== 'string' || !Array.isArray(d.periods)) throw new Error('format');
      } else d = parseTxt(raw);
      $('.list').value = state.list = d.list; save();
      const known = new Set(years.flatMap(z => z.periods.map(p => p.href)));
      const hrefs = d.periods.map(p => p.href || findPeriod(p)).filter(Boolean);
      periodSel = new Set(hrefs.filter(h => known.has(h)));
      years.forEach(z => visited.add(yearKey(z)));
      savedChoices = new Map(Object.entries(d.choices || {})); savedFilters = new Map(Object.entries(d.filters || {}));
      savedCodes = new Map(Object.entries(d.codes || {}));
      const first = years.findIndex(z => z.periods.some(p => periodSel.has(p.href)));
      if (first >= 0) { $('.year').value = String(first); state.year = yearKey(years[first]); save(); }
      plan = []; renderPlan(); renderPeriods(); persist();
      log(tr().loaded(periodSel.size, d.periods.length));
    } catch (_) { log(tr().badFile); }
    input.value = '';
  });
  root.addEventListener('input', e => {
    if (e.target.classList && (e.target.classList.contains('cuser') || e.target.classList.contains('cpass'))) { saveCreds(); return; }
    const c = e.target.classList;
    if (c.contains('thm')) { state.theme = e.target.checked ? 'dark' : 'light'; applyTheme(); save(); return; }
    if (c.contains('list')) state.list = e.target.value;
    else if (c.contains('at')) { state.at = e.target.value; try { localStorage.setItem(AKEY, JSON.stringify({ v: state.at, t: Date.now() })); } catch (_) { /* ignore */ } }
    else if (c.contains('conc')) state.conc = Math.max(1, Math.min(10, +e.target.value || 1));
    else if (c.contains('ltabs')) state.ltabs = Math.max(1, Math.min(10, Math.round(+e.target.value || 1)));
    else if (c.contains('ldelay')) state.ldelay = Math.max(minDelay(), Math.min(60, +e.target.value || 2));
    else if (c.contains('lmax')) state.lmax = Math.max(1, Math.min(240, Math.round(+e.target.value || 30)));
    else if (e.target.dataset && e.target.dataset.opt) { state[e.target.dataset.opt] = e.target.checked; if (e.target.dataset.opt === 'lite') applyLite(); if (e.target.dataset.opt === 'cremember') saveCreds(); if (e.target.dataset.opt === 'cauto') loadCredsUI(); }
    else if (e.target.dataset && e.target.dataset.pf != null) {
      const p = plan[+e.target.dataset.pf]; p.only = e.target.value;
      p.cands = p.only ? p.all.filter(c => pnorm(c.period).includes(pnorm(p.only))) : p.all; p.choice = best(p.cands);
      renderPlan(); persist(); return;
    }
    else if (c.contains('year')) { const y = curYear(); if (y) state.year = yearKey(y); plan = []; renderPlan(); autoPeriods(); }
    else if (e.target.dataset && e.target.dataset.per != null) { const p = curYear().periods[+e.target.dataset.per]; if (e.target.checked) periodSel.add(p.href); else periodSel.delete(p.href); persist(); return; }
    else if (e.target.dataset && e.target.dataset.row != null) { plan[+e.target.dataset.row].choice = +e.target.value; persist(); return; }
    save();
  });

  root.addEventListener('contextmenu', e => { const c = e.target.closest && e.target.closest('.dchip'); if (!c) return; e.preventDefault(); showCtx(e.clientX, e.clientY, c.dataset.base); });
  root.addEventListener('toggle', e => { const d = e.target; if (d && d.dataset && d.dataset.rid) { state.dopen[d.dataset.rid] = d.open; save(); } }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') root.querySelectorAll('.ctx').forEach(x => x.remove()); });

  // "?" next to a control: shows or hides its explanation right below the control's row
  function toggleTip(btn) {
    const block = btn.closest('[data-hb]'); if (!block) return;
    const next = block.nextElementSibling, key = btn.dataset.help;
    const same = next && next.classList.contains('tip') && next.dataset.key === key;
    root.querySelectorAll('.tip').forEach(x => x.remove());
    root.querySelectorAll('button.q.on').forEach(x => x.classList.remove('on'));
    if (same) return;
    const tip = document.createElement('div'); tip.className = 'tip'; tip.dataset.key = key; tip.textContent = tipOf(key);
    block.after(tip); btn.classList.add('on');
  }

  // Wilma's own "Käytä pikavalintaa" checkbox: tick it once per page load (not again, so you can still untick it)
  function wilmaQuick() {
    if (!state.wq) return;
    const label = i => [...(i.labels || [])].map(l => l.textContent).join(' ') + ' ' + ((i.parentElement && i.parentElement.textContent.length < 80) ? i.parentElement.textContent : '') + ' ' + ((i.nextSibling && i.nextSibling.textContent) || '');
    const find = () => [...document.querySelectorAll('input[type=checkbox]')].find(i => /pikavalin|quick\s*select/i.test(label(i)));
    let n = 0;
    const tick = () => { const c = find(); if (!c) return false; if (!c.checked) c.click(); return true; };
    if (tick()) return;
    const id = setInterval(() => { if (tick() || ++n > 30) clearInterval(id); }, 500);
    wqTimer = id;
  }

  function makeDraggable(handle, onClick) {
    handle.addEventListener('pointerdown', e => {
      if (full || e.button !== 0 || (e.target !== handle && e.target.closest('button, label, input, select, a'))) return;
      const r = host.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top, sx = e.clientX, sy = e.clientY;
      let moved = false;
      handle.setPointerCapture(e.pointerId);
      const move = ev => {
        if (!moved && Math.hypot(ev.clientX - sx, ev.clientY - sy) < 4) return;
        moved = true;
        state.x = Math.min(Math.max(0, ev.clientX - dx), innerWidth - 44); state.y = Math.min(Math.max(0, ev.clientY - dy), innerHeight - 44);
        Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
      };
      const up = () => { handle.removeEventListener('pointermove', move); handle.removeEventListener('pointerup', up); if (moved) save(); else if (onClick) onClick(); };
      handle.addEventListener('pointermove', move); handle.addEventListener('pointerup', up);
    });
  }

  function unload() {
    cancelled = true; clearInterval(wqTimer); clearInterval(loopDog); clearTimeout(netTimer); tick.stop(); try { if (netBc) netBc.close(); } catch (_) { /* ignore */ }
    sheetCleanup();
    host.remove();
    delete window.__wilmaKurssit;
  }

  function applyTheme() {
    const th = state.theme || 'auto';
    shell.classList.toggle('light', th === 'light'); shell.classList.toggle('dark', th === 'dark');
    const box = $('.thm'); if (box) box.checked = th === 'dark' || (th === 'auto' && !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches));
    const sw = $('.sw'); if (sw) sw.title = tipOf('theme');
  }

  // ---------- dashboard ----------
  const baseOf = code => String(code).split('.')[0].toUpperCase();
  const rowOf = (base, req) => { let hit = null, len = 0; for (const r of req) for (const p of r.p) { const u = String(p).toUpperCase().trim(); if (u && base.startsWith(u) && u.length > len) { hit = r; len = u.length; } } return hit; };

  function dashModel() {
    const all = new Map();
    for (const [b, v] of Object.entries(state.seen || {})) all.set(b, { base: b, d: !!v.d, s: !!v.s, o: !!v.o });
    for (const b of Object.keys(state.manual || {})) { const c = all.get(b) || { base: b, d: false, s: false, o: false }; c.m = true; all.set(b, c); }
    for (const b of Object.keys(state.earned || {})) { const c = all.get(b) || { base: b, d: false, s: false, o: false }; c.e = true; all.set(b, c); }
    const hasHops = Object.keys(state.hops || {}).length > 0;
    const hasEarned = Object.keys(state.earned || {}).length > 0; // completions read from Wilma win over the tray's flags
    all.forEach(c => { c.ign = !!(state.ignore || {})[c.base]; c.hp = !!(state.hops || {})[c.base]; c.done = !c.ign && ((hasEarned ? false : c.d) || !!c.m || !!c.e); c.sel = !c.ign && c.s && !c.done; c.todo = !c.ign && !c.done && !c.sel && c.o; });
    const rows = state.req.map(r => ({ ...r, courses: [], done: 0, sel: 0 }));
    const other = [];
    [...all.values()].sort((a, b) => a.base.localeCompare(b.base, 'fi', { numeric: true })).forEach(c => {
      const m = rowOf(c.base, state.req), r = m && rows.find(x => x.id === m.id);
      if (r) { r.courses.push(c); if (c.done) r.done++; else if (c.sel) r.sel++; } else other.push(c);
    });
    const groups = {};
    rows.forEach(r => { if (r.alt) (groups[r.alt] = groups[r.alt] || []).push(r); });
    Object.values(groups).forEach(g => { let top = g[0]; g.forEach(r => { if (r.done + r.sel > top.done + top.sel) top = r; }); g.forEach(r => { r.inactive = r !== top; }); });
    // courses numbered 1..need of a subject (ÄI01–ÄI06) are compulsory, higher numbers (ÄI07…) and everything else elective
    rows.forEach(r => r.courses.forEach(c => { const n = /(\d+)$/.exec(c.base); c.kind = (!c.ign && !r.inactive && n && +n[1] <= r.need) ? 'm' : 'v'; }));
    other.forEach(c => { c.kind = 'v'; });
    rows.forEach(r => { r.missing = r.inactive ? 0 : Math.max(0, r.need - r.done - r.sel); r.todoList = r.inactive ? [] : r.courses.filter(c => c.todo); r.have = r.courses.filter(c => c.done || c.sel); });
    return { rows, other, all: [...all.values()], any: all.size > 0, hasHops };
  }

  // Course numbers by study year level, from Tapiolan lukio's subject selection card 2026-2027 (Ainevalintakortti, 1st/2nd/3rd "vuositaso").
  // [code, 1 = number written with two digits (ÄI05) / 0 = as is (RAB22), alternatives group, numbers of level 1, 2, 3]
  const YP = [
    ['ÄI', 1, '', ['1 2 3 4 12 13', '5 6 7 8 9 12 13', '10 11 12 13 14']],
    ['S2', 0, 's2', ['1 2 3 4', '5 6 7 8 9', '10 11']],
    ['ENA', 1, 'a', ['1 2 3 4 13', '5 6 7 8 9 10 12', '8 9 11 12']],
    ['RUA', 1, 'a', ['1 2 3', '4 5 6 8 10 11', '7 8 9 10 12']],
    ['RUB1', 0, 'b1', ['1 2 3 8 12', '4 5 6 7 9 12', '7 10 11 13']],
    ['RAA', 1, 'a', ['1 2 3', '4 5 6 10', '7 8 9 10']],
    ['RAB2', 0, 'b2', ['1 2', '3 4 5 6 10', '7 8 9 10']],
    ['SAA', 1, 'a', ['1 2 3', '4 5 6', '7 8 9']],
    ['SAB2', 0, 'b2', ['1 2', '3 4 5 6', '7 8 9']],
    ['EAB3', 0, 'b3', ['1 2 3', '4 5 6', '7 8 9']],
    ['IAB3', 0, 'b3', ['1 2 3', '4 5', '6 7']],
    ['MAY', 1, '', ['1', '', '']],
    ['MAA', 1, 'm', ['2 3 4', '5 6 7 8 9 11 14', '10 11 12 13 15']],
    ['MAB', 1, 'm', ['2 3', '4 5 6 7 8 12', '9 10']],
    ['FY', 1, '', ['1 2 3 4 12', '5 6 7 12 14', '8 9 10 11 14']],
    ['KE', 1, '', ['1 2 3', '4 5 6 8 9 10 11', '6 7 9 10']],
    ['BI', 1, '', ['1 2 3', '2 3 4 5 6 7 9 10 11', '4 5 6 7 8 9 10 11']],
    ['GE', 1, '', ['1', '2 3 4 6', '2 3 4 5 6']],
    ['FI', 1, '', ['1 2', '2 3 4 5', '3 4 6']],
    ['HI', 1, '', ['1 2 4 9 10 11 12', '2 3 4 5 6 9 10 11 12', '6 7 8 9 10 11 12']],
    ['YH', 1, '', ['1 3', '2 3 4 5 6', '4 5 6 7 8 9']],
    ['UE', 1, 'r', ['1 2 3', '2 3 4 5 6', '5 6 7 8']],
    ['UO', 1, 'r', ['1', '2 3 4 5 6', '3 4 5 6']],
    ['ET', 1, 'r', ['1 2', '1 2 3', '']],
    ['PS', 1, '', ['1 2 7', '2 3 4 5 6 7 8', '5 6 8 9']],
    ['TE', 1, '', ['1', '2 3', '4']],
    ['KU', 1, '', ['1 2', '2 3 4 5 6 7 8 9 10', '3 4 5 6 7 8 9 10']],
    ['MU', 1, '', ['1 2 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25', '2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25', '3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25']],
    ['LI', 1, '', ['1 3 4 5 6 8 9 10 11 12', '2 3 4 5 7 8 9 10 11 12', '3 4 5 6 8 9 10 11 12']],
    ['TO', 1, '', ['1 2', '2', '2 3 4']],
    ['LD', 1, '', ['', '', '1 2 3 4 5 6']],
    ['OP', 1, '', ['1', '2', '2 3 4']],
    ['RAB3', 0, 'b3', ['1 2', '', '']],
    ['SAB3', 0, 'b3', ['1 2', '', '']]
  ];
  const YLV = {}; // course code -> the lowest year level (1-3) it is offered at on the card
  YP.forEach(r => r[3].forEach((s, lv) => String(s).split(' ').filter(Boolean).forEach(n => { const code = r[0] + (r[1] ? String(+n).padStart(2, '0') : +n); if (!YLV[code]) YLV[code] = lv + 1; })));
  const aboveYear = base => { const y = +state.syear || 0; return y >= 1 && y <= 3 && (YLV[String(base).toUpperCase()] || 0) > y; }; // a course of a later year level than the chosen one
  const yearSel = (cls, extra = '') => { const t = tr(), y = +state.syear || 0; return `<select class="${cls}" ${extra} aria-label="${t.yearLbl}" title="${t.yearLbl}">${t.yearOpts.map((o, i) => `<option value="${i}"${i === y ? ' selected' : ''}>${o}</option>`).join('')}</select>`; };

  // course types: each subject row and each loose course belongs to one menu (the longest matching code start wins)
  const CATS = [['ai', ['ÄI', 'S2']], ['a', ['ENA', 'RUA', 'RAA', 'SAA', 'VEA', 'ESA', 'ITA']], ['b1', ['RUB']], ['b2', ['RAB2', 'SAB2', 'VEB2']], ['b3', ['RAB3', 'SAB3', 'EAB3', 'IAB3']], ['mat', ['MAY', 'MAA', 'MAB']], ['sci', ['FY', 'KE', 'BI', 'GE']], ['soc', ['HI', 'YH', 'FI', 'PS', 'UE', 'UO', 'UK', 'UI', 'UJ', 'ET', 'TE']], ['art', ['KU', 'MU', 'LI']]];
  const CAT_ORDER = [...CATS.map(c => c[0]), 'oth'];
  const catOfBase = base => { const b = String(base).toUpperCase(); let hit = 'oth', len = 0; for (const [id, ps] of CATS) for (const p of ps) if (b.startsWith(p) && p.length > len) { hit = id; len = p.length; } return hit; };
  const catOfRow = r => catOfBase((r.p && r.p[0]) || '');
  const catName = id => (id === 'oth' ? (D[state.lang] || D.en).other : (tr().catN || {})[id] || id);

  // ---------- PDF export (a hand-made PDF with the Inter typeface embedded: a Latin subset of Regular and SemiBold) ----------
  const PDFF = {"r":{"d":"eNqlfAdAFMfe+Mzu3h0oIgd3NAU5DjgQAeU4ji4djl4VEOlVekeaiGJFKYm9YUMsYMOYaKLGGGP88pL3SDGJvhdj8kzyUl5iypcot/xndu9ogvj3Q+d2dnf212Z+bWZ2AQQAzADNgARmkbEOjqWxegIAoDW6mpZZlF66PmXjWwBQvejaD7mFK3PWv/7r7wBooPvRl/Ky07Mclpq/h9qeQsU5D12YXcHdiOpfo2KRV1RZ2/X3lOPo2Q0AkGaFJZnpWyUrfwaA+zK61lWUXlsKPgSZqK6B2psVpxdl8/4y+B6ARPx8S2lJRSV9DLQBkJSH7wNMKwXAp1EO8tTZHr+zjwHwZXPsFnz8Rnut3fAZ2kwD8B6jUxIQgP1Dz/Gu0bqIbjB8Zrhfg7ky7u8Wc+UWyECyUD0x4Y/iiGAH4ADAkVJ/Q+e72SPxN9BGHEBHwCEBPlDNGDMYwQ1iYsNjwTVgZnaKpYF3Df6kxkClcAYZzjQ43jCY0wqcpiq8X9HRAwxwPgV1TLkJBqgPJimvoTZ/ovuPwABhhcvwbXScqaoPUp0gi5OG2q0DAzw3MMDlqYopqJuqcOay9zkIBsccVHLmgwzOb6g+sWA6HyA6q4ArpxgdcdEAdVQTSJqq8Jai40OwnyldII8pD1E58XQh/gAC6ltUvwz2w59BA/x5+Awqv6A6Oh9+FZWHVBZzbz+PQPAuqcp76JnREjvunMWdR5Lo6AoKqZ+QnPYjPAgHU86ojuqyCjhz20AglQJ8cH2kFIAmjj7opY6DPCwjho8cYEp9BYo58UgOWqCO9AFp1JdgN/ULaOTYglrqnwjeH0g+60EG9Ss6ojpHgvgMB924UAYgBpUc4nvwOSppqDxApZ7MBx2o1PMuofZ8YM55D9QSD4A9cRxyCRtwDdfJftCBVAVgDaGaISD0EUxccsAgeQmVdaAbFyICNKPSzf0PU+8mVrDniI8sVKI4oaAflR9ReYDKW6gMqsr7qPSicp/sQUP+bUQrAco5KSCPFwV6yaOghdwFNpC7QTk1CIqpIsRXCcgkN4JSshPkct8BodwCEMrTBlm8u+AhsQ30orKdugQF5CD4iLAEewhvpEaocL4EApVGYc0SoF/IHCn4KToaAh10RQM4AFfQhCzRsJnAzMjMxMzczMrs1PAwo18LgRvoBv1memaGZnPH3AlmdfR+y/1m9K/qft0X/4NgG6JLTuB18NEEG/A2WAP2gK2gAlwFLWA3WA82gLPgONgPXgYHQAc4CA6BHtALjoFWsAXB0UTWRAvMArpAD1ErBMZgDpgLTIApokgCrIENmA9swQKwCDgCKcLoDDaCl8AmcAacBm8COVgMfIAf8AcKEAJCQRiIBjEgFsSBeLAUpIBUkAbSkfXMAitAASgERaAUbAadyF72gZtgLagE1aAdVIEu8Cq4Ds6DC+AI6AfnwFtgAEnpEriMrFIOuAgOgxvgNfAKOAreQDxfAeuQjeUALmM/eUiuM4E2mI1kzAcGSDJGQB+8A+YBC2AJrIA5EIETQAzsgD2S/0IgA2XIhroDF9QXnkjmHsAL+IJAEIQkHQAiQCSIAuGgHCwBy0AyWA4SQQI4CZJALsgD+SAblABvUIwkXYAo/wJawmjYCE8TgLAi8okjxG+kCelExpGV5C7yHvkL5UAFUnHUFuoQdZEapB5xBBwxJ52zifMxV4/bwL3LW8Ar572qQWrYaVRpHNX4Q1ND014zWXOT5pUZOjPsZ+TO2DfjyoxvZmrPzJ55Q8ta68QszVlt2pR2g/br2srZ0tmrZl+d/UQnU+eYzvd8GX85/xz/Dv8v3UW6AbqJuhW6B3Qv676rx9Wz1SvTOynQERQIXhfQQm/heuEtfU39+fol+gP6n+vTBuEGjQbHDT425BqKDZMNNxpeNOIbBRulGW02+srY37jF+Izxozm+c2rntM25Nld7rt3cwrmvz/3AxMmk1eQHUx1TJ9PVpu+b/jJPOE8yz3Ve5bzTZi5mZWZvm31s9pXZ/4q4Ij2RmchOFCFKFq0Q1Yq2iA6JLoreFn1pbm2eZN5kvsf8dfN/mj8Sa4pNxDLxUnGH+LT4K/FvFsBCaOFl0W2pZ6mw3Gz5puW/rFKtyq26rf4tsZEkS65ZL7T2sg63XmXdZn2C+fdPHCPAYDqN/JPnjcYFD41nE9TrWOMWoxEahNyZiC+CfBEfF7FQKpMKxTJSKJKJ5TKRUMrUZBLmV4ovCEnchqnx8FUhH90gcflTGUWcoTWgN30Nel/zRv+h95079LVPP4XezehSRwd9rbT0WjN9rbkZotvXmr296TSN+4/BMNI42Ix/m1HLIXR9lY8359p9725UTUP/lde8u9Gh2ft+t9K7mbyfhm2KE7Iv0cgL89AIB1IohWJSROqJSCsrCZfLcyJM7hEWt7Ypd3fchr8UzglwcAg05Aw+tofddBoRCO1DPzt09F4A0hgGDq+agYPtzdOwSHMrK5mTs7PUUV9fKOByRRPOJ8XlI3I2M3MWiWRmZjK4dszJ00SQQjO5GXNPhCpj69husvTlM/TZTEIdNLcnxOZcntiLkDqaouIsl05BExRYBi2W6RkbEU2ERZBM4usmMzIy5tSTsZMQJTISGTmaeKQ4G4uMrWxTykdp2cTQIpiEFj1Sqjcp5pA33217GgfxM7SiP38euHpSclK4vm3vXn9OuEaTwRXL9KR6QrFkcnGd/f7kD+e3TiIbQhPOpH/XPA1Gxs9jhMNg/PiBE4YJHMHq6Owsc7KyQr3GFQr09ccghzcUNUFBNQrml35jhJROsYu5yFUsdhWZu6rp4XL8ywMCy/z8ygIDyv2HfEaom41bupibu+D2rKbwipCmzEbaj6gTCZHKqwuJ9F/sRLxHZSidiP3KDOLOUIXym+tQC36wnDPYSwt6ad1ehnsv0ghJdACxfAvB0kf+YwGCxhehMYe54wlNSaFAmxBbitTsiWSj1QFCp+pUmYt/iY9TQaKzW+0ba+l9MKVyi3fY5jR6JwyOagnzqE+nz3EGPYvaY9IaQ3S1SWnK+oS4zkKPXq9879CmsO7FFeE+eV44Aq8b/oGTx3mIfDHgICkTMiddLGdTwkCMlUEbUcRoAlIFbZKc3f7oXEbGuUftZe92FwiuCFeeSs/qX61QtPRlZZxcKbyiV9D9riD/FjQ+exbOfWeF76oLFTltQeHb77W3390eFtyWXT7Q7Iex0rEMVhdEggxBR5yJxXJ74pnoCZ6Q6X4xcaBabmsrjzFo/eJw4jOoMdzz7ZaMZSW1dGy+iaXl3NMzym5CneNTUNb+cZ1mJBUenRCD+hn1DScM9c0MFLEAEepcR0pXKCAo3CO6MicCdQPRSjvArz+HsqM99HV6BuS98t/qqm/66G84g+fo8998R58d6N0MqQvnIdyEOMa9rUAQZzI9PTJuBsg2pSOxT5lJ3MFjxLiX1upl8VMKpG0z0Ugb1x4iszDmGeV/GWugepCbxSjrM59H6j/2+W8YrX/G84IJz6vVfCyQHrV2q+FUq5WaVEGqRpDmoDhvPKxpnMFYFFlT+wA10o1Tmn5W+kjbUTQ6hoIBslXpSqxRNmIYRK+yQa0PtWhk2jytD9jMjBmQSCexlpLCbb+fTUs783N79d8OFQhu2H+4P+MkGoRrTuc2vlFE0E2ER9KR+4IV76iVIrDlfGF7b9j2ex1b720Lz7u2pufw5i8OxLNUcrzUYwTRiYoY/Q5cIbWvXBl6xBlUNhBrH9sTPcoktjUsR61RPgBRO1h+BZsznEyTw7dRJyYjqZPITonZ+5JppI2er3iWo+UMXpzatxKYZliORgyOjBh8cjRSEUxDlbviDHYxg4sZW4TRuJZoTKKWOioHNNJyGLFCxDEttVQ8qEcfar5o1KVwBo+MeBEIsoZ/IP+JxKDH9qAMxWECfWxjkDgRn4RozbtlV9oqytuulN4S5L3THhW1ob19A2X95NP2d/JUvSBhbDzTCyTqauSGoBjycE94rfKHb/yl7CGWfUmTSGdpgv4parsCfqmsHzpPvPcVbQBU480CweCoelI4cIVABvnxJ72qu9x16K4FMxohGltehBx7Dz7qDzmycwiZPSFB3oA/ALVhibaVDV/X2nI2XAFnXyZIYo6LI58+f5Tu11noYorOOYNDcRZlqz3dmyssyVOP7clYeUd3eHzv5gVDfWTs/I3Hlgbte8ltqE+Fm4NiFORhMWVQX98AiQgPNGhPStBI4A/cJ1JMU6Wa1JUHyq+NHOV+C7iaCEGQw5HswoseZBcCH2Udk1oT0X7HeahfZStjUVRlwHjsSWFOHlhNhol4Rlw1FQ3cbU/FVwSjx0eQHutN9Gz6+tiSc7kSRy90adTJkDrIt2VmIm/S/gv2cb+0Z51qQb7kVFZWPz72j/FrK96hvz57ln54K/9M2Pa77R33todhT4L1GccxDG6kfRi3HGcGz4V/Gv2clr7iqbT3+Qjn/DilepMqjvIZjryfjx+9Sft8Wi6+mar/n5OLvyaJteuGBzlHuAAYo3x9IUO9hCeRj3BgIDfgqZiAUGXj9SHDjpUE6pM6ORfDk1ty49Mw2e/vTW7Ji09FlCtpoqq0C5PtAo9iLuSOys2lAmentUkvZ0KDfobUgtakbZn0t/0MtbCc3BiJKW14m/4dU95wUzFUGzki302MfG2fU77Ivk4rTRNkfZ9TcLdY3/9itCALPi0tQmTf/y+0LHxOPVL7iGkJWsB6kOek6XO1i2Gjo35kQ7WZTEgVt6N4XcTnjwnTIb3maqOnZ+PVFvoqdKnu8PHprKFvcwYVq/sys/rWKJT/Jq5Hb0lI2BzF2qtKxl7pA/vJ+OQZiCVcUmqAoY8LjOXj2dy88trN1Svfv7k3LnMMp1k24RYT2fyQvpYx3CeDD/8W8mvPWE5naakjwG8Rj3wwl+WRsULYM3HNn2K0/8ui9VtgxD36tiZfk+G23de3g+G25u+tL991VO4h/KDyCvF9wKqliWsUyA9VDj9EMnwIXFluJVI2qsLcSSTY8rFmg00DcHKH6gamFJYz0Xnwx3Wab2lk7FqafTDFIWaFx8DArYi2S4XFF9eHk5c0ErcmpnVGuSZk2GxbWF6y3CV487vGeZcb44pkvrWRzuHO1nyp9MrLqbuLPTwKOuMU2c6LiwLdYuTimTazrL0SG2OX7a/yRRRmqPIzFKXoyXC8KOZnUDm03RXO/N7ex59w5mNvOvwtx5v1phxk75gQQ1+fYQRXEa1P1t7ZHXMl9Uxd3emUKzG7PjGMbL9eQd4Zcik4lpZ2rIC8NWRTcb09Ekscw0Jj3QBFylNAI5HOPwXxf5COTwGV26COuZ4DNtLhp2B/iHT2+WGbTQV7JGt4CgH9A6uEUyHZOiaTYPBUIzzYq06FaRov+jQBJ6Zym1ORdPAZeYZ6Jg2pkAgykRAbPRIJynu3oLtRsL1DkCGU3lY+QOFMW8AX3UfuBpCVj+0B+ywPWxVT5lk99lm90QpSPdUkGrxNr7j+g+ECgcDO6JdP/2tkJxQsMPz+Bp33z2GgZ8nXEesPI/DFaTfz82+mkV1DxSlv5eW9lcLETWeCDmUsOxA9FIUwYt3zQBhN8FwGQmlKGniRGBMbf+JA1JXQp2feuyNaKLEQCCwki0R379AzCf5d+omls52Rob2zhP6LeELcoW8sVHj7SCQ+3oqF0EO5cIiGdfLo8EUO4bFyep1KMm6MzQQi/ljR8LFs7kGJlZepqZcFtLqrvEdkkKX0PM/SwOBSd/jlUIdyv3qW0g2NM22g+xQMZvA+Bacfjd6nYamzXJTrIQ1HCQTO8aUyiEBxuXimRQiRkNGQEQlbiN3moVYh20OUv1NaylLLSJuQl0II7XXkF445jiTRu2FokXORDFUwfUnDD8n7VCGYD7xUo9MJSRM5Jzy5gUwYT+JFIpNG4nlesTbB+C2ZNsVjwg19eCdyc56749KSRq+sJs/qyqjyIN0+s6y6tT52JaUprme19OLWeYdWRNpoOgWF+Qp9yvw98oztEptjwgsCbQ01Zmmb23DzKhxDJa5hOZ7GOnYJW/KV83ZKYl0O2EWkS/fM0NWeqUFqSEK93SKssWdlqOXqM9T6vgC92OW/CM0LUJ+8KN1UgTouGEt90AtQPxIkvAgLQtZkvTAXjWqbRqn4IBg+IkDKi3AyXVr/AgwuncokvjDLHc/ILf7PIxFPNLwAl07Ib/5fR6K6B/ci6t2etwcndhk5gZ8Jc9rPw5tGcG1QUG0wM9e9egKf9WJXc3PVhPdz8Utd9S8PDCzz9y8LDCz3f3J/Evb3m4/Oi5ur+5DzO9OHS1+kDydNFl+kV+mp8scX7uq9k2SUiF/ur8jWe4IwsGSUX6l0PLeEATN3SAqFIpYpA5QloOxTm4Tq3pViQchFTuzkIvw0CnHskl633ve3yjH82mZmxJu6v9oQ1Faf5jx0h5OwIz2r3ey0ccOrlV2fughiy1vhzEeR62M98vxCyyOtDxIlIeuWBVfGLWS5Lg1zEOSPMqwtUbgvzbCMXnOpIbTyUNzSeLv41YrKDLsIDxGhZROHucZy+GN5V6xTUiX2bfuHv6WakKc0xisVmFuJWChGEZeUZRNH5aN5GMsYcTSqVGGvLegf0NZeEFwak9+3KiCgqW9tRE2UtSSqOiq3LSh4i6Gtt59BH2dQ+Zm+z2LbqB0ftbbe2RF90KdiV8LS7WWL815raLhSgPHTKRPx858Pv/bAtPiVZ3mVzyYAxQp5SAL2qMfFI71NYP014I2bFcYdTGSXX16vUKy/XF54ca1pn1FncVxdtEQSXRdX9pLRKdO1rxnG7Ppo9ZpPdsUoNmUsWlLiV7UjLmZ7pV/FskWZ7WEMLsQtxiUbvzpCPgOpemkE/sEujQhzj9X6TEXDnOojGcy6SAqzLnJQM2nH7ZWTEpS8IVLTm10UQb2AZRA8thdGsjQ8yYn1mpSMGC+WPMInv68pIGBVX35MafAC1Bv9Am17Rakspy04qC03siZKYh1VYxi9405r60c7omwX++gTksf2fQZ+3rYHC640NLyWt7hs+9KEXRU+KvyBSC4m7JzeCP5x+gVFbH5MVK68vjE4aO2l8qC2xjT50KdIaTIz2+f1GzdcpF2IUo2QluTgihgHw5idH65e/fGeeFYfqg4ifVgY1xxMHErtjMHDn2LxIi9tMjqf92zcetNlIc9JW86Uuck0RBOhz1oHZ/nRZ/ixfQ5ucNb5nBT/gpPR6YizUq0p///SgYP856TjO5y4vggdC5+DjpFs9jmJ6VXluNPR4zJmFUOAFO4TLt5rBCAz94B3jbD6z6o/Vygkemh64N49WVK5p3ecwFHbzio2jErZPeRB3ti9TVEUYinU3M3Rio8uwrpDB1IhSHcWAA8EEc+4yE1JJnHGaisep8wydkLAcYwmI3ua2XChVtyl6xCUF5K4OZKvbacojc46tToocFV/fjQ2tfzToa1nC3YeQoodVRtpHbyVDlyc55li6CoVuVQn3zdc7CkJ3vw/a1v+sS1qvre3wfknrYX7shYShR9crLmQu7i4K67iTCbiHCV7lAmblUHGyKv0Bi+PMM4VxgwMyE8VlZ1MvbC+Kqo5BC+2IxdyuzRt+eWtSjfi4uquwHXYXuEFvRouyayCsWs5E/Rw/0CiOQ6OzJkQiUp5cogjxCrGKpozik6HzyBAvkj3VStpGMp0cwz7B+iPp1JcFY6plJMY/gXRHIPGIrM6xtCMtG//QDfSK/ws9bNq1gVJCQ6Pa4e0Y/9ALxr3Y9sNv4rod2PaaanaqUfv/oHv2HHJ0DS6D4MYfkinwGokN7xmC/SkfH2uWMz4oYl2bd8F2HPYQhQRvGy8GGO6z/UkxnKyx8mS7dlgdnYEUyJVL6vtH9CH//qCXgD/9xs6t5ozOHQA/kibKVuImSV0FvscjBmz0hkzoF7pZO5xs6hyZj8PX2rAKgjrJtkRw8bRY6v7T8O5afW+xZ2mc/LaotO7Uy945XqEFrkPuGYu9qkIpFL+Fpbp2JAXlCOPO9Gi1CZ+jM60W1wcpLQihr2WO3nWJiq9VZipuUij1OPUYJJx2gedz5SWnUgdGBmoVMoHNTkTxikDCUXPQjz3OwWsyQPkiRjg1qnC38lwE+KJoS3rY7MQV3oTfOyEGEvl3UdCnfLXNygUG14vj2/AYUZDvCrcGAl1YnZ9smb1R7tiDvpVbo+J3VHlrw4ygMq/ZiEd05vEv06Kd7qkd1q6mqZ2rNMRTLU9I5dlOEE9ObJO9mw+Jk97pqX+zlSd/BzU75wkm4kd/pCqoTYjbZcA6ej6mJXa3+D1Mf1R+vGimL4EjrgGIju526uoYOVCJ0zzsn1e5SsaHOVquvUNaENJ9j/hv62yvDD9AkO5dFXS1uBXizChTo6tSV2KN8pGiF1cLVXeEFu/RbiYW2Ki3UvVEUsWsmJ6T0UKk8sVRyzTSXEWE6pMK7Bc9ZzT/y8NOFqZjgYOE6a8GA0Ln0NPRiKV6QjxUIco09KycnQdjMnKkK1g8gE9vlQ4Jh0Ts0kanJCV7Ufx/5hsLJ/N0aDLuKyMTuGC82PzMTZLI2yfygtxphSspgCiIOnpUAZOyEioYJQQohQkalxiIuinBeNyEjqFiMRZyNjU5PyQ7YSchPECxMdUMbtPCkuA0RjhiK/p1xIuqfIVyHU0vC2iVgVTKadc4xwIeIHQ8KsKU/ojCIXD35IfIh7YdT+JXLWe4TS6DIYzvhERGhiwukgYn/ra9KRha1ZExeIjl3a+7FW6I7HiYLbR4dmuKcF++Z5JGcd3dnlXHTLc3mmTvMQ+3L5CssBiR3VwTYJDwMrI+dbB9vMVDl6hBtYWOyoUDcmOql0rdZyHwBHz4sRue8KLfkJVlzJBACvMMVWGz4GSt5tTDtb4rSpI74z2qjiYefRoRPniwFUJq5cF57t6lUWGVvlRsY0X0mVZW5MaTltqa6bty03cXux5bHFJUFil3wlFlW9Aia9nQdCTMzj6HX5EVHHy8LoaFIr5zP4duQGXKza3kuFIGEUPxJKHnkF8mb7l3CBx56He3gEU+SpTQgM0qJ0zZuzaSJzZDWfQf+AeGn5EmVAp2E8z+4GYNSP1kpFYhuytEQolBzZURa0KudAvP6u9/PUtxE2lAnnI9anE/ieH/lGXjXWPgYO8lBBY4sx8cljTeqbxuIam8kOTEcERP2PlCetiD+JyHqOJ41bF9KVSodhcwkw9WUlQtKWoDw2rCRhY6GFi8aWtSXqBnW1OyjysdMqkvLWeXmvyiJ6hA3LbPb1B0WYmCh/lO8wMEOZeH3FvNCXv2OqO568M2djJWKFo9U7D54GLLel4uCuR3XxeuKZTwh2xjuOBX2Jt4aRdoKO2fhA4452NSOJa49frIPySjn/7J+P5eno2xj+9TcdTKcp8RWdgYKeC2PHkEI4cA1HMit+emnqlT71dHu6i+65uMJTPneNstO7aWkOZ8Vy50YardN/5zrlSYyPZnE4qhTZMuLOu+dPl8FvaMPFOS/OdZfDbJ4fg47T3ClZ8kEJzMUYfnFMhjAbsSp8Bi0mO428Ji4rnAzfSWwc3W3mazHGRbH2f3gQ3/OOIpdtcI7lVD+FFmH3mXuToWOT+mfIT5XtPXHMdHHJdn2Ap0EsYKRiicSc30MdQxwqDUdk2ez15UvAcM0YuNlguP9+ghdIjNQsD6YK9HO1ZYVHLqSwkpY7AwA4kpcdPWpu0kcYxsJHGGQJrvFN4SvjTTbc8A/9HUyng1IRxzz5rHyRLsz6iee4zKMbbcJ9BFVyKxvczKGhTr2A2IcP0I5L+TGYFU8YsXgpFwiaiQnmQDFIeIKrWkVYzj7UPfTXzGKauF40DvGeU2cOPMjvO6NYVsZ6InWkU9V6Dc2pfbfLxaXq1lv73NXS269ChXfS/OYP0B9Cvek9i4t5qP/oy/H5jfX2Hel7Qh2sHrPCKMuSpduaIx06TStEo4+CYEvs3Azl0HL+RhXzn9vKu+Pp/vlz2yuqAgLrDy+MalxjqmNXn048d/mGb6aLw3+jzJ301ry3YIqw2LrIqQmIRWsNZn5HyA/1d98Aw2BDZcaOq+kZ7hFu8bcL/ZKwqzjbzmttonuBc+/iljJ6cwC2VgV6Fm8MVG1Z4oXFVOWxF9XNPIY/rClACwpGhUEWKogW+yuPKZVKhKYm3nkj4zJ4TvCefzwYyErGEr0p+4jsGazTe4kU2hbgP3PKtPphSm91TF0Be4oXUhLozO0/KPtm9ZF0Y3qECa8MrvBaGJ35+XbNwoCok102DMOZLr7y8pKPIT/P2OzzvFZuifFLdeDRPh92EUv561czrsGhGQGkQs2XlM/jJDN8sL1mEsxhLHPWjPbNXAGVpIhkWNBpdmGwCzw5J+M6qWWGSr5q9mbf2ZlHRzbXV6Yer5vbp1yxbXqd/am71kczqpeVyefkJ/vY/Dhz83506p05ohK9NWhSerzV0Q6s4elHyhiiNXhhBOumu7M/MOFWDxhyyWlQIwo1HEMQ5vFQo4gnZDTJoAMok6Af+F/pS0G+Q3krTV0noT7/+Bn0JBpL0GxDQ7ZxBpQdxQ6m/gdu1Ab/itKGLu4H4Dx7PxQh2BYpA8PsQMkdnCX4dSmI1dtabyzUwQLj09Lk8PF7x5l6uuDgxnNTcvY1HelafXFF+sYbfp9dakNrgRvDgV7S5JhEmIxbZWx1vXHcsJx0u3P4w41hjYPKxsrkFTeEt0d9vp+9EZc6R2Hk5tLbinQrDP1B3EQ149p0nYmMuEU89Dcior5VELJcyNkaOKmMn5bg8yt5feRmiP2KGHx1pUnUoLf2AZ2jYe6Xbf+sxf1fWgm9dlL1s3vPb9rLb0Qq/7rS0w1Um5FudupZ6ehb8l1YeiQtx2hesaPnt5Eu6Frp6lrqdp35bEx52wCMs7mgdu7OV6kL0zca+Hnk2ZqMYooBROon6/QRzLup3XX1iXc9/Ghr/c/To9w31/zlWtDMqamcR8ysYgPG/PoJLXnmFPvHoEX1ioGcrnPnGFThrazv925U36N+34v7Ar4dtYfdA4XkJMZRZElsuz6B3Qn9mCsac/v29/6J2u1G/RSKazBk7xCSJbGAoHpOd8LBp2g3/G1vsEtIUFd/o/0pg04nMrJ46P7PQlkz6EnF6I2GUtKE+IKLcM6AxLvNwlbd32c6lHhWrD+TTR7WOITyNiPca9r0RZhVoZNfYUyEpyqnJCfErUV/06oZw6ho3fnN8Smdc9O6SlSuXtob41EaHtcaTF8nw1r6MvJ4qz9by1PVBYRtfE7jmdyUE5cp9qsOj6wOPLi4PDyn2lOcoEjrzXX1KOqKazphrzc7YnrJsb7k36pdaJIMLzDsjs/GOMYjTAbxKJUdiE9YSbd/cvv0K1KKNoMMeSmOIOkb/AzocI7WHaC1mNglxlometpmEM2ZBUQ+NelKqDsoRN+UZvY0K6lVuRGNo0paouM4U+9Q403MJpI6yQ6ph3xae09ccFLLugsC9oDPeN8897uWUtJ1LBWIDfeLBMTrcalHI+lcKCy6sC1HtlqYakFwtVJIlZTrMmNIf2X83BvNTs0DrQrevy/do/f14480m3Us6IWUR5UcTtDyuVqYdX60IWvtauV/lkkUOceX+/lUJixyWVAhs0w//fBRyYcmbWeeqfHI81inPL88Pbh0ozHtlY8QxafLKQP+aJKlseY2Pb22ys2ovniU7DqUqN3eL2K6kyLeUBZx5WsfOPv6C3S1KrWTeZRo3iySXjc2SR9+vkkxYaJ+48E6sLL+8IWRBxIrFwQVu/vXHMjN6Gvzd84M886PsQjdeLsvsiIzrSk7piovoyoqsC/Kvj46p9w9oEHiW7lwW1JTjP1NDL31jZHxngTvugsiN6XoaM/1zmoKW7Sz1POpTFRm7SqFYFRtZ5UNcXVweGlrs6VkcGlq+eLQ/vlX3x5j9kWLuiGPFrkmHYLcPjO2OZatQN7yuE1wRUX4kUcvjSlXaiRZFcOulCsW2dXkea3/b5V+d4OiwpDIAdctC+7hyQdZAjW+e5zp6YFmhYi3qhIubwglom37ov0fov+j2a8RV5+U1vt7Vyc7S5NqAgJokR2Ym4gcOj3MfjVcZ8B8ja9YVqSIvHg8ikqVY5gZilIDoQZ561dsZyhkzoRI24V9ypsHHNrLQ2ynCNulocemhhJKlhXCxiVmfhdzk75/lLlq95UO6W5ocGtgUE7WDHkqf422XGu2yxEEh8CrdtiSoLC3RYXFZtX/mziVLOxNz9/lE0Y0u68Py9hRbDjUs9DaDfNhj5V8VoCjx8iDeCRa4RDgFJdtHO/utxPLuHv4V9jEzzHpId0kpOTGPe0/rvVkJll4WFl6Wlp4WFp7wC/LXoVm0wMLT0gqfW6GrGA69A/ZR1So4KKSfCOfNWee1chkI7HP0DgyHGlTDtUQ4EJyY4V/Js4w+OuE1YCzYiaaNFbA2KRROxAFXmbrFOPkm+RT7uxcFc69QgTV7ElqurliRvtB/vmAcF2/OzGld4jXPun5pYLbLorzYlJeyZdnnyleecjeV+SzznUk7jmMQUZZD15JvUwUqyhizPtKlzDuCYpYauRcpk+mpKFJdcyZ2qigr8XMvUnAwZbsTV19TUzaCyMKT2DdCWUCOmrKcs6OUwfdZYbGsYAv6Of0dsRlFobpI8k66ugwxyAXqGoitiM+tAlJdTrst9zGXlSw5vWoNkVoHNSD1/fLqJ8pHxa30z/Q/zn0Gr2OPh6DwVVCcdXWZkE+KIlpmE3ZaYrHU3Ge522mX1ACr1kb6u4twEdRuLn6kfFKd/D39hP6z7gva62NMzQMEpxTBwbuH+SK8WUL4AG59gC7z/Hf99dMu3KYetdFUtZHhnFTEr3+AWtHf7eLq7vrzddymA7X5CbWRsKt2eDuNBHk6vG6Hu1xohWdfWKNGCJm0n/ip/URoTK7IPCcm9ER7XLqNKCEuLkFknR5Pfxfdt/Hr4lzeK9zcoocbT8XsgE4F8fQDt3R/voAfmOZOfx1X5KSm7DOE1RpTxqTMTHyJd9ziQSjD/Yo73UAqxPqL+7g+Pt3aLDE2NtEMYWo/Hmq9PJIXk2YTepz+bptTURyc65YeiLD4p7tB07hC6Y6YUxsfRqQtgAN26ZFfb+yLxlaPruJ5c/aDaJCOiDCzIPgosrGQOlKM3yHZKUV2anE0sZCNTnY42aM2FI57KLytBkXA5MgiJruFnBLQd+isj+u+gxEfHYEzbq33nyUJa0iWJMW68jT4QUVhWTuypZ4lO5K8swJ1Z+w3dbNVRJjKCg7d3fxv+lJfP4z706MqN0rf1jy7um5zZ5NHzdKYSq+5Hul01R24B1p9DGN+bFy6+/Z3dfH9++qDdCU+9rYKu7D1F1Zkn2gOFC0yjlMWWfvPz/r74cyrR5uCXqN7fv2D7h3QNTbmtc02MdQmFKfP1a6Xx2+JC1iV5YokguIp6kdkl+bgWE+kJyLFeijgZIqUFKEi5YmZAtFN4h1/us1vh9+/jP7lcdfoLqrBSv8dfvcM2FM6ClZ60G1wD50N92yHxTvZGp29k+7aTmcTi2AxjmKQXV9CfQPE7B7rkZUAZ7lEzq5KqZcDkE3nSZ5+/4J4sOKN8ObqNVLXxfIt1VtDX8nOeS2sve4luaeLdFPd6vA3C5L2Vvv6Vu9NStpX4+dXs08Q5N3SsC78tdzCaxGdDR3u3n7uLzW8HHGlIOdi2KaGVh/FIcXq3rT0483Bwc3H09N6VyvwCLUfNiMGuIbMmiAUQ2KANuuB97mGf2lw/8SXuLQZPMw7N7JmeHgf79wfxZpd2IZdo7+F+Yy15zFZsFgPtbh2HP3Bl5Tx3P8oE4ljE3Bw8CZubQbHfe6ff2lgzSRsSFPiAwaDUCQjTZXlxAc9Pfi7LIQNBUbvUGAIjN7RGHNHA/ypugMB1CWbyS7sN+CEWX3C27cywdExodJXdYS6Y06YI6a2m9wDb7KrpHjtoXvvpgRyDyFXvjvJvYT3947cG0T3XlbdQ57vW/3r+qp7BL5HfDsiKXRXqmpxZaSVqiXCQDqPtMQjU0XDoRE6ntkSUfRwhCoVZc30LtgD/q6muhndp3epOUIeux+JbbZqdm+s/5OwfoFxJ7PUFSvsWUn8HDeEeW4ecHj6WdF022nHwiaspzoZh3Wquiru6Kfmj+Ry4/eFPgu31VTYSJsJOLAUbyMc6piEnDhdhuXqOgYcK2NqzTg4SOKEJ+wnQ7HE4TOl4jnuQURBFuigEilvwMHzVJYQL/uz/+HvdAnsfJ+uhptujdQ64KfwU9qatlYfEYQoBCFADUE+BkIU3ERXvw876ZJbI7WnASDq+8ECKoXKYH0tFOJ//eQZpQtxi9Bogvdu0P1adP913PJH1HIf2xJCGfOP2jcURdxSupBnCA3a4jqM0YIxN2iGtwdwDrWCrFCNZpyYoPKA3DBUS26Ac3p64Dmk3gjqWyCL2oB6AUsAT5Pw2ffQiWi6HG49jnx+eRZ8+QB8iS46QBdirQSlVBNlqpKYBELEtQGE1Ax6P72/EmYwPzCjkt4PM0pHTqvpfTCzGjfBKxaDIJiqp4JG3gJHFsdymjFG1Q8thR9aoN7zsLR0t7Bwt8R1TwumTuw9ceKQ2NPSwgPdtrD0FCtnoGYWHmIxOvPAY+19EICoTme/O6A3wiWyv0gq78O1x+EauvE43YAE2dULJfRnvfTn0Ep5vpd5L/oY7KCOkFpAhJ5VT/owaY9Mqq9avWCyUYNe6BCb77IoPtFZ7Ghn5BV0BC6MzZc7Jix1spDaGrmFQXhxeUu05Rx3B1NLftLS5aujLU3cF8yz1IlJxXjuQ3fKgvgOv50Nmb4g65XZpD90h7MP0DHMd+mGk/AXvbDlEWHb3jOUxNjvGNKerOAcZvqa+TaJmIyBdu9Au7OfzbpD2hNVys3wDm2DWpYTbWQH8/4cgHociaWlnINMp6UBh8Oz1IOvzaJ/C4bG9MNgqDWrQwvODKYfQuNg+nctog16nmzq6mo+CT3pt042d3U1naTfYnZJwCTqN5QTGABb4I7XEKA5syWU3VYtwHsvx3tiifqLIjj5Egv5ozMlRH/aaTYtPZ2W3t+1wt19RVd/evKBOn//ugPJy7pXBgSs7C6HOsauTmZO4qK1KRWFfEvjORazi2ES89Do40xti39d97LRx+v8zxOGwvnetvIo/X+88gqcLZxvZmYxG0mzd/g7bi/nO8SDA4hXzTSM54BkozgcupuScNxbgKMbXqVsEEj2rnp4bUtExJZrD1eN1jLObSvy8Cjaht/5VNXoS341e5MiNhUHzzgzwz/DxTlNYWOjSHOOq5p9ZlbhsbykvTV+BhPAMLX+8XDYGhGN20uXNQQ7hi2wUaTKnVODbVJD03cnomgG24QW0pMUc/6l0rqn1ugnbO//KLBuuUy2vC4wYOVyJ6flKwOkcY6OcVKneEfHeNLTKbkuYKRBXbLTdnwrTiqNc0LNEK4NxAA5m3OT/YYMu7iA9Fm9EV0oUes2CpLxFyxIfJFdTiUiTLNCatac6stxc/cNORXelprQopg5+wxHc0bOkmgXD5slxqSGuWNjbslKRy9f6SIdvzxPr7pk+uaixAV8c2jgu2C+vZUR5rcc0WCNaOBjfvVGzIk685Or00OZmu/yuH0rCvfExe0uKNwX1y+JcHMNs7QKc3MNl1CCiLyDy5K78yJyDyQtOzAQ4b7cWZbiHuGeIndJUc8QmzIrGIDZFamWLlLizIG4mlebvL2bXq2Bb3EWDA0FrjqZk3VyVSB+vw7vFRikNJD++IMEvFdgTBcYcExJHrOHmt25gEyidCSnQEbHEuHA00ijppJkLlvh5Bc/ru9FkEf65y/x9Y6xcVSYQyOT0EBbinRNlOV55q8PqRjIPeOa5SNb5rIwSEw/dMpaDGXLXO1dlx/OLz26LBB5Sfrf+q5yS4KQ+FhALUMvd2uqzDNV7hBoaRviLjis4xJdHCzNCuMTyV3RtZFWy45X+qc5mgfInIMdBQdNE+ujnQtidTgOFUHJW2NSe5XmNv4ugoNaM+cH2C0Mlgl3zZplF4Bll0m2wF+5/SOzuTyZHP7ap3H3A27/0EfErtU7mS+glJItpAn3VfxWoB5+K041ksQjXgJxjef7q2FccFBKQFBiT+zLadnbYgTOOTG74AWypR7Ocg23c1682DmszMtzRaDILyzZo4S3GcHOJWtJJwR7oWoPKjurxexvV8/eqmY4CPUMh1AVYtzO6E4lzhCLYhZGZBYkh4VJo+yX+NuHO8BjcNmulPTOqJzYgvLlh8lat/xA4/kGXg6LvOrnLjKzczWyMw1c4eGZ5+O/bCZ3VkZ4QKEnskShAHBzmCjUHMxnvzQlUnE7Obtqib1BgeMonv8c6sjcxXIzR+89isaw6Hp/vl2MzwoY+CTqoOabh/HkeCGUuMbbmy0wcF6kyHP1zPGa6xaSE1w1Yz1nEEn7yLbuRmzVMR0CZtZYG+jj/ZaWqpljoViGkw49dUfxxaSQPAr9b2Vm7n7SwxDBoKIWzHy3cTVhr7yzrrGxkd0YqYL/ZBHMpw/NRFiyEJaLnLsMFi+85jUBCzlJZzyjLzAtVPA4Wupi10ZyDnOs3c3cooLD4+LkAa6L5nrakrupmJaw+AoPhdeS2MiN5CcTiSX2OSx15xtru9o7BTQtdlog45sZeiY7eWfLA1O0Z8zIjfDN86RzWD444OHwV9zfOf9hLI0EuGLpsd94GWtz4FNXSMSi5VgDxExewKeucAZT1/j5r0lJa/HxW/3kc9XJal+/1Z8wTJLbpB5zjD2cHL3mzvEaKhxzYhK7KSYiZmNs7EZ02BRLJo8/H3oT85qzKHJBxILIRaoDmTz+HOlHL/UzVDK7dZlIndnNy+7khWA7qn3P3sNfgYJL8Zbgn1X7HaCAIyR7uASbSUy3QxlunvJLP8Jn7DH5iBNA0JwP1dkrQSs/4Xy4dSu6s4dOgX8hrdZlZrLUb6xIVS+l7GHfSTFNHfPSycN16m9tCVAf5jJvBpsw39rC23sm+d4WDiSJbtrh8uVJv7oFB+gwYu9uYu9TH9+itXazXy8GzvirqZQmoncGE9vhOoHwzlDVKWAMDFV1Lqo7AgXyN5UgG5SDGPSbC6pAIUhHZ6PXzaa8YzfhDvvlVvRHH8Hfc3767/8Biiad8w==","l":23176,"w":[281,288,466,633,642,982,644,300,365,365,501,662,288,460,288,360,631,407,610,618,646,608,620,566,619,620,288,302,662,662,662,511,966,690,654,730,722,601,590,746,743,269,571,672,565,903,753,765,639,765,644,642,646,744,690,985,682,679,629,365,360,365,471,456,323,562,612,571,612,583,370,613,591,242,242,549,242,876,591,600,612,612,376,528,327,591,562,818,546,562,552,426,333,426,662,0,667,0,0,0,0,864,0,0,0,0,0,0,0,0,0,0,0,261,261,440,440,562,500,1000,0,0,0,0,0,0,0,0,281,288,571,611,725,550,270,553,591,914,450,583,662,0,671,478,456,662,442,446,323,586,603,288,268,304,450,583,802,847,882,511,690,690,690,690,690,690,994,730,601,601,601,601,269,269,269,269,735,753,765,765,765,765,765,662,765,744,744,744,744,679,636,616,562,562,562,562,562,562,917,571,583,583,583,583,242,242,242,242,583,591,600,600,600,600,600,662,600,591,591,591,591,562,612,562],"b":[-39,-234,1000,997],"a":969,"de":-241,"c":728},"b":{"d":"eNqlfAdAFEf3+Mzu3h2IIsdxnEiR4+AO6XAcR++9I9I70qSKIM0GYu9Y0Nhb7NEYSzQaJTGWaPSLGkvyfV+iiUks8ZdEvxiN3PKf2b2jCpr80bmd3Z19bd57897M7AIIABgGmgEJzOMSHV2qjYWxAEBrdDV3QkXepHnZC84CQO1G134pLm8smhJelgCAFrofP6ukMK/A0cviAmq7HxW3EnRhZAp3LarfR8WypKK24b368fPQs/MBIM3LqybkTZQmRQDAXYWurajIa5gEboBMVNdC7c0r8yoKuS9FZQCkYnjTJlXV1NLHwXsApGF6zAGmlQJAf98mnZyR3n+wjwFwrzlxCT7+rDvbvmsVba4FeH+gUxIQgP1Dz/E6aH1E99iuVV2rtJgrff4uMlcuggwkC/UT/f4ojieRCjgAcOTUFXS+jj0SV8B7xGZ0BDwS4APVjDGDbtxgXGJMIugA5ub7WRp4HfD/NBiobM51hjMtjj8MR3WXwYqWMTqGgnbOj6CYKRdAO3XnNeUIakOj+3+CdkKJS9eHqDxX13dQ20EsZwtqNxe08/JAO1egLlJQPFjhjEX3HdHRHcF2BTmccJDI+QHV+xdM51hE56dAwTmKjri4g1pqLYgerPBi0JEGC5myB6QxhUbl5MBCmgADDkT1n8BCYhSYQozq2oXKT6iOzrtWoXKLWsrcW8hzRfB+VJfv0DM9ZVyfcxZ3GmmPjoUglSNFcroBDDAOpjxSHzXlAyDjfgjsqCXAhToKZN1lHmjiBIFlVAdIwzJi+JgFzDjaYAKnErhzwkAxmQ+yqU4wgyMCZZzxqGiBRRwzUExtQPIcg+SL6pwYkEasADtxodJAPCr5RCf4CJUYVD5DpYLcDpagUsHD/SwFo1F/zyK1gAXxHXhOzANXcZ08AZYgUwHYQigeei4d7GDKenCFckRFF+ygSHS+BDShspO3E+FER2Ibe84RgCxUojn5YA8qd1D5FyonUTmOymeodKCyFZVvyE+Qyn8DIqgE0MZJAgW8eLCb3AsayAtgPXkOzEJ2kkZtBlXEGlBGbgVF5FGQz/0DxHF3gjheIEjU0gYXiX+BPahspH6EuuRGcIjYDa4RiAFcuCQwUFsUtiwD9AuZIwXvoOMooIeuaAFH4AFmIE/UZW5gbmRuam5hLjXf39XF2JcT8ARbwAFzgfkoc5Ned8JZG707624z+jflbtN3lxHsUeiSKzgFvurnA86BVrAeLAU14AyYBdaBeWA+OAT2gE1gFdgMloOtYBvYCXaDXWAOWILgaCNvMhyMAPpAgKgVgtHAGJgAU2CGKJIBazAW2ABbYAecgQuQI4xuYAFYCRaC98FB8AlQAj8QAIJAMIgAkSAKRIMEMA4kgvEgCaSAbJADckEemAAKQCkoA+WgAkwCi0AbWIw85nkwG9SCOrAMTAErwHHwKTgMjoId4AD4AJwFR5CUPgInkVcqAh+C7eAzcAIcA++CjxHPp8Fc5GM5gMv4Tx6Sqw7QBSORjPlAhCRjBAzBBTAGWAIrIAUWQAz2AgmwBw5I/k5AAapBPvAC7qgvfJDMvYEvCAShIAxJOgTEgjgQD2LAZJCMPG0myAJpIBXsA+mgGJSAiaAQVAF/UIkkXYakeQ9KYSJshodhF2FFFBCbiCekgLQhI8lScjl5g3xAWVG+VDQ1h1pPHaKuUP/H4XPMOfmcJZw7XH1uPfcaz5yXz9vB+0VLqJWhNVvrhtZP2iO0vbXLtLdq/2+YYFjssNZh7w7717DnOqE6m3RUwxuHXxsRP+ITXQfdCt33dO+NtBk5ceRWPY5eiN4cvS/0nvFD+KX8Jfzz/H/zf9Mfru+un6xfoL9V/5xgmMBfsE3wwiDYYJZBh5ASBglbhduF9w2tDeMMaw3PGb4QWYnGieaKdoi+HTVilNeo1aMuj/rBSM+o2OjsaDjadnT56FOjfzfmGHsYLzTea/zAxMMk2uSQKWlabLrY9H3TTrNws3KzZWZbzQ6b/TrGdszeMT+YK83DzJPMJ5o3mM8xX2G+2bzD/Kr5f81/EZPiUWJHsa84XbxVfEP8wkJoobRIt5hkMd9ivcVhi5sSXYm9JEtSKWmSLJMcszSwnGV53PKFlYNVlNXnVv+RDpPGSJdJP5VZyVbLtss+kN2X/W7NZ/4F4BgBhtO55AueP9ILHtJnU9Tr2OL8kIaGoeFMzBdDvpiPi0QoV8iFEgUpFCskSoVYKGdqChnzK8cXhCRuw9R4+KqQj26QuLxQxRPv01rQn+6A/h3+6D/0v32b7rhzB/o3o0vLl9MdkyZ1NNMdzc0Q3e5o9venc7Xu/gW6kMXBZvzbjFp2ouszA/w5HXf9t6BqLvqv6vDfgg7N/ne3qPybybu52Ke4oBF9Kxq5eEjDgRyKIZIiKRDLpFIZl8tzIbRgImFA/3um6kbTJ3BjgDh8rHXwGM71vxxgNb2MCD9d/Grdhs4CHJcwkHjzGEjY4wyEBi2kUoWrm5vcxdBQaMDlivudD4INlsv8raz8ZVI/qdSPlkr9mf/4ZAAd5CQrX6nUx8rKRyr1tepdx76TpXAqQ6H1a+lzICQWXJ4Ek2RGyF3clPLBqTK2j/CVG5qaEWvJwjT7ME9XozGm1GqidCBRTaYyU4V0cqup1NTesba1m5KVDCUGr6FEQMoFg+BVXFItGogiA7rQV8HbQBbIyUEgOy7qvPSWkI1eB1migHIolMgGAU88hCOvQ73HSwfiKNaCZvT3Wvu6tegPhEWEtMiuB09/5YHdeF3cFK5S1G9CA8M+qGFbbFNoaFNsHP6l73UT0uYaEqxwDQ7W0MHVCpwUEjIpIAD/Bnb6a6hqDZK7BAW5yIPUdsJ7F9nJSGT7mCYhMnhNQTLgS1yIDdQ1VQixUFVHfNLpRxtuewFXjeNcv0eXfUtPuAfr6QWED/EYS7IdmctjBMsAjSNjETS+WM0TT2hG4qPESuzihrmSSsQKdVUibic8t94qDZ0S4TU5w23SvX30B9BywlSPwMZE+gYcETYpoKmBfsK5XniwKn1WPH8kKc+eM772eOl3rpleQaV+n7jmBiZXI+9Q3PULZy7nJzR+AQ6SKaFw1Wf1XSRm1B/L0RDpvptSrEuS/JUvjxcVn3ixYurNneX69DO9wtVpTR+XlZ9qTFtdyIe6Iwu3f2NQfB4aHzkKTc4Xh8zpaEqdFjD18Z59jxoCpqWWnVwaj3HSaQxON+QpFXK2wyRKB2Jo5DyeG5KGhFg5zWXsWJe00fPu7cwYipTM9guN1NnqqXTaZDMLC5OdOtVnod7e19JVdHhxklYkuS0jAfUt6g9ODuoPHdy3YtShLpShvtCAoKzk5nw9QiIhltJaBLEL8o7n7aM/pp3uwtuPf/wZifoT+smBh/Shwz8TFMRBGWT6Np+Bhfu1W0vayYuqIGKBqp74BKtE5bd07j0WM5WPbEoH6VWf9hA5gF7PqM5c6lzU/SA3j7XJoZ5HZt77+eOLVJeHfN6g3/MaY+4NZPFDqHsDjny0tAdShcZySTWseQiWMYrq+kJ7g+PvjSRAip29VOZnZeUHl/Q66UFaN6iTZ+Ufj+Sv3ZuCdvIjVQJRrlqFYQR8q9oP1HbQhnRSNtAOpNK+qogGagNdgjRaR384oejES0YB+fSvlofnN3xcXnZm+qR3swh6N5GRtfdng4kX4OhDR6DJhZLw2ccq6xc2Pd6z+/HU5I1l1w8v/3FrslpHOHndOtL9rx3qEEehDv2HKopzXbWWKPnLActE/QTEozSK/5koYyv9B/Ze+ErXh6gjW5DcSaS9Eva+7A3yxs+PH1zOGPCOQWVMdD3H1CCtwZEQg0+JtBXDtLnUuZh9fFkvDSMC+rRFmonbShiN7N22awf6WcW0Ha7mQ6OF+AFtZvxgtA8/tV6jeRDEdv1C6SJZCNieVODuwj2nQCAQt4TTyq/roM6U/LxaqD3ltkHZ1ZVJKXUNDXWUyaufV10tU/dIGePdmR4hUaejYQf95+FeoRQ1EXAejFZ9RoTS52hvRDcdSn8S354ET6umdh4mNvyXDlDrnhxB4aj7VYh7dAXn+quR99i7XPQkE3mgYNGMFPmSShw38l19CaUuwYMS6EDI0AiAcK6AxjomZqYjRpiaGevAUXAl/ZwgSWjk7qJPP/mBfsh3UZqgCwTnemeXOG9yg7uyviYfDZJIZX6zqZmzODDnzBYXlR7xm/P6U7l+82fX2Kj01HxORzSIWBoMDUUOBJaSGGNGuoEwOxCkdbYzh0fBkfQ12lEWEu2ipYPQXPbfNyl82Qx7Uhfh+MGvcXnewru+KhN1H3Omo7hKhCLiQeC+PrQaBBt8Yhfp48qGVkWp9mFeciNzE6qdnDg4GdzmfjEWwdj3GWTfjFX0tnBDxrlzuTLNGKu2ddJg5cuPios/erlyxcsTxcXIzhtPlpaebGw6VVZ2qtcYV3yevn/0CH3/XPGvjY/27nvc2Ph4357HjTgGZnAiW8Q45SgzeDu8b7DWIenK7WfG3bHxmwnmrB/Uxkk1J1MZTrzejo/X9/GQ1EOyb093B9FvQf27A6Lq4q7znDNcHRSdSlA+jmiW8WTKbrJFShFPTTmEGqIhy4MM4u7/YnPOkpK0QkzrF5twtQCRSxsTDtnTEbVjYQOiXGaluu5YZZA/P39VPjQ6xFA4YX7+6nz6wQcMkfAgaeKPSCze2QUQvcW7/Dp/HGPeLdGVjERlbydRnAYMKT9TlAy8hajmamL4f0ID8tdD0iBCjvyf0mD3lhaiGQeGJMTwAdRFCcajpW9BzQrN6MHGQF8in6jLZDUo+DMj8GgvEfP5cg0dknbCvuWzOUHB88610N+/Kmzx8W0pesm5HjH3cFnZkTkRKDz8KnRaXHxjMGA8z0zG8xjiOGggfzyUMnFJuagvj9hc+rLXUv2vLjB96v3fpvuFanhsMvM07s/eJfpKPv18swvB2RZ4dUE3j9o8jW/mMdyJemUaPJxUMfwxkTjibv/DhvmzYRB9k/43/ejVmsVL1iL2Gm4vXfO1QvU+IVH9lwQz6+rnojEkp+shdRNxp8C8WUplYsbUGV5kMuy5fIm+URSqi9i8htj6XhdYxoU8bvKC8anzooMaE/acvJaw6vyU+rNLY0laNWxN4/jGAPvIdPtFiRumR87tFJVfXRlbInfL8/eMdhXaOZ3dOGFrrZ9fzcasnFJ5qodjsKO5jqVBYOGy/NYLVThSSkS9+QcznwEECib+4ydS22gF/Qf1+717r0ZSvzPxVNcjTiw7DnIs2KFKHewxVV2CeLrg283JUCdxTXHxmkSok7zlW8PY5ecayCudEVkrEhNXZJEfdsobzi2PxTLG0JBGi1DkOwg8Elnya2DeRwHTIHC59YzBvB10ZKOvgf4YWebbQzcfDHp3LvAaFPRDTVQ2GKLWXhkCg2sewiUDykGxvWE0fB0RmwaLZQcjavEQGYRmRgzFoMhIcCzDRoNEiOoJtIJa5uFjx4aMQemepeo5Ckj+mvDXuvUvCkjuXw6AfZr3J3rajHlawD4t6KlAMclOW5DwM7oSjvlUZC0wsDW6BI0/N7I1EIwVfQLN6Qr66tcGYv7IMYZfIww/F96rqrpXSBp1/lzwbWXltwWk0V8OpDL2/dzMg4mdn2Os2BaXIKzGeG4CoUUmh2JKAQ5hSRSBoeCSVBAi2gAqjkpdbQwNbRXS49CBFhF69PnvJc4yoVDmYvUT8Rdxh/7NI3Ocre24TA+op3LuVMFYt7hQa1lovBv9gZo/TivjTwDKQ3qJh0+kqr6B7nDYGLmRkdwUcqCb6i4RQLbRNspiX/9iBbzVWaU6o5lzbEU6pwv0B0BhVPk1kLAuD4SmyWQhqEV2fw7RJUQSUEAEjMvFcydCiESNlEcsbCCqLRNswtsiaF0qWrVOmmIf1R4FH+4kZ8uL5BS8t7tzsbLCDVUwhdHIx+lS5UhP3dU5BY7RfQkFO9PE5ckYJ0fieVuJLsGMVwpdkqdL4Jji09K9+WFNaxPymjwKcgJyvHV/Fy88M8mvpS7T7eWwUamzDOLrAkb4REUYeWa5lYli2itzpkZKtXX0LKWccRnW/lbOE1r8RYq01jSVcJ1TvPMn/hN9Zw/TH6FDalkFyCMikSUx9HHHMPR5/30K8Zj+96i0R+L/+5RSQUz39KU34B/Q250H/i2ioWa+4h9QHqdxWyiqZ6kXMNSHg9R/oBFvysf/HlulvTwcbdXr5B/wmTpEDvD/q2V4VuBvceZ6qXPRP9YyTT/tQvR6gEiQ/jYUCyx6IhYm1+rLQf8M503c2EROi7CJynd3z4+yiZi6oDdvyy2UYrHSAv+6v5lHqiO4NkyRGWptHZqpCKsN7oT9mZ6tBsb8gu7e4jG9Ff9PdPR12dvf1EwjlM7JRZp0LtxTk7j/g07N75fesRxyXyCv7IYy6+geDuXyPvzhoYTpTiEbmSpFKJi3kKJBUKDuRybaEKgnnOGVSQcmJC4+mHWjF39lB938D1cXH1+a0PkHFTFzXPI042eiWRdnLf7Kx6J5+/3Poif7l42Ln+J/nxhO+lXFxNcGYQ5z54yT5nYzFxwbEhO48ObKcQXzQyLDTXOXJxSleiY5QpV1pGtUFGIXcuPqg0Ib8HizsOsXaicavUYDGzYukkmEEhQPyX1JuTof6Z8TEXfCy6JcRvJpSOmMdIosj8rbNSMsZPqePSl13l51qcl1Pr51BlLvELNDnOuqG2bBvrKoFbcWL7y1KuZWzo6JJduz0rZVVOzIYLDT2f2xMxOSb8auQ3e+Cb3qPV7tkPghSEOaOx71q1gdEzL2iEICXt/sCPUjUdV0bnFU1OJzTdMvzhn1TNiYk97o7d2YnjvN4NmouZ+LEtd+1dL61bpxSRsr5CkluTsnFu/MK8+QV21NYfAgPjEel36rEEMg5PHcsIeWwP9Nc7GxcUkdtfyrmtejN6w/NInMKaieRmdPNrWQmGzSbX+x9TW0FL+ToR1EJMQzKw9pqN+n9JZ8d/aEJxCxlZIDJC+dsGdaSOiMXXlR5VFOI3Ug1aU30iW6DCbV+frUJafWefvUGcSsurVw8a0VUTLfYDPC/i+HQ2Yh3tJbGTsqKralZW0vmbgjBzDYH1JFSB6jgQVjTd3Ykel0SwCq8ziiYc+z1siFnzYUnVg6rvM5Z+P05KmjfzWedZYuIYbrzKqNqw0ULYXEwZab68Yzar96Q2SYc/q8KOJAQxvWcorFh8ZRjM8FBL4Z5xtzgTfTBL8edLAcglrCfKh1ZJaPMQwf0jdzgcfBt6B0Ox78hqJJRzOD8nfx45D6zfg34BDvb+KXqGc4Xo+/O2p7owp9q4nU6FdDKxNHTx2XdT5jtQrilSuS4o7Cu5Yg4zTxHgtWSdQGLRQSt57SqitXsjfmhpQaKfTk5hF+VPYXnZXkii/KJq2KMtS+xNEJD0zBNkGHUvXIJmxQDAGw/smUzCiiwLYo6WOhCjmTe7v0Nc/yuRdmmvxH37c0oXGFIfKMpeG5yDOGzdidF1kR7TxStyt2yZmq5gXYVOu9ferp0OApkXFjAuyqG26YBbhZBM+/Mn/hV22M5Z54tXnSuxUKYu2xLaWb0zK3FBWvS8IcL0TGlMmsHzOrJGI+axB4JYE1m6XILYPC/6vZn0u/qi0KKfcllqmq0TDw8X/zT81TeRCbq2d612APMAVB2ME1YtaO2JWPfha2EFKzxoaghHesDf6lsl9tozplATJrPNFsjSpI+F27EKhqZNfqFSgM502Wi+DS78rwPLVMOiBrx1g4xOAWSHT9hOheijSQWVVi6EY2hmB+e6lzMUPjE836E5IV4dynJbIG1PLHxZ2X+7TsWoV+ZjMth6t50OgvJvZXzTwH89DL7uyA6LpFZzMyxOueQIBXnCQSZnQR9ON5AeR88aFCGh3Q2leieUf334wI5Xj2ESvbyzPZeQhMjVyzIIWoEcCV0JmOg5fpi/SuXM71zs/hWdpUNQd+V0zPV2sIXNprvRAphHq9kLnH3UtNYnceyEVsyMQOgKwKsbrMl/RUF/5PyzR/WmD5Mkuz8iWxhVuy6VeuKW5+Gc60c5LSI8edyr4ZX+Q8rT6h3C117zSVLnEpJM3GLcdPFUjc8khycC2KUiWqOcpAtqXWW7noNXr7nCx4XrM/h+7s1lsq+7snvdWWYOGgSNcAzx+/HtLrg9kB8GEFDlgNzboDVnb9gZz4GsSEXf+IlB1B5yKO1GtMPd7htTFTd/DSdB4fzzdlNHh7N2SkN3h5NXSHLuPWfdXa8tXaxBv5O4uKd+bn7ywu2pmvGT3nIivrtbY0NL43jp5D0QNde60l4U1XPePmkJRSoW8aOedyeT2rSkNzIHhtNw5J9w+DLB2+ger4gdnGuK7r1CJqMbJqK7yuiUY5ZjlJnS4aMstJhj1U4yUkGdTQTlTl7QioKJ2i8MB05mz3r55Yr/RS02pM55knd8CN5uNdEc0ihfP0zDkRH0/C1MkdZ2UuiPikVkNhQSxtZW71Gfx6jBhRmtUjwzE9azhDy5CZeR5KYuQl1aI3SMe598j/d3DjyGMo3No45vgHuO3eAnf3rPVQBLg90EwRDU2FT896EZMtMVEzitkFfLmwV5okYZMn2I+WhTS/d440gc2dINUrV6KzueBE7yyJzZ2Igj7JEsHkMFM02CEKdgZGJf2xU1PoTh2cIoT3yRz0ulQveuUMdDaRiLOE3qnDic6CvjkD48NJDlXBxguIdzbOEnaPFJ3DzdpzDd0EeuGS8MmBVPbJvIkU+StHy7ciTFWJnk9Fvchn4ismf5cpmY0arjKZpcY19crCRCLWwgjn5gszDJ7ZncmtXnOGPj/58tyZxyYbPhAUpitT5ZFJpzevC21+XxS5tNBhR4xHjnhs8B8la8eHt6Q4eCWIvaTOfgJri/a6uNk5rpodWpc5PwFnzIGreq7AAO+9Y2aA2MFbvezXU2W4a2/8uq34yIKY+uK8ZXG11xaeWBda7OFXE9eY6J3m5DYhNHiiJxXd/OEE18KVuXV7zEdq5W0tmXG84D+KbN+ACcpbXnke3jnubrkBr67huLXrd+IApwSvQeG41YANmxEBFlIFjmHRYEYsu+Pqpe8pGGubPnbLe5s3QwpFrao9Ph7a1OcjdLasIiq+gMPo50y/dD2lMqlsPP/NzIsw6yqaZRWJDHlNbRQOQmpKUUiZL+T8Sbgc0M3/eC5xQZU3qdlncgKx7NW2uw11yM4YSGicESK/pxgM2pv2LAzE9miwNZrXkcHRG3wUgYwF3kW8mmP767t+ZCiXC9nJHgnWLhQskT6lAYHFXpC0dbbOq54vMk7MspGlxZtig1MVJVe7KSclE+s6P3ewvpaaFBg1xjjQXXWRnZPBchiD5GA0qBSwbx3AaTlK5F7HFPVKveb2NpCx5xwAuQa5y7eEbDYo5G6/OAD8Zk2M+9ou4XXHvBD7fgoF2uo1sp7FLXiBzoWGXxjJBPpSo8vQAHVUtmpL5OqY6PZIIvfVNvws8t3cRejZvitk8tetkDXSh6F+paHLKCP5qOoXlSK5kcjFsBKB/YB+2SqyNTS0FbVS2XRkxu3m6bez4TE6Muv2DKb2ahu8GP9xdvbpONqdXbVCkWc2swaOomgRi0uJI2r1LmKeC5xM74Bmk8XK0aPdLOrgKHoTrKHvL0TnRq7ihYQvYX7ao8LVtdL9tOob1cW77qVyean7XUYadDK1lIUuUIoMEeDeMmEseqbPmNQ6Az06HUlnlKWeQGZ0Awpoc/mxtcosuvqylsg9N4zKV22JWB4Z2RaORKU/dxUfj3oMbGSN6jXTweC/KdYbCj+xabD99YNSxl0/RHampnkMu2I9KMVIw4eiCuYt6rw0OAHsdhIImlDPjkCy12HW/RTMkp9QLGwiAlTXyErVN4THTuKW9tdHVO7aX2PalqH221EepKfO1kSakVvCF8Mex78MjnjacmFeaOi8Cy1P6WfoLGeqj8/UnKec6/QPMLhxW3bOtsYg+jwx0qs4MKjUl8kFHlDFXBmQ4n6CPPVeFknvCU050jUOjiHRsGcosmIH6p59z+Tpw0Ub05ofbZlyen5EUOO7+ZE14431rGZl0v81+5fDBKVjyv44SNJnUxv9zAOLw9LrvT0bODPTMn6in2w+Sr9cFrvsXN3kjqVx9qHS5INxbS0lY5RG7SZJ7rP+Op7cnhs0Ld8zY11O1rpMrFc5XS7UTe4WYAtcmbUdBQpcxCh+4Ku3cCgVciG7iUPGV+/e4An5vgSzzYPkqzOagvX3m/F2juCqkPiT10KbD5Q0tN1uImmVdn1+EN7BUf/9lvAyL6+y8Ia8Cq+cqye0qy8sDMlz14IfCZ3ObsxcOzlE++NT2pNP1I0vGk7n8JmdHFPP1Aw7ATdre6S5KyPkAmgAW3RLIt2inJiMC/XfeGZ9HfkgsQILFykVSywPE+vGztsKST6zrGFIOCy/XlNzfXld1aF6w2f62ZGRefrPDOs/qK4LzrC3z9g3cvWLLdtertHdt1c7rb1QHjlhhMpetyiWmafdC1uJL/hFqzPQHaRryGNRRQi3IQDaBNIWpGfsDhMx1jsUeEEFHA5HINex8yF9FSso/YI+AwPoM530bs511RKiRmW1ffp2+gvoig7EvxHMCQjmXs7PzJsOONqQ4beAZNI+E9IiEUIjMuTyxHgeSo7noyfApCRKZ8MqLU5Ay9HKqedaBH/oVWU2Taa4cBedo0XEexJAYvpszdp7KeMh9cGJqqOzQnMPNkjzSxfXnPvgx7i80WMsPBVt7YgC965fqL/Y/TyQJ2bjLjFPrN77zAYkUplEKWc8ihJV2PyHx+ZmVFAoDZm/05H0DtmRaQHlyeZFsZeq173ab/mlxyx856THGsn+znU1F8cVSNLKA6YdkZGX39G3MtC35G9sb7OQG90MDpnx256NfEt9Ayv9d/b9PjM89LaJQrJyDbuPk7qL6BsJTJkdR3gzlaXchWJ26Mtc9LunKfT0iR1Hu8D8+RAcPQLB/Hld4OiKjWHz8vLmh200OAKTnz6FyceO0Xt+f0rvPXIXjobEe0+bm5/tp2kaTyiBbPw+M7t3iHmPi6OwIq7Qfw5D40IYnj6h7v9FP0LtZqA+a0EUWTA+h7UJhgJJr3yEh93QXIITMUEeUBUWVenTFTnveNWk43PCLcYtq6BVxIIOqIqcUukXWqT0roop3Tc10H/KpizfujnbJtIvdL5DeMoQ5+8jPB7qVZleO636haY8sSYH4aoDWRQ0L5pyrm0cCUdQkU1R8dNCw+fmzJ4dWxfoWRIaUhtO0F1E/JKT5VVHW0KCGhNKlkclrPrcwKd6Q7ZPurN7YWBwiddVt/xAv2yFc4Zf1rpqH//Jq5PGz07TH66buzIre9MUf2yNZUgSvyGJDcM7pwUKlI/ImSlYJV8ChWVEI4zu6OgCnOF0IhTeJB90jvkP/RgK/0McUmXgLd5gEeJwK7snegCHSLdkAqT4pFwTo2OeKk4siCUhSYVOCkI8RcwYF9wifRpD5qhm2mrZrE0v3D8zNHbZWQO/yeszfbIUES3jk2ZHycfKSHCXrnX2i5hzpKzqowVRQK1XHyLpStk9Hg7kwBcA5K9LL7FbMSOIzUnvtlX6jXvn9tySg7MTh9N/CWfklbRF6VhOWhafv3tGaMzSc41xMyLCpsV7FUXbjo0qNHAo2v10xxlo92WF3+R3MpJLmn7YFJDpHD7rg9LKkwtjvo6ZnZDQEu0QV+LpVRLvoNnLFsHqo1w9tJ0gmlTm5HPVXOrBsLs/vTJg91NSx5n3GJT4TURNXqxU9M6PNe8WvWaOpf8s1bLGyysTHMdPDoyp9Y+ce6y87Ni8yICa6IDqJKdxqy41jp8WEj49Pn5GeMj08SFlPt5loWFlXj5lBr7V72SETi8I1NHm5y6MT24r9/Yub0uOX5jL19YJLJgemvFOte9Vz4kh4ZV+fpXhIRM9iV3uEwICct1QPhQwwZ3tkceoRx529wjSB3VoL2FTa8yPyIxi9oiSLtjwegZPonri+6gfoJbBjPzi5dHDLKuXJuTvQf2w7Hxj0o5llX4J79xq8i6KsR0bXejNdIzQr2Z9RnJZ0/3NflkuqBsmVp5aHENAh6JdT3d00F9dqyB+cIif6OlREucQ05oQPyuanYV4zPHh/IA01pVdwVKPQOxBk0vyICJajioiMV53RiOkZlGRVDL+gn1djQiafLQ5KGxGom2odd77dSmL813L03OhwFR8L8rtG/p+jmvL/IP050bhgV6lob5Tr6eYuVnEh0Wkegr9qttTMubXeLpV1geXvJujyJkaVrwzIJQ+494ase7f4V0Vdp4m0AoW6rtO8PXNktsQB7yErgHWXrFJwcqJWNY7u36FvzAzxCiTF5Bisn9Gd0UfGguaHCNtbCIdmV/4DfmiU4sWjg2zdwyztg5ztA8by0CiV8JfqDo1JBTI94d0SvCHYGkvQPRKDIjabR3u4BA6dmyog0O4NYIT3/Ur+RzpMZ7dBJBR4V4OToIdHLt3FRmgsD8OONvYNcopKMMt08M1y4fqIiKbd+UsulFXU+gdZVnnGGVjE6Xm4oIgf1aSj9nYyljP8Y526cEl6ye65h9umr7P2zI0L1ZAW/fnL59uoLSpKjVdjGvv9W6QHM+/sCMj3mghUNOjvuZG3FTTleXem676KQXe0ZI6J0yRE0MXsaabLo8kTFfxBg1dViH5MQJ4hxUUKzTsHT6iHxIHufYApQkCV319PDVKIOXT1xdJpMRH0pBsj2cRZR7OExOfzWwlcqbCYZB6lLGBPkgfWd1K/4++dvwreBbDiUFwAhEcfQTHFzlBgpDJUfDK7FSO8Uv3MPYojXzmkR0inT2Dfrj4t5uf5a2G0TBhQ8YjupN+PvUe7YNXFT5DUJYhKDwmJ0eDgFz4Gbz85Zf0Q17w5b/GXcaYKlAbpbqNQs6XKMT8ii+/hJfoh5c5By6/OIXbLKEfkm6oDWYR2xbenI/GOrxTBTszoRTJvnuUY3qBdKvYV+ebXGZiUpbsW7evIilXKsnLysqTSHOT6IeSlI1NHeXFnKecorJPmzamSC5Bx/zo390LYwwNDeMK3X+NzndS00YaIrx4Tk/BbIxh4kqWAqlE4aJGJ5ILLRgSdImK5ByEKTMTYcpJrthb52uTk0Al5tn41u2lH150yo/+1b0wDmGJLVT+Hp3neAmT8mlUjh38zSEnugPTgn0encNbwzkBIvC+MmhuSfDRKITDG2bYIdnYS6NPbODFLDyyfpHxfxTudYqN1gasR1Lm9DU6+e6032H293uh8TftsaPc0men+9QlDtMyXl0771S+b83G7PwFJjqn5a5BUWPG71LtfUSf2r0XxjxLWDPVKsh57bFVrU0eVQmxlZ7yMjrnP3AbtLkNM1/OTXrn+qtFOYfWVPtZRHqF5TR/v6LscGt4qHOuKt81KOXokkVP3s//gD788Al9fN9oy5EnRLYmxMxN60qmuUXMTEheNh5xPxp5UB1m3+oYFM0LxKREgOJLpshJMSpynoQpKH0UEyf86DN+l/xuWFx3vWbxJarBQPRzXXxDft3imj+dBAPlKNxuoWfClkvQ6zJbo2deps9domcSUdALYZyF/Hcz9QRZs7LPnL6bUqYUsZOZ6ol95Lx5MvwugmacUQ/8qomnY2a3znN293Zb3roi6sOCouPRK+e2u3krnRfPnRN7pixt/ZTAwCnr09LX1wUG1q03CPFpnT8v+lhB6amYFfNXuPv5e66e3x59sqTgSOSi+XP9Qg+HTNuelbO9KSSkaXtO1vZpIVgfLbrMiZ+4o5gVPCiBxE+0+X14lzvqpRb3Bb7/nDaHD3gfsCt8Ej588JT3wfNK7RXYY12lH8ATjG/HloYMTYBaXH2M/uB6VQz3kSqBONgPBwfKIUEwOO5yX7zUwpZIQNKWuMNgEIoVpK0qn7hz+zZ+zZWAFOi5Q4FO0HNHq9cdLfBCc+czqE8GkyvwGAH7zdwTVGBtqotLam2g+gj1e50wR0ztDrKe0GLXNPGOhh0HjqWiKxmqd/vfE5M7UuHwA+qb6O4Vsh5eVd9FI90DYwiNNXcJfJfM10gLkmLmHzENN1Jt7WnKNCcwJvJUt2yxhqpp2XVQQ0+vloe64SKqsH4T0alwxEHVth4C1Rw00S3wO/AfDQdNuBndouEAj9Y/QwccZXP6j3yh9uG2tuH29hG2thF8mwh7+3AbG3xqg2Ch53iAeW6Meg1ryFki8VCwqSfMAUO2iVCFak76Yx2sro45fqZsGGoG0EIOhdt+MB6JTnyZPQu3RTiwHDspG000Iib7r8IzkrXrxQorZaq0DyAsc0ICfybzsczhULQRkr5PEiALLKfOU/6Ag2elrPCqPZQzv/D/6CrYBo3oOrhwF1MdhavL4R14h7amrTVHvAMdwTjWFwb7nxgOF6KHjGAbXaWS9dQHAkE87AHG1CKqlR1xIR8KIX8P+b0qhDgJH1yFV1Di+9UI+kYX8z2uO6jtCbYtRE1xc+pE5xjilCqYvAcf0HIIoP0IaAcJWo65/Bf4k1pF7mT1G3/mBKUown+R5zq9yHN/3r0Lr337LYJ6EqRSu6lQhgs8T8Jn38om/OmpcM73cC6N+mPJTbiYrr1J16D2x0EidYCKUnMtg1AJoQhCaji9i969HaYyPzBtG70bpibi020wDaa+S++E6e/Su+ldOEb/DFhRm6nG7jeikSey6q9tmnidPaU2d1rBJ3bhtjYRdnZhtrZhdna4g9k6ceqbb5p7bkTYdD6E6NQWn9raMZrdAXyobdQU9j18QTeXyC8jmXTAlnuwmW6+R88kvydWfQVH0M++ov8Hh6v2fP01lvwmOJ06R9rg+Q2BVL0IxoSXKBBjhn4Zk+aItpKxS9Ick9IUjt5S92B4nUxYkhIxI1rsYG2kCCPgljkHk43cnaxlSSmzDyb7Bppa6MXjj8uBb6CMiiYJ/F4yZPqALFNVkZORdDm3aGZFBXQ54q9YYe8jxr7+k06/a3iNKoJ0INs4+xj9QTosISVkBHT+CTrf/Hz4RSTD6apW2EH7o5ZtxGKyA3k7PvZ1PJmVlVJEykmliMNBWTz8kv9nGtSm/0z7k/++3otU+gXUSn2hRyyGsu3rZs/esB3K6K+3b5g9e912+mu816EAplO/oVxABGyBJ97rAJn8nJnkwFks2X9UlnW/2SaSyCTC7jfbiL25B9vwBGTbwdy8AytKvbxKVxzIS99YHxRUvzFdfayHOvbjXJ2lpStSJuSYOrmMzoXpzBM9zzK11b2eYY77iFGyWA9ljOGXR49CQxsbWwmS4O6uh9zdKIvFtMdrZhYGpxxqVm4lfT6AwSYWDgS5e+ZPHUtiY5d0/DSzpzb54trk5LUXJ6uP9K2AmrUp0fPKQrQvanmOc/It8UX/w4pGXNQOLJ4dnbK2JkDUDwJTu9MLBnMkZLitS0ZTmE2ApU+xn2+JT5xfWFOGC4KPbb6BtCBdOP9V29Wb9p/cCp+Z5+aWNzM8fAZO82eE20fZ2UXZM7+kBb4QwTaIwA1O2EXaO0Ta20c62EfaIVzriSOkHec8MMd7DNk1A2Syms3eQpnGfFEsjDIeks2oseSI4jFFkY2zDxws8fQJinw/dllu2pxIHb3DOrolKeM8fMamGJM8C+fpxVUNcp8gufPIoIk+vk2Z9HmHdEcLaB1oN9ZRaoQjReIwGYTw8zGvgm5vocnulJoUUKHheVby5rLKTUlJGyoqtyQdksV7ecZIZbFenrEyyiBm4taMzK0lMcWbMzK2HI7xynJTZHvFeOUo3ZlVdTyrrWRWJQD2Gt2LBshUU44kNZ5sDghoPtkIH1JdqrGhM/cVFeybGYrfNyNAOX2DUiBLCQF4a6BEqp5ZMBRxzCge3r/MrqAz+YPcwFCpnsG3csATEUpFd1ZhSLqhqyi74nHxsrubG/nvxzBxfHiaY/AYKBL5+ruacDi+460JTy//SauTZpyt/KU8zTbWxSHQjH5gOS7MmiI9k+zkfp6lbSlNRwrnk0HetGq0jz3FifDsHO3vTBWHZIYqpH5OI5fqSJVR+b7uqV7DCfnM+PGzUuxz3q9PSCXgaDcbOx9bvcX67nHlYV6ZvsMplxlxUTOy5BP2q5wcYk1aRgjcbV1jTKbrGnpiqZWRMwgL7hF2vhZJjadQEha3tO98yT3SeYmYPfPoNNyqiJxBenFPM94Vvxmm1h9Jt/vHUhKKhTUwJ9Avydc/7nLqhqLKLSkCz5rciXAzOWMNpFwCZC5KV6eEOj/fqkiLsLgsjyjeHgQ7n6wlUxBsR9YacOKs8TyaDeZ4+5JaxMwuA3UEcSdqXrE3/IZICwxOTo/OzQ0YH+Xrl0x84Z7fElm0PrksuaZmwn6y1jIo011i72pjp5ilsLV2srdyzwiw9KsICUrV5g3PiYmo8kUeJw4A7g4m0hQzu/qQpxYPxalGWFco8CkK3a9CU4VzsIOD19Go1sSM2eF8p6yYSBjwyu609kfv4nnvVjhaEWXr5OriEF3h5VsWZOITVx6VMGwd3nhIvLP04HTksTEN2cxMsC4wxGtrVgqIN4hIhBIFTi4EapwINykkv4BBT/Lzj7yaw1AQgBFRaTrHa1cTDqrb62pra9ndimrwr7xhDH1aB2FJRFhecv7NYPHB82/9sOAg8vWdgGeQBnQCpoUqhsG/qGk52wk2j1ucSn7CCbd3DQ4OTE52CXSzM1VaEkfJ8QsSUqcHJQRnpSe2kV39aSVWuGQHGpq62th7L/a0lznxzQ2DCt0DSn2DM3WG6eTFhVT40tNYLjjgYtePPH/OI8az4HeVojTfLentY+CAKyRi0Kq3w2EmJOCAK1xe0ZLwyCUFxYvCwhe9au91cplhkdzpqBAZKpwclKNGKTtt0InQzcnBbZRIaZy6Ijk2ZUVKalsKPpDK3udtqZ33MauL7ENlsbIwe4cwaaws1J5U9j3HUSf1hHBidtIyGdKeRZ2X1NtsIdiI7lmx9/A3jmDxJdWi7j24UJdDkHe4AjZDeONbc+8M9u2LITYPQ3CIIyd+4XyvyVGJX1TnON8fPIjuXKOziUBgz2QOPe+HyIXqd0Cusa+AWFRQORMmaV7z+M4+hX2ZA/liA9SPG5ivyBgz35FiNvH0/5YUDgyJS7TW6dPMF6VO5O3v+aIUXERPIRadIhb1/7AUnXmK/QovcMNf/6S00TUTJl7DdQJZg4m6TvW6zkV1GxABKkEtKAST0UiaiI4VYCKynCpQDgrAOHReDKageh6639PSfkBLkv0EKH0Uf4944N//A6p9bDc=","l":22856,"w":[252,321,523,644,650,1004,663,326,373,373,540,673,319,465,319,379,660,423,623,636,666,629,640,576,640,640,319,329,673,673,673,543,999,728,659,737,722,605,588,749,746,277,580,703,565,922,759,769,645,773,652,650,660,736,728,1020,720,713,652,373,379,373,481,469,351,574,624,583,624,591,389,625,612,262,262,569,262,900,612,609,624,624,397,549,353,612,587,839,569,588,566,455,359,455,673,0,679,0,0,0,0,956,0,0,0,0,0,0,0,0,0,0,0,294,294,507,501,503,500,1000,0,0,0,0,0,0,0,0,252,321,583,629,749,563,316,578,612,914,472,634,673,0,667,452,458,673,454,463,351,614,600,319,332,324,471,634,831,870,907,543,728,728,728,728,728,728,1013,737,605,605,605,605,277,277,277,277,751,759,769,769,769,769,769,673,769,736,736,736,736,713,658,644,574,574,574,574,574,574,913,583,591,591,591,591,262,262,262,262,594,612,609,609,609,609,609,673,609,612,612,612,612,588,624,588],"b":[-53,-234,1000,995],"a":969,"de":-241,"c":728}};
  function pdfBytes(M) {
    const W = 595, H = 842, X = 40, CW = W - 2 * X, F = [PDFF.r, PDFF.b];
    const C = { head: [.20, .36, .29], done: [.16, .52, .30], sel: [.15, .40, .70], miss: [.80, .43, .12], text: [.10, .12, .14], mut: [.42, .45, .48], band: [.91, .94, .91], track: [.87, .88, .89], zebra: [.96, .965, .96], white: [1, 1, 1], pale: [.84, .91, .87] };
    const mix = (c, k) => c.map(v => v + (1 - v) * k);
    const SP = { 8211: 0x96, 8212: 0x97, 8216: 0x91, 8217: 0x92, 8220: 0x93, 8221: 0x94, 8226: 0x95, 8364: 0x80, 8230: 0x85 };
    const enc = s => { const out = []; for (const ch of String(s).replace(/→/g, '->').replace(/[✓✔]/g, '+')) { const c = ch.codePointAt(0); out.push(SP[c] || (c >= 32 && c < 127) || (c >= 160 && c < 256) ? (SP[c] || c) : 63); } return out; };
    const wid = (s, size, bold) => enc(s).reduce((a, c) => a + (F[bold ? 1 : 0].w[c - 32] || 500), 0) * size / 1000;
    const pages = []; let pg = null, y = 0;
    const col = c => c.map(v => v.toFixed(3)).join(' ');
    const newPage = first => { pg = []; pages.push(pg); y = first ? H - 84 - 18 : H - 46; };
    const tx = (s, x, yy, size, bold, c) => pg.push(`BT /F${bold ? 2 : 1} ${size} Tf ${col(c)} rg ${x.toFixed(1)} ${yy.toFixed(1)} Td (${enc(s).map(k => (k === 40 || k === 41 || k === 92 ? '\\' : '') + String.fromCharCode(k)).join('')}) Tj ET`);
    const rc = (x, yy, w, h, c) => pg.push(`${col(c)} rg ${x.toFixed(1)} ${yy.toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)} re f`);
    const need = h => { if (y - h < 54) newPage(false); };
    const wrap = (s, size, bold, maxW) => { const rows = []; let cur = ''; for (const w of String(s).split(/\s+/).filter(Boolean)) { const t2 = cur ? cur + ' ' + w : w; if (cur && wid(t2, size, bold) > maxW) { rows.push(cur); cur = w; } else cur = t2; } if (cur) rows.push(cur); return rows; };
    const fit = (s, size, bold, maxW) => { s = String(s); while (s.length > 1 && wid(s, size, bold) > maxW) s = s.slice(0, -2) + '…'; return s; };
    const right = (s, xr, yy, size, bold, c) => tx(s, xr - wid(s, size, bold), yy, size, bold, c);
    // header band
    newPage(true); rc(0, H - 84, W, 84, C.head); rc(0, H - 86, W, 2, C.pale);
    tx(M.title, X, H - 46, 24, 1, C.white); tx(M.sub, X, H - 66, 10.5, 0, C.pale);
    // tiles
    const tw = (CW - 20) / 3;
    M.tiles.forEach((t, i) => { const x = X + i * (tw + 10); rc(x, y - 48, tw, 48, mix(t.c, .88)); rc(x, y - 48, 4, 48, t.c); tx(String(t.v), x + 14, y - 28, 20, 1, t.c); tx(t.l, x + 14, y - 41, 9, 0, C.mut); });
    y -= 48 + 16;
    const band = (name, right2, acc) => { need(48); rc(X, y - 22, CW, 22, C.band); rc(X, y - 22, 4, 22, acc); tx(name, X + 14, y - 15, 12.5, 1, C.text); if (right2) right(right2, X + CW - 10, y - 15, 10, 1, C.mut); y -= 22 + 9; };
    const lines = (label, items, c, ind) => { const lw = wid(label, 9, 1) + 8, rows = wrap(items, 9.5, 0, CW - ind - 10 - lw); need(rows.length * 12.5 + 2); tx(label, X + ind, y - 9, 9, 1, c); rows.forEach((r, i) => { tx(r, X + ind + lw, y - 9 - i * 12.5, 9.5, 0, c); }); y -= rows.length * 12.5 + 2; };
    M.cats.forEach(cat => {
      band(cat.name, cat.want ? `${cat.have}/${cat.want}` : '', C.head);
      cat.rows.forEach(r => {
        const dn = r.dn.length ? wrap(r.dn.join(', '), 9.5, 0, CW - 20 - 60).length : 0, sl = r.sl.length ? wrap(r.sl.join(', '), 9.5, 0, CW - 20 - 60).length : 0;
        need(36 + (dn + sl) * 12.5 + (r.missing ? 12 : 0));
        tx(fit(r.name, 11, 1, CW - 90), X + 10, y - 11, 11, 1, C.text); right(`${r.done + r.sel}/${r.need}`, X + CW - 10, y - 11, 11, 1, r.missing ? C.miss : C.done);
        const bw = CW - 20, yb = y - 22; rc(X + 10, yb, bw, 5, C.track);
        if (r.need > 0) { const dw = bw * Math.min(1, r.done / r.need), sw = bw * Math.min(Math.max(0, r.need - r.done), r.sel) / r.need; if (dw > 0) rc(X + 10, yb, dw, 5, C.done); if (sw > 0) rc(X + 10 + dw, yb, sw, 5, C.sel); }
        y -= 30;
        if (r.dn.length) lines(M.l.done, r.dn.join(', '), C.done, 10);
        if (r.sl.length) lines(M.l.sel, r.sl.join(', '), C.sel, 10);
        if (r.missing) { tx(`${M.l.miss}: ${r.missing}`, X + 10, y - 9, 9, 1, C.miss); y -= 12; }
        y -= 8;
      });
      if (cat.others.length) { lines(M.l.others, cat.others.map(o => o.b + (o.sel ? ' (' + M.l.sel.toLowerCase() + ')' : '')).join(', '), C.text, 10); y -= 6; }
      y -= 6;
    });
    if (M.plan.length) {
      band(M.l.plan, '', C.miss);
      M.plan.forEach((p, i) => { need(15); if (i % 2 === 0) rc(X, y - 13, CW, 15, C.zebra); tx(fit(p.tok, 9.5, 1, 120), X + 10, y - 9, 9.5, 1, C.text); tx(p.nf ? M.l.nf : (p.raw ? '' : p.grp), X + 140, y - 9, 9.5, 0, p.nf ? C.miss : C.text); if (p.per) tx(fit(p.per, 9, 0, CW - 250), X + 240, y - 9, 9, 0, C.mut); y -= 15; });
    }
    pages.forEach((p, i) => { pg = p; rc(X, 40, CW, .6, C.track); tx(`Wilma Kurssit · ${M.l.page} ${i + 1}/${pages.length}`, X, 27, 8, 0, C.mut); });
    // file structure
    const bin = s => atob(s), objs = ['<< /Type /Catalog /Pages 2 0 R >>', ''];
    const nm = ['AAAAAA+Inter-Regular', 'AAAAAB+Inter-SemiBold'];
    F.forEach((f, i) => objs.push(`<< /Type /Font /Subtype /TrueType /BaseFont /${nm[i]} /FirstChar 32 /LastChar 255 /Widths [${f.w.join(' ')}] /FontDescriptor ${5 + i} 0 R /Encoding /WinAnsiEncoding >>`));
    F.forEach((f, i) => objs.push(`<< /Type /FontDescriptor /FontName /${nm[i]} /Flags 32 /FontBBox [${f.b.join(' ')}] /ItalicAngle 0 /Ascent ${f.a} /Descent ${f.de} /CapHeight ${f.c} /StemV ${i ? 100 : 80} /FontFile2 ${7 + i} 0 R >>`));
    F.forEach(f => { const d = bin(f.d); objs.push(`<< /Length ${d.length} /Length1 ${f.l} /Filter /FlateDecode >>\nstream\n${d}\nendstream`); });
    const kids = [];
    pages.forEach(p => { const c = p.join('\n'); objs.push(`<< /Length ${c.length} >>\nstream\n${c}\nendstream`); objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${objs.length} 0 R >>`); kids.push(objs.length + ' 0 R'); });
    objs[1] = `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${kids.length} >>`;
    let out = '%PDF-1.4\n%\xE2\xE3\xCF\xD3\n'; const offs = [];
    objs.forEach((o, i) => { offs.push(out.length); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
    const xr = out.length;
    out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offs.map(o => String(o).padStart(10, '0') + ' 00000 n \n').join('') + `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF`;
    return Uint8Array.from(out, ch => ch.charCodeAt(0) & 255);
  }
  function pdfModel() {
    const t = tr(), m = dashModel(), d = new Date(), y = +state.syear || 0;
    const live = m.rows.filter(r => !r.inactive), miss = live.reduce((a, r) => a + r.missing, 0);
    const cats = CAT_ORDER.map(id => {
      const rs = m.rows.filter(r => catOfRow(r) === id && !r.inactive), os = m.other.filter(c => catOfBase(c.base) === id && (c.done || c.sel));
      if (!rs.length && !os.length) return null;
      return { name: catName(id), have: rs.reduce((a, r) => a + Math.min(r.need, r.done + r.sel), 0), want: rs.reduce((a, r) => a + r.need, 0),
        rows: rs.map(r => ({ name: r.name, done: r.done, sel: r.sel, need: r.need, missing: r.missing, dn: r.courses.filter(c => c.done).map(c => c.base), sl: r.courses.filter(c => c.sel).map(c => c.base) })),
        others: os.map(c => ({ b: c.base, sel: c.sel && !c.done })) };
    }).filter(Boolean);
    const rowsP = plan.length ? plan : parseCodes(state.list).map(token => ({ token, cands: [], choice: 0, raw: 1 }));
    return { title: t.pdfTitle, sub: d.toLocaleDateString(state.lang === 'sv' ? 'sv-FI' : state.lang === 'en' ? 'en-GB' : 'fi-FI') + (y ? ' · ' + t.pdfYear + ': ' + t.yearOpts[y] : ''),
      tiles: [{ v: m.all.filter(c => c.done).length, l: t.pdfDone, c: [.16, .52, .30] }, { v: m.all.filter(c => c.sel).length, l: t.pdfSel, c: [.15, .40, .70] }, { v: miss, l: t.pdfMiss + ' (' + (D[state.lang] || D.en).req + ')', c: [.80, .43, .12] }],
      cats, plan: rowsP.map(p => { const c = p.cands[p.choice]; return { tok: p.token, raw: !!p.raw, nf: !p.raw && !c, grp: c ? c.code : '', per: c ? c.period || '' : '' }; }),
      l: { done: t.pdfDone, sel: t.pdfSel, miss: t.pdfMiss, others: t.pdfOthers, plan: t.pdfPlan, nf: t.pdfNotFound, page: t.pdfPage } };
  }
  const stamp = () => { const d = new Date(), p2 = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`; };
  function download(name, data, type) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); }
  function exportPdf() { download('wilma-kurssivalinnat-' + stamp() + '.pdf', pdfBytes(pdfModel()), 'application/pdf'); log(tr().pdfSaved); }
  function exportCsv() {
    const t = tr(), m = dashModel(), rows = [];
    const add = (c, name) => rows.push([c.base, name, catName(catOfBase(c.base)), c.ign ? t.csvIgn : c.done ? t.pdfDone : c.sel ? t.pdfSel : t.csvOpen, YLV[c.base] || '', (c.kind || 'v') === 'm' ? t.csvMan : t.csvOpt]);
    m.rows.forEach(r => r.courses.forEach(c => add(c, r.name))); m.other.forEach(c => add(c, ''));
    rows.sort((a, b) => a[0].localeCompare(b[0], 'fi', { numeric: true }));
    const q2 = v => { v = String(v); return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    download('wilma-kurssit-' + stamp() + '.csv', '﻿' + [t.csvHead, ...rows].map(r => r.map(q2).join(';')).join('\r\n') + '\r\n', 'text/csv;charset=utf-8');
    log(t.csvSaved);
  }
  async function copyList() {
    const t = tr(), txt = parseCodes($('.list').value).join(' ');
    if (!txt) { log(t.copyNone); return; }
    let ok = false; try { await navigator.clipboard.writeText(txt); ok = true; } catch (_) { try { const a = document.createElement('textarea'); a.value = txt; a.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(a); a.select(); ok = document.execCommand('copy'); a.remove(); } catch (_2) { ok = false; } }
    log(ok ? t.copied2 : t.copyFail);
  }

  const inList = base => parseCodes(state.list).some(t => baseOf(t) === base);

  function loopStat(d) {
    const L = readLoop();
    if (loopActive()) {
      const left = Math.max(0, Math.round(((L.t0 || 0) + (L.max || 30) * 60000 - Date.now()) / 60000));
      return `<div class="lstat on" role="status">\u{1F501} <b>${d.lsOn}</b> \u00B7 ${L.mode === 'fetch' ? d.lsFetch(L.workers || 6) : L.mode === 'hybrid' ? d.lsHybrid : d.lsReload} \u00B7 ${d.lsRound} ${L.rounds || 0} \u00B7 ${L.delay || 2} s \u00B7 ${d.lsLeft} ${left} min${L.unstable ? ' \u00B7 \u26A0' : ''}</div>`;
    }
    return L.why ? `<div class="lstat" role="status">\u23F9 ${d.lsOff}: ${esc((d.why || {})[L.why] || L.why)}${L.rounds ? ' \u00B7 ' + d.lsRound + ' ' + L.rounds : ''}</div>` : '';
  }
  let statTimer = 0;
  // the loop's status strip is updated in place (scroll position, hover and open cards stay); a full redraw only when the strip appears or disappears
  function paintStat() {
    const el = $('.lstat'), next = loopStat(D[state.lang] || D.en);
    if (el && next) el.outerHTML = next; else if (el || next) renderDash();
  }
  const schedStat = () => { if (statTimer || !onDash()) return; statTimer = setTimeout(() => { statTimer = 0; paintStat(); }, 600); };
  function renderDash() {
    const el = $('.dash'); if (!el || !onDash()) return;
    paintProg();
    const d = D[state.lang] || D.en, m = dashModel(), pm = !!state.pickMode, op = Math.max(1, +state.opPer || 2), hid = state.hiddenReq || [];
    const act = m.rows.filter(r => !r.inactive);
    const reqEarned = act.reduce((a, r) => a + Math.min(r.need, r.done), 0);
    const need = act.reduce((a, r) => a + r.need, 0), gotC = act.reduce((a, r) => a + Math.min(r.need, r.done + r.sel), 0), miss = need - gotC;
    const opOf = c => { const e = (state.earned || {})[c.base], h = (state.hops || {})[c.base]; return e && e.op != null ? e.op : h && h.op != null ? h.op : null; };
    const doneC = m.all.filter(c => c.done), nDone = doneC.length, nSel = m.all.filter(c => c.sel).length;
    const calcOp = doneC.reduce((a, c) => a + (opOf(c) != null ? opOf(c) : op), 0);
    const sumRows = state.summary || [], sumTot = sumRows.find(r => /yhteensä|totalt|total/i.test(r[0]));
    const wilmaOp = sumRows.length ? (sumTot ? sumTot[1] : sumRows.reduce((a, r) => a + r[1], 0)) : null;
    const earnedOp = wilmaOp != null ? wilmaOp : calcOp;
    const estimated = doneC.some(c => opOf(c) == null) || m.all.some(c => c.sel && opOf(c) == null), plannedOp = m.all.filter(c => c.sel).reduce((a, c) => a + (opOf(c) != null ? opOf(c) : op), 0);
    const mathRow = act.find(r => r.alt === 'mat'), lops = mathRow ? (mathRow.id === 'maa' ? 102 : 94) : 0;
    const lopsTxt = lops ? (need * op === lops ? d.lopsOk(lops) : d.lopsDiff(need * op, lops)) : '';
    const pct = (a, b) => (b ? Math.min(100, Math.round(100 * a / b)) : 0);
    const stOf = c => c.ign ? d.stIgn : c.done ? d.stDone + (c.m ? ', ' + d.stManual : '') : c.sel ? d.stSel : c.todo ? d.stTodo : d.stNone;
    const chip = c => {
      const cls = c.ign ? ' ign' : pm ? (c.done || c.sel ? ' blue' : c.todo ? ' todo' + (inList(c.base) ? ' inl' : '') : '') : (c.done ? ' done' : c.sel ? ' sel' : '');
      return `<button class="dchip${cls}${c.m ? ' man' : ''} k${c.kind || 'v'}${c.hp ? ' hp' : ''}${aboveYear(c.base) ? ' above' : ''}" data-dact="chip" data-base="${esc(c.base)}" title="${esc(d.chipTip(c.base, stOf(c)) + ' \u00b7 ' + ((c.kind || 'v') === 'm' ? d.man : d.opt) + (c.hp ? ' \u00b7 ' + d.inHops : '') + (aboveYear(c.base) ? ' \u00b7 ' + tr().yearAbove : '') + (pm && c.todo ? ' \u00b7 ' + (inList(c.base) ? d.inList : '+') : ''))}">${esc(c.base)}</button>`;
    };
    const key = r => (pm ? 'p:' : 'n:') + r.id;
    const isOpen = r => (state.dopen[key(r)] != null ? state.dopen[key(r)] : pm);
    const bar = r => `<div class="bar"><i class="d" style="width:${pct(Math.min(r.done, r.need), r.need)}%"></i><i class="s" style="width:${pct(Math.min(Math.max(0, r.need - r.done), r.sel), r.need)}%"></i></div>`;
    const card = r => {
      const body = pm
        ? `<div class="dsub">${d.todo}</div><div>${r.todoList.length ? r.todoList.map(chip).join('') : `<span class="dnote">${r.missing ? d.notOffered(r.missing) : d.yellowNone}</span>`}</div>${r.have.length ? `<div class="dsub">${d.have}</div><div>${r.have.map(chip).join('')}</div>` : ''}`
        : `<div>${r.courses.length ? r.courses.map(chip).join('') : `<span class="dnote">${d.nothing}</span>`}</div>`;
      return `<details class="dcard${r.inactive ? ' off' : ''}${!r.inactive && r.need > 0 && !r.missing ? ' complete' : ''}" data-rid="${esc(key(r))}"${isOpen(r) ? ' open' : ''}>
        <summary><span class="dname">${esc(r.name)}${r.inactive ? ` <small class="dnote">(${d.alt})</small>` : ''}</span><span class="dnums" title="${d.done} ${r.done} · ${d.sel} ${r.sel} · ${d.miss} ${r.missing} / ${d.need} ${r.need}">${r.done + r.sel}/${r.need}</span>
          <input type="number" min="0" max="40" value="${r.need}" data-dact="need" data-id="${esc(r.id)}" aria-label="${d.need}" title="${d.need}"><button class="x" data-dact="del" data-id="${esc(r.id)}" title="${d.del}" aria-label="${d.del}">✕</button></summary>
        ${bar(r)}<div class="dbody">${body}</div></details>`;
    };
    const shown = pm ? act.filter(r => r.missing > 0 || r.todoList.length) : m.rows;
    const finished = pm ? m.rows.filter(r => !r.inactive && !shown.includes(r)) : [];
    const yellow = act.flatMap(r => r.todoList).filter(c => !inList(c.base) && !aboveYear(c.base));
    const ignored = m.all.filter(c => c.ign);
    const hopsMissing = m.all.filter(c => c.sel && !c.hp);
    const catHtml = CAT_ORDER.map(id => {
      const rs = shown.filter(r => catOfRow(r) === id), os = pm ? [] : m.other.filter(c => catOfBase(c.base) === id);
      if (!rs.length && !os.length) return '';
      const live = rs.filter(r => !r.inactive), have = live.reduce((a, r) => a + Math.min(r.need, r.done + r.sel), 0), want = live.reduce((a, r) => a + r.need, 0), k = 'c:' + id;
      return `<details class="dcat" data-rid="${k}"${state.dopen[k] === false ? '' : ' open'}><summary>${esc(catName(id))}<span class="dnums">${want ? have + '/' + want : os.length ? os.length : ''}</span></summary>${rs.length ? `<div class="dgrid" style="padding-top:8px">${rs.map(card).join('')}</div>` : ''}${os.length ? `<div style="padding-top:6px">${os.map(chip).join('')}</div>` : ''}</details>`;
    }).join('');
    const xt = tr(), xr = (act, icon, label, desc) => `<div class="xrow dtools" data-hb><button class="act" data-act="${act}">${icon} ${label}</button><span class="dnote">${desc}</span></div>`;
    const exportHtml = `<div class="dexp"><div class="xh">${xt.expHead}</div>${xr('pdf', '\u{1F4C4}', xt.pdfBtn, xt.expPdfD)}${xr('csv', '\u{1F4CA}', xt.csvBtn, xt.expCsvD)}${xr('save', '\u{1F4BE}', xt.save, xt.expTxtD)}${xr('cfgsave', '\u2699', xt.cfgsave, xt.expCfgD)}${xr('copylist', '\u{1F4CB}', xt.copyBtn, xt.expCopyD)}${xr('debug', '\u{1F41E}', xt.dbg, xt.expDbgD)}<div class="xh">${xt.expImp}</div>${xr('load', '\u{1F4C2}', xt.load, xt.expLoadD)}${xr('cfgload', '\u{1F4E5}', xt.cfgload, xt.expCfgLoadD)}<div class="xmsg dnote" role="status"></div></div>`;
    const html = `
      ${exportHtml}
      <div class="dtop"><h3>${d.head}</h3></div>
      <div class="dtools" data-hb><label class="dnote">${tr().yearLbl} ${yearSel('syear2')}</label>${q('syear')}</div>
      ${loopStat(d)}
      <div class="dtiles">
        <div class="tile" title="${esc(tipOf('tileop'))}"><b>${earnedOp}<small> / 150 op</small></b><span>${d.earned}${wilmaOp == null && estimated ? ' \u00b7 ' + d.estimate : ''} \u00b7 +${plannedOp} ${d.planned} = ${earnedOp + plannedOp} ${d.projected}${wilmaOp != null ? `<br>${d.wsum}: ${sumRows.map(r => esc(r[0].replace(/^Lu21\s*/i, '')) + ' ' + r[1]).join(' \u00b7 ')}${calcOp !== wilmaOp ? ` \u00b7 ${d.calc} ${calcOp}` : ''}` : ''}</span></div>
        <div class="tile d" title="${esc(tipOf('tilereq'))}"><b>${reqEarned * op}<small> / ${need * op} op</small></b><span>${d.reqOp} · ${lopsTxt}</span></div>
        <div class="tile m" title="${esc(tipOf('tilemiss'))}"><b>${miss}</b><span>${d.miss} (${d.req})</span></div>
        <div class="tile s" title="${esc(tipOf('tilecnt'))}"><b>${nDone} / ${nSel}</b><span>${d.cntT}</span></div>
      </div>
      <div class="bar big" title="${esc(tipOf('tileop'))}"><i class="d" style="width:${pct(earnedOp, 150)}%"></i><i class="s" style="width:${pct(plannedOp, 150)}%"></i></div>
      <details class="legend" data-rid="legend"${state.dopen.legend ? ' open' : ''}><summary title="${esc(tipOf('legend'))}">\u{1F3A8} ${d.legend}</summary>
        <div class="lrows">${d.legRows.map(([c, l]) => `<div class="lrow"><span class="dchip ${c === 'kvm' ? 'km' : c === 'kvv' ? 'kv' : c}">\u00C4I01</span><span>${esc(l)}</span></div>`).join('')}</div><div class="dnote">${esc(d.legBar)}</div></details>
      <div class="dtools" data-hb>
        <button class="act pick${pm ? ' on' : ''}" data-dact="pickmode">\u{1F3AF} ${pm ? d.pickOn : d.pick}</button>${q('dpick')}
        <button class="act scan" data-act="dscan">↻ ${d.scan}</button>${q('dscan')}
        <button class="act" data-dact="fold">${d.fold}</button>${q('dfold')}
        <button class="act" data-act="pdf">\u{1F4C4} ${tr().pdfBtn}</button>${q('pdf')}
      </div>
      ${pm ? autoHtml(d) : ''}
      ${pm ? `<div class="dtools yel" data-hb><span class="dnote">${d.pickHelp}</span><button class="act" data-dact="addall"${yellow.length ? '' : ' disabled'}>${d.addAll(yellow.length)}</button>${q('dlist')}<button class="act go" data-dact="go">${d.go}</button>${q('dgo')}</div>` : ''}
      <details class="dtoolbox" data-rid="tools"${state.dopen.tools ? ' open' : ''}><summary title="${esc(tipOf('dtools'))}">⚙ ${d.tools}</summary>
        <div class="dtools" data-hb><button class="act" data-act="dprest">${d.getDone}</button>${q('dprest')}<button class="act" data-act="dhops">${d.getHops}</button>${q('dhops')}</div>
        <div class="dtools" data-hb><input class="dmanual" placeholder="${d.manual}" spellcheck="false"><button class="act" data-dact="manual">${d.manualBtn}</button>${q('dmanual')}</div>
        <div class="dtools" data-hb><input class="dnname" placeholder="${d.addName}"><input class="dnpref" placeholder="${d.addPref}"><input class="dnneed nn" type="number" min="0" max="40" value="1" aria-label="${d.cnt}"><button class="act" data-dact="add">${d.addBtn}</button>${q('dadd')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.hidden} (${hid.length}) <select class="dhid"${hid.length ? '' : ' disabled'}>${hid.length ? hid.map(r => `<option value="${esc(r.id)}">${esc(r.name)}</option>`).join('') : `<option>${d.hidNone}</option>`}</select></label><button class="act" data-dact="unhide"${hid.length ? '' : ' disabled'}>${d.unhide}</button><button class="act" data-dact="unhideall"${hid.length ? '' : ' disabled'}>${d.unhideAll}</button>${q('dhidden')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.op} <input class="nn" type="number" min="1" max="6" value="${op}" data-dact="op"></label>${q('dop')}<button class="act rst" data-dact="reset">${d.reset}</button>${q('dreset')}</div>
        <div data-hb><span class="dnote">${d.ignored} (${ignored.length}): </span>${ignored.map(chip).join('') || '<span class="dnote">–</span>'} ${q('dchip')}</div>
      </details>
      <details class="dtoolbox con" data-rid="net"${view === 'con' || state.dopen.net !== false ? ' open' : ''}><summary title="${esc(tipOf('con'))}">\u{1F5A5} ${d.con} <small class="ncnt dnote"></small></summary>
        <div class="dtools" data-hb><button class="act" data-dact="nclear">${d.conClear}</button><button class="act" data-dact="ncopy">${d.conCopy}</button><button class="act${netPaused ? ' on' : ''}" data-dact="npause">${netPaused ? '\u25B6 ' + d.conResume : '\u23F8 ' + d.conPause}</button><label class="dnote"><input type="checkbox" data-dopt="nonlypost"${netOnlyPost ? ' checked' : ''}> ${d.conPost}</label>${q('con')}</div>
        <div class="ncon" tabindex="0" role="log"></div>
      </details>
      <details class="dtoolbox dev" data-rid="dev"${view === 'dev' || state.dopen.dev ? ' open' : ''}><summary title="${esc(tipOf('devunlock'))}">\u{1F9EA} ${d.dev}</summary>
        <div class="devwarn">${d.devWarn}</div>
        <div class="dtools" data-hb><label class="dnote"><input type="checkbox" data-dopt="unstable"${state.unstable ? ' checked' : ''}> ${d.devUnlock}</label>${q('devunlock')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.devDelay} <input class="nn" style="width:84px" type="number" min="${minDelay()}" max="60" step="0.001" value="${state.ldelay}" data-dopt="ldelay"></label>${q('devdelay')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.devGap} <input class="nn" style="width:96px" type="number" min="0" max="60000" step="1" value="${state.gapMs || 0}" data-dopt="gapms"></label>${q('devgap')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.devMode} <select data-dopt="lmode"><option value="reload"${state.lmode !== 'fetch' && state.lmode !== 'hybrid' ? ' selected' : ''}>${d.devReload}</option><option value="fetch"${state.lmode === 'fetch' ? ' selected' : ''}>${d.devFetch}</option><option value="hybrid"${state.lmode === 'hybrid' ? ' selected' : ''}>${d.devHybrid}</option></select></label>${q('devmode')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.devWorkers} <input class="nn" type="number" min="1" max="6" value="${state.lworkers}" data-dopt="lworkers"></label>${q('devworkers')}</div>
        <div class="dtools" data-hb><label class="dnote"><input type="checkbox" data-dopt="lite"${state.lite ? ' checked' : ''}> ${d.devLite}</label>${q('devlite')}</div>
        <div class="dnote">${d.devNow}: ${Math.round(state.gapMs > 0 ? state.gapMs : Math.max(minDelay() * 1000, state.ldelay * 1000 / (state.lmode === 'fetch' ? Math.max(1, state.lworkers) : state.lmode === 'hybrid' ? 3 : 1)))} ms</div>
      </details>
      ${m.hasHops && hopsMissing.length ? `<div class="dtools yel" data-hb><b class="dnote">${d.hopsMissing}:</b> ${hopsMissing.map(chip).join('')}<button class="act" data-dact="hopscopy">${d.copy}</button>${q('dhopscopy')}</div>` : ''}
      <div class="dlog" aria-live="polite"${m.any ? ' hidden' : ''}>${m.any ? '' : d.empty}</div>
      ${catHtml}
      ${finished.length ? `<details><summary>${d.done2} (${finished.length})</summary><div class="dgrid" style="padding-top:8px">${finished.map(card).join('')}</div></details>` : ''}
      ${pm || m.other.length ? '' : `<div class="dnote">${d.nothing}</div>`}`;
    if (html === el._h) { drawNet(); return; }
    el._h = html; el.innerHTML = html; applyTitles(el); drawNet();
  }

  // ---------- automatic group builder (dashboard, new-courses mode) ----------
  let autoRes = null, autoBusy = false;
  // Picks one group per course so that no two chosen groups share a bar (same time slot) - maximising placed courses first,
  // then group quality and an even load across periods. Depth-first with a node budget; the first dive is already a good answer.
  function solveGroups(items, used0, opt) {
    const used = new Set(used0), per = {}; let best = null, nodes = 0;
    const order = items.slice().sort((a, b) => a.opts.length - b.opts.length), cur = [];
    (function dfs(i, score, placed) {
      if (++nodes > opt.budget) return;
      if (best && placed + (order.length - i) < best.placed) return;
      if (i === order.length) { if (!best || placed > best.placed || (placed === best.placed && score > best.score)) best = { placed, score, sel: cur.slice() }; return; }
      const it = order[i];
      for (const o of it.opts) {
        if (o.key && used.has(o.key)) continue;
        if (opt.maxper && (per[o.c.ph] || 0) >= opt.maxper) continue;
        if (o.key) used.add(o.key); per[o.c.ph] = (per[o.c.ph] || 0) + 1; cur.push({ it, o });
        dfs(i + 1, score + o.sc - opt.bal * (per[o.c.ph] - 1), placed + 1);
        cur.pop(); per[o.c.ph]--; if (o.key) used.delete(o.key);
      }
      dfs(i + 1, score - 100, placed); // leave this course out
    })(0, 0, 0);
    return best ? best.sel : [];
  }
  const autoHome = () => {
    const A = state.auto, ok = k => years.some(z => yearKey(z) === k);
    if (A.home && ok(A.home)) return A.home;
    const sy = selectedYears()[0] || years.find(z => z.periods.some(p => !p.closed)) || years[0];
    return sy ? yearKey(sy) : '';
  };
  async function autoBuild() {
    if (autoBusy) return; autoBusy = true;
    const d = D[state.lang] || D.en, dl = txt => { const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = txt; } };
    try {
      if (!years.length) await reloadYears();
      const A = state.auto, home = years.find(z => yearKey(z) === autoHome());
      const others = (A.others || []).map(k => years.find(z => yearKey(z) === k)).filter(z => z && z !== home);
      if (!home) { dl(d.aNoHome); return; }
      const wantT = parseCodes(A.want || state.list), otherT = parseCodes(A.other).filter(t => !wantT.some(w => norm(w) === norm(t)));
      if (!wantT.length && !otherT.length) { dl(d.aNoCourses); return; }
      dl(d.aScanning);
      const open = z => { const o = z.periods.filter(p => !p.closed); return o.length ? o : z.periods; };
      const prevChoice = new Map(plan.filter(p => p.cands.length).map(p => [norm(p.token), p.cands[p.choice].target]));
      periodSel = new Set([home, ...others].flatMap(z => open(z).map(p => p.href)));
      state.list = [...wantT, ...otherT].join(' '); const l = $('.list'); if (l) l.value = state.list;
      if (!await find(true)) { dl(d.aNoHome); return; }
      const inY = (c, ys) => ys.some(z => c.year === z.title && c.school === z.school);
      const yOf = c => [home, ...others].find(z => c.year === z.title && c.school === z.school);
      const sc = c => { const z = yOf(c), pi = z ? z.periods.findIndex(p => p.href === c.ph) : 0; return (c.selected ? 30 : 0) - (c.full ? 60 : c.off ? 40 : 0) + Math.max(0, 6 - pi) * .5; };
      const rows = plan.map(p => {
        const isOther = otherT.some(t => norm(t) === norm(p.token));
        const pool = p.cands.filter(c => !c.closed && !c.done && inY(c, isOther ? others : [home]));
        return { p, isOther, pool, opts: pool.map(c => ({ c, key: c.block ? c.ph + '|' + c.block : '', sc: sc(c) })).sort((a, b) => b.sc - a.sc), c: null, fixed: false };
      });
      const maxper = Math.max(0, +A.maxper || 0), used = new Set(), opt = { budget: 300000, bal: 4, maxper };
      const take = (r, o, fixed) => { r.c = o.c; r.fixed = !!fixed; if (o.key) used.add(o.key); };
      // stage 1: other schools - a group already chosen by hand stays (when locked), the rest is solved first
      const oth = rows.filter(r => r.isOther), free = [];
      oth.forEach(r => { const t = A.lock !== false ? prevChoice.get(norm(r.p.token)) : null, o = t && r.opts.find(x => x.c.target === t); if (o && !(o.key && used.has(o.key))) take(r, o, true); else free.push(r); });
      solveGroups(free.map(r => ({ r, opts: r.opts })), used, opt).forEach(({ it, o }) => take(it.r, o, false));
      // stage 2: your own school, around those
      const mine = rows.filter(r => !r.isOther);
      solveGroups(mine.map(r => ({ r, opts: r.opts })), used, opt).forEach(({ it, o }) => take(it.r, o, false));
      rows.forEach(r => { if (r.c) r.p.choice = r.p.cands.indexOf(r.c); });
      autoRes = { rows: rows.map(r => ({ tok: r.p.token, other: r.isOther, c: r.c, fixed: r.fixed, why: r.c ? '' : (r.pool.length ? d.aConflict : d.aNoGroup) })) };
      autoRes.placed = autoRes.rows.filter(r => r.c).length; autoRes.total = rows.length;
      renderPlan(); persist(); renderDash();
      dl(d.aDone(autoRes.placed, autoRes.total));
    } catch (e) { dl(String(e && e.message || e)); } finally { autoBusy = false; }
  }
  function autoApply() {
    if (!autoRes) return; const d = D[state.lang] || D.en;
    const ok = new Set(autoRes.rows.filter(r => r.c).map(r => norm(r.tok)));
    plan = plan.filter(p => ok.has(norm(p.token)));
    state.list = plan.map(p => p.token).join(' '); const l = $('.list'); if (l) l.value = state.list;
    renderPlan(); persist(); save(); setView('sel'); log(d.aApplied(plan.length));
  }
  function autoHtml(d) {
    const A = state.auto, home = autoHome(), yn = z => `${z.school ? z.school + ' ' : ''}${z.title}`;
    const homeSel = `<select data-aopt="home">${years.map(z => `<option value="${esc(yearKey(z))}"${yearKey(z) === home ? ' selected' : ''}>${esc(yn(z))}</option>`).join('')}</select>`;
    const oth = years.filter(z => yearKey(z) !== home).map(z => `<label class="chk"><input type="checkbox" data-aoth="${esc(yearKey(z))}"${(A.others || []).includes(yearKey(z)) ? ' checked' : ''}> ${esc(yn(z))}</label>`).join('');
    const res = autoRes ? (() => {
      const per = {}; autoRes.rows.forEach(r => { if (r.c) per[r.c.period] = (per[r.c.period] || 0) + 1; });
      return `<table class="ares"><tr><th>${d.aColCourse}</th><th>${d.aColGroup}</th><th>${d.aColPeriod}</th><th>${d.aColTeacher}</th></tr>${autoRes.rows.map(r => r.c
        ? `<tr><td>${esc(r.tok)}</td><td>${esc(r.c.code)}${r.fixed ? ` <i class="dnote">${d.aFixed}</i>` : ''}${r.c.full ? ` <i class="dnote">${d.aFull}</i>` : ''}</td><td>${esc(r.c.period)}</td><td>${esc(r.c.teacher || '')}</td></tr>`
        : `<tr><td>${esc(r.tok)}</td><td colspan="3" class="bad">${esc(r.why)}</td></tr>`).join('')}</table>
        <div class="dnote">${d.aByPeriod}: ${Object.entries(per).map(([k, v]) => esc(k) + ' ' + v).join(' · ') || '–'}</div>`;
    })() : '';
    return `<details class="dtoolbox auto" data-rid="auto" open><summary>\u{1F9E9} ${d.aTitle}</summary>
      <div class="dnote">${d.aHelp}</div>
      <div class="dtools" data-hb><label class="dnote">${d.aHome} ${homeSel}</label>${q('ahome')}</div>
      ${oth ? `<div class="dtools" data-hb><span class="dnote">${d.aOthers}:</span>${oth}${q('aothers')}</div>` : ''}
      <div class="dtools" data-hb><label class="dnote grow">${d.aWant}<textarea data-aopt="want" rows="2" spellcheck="false">${esc(A.want || '')}</textarea></label><button class="act" data-dact="afill">${d.aFill}</button>${q('awant')}</div>
      <div class="dtools" data-hb><label class="dnote grow">${d.aOther}<textarea data-aopt="other" rows="2" spellcheck="false">${esc(A.other || '')}</textarea></label>${q('aother')}</div>
      <div class="dtools" data-hb><label class="dnote">${d.aMax} <input class="nn" type="number" min="0" max="12" value="${+A.maxper || 0}" data-aopt="maxper"></label>${q('amax')}<label class="dnote"><input type="checkbox" data-aopt="lock"${A.lock !== false ? ' checked' : ''}> ${d.aLock}</label></div>
      <div class="dtools" data-hb><button class="act go" data-dact="abuild">${d.aBuild}</button>${q('abuild')}<button class="act" data-dact="aapply"${autoRes && autoRes.placed ? '' : ' disabled'}>${d.aApply}</button>${q('aapply')}</div>
      ${res}</details>`;
  }

  // ---- Opinnot -> Suoritukset and Opinnot -> HOPS (links are found on the page, nothing is guessed) ----
  const CODE_RE = /^(?!LU\d)([A-ZÄÖÅ]{1,6}\d{1,3})(?:[._][0-9A-Za-z]+)?(?=\s|$|[,;:])/i;
  async function findLinks() {
    const found = {}, docs = [{ doc: document, url: location.href }];
    try { docs.push(await getDoc(url(''))); } catch (_) { /* ignore */ }
    for (const { doc, url: u } of docs) doc.querySelectorAll('a[href]').forEach(a => {
      const tx = a.textContent.replace(/\s+/g, ' ').trim(), h = a.getAttribute('href') || '';
      if (!h || h[0] === '#' || /^(javascript|mailto):/i.test(h) || tx.length > 40) return;
      try {
        if (!found.done && /^(opinto)?suoritukset$|^prestationer$|^avlagda\b/i.test(tx)) found.done = new URL(h, u).href;
        if (!found.hops && /^hops$/i.test(tx)) found.hops = new URL(h, u).href;
      } catch (_) { /* ignore */ }
    });
    // the menu is not on every page (e.g. not on the course tray): fall back to the known Wilma addresses
    if (!found.done) found.done = url('choices?view=gradebook');
    if (!found.hops) found.hops = url('choices');
    return found;
  }
  // Table rows that start (or contain a cell starting) with a course code; credits from the column headed "laajuus/op".
  function parseDone(doc) {
    const res = {};
    doc.querySelectorAll('table').forEach(tbl => {
      if ([...tbl.querySelectorAll('th')].length === 2 && /ects/i.test(tbl.querySelector('th:last-child') ? tbl.querySelector('th:last-child').textContent : '')) return; // the per-type summary, not courses
      const rows = [...tbl.querySelectorAll('tr')]; let opCol = -1, gCol = -1;
      const head = rows.find(r => r.querySelector('th'));
      if (head) [...head.children].forEach((c, i) => { const t = c.textContent.toLowerCase(); if (/laajuus|\bop\b|opintopist|\bsp\b|studiepo|credit/.test(t)) opCol = i; if (/arvosana|vitsord|grade/.test(t)) gCol = i; });
      rows.forEach(r => {
        if (r.querySelector('th')) return;
        const tx = [...r.children].map(c => c.textContent.replace(/\s+/g, ' ').trim());
        const m = tx.map(x => CODE_RE.exec(x)).find(Boolean); if (!m) return;
        const g = gCol >= 0 ? tx[gCol] || '' : '';
        if (/^4$|hyl|underk|ej godk/i.test(g)) return; // failed grade is not earned
        let op = null;
        if (opCol >= 0 && tx[opCol]) { const n = parseFloat(tx[opCol].replace(',', '.')); if (n > 0 && n < 20) op = n; }
        else { const o = tx.map(x => /^(\d+(?:[.,]\d+)?)\s*(?:op|sp)\.?$/i.exec(x)).find(Boolean); if (o) op = parseFloat(o[1].replace(',', '.')); }
        res[baseOf(m[0])] = { op, g };
      });
    });
    return res;
  }
  // HOPS: credits per course live here. Tables first (column "laajuus/op"), then any element whose text starts with a code
  // and mentions "<n> op".
  function parseHops(doc) {
    const res = parseDone(doc);
    // credits that hide in a tooltip/data attribute of a course's own table
    doc.querySelectorAll('table').forEach(tbl => {
      const m = CODE_RE.exec(tbl.textContent.replace(/\s+/g, ' ').trim()); if (!m) return;
      const b = baseOf(m[0]); if (res[b] && res[b].op != null) return;
      let op = null;
      [tbl, ...tbl.querySelectorAll('*')].some(el => [...el.attributes].some(at => {
        if (!/title|content|ects|credit|laajuus|\bop\b/i.test(at.name)) return false;
        const o = /(\d+(?:[.,]\d+)?)\s*(?:op\b|ects|sp\b)/i.exec(at.value) || (/^data-(ects|credits?|laajuus)$/i.test(at.name) ? /^(\d+(?:[.,]\d+)?)$/.exec(at.value) : null);
        if (o) { op = parseFloat(o[1].replace(',', '.')); return true; } return false;
      }));
      if (op != null) res[b] = { ...(res[b] || { g: '' }), op };
    });
    doc.querySelectorAll('tr, li, a, td, span, div').forEach(el => {
      if (el.children.length > 12) return;
      const tx = el.textContent.replace(/\s+/g, ' ').trim(), m = CODE_RE.exec(tx); if (!m || tx.length > 160) return;
      const b = baseOf(m[0]), o = /(\d+(?:[.,]\d+)?)\s*(?:op|sp)\b/i.exec(tx), op = o ? parseFloat(o[1].replace(',', '.')) : null;
      if (!res[b]) res[b] = { op, g: '' }; else if (res[b].op == null && op != null) res[b].op = op;
    });
    return res;
  }
  // "Suoritukset kurssityypeittäin | ECTS" summary table on the Suoritukset page
  function parseSummary(doc) {
    const out = [];
    doc.querySelectorAll('table').forEach(tbl => {
      const heads = [...tbl.querySelectorAll('th')].map(x => x.textContent.replace(/\s+/g, ' ').trim());
      if (!(heads.length === 2 && /ects|\bop\b|laajuus/i.test(heads[1]))) return;
      tbl.querySelectorAll('tr').forEach(r => {
        const c = [...r.children].map(x => x.textContent.replace(/\s+/g, ' ').trim());
        if (c.length >= 2 && c[0] && /^\d+(?:[.,]\d+)?$/.test(c[c.length - 1])) out.push([c[0], parseFloat(c[c.length - 1].replace(',', '.'))]);
      });
    });
    return out;
  }
  async function fetchDone(links) {
    const d = D[state.lang] || D.en; if (!links.done) return d.linkNone(d.prest);
    const { doc } = await getDoc(links.done), res = parseDone(doc), n = Object.keys(res).length;
    if (!n) return d.noRows(d.prest);
    state.earned = res; state.summary = parseSummary(doc); save();
    return d.doneRes(n, Object.values(res).reduce((a, v) => a + (v.op || 0), 0));
  }
  async function fetchHops(links) {
    const d = D[state.lang] || D.en; if (!links.hops) return d.linkNone(d.hops);
    const { doc } = await getDoc(links.hops), res = parseHops(doc), n = Object.keys(res).length;
    if (!n) return d.noRows(d.hops);
    state.hops = res; state.hopsAt = Date.now(); save();
    return d.hopsRes(n) + ' (' + Object.values(res).reduce((a, v) => a + (v.op || 0), 0) + ' op)';
  }

  async function dashScan() {
    const d = D[state.lang] || D.en, dl = txt => { const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = txt; } };
    if (!years.length) await reloadYears();
    const ps = years.flatMap(y => y.periods); let n = 0; const fresh = {};
    dl(d.scanning(0, ps.length));
    await pool(ps, state.conc, async p => {
      const idx = await scanPeriods([p], viewUrl);
      idx.forEach(c => { const b = baseOf(c.code), r = fresh[b] || (fresh[b] = { d: 0, s: 0, o: 0 }); if (c.done) r.d = 1; if (c.selected) r.s = 1; if (!c.closed) r.o = 1; });
      dl(d.scanning(++n, ps.length));
    });
    const old = state.seen || {}, next = {};
    for (const b of Object.keys(old)) next[b] = { d: old[b].d ? 1 : 0, s: 0, o: 0 };
    for (const [b, v] of Object.entries(fresh)) next[b] = { d: (old[b] && old[b].d) || v.d ? 1 : 0, s: v.s, o: v.o };
    state.seen = next; save();
    const msgs = [d.scanned(Object.keys(fresh).length)];
    try { const links = await findLinks(); for (const f of [fetchDone, fetchHops]) { try { msgs.push(await f(links)); } catch (e) { msgs.push(String(e.message || e)); } } } catch (e) { msgs.push(String(e.message || e)); }
    renderDash();
    const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = msgs.join('\n'); }
  }

  // "?" help text also as hover text on the control it belongs to
  function applyTitles(scope) {
    (scope || root).querySelectorAll('button.q').forEach(b => {
      const tip = tipOf(b.dataset.help); if (!tip) return;
      b.title = tip;
      let el = b.previousElementSibling;
      while (el && el.classList.contains('q')) el = el.previousElementSibling;
      if (el && !el.matches('input.nn, .dchip')) el.title = tip;
    });
  }

  // small right-click menu for a course chip
  function showCtx(x, y, base) {
    root.querySelectorAll('.ctx').forEach(e => e.remove());
    const d = D[state.lang] || D.en, ign = !!state.ignore[base], man = !!state.manual[base];
    const m = document.createElement('div'); m.className = 'ctx';
    m.style.left = Math.min(x, innerWidth - 230) + 'px'; m.style.top = Math.min(y, innerHeight - 100) + 'px';
    m.innerHTML = `<div class="ctxh">${esc(base)}</div><button data-dact="ign" data-base="${esc(base)}">${ign ? d.unign : d.ign}</button><button data-dact="mark" data-base="${esc(base)}">${man ? d.unmark : d.mark}</button>`;
    shell.appendChild(m);
  }

  // the full-window view has tabs: selection, dashboard, loop settings, console, settings, developer
  const VIEWS = ['sel', 'dash', 'loop', 'con', 'set', 'dev', 'exp'];
  const TABV = { vsel: 'sel', vdash: 'dash', vloop: 'loop', vcon: 'con', vset: 'set', vdev: 'dev', vexp: 'exp' };
  function onDash() { return view === 'dash' || view === 'con' || view === 'dev' || view === 'exp'; } // these views are drawn by renderDash
  const paintTabs = () => root.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', TABV[b.dataset.act] === view));
  function paintView() {
    VIEWS.forEach(v => shell.classList.toggle('view-' + v, view === v));
    const more = $('.o6'); if (more && full) more.open = view === 'set' || view === 'loop'; // in the full window the "More" parts are pages of their own
    paintTabs();
  }
  function setView(v) {
    view = v; paintView();
    try { history.replaceState(null, '', location.pathname + location.search + (v === 'sel' ? '#wk-full' : '#wk-full-' + v)); } catch (_) { /* ignore */ }
    if (onDash()) { renderDash(); if (v === 'dash' && !Object.keys(state.seen || {}).length && !busy) actions.dscan(); }
  }

  function dashClick(b) {
    const k = b.dataset.dact, d = D[state.lang] || D.en, base = b.dataset.base;
    if (k === 'chip') {
      if (state.pickMode) {
        if (!b.classList.contains('todo')) return;
        const toks = parseCodes(state.list), i = toks.findIndex(t => baseOf(t) === base);
        if (i >= 0) toks.splice(i, 1); else toks.push(base);
        state.list = toks.join(' ');
      } else if (state.manual[base]) delete state.manual[base]; else state.manual[base] = 1;
    }
    else if (k === 'ign') { if (state.ignore[base]) delete state.ignore[base]; else state.ignore[base] = 1; }
    else if (k === 'mark') { if (state.manual[base]) delete state.manual[base]; else state.manual[base] = 1; }
    else if (k === 'abuild') { autoBuild(); return; }
    else if (k === 'aapply') { autoApply(); return; }
    else if (k === 'afill') { const m = dashModel(); state.auto.want = [...new Set([...parseCodes(state.auto.want), ...m.rows.filter(r => !r.inactive).flatMap(r => r.todoList.map(c => c.base)), ...parseCodes(state.list)])].join(' '); save(); renderDash(); return; }
    else if (k === 'ncopy') { const txt = [...root.querySelectorAll('.ncon .nl')].map(x => x.textContent).join('\n'); try { navigator.clipboard.writeText(txt); } catch (_) { /* ignore */ } const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = d.copied; } return; }
    else if (k === 'nclear') { netBuf.length = 0; netTotal = netPosts = netBad = 0; drawNet(); return; }
    else if (k === 'npause') { netPaused = !netPaused; renderDash(); return; }
    else if (k === 'pickmode') state.pickMode = !state.pickMode;
    else if (k === 'fold') { const pm = state.pickMode, ids = state.req.map(r => (pm ? 'p:' : 'n:') + r.id), anyOpen = ids.some(i => (state.dopen[i] != null ? state.dopen[i] : pm)); ids.forEach(i => { state.dopen[i] = !anyOpen; }); }
    else if (k === 'addall') {
      const m = dashModel(), toks = parseCodes(state.list); let n = 0;
      m.rows.filter(r => !r.inactive).flatMap(r => r.todoList).forEach(c => { if (!toks.some(t => baseOf(t) === c.base)) { toks.push(c.base); n++; } });
      state.list = toks.join(' '); const l = $('.list'); if (l) l.value = state.list; save(); renderDash(); const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = d.added(n); } return;
    }
    else if (k === 'go') { setView('sel'); return; }
    else if (k === 'hopscopy') { const txt = dashModel().all.filter(c => c.sel && !c.hp).map(c => c.base).join(' '); try { navigator.clipboard.writeText(txt); } catch (_) { /* ignore */ } const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = d.copied + ' ' + txt; } return; }
    else if (k === 'del') { // hide: the subject is kept in the hidden list (with its place), so it can be brought back
      const i = state.req.findIndex(r => r.id === b.dataset.id);
      if (i >= 0) { state.hiddenReq = [...(state.hiddenReq || []), { ...state.req[i], at: i }]; state.req.splice(i, 1); }
    }
    else if (k === 'unhide' || k === 'unhideall') {
      const hid = state.hiddenReq || [], id = ($('.dhid') || {}).value;
      const back = (k === 'unhideall' ? hid : hid.filter(r => r.id === id)).slice().sort((a, b2) => (a.at || 0) - (b2.at || 0));
      if (!back.length) return;
      back.forEach(r => { const { at, ...row } = r; state.req.splice(Math.min(at == null ? state.req.length : at, state.req.length), 0, row); });
      state.hiddenReq = hid.filter(r => !back.includes(r));
    }
    else if (k === 'reset') { state.req = JSON.parse(JSON.stringify(DEFAULT_REQ)); state.hiddenReq = []; }
    else if (k === 'manual') { parseCodes($('.dmanual').value).forEach(c => { state.manual[baseOf(c)] = 1; }); }
    else if (k === 'add') {
      const name = $('.dnname').value.trim(), pref = $('.dnpref').value.split(/[\s,;]+/).filter(Boolean);
      if (!name || !pref.length) return;
      state.req.push({ id: 'u' + Date.now().toString(36), name, p: pref, need: Math.max(0, +$('.dnneed').value || 0) });
    } else return;
    const l = $('.list'); if (l) l.value = state.list;
    save(); renderDash();
  }

  // ---------- retry loop: refresh -> pick, in one or several tabs, until every course is selected ----------
  const LKEY = 'wilmaKurssit.loop';
  let lrRaw = null, lrObj = {}; // the loop record is read several times per turn: it is parsed only when its text has changed (callers never modify it)
  const readLoop = () => {
    let raw = ''; try { raw = localStorage.getItem(LKEY) || ''; } catch (_) { /* ignore */ }
    if (raw !== lrRaw) { lrRaw = raw; try { lrObj = JSON.parse(raw || '{}') || {}; } catch (_) { lrObj = {}; } }
    return lrObj;
  };
  const writeLoop = o => { try { localStorage.setItem(LKEY, JSON.stringify(o)); } catch (_) { /* ignore */ } };
  const loopActive = () => { const L = readLoop(); return !!L.on && Date.now() < (L.t0 || 0) + (L.max || 30) * 60000; };
  const loopStop = why => { writeLoop({ ...readLoop(), on: false, why }); evLog('STOP', 'syy: ' + why); paintLoop(); schedStat(); };
  function paintLoop() {
    const b = root.querySelector('[data-act=loop]'); if (!b) return;
    const on = loopActive(), t = tr();
    b.textContent = (on ? '\u23F9 ' + t.loopStop : '\u{1F501} ' + t.loop);
    b.classList.toggle('on', on);
  }
  window.addEventListener('storage', e => { if (e.key === LKEY) { paintLoop(); if (!loopActive()) { cancelled = true; if (location.hash === '#wk-loop' && window.__wkCloseTab) setTimeout(window.__wkCloseTab, 800); } schedStat(); } });
  function openTabs(n, u, win) {
    if (window.__wkOpenTabs) { window.__wkOpenTabs(n, u, !!win); return true; }
    let ok = true; for (let i = 0; i < n; i++) { const w = window.open(u, '_blank'); if (!w) ok = false; }
    return ok;
  }
  function loopBegin(openMore) {
    loginLost = false; lk.v = ''; lk.at = 0;
    // "win": every loop tab, including the hybrid's three, runs in its own window; this page only starts and watches the loop
    const win = state.lwin !== false && state.lmode !== 'fetch' && (state.lmode === 'hybrid' || state.ltabs >= 2);
    if (!loopActive()) { try { localStorage.removeItem(LPK); } catch (_) { /* ignore */ } writeLoop({ on: true, t0: Date.now(), max: state.lmax, delay: Math.max(minDelay(), state.ldelay), keep: !!state.lkeep, rounds: 0, mode: state.lmode, workers: state.lworkers, unstable: !!state.unstable, win }); }
    const n = state.lmode === 'fetch' ? 0 : win ? (state.lmode === 'hybrid' ? 3 : state.ltabs) : state.lmode === 'hybrid' ? 2 : Math.max(0, state.ltabs - 1);
    if (openMore && n) {
      const ok = openTabs(n, location.origin + basePath() + '/selection/view#wk-loop', win);
      evLog('TABS', ok ? `avattu ${n} lisävälilehteä` : 'selain esti lisävälilehdet'); log(ok ? tr().openedTabs(n) : tr().noTabs, true);
    }
  }
  // ---------- the fast path: picks go out first, the scan of the course pages runs beside them ----------
  // A scan is not needed to send a pick (a pick goes out whether the group looks full or not); it only tells which courses are already
  // selected. So the loop keeps the latest scan (shared by every tab through localStorage), sends what is still missing straight from it,
  // and scans in the background: once every few seconds, and once right after a pick was accepted.
  const LPK = 'wilmaKurssit.lplan', LSK = 'wilmaKurssit.lscan', FAST_AGE = 15000, SCAN_MIN = 400;
  let lpRaw = null, lpObj = null, scanP = null, scanTm = 0, scanAt0 = 0, llAt = 0;
  const lpGet = () => {
    let raw = ''; try { raw = localStorage.getItem(LPK) || ''; } catch (_) { /* ignore */ }
    if (raw !== lpRaw) { lpRaw = raw; try { lpObj = raw ? JSON.parse(raw) : null; } catch (_) { lpObj = null; } }
    return lpObj;
  };
  // the shared scan is used only while the list, the periods and the chosen groups are the ones it was made for
  const planSig = () => [String(state.list || '').trim().replace(/\s+/g, ' '), (state.per || []).slice().sort().join(','), JSON.stringify(state.choices || {}), JSON.stringify(state.filters || {})].join('|');
  const lpFresh = () => { const lp = lpGet(); return lp && lp.sig === planSig() && Date.now() - lp.at < FAST_AGE ? lp : null; };
  const scanEvery = () => Math.max(1500, Math.min(5000, (+readLoop().delay || state.ldelay || 2) * 1000));
  const scanDue = () => { const lp = lpGet(); return !lp || lp.sig !== planSig() || Date.now() - lp.at >= scanEvery(); };
  function lpStore(at) { // k = typed code, c = group code, g = target, x = period closed, s = some group of the course is selected
    const rows = [];
    plan.forEach(p => { if (!p.cands.length) return; const c = p.cands[p.choice]; rows.push({ k: p.token, c: c.code, g: c.target, x: c.closed ? 1 : 0, s: p.cands.some(z => z.selected) ? 1 : 0 }); });
    try { localStorage.setItem(LPK, JSON.stringify({ v: 1, sig: planSig(), at, t: Date.now(), rows })); } catch (_) { /* ignore */ }
  }
  // a scan under way in another tab is not repeated (the record goes stale after 4 s)
  const lockHeld = () => { try { const v = (localStorage.getItem(LSK) || '').split(':'); return !!v[0] && v[0] !== tabId() && Date.now() - (+v[1] || 0) < 4000; } catch (_) { return false; } };
  const lockSet = on => { try { if (on) localStorage.setItem(LSK, tabId() + ':' + Date.now()); else if ((localStorage.getItem(LSK) || '').split(':')[0] === tabId()) localStorage.removeItem(LSK); } catch (_) { /* ignore */ } };

  // One scan of every course page: updates the plan and the shared copy, and decides whether the loop is over.
  // Resolves to 'ok' | 'watch' | 'fail' | 'stop' | 'done'.
  function loopScan(quiet) {
    if (scanP) return scanP;
    scanTm = 0;
    const pr = (async () => {
      const at = Date.now(); scanAt0 = at; lockSet(true);
      try {
        const t = tr();
        if (!parseCodes($('.list').value).length) { loopStop('nothing'); return 'stop'; }
        const okFind = await find(quiet, { priority: 'low' });
        if (loginLost) { loopStop('login'); log(t.login, true); return 'stop'; }
        if (!okFind) { evLog('SCAN', 'haku epäonnistui, yritetään uudelleen'); log(t.loopRetry); return 'fail'; } // transient failure: try again
        if (lastScanErrors.some(e => /HTTP 429/.test(e))) { loopStop('rate'); log(t.rate, true); return 'stop'; }
        const part = lastScanErrors.length > 0; // some course pages did not load: what was read is good enough to send from, but not to call the loop finished
        if (part) evLog('SCAN', `${lastScanErrors.length} sivua ei latautunut, käytetään loput`);
        lpStore(at);
        const rows = plan.filter(p => p.cands.length), pending = rows.filter(p => !p.cands.some(c => c.selected));
        if (part) return rows.length ? 'ok' : 'fail';
        if (!rows.length) { loopStop('none'); log(t.nothing, true); return 'stop'; }
        if (!pending.length && readLoop().keep) { log(t.loopWatch(rows.length)); return 'watch'; }
        if (!pending.length) {
          loopStop('done'); document.title = '✅ ' + document.title.replace(/^✅ /, '');
          log(t.loopDone(rows.length)); if (location.hash === '#wk-loop' && window.__wkCloseTab) setTimeout(window.__wkCloseTab, 4000);
          return 'done';
        }
        return 'ok';
      } catch (e) { evLog('SCAN', 'haku epäonnistui: ' + String(e && e.message || e)); return 'fail'; }
      finally { lockSet(false); }
    })();
    scanP = pr; pr.then(() => { if (scanP === pr) scanP = null; });
    return pr;
  }
  // ask for a scan: at once when allowed, else when the minimum gap since the last one has passed. `force`: a pick was just accepted, look at it now
  function scanSoon(quiet, force) {
    if (scanP || scanTm || !loopActive() || cancelled || (!force && lockHeld())) return;
    const wait = Math.max(0, scanAt0 + SCAN_MIN - Date.now());
    if (!wait) { loopScan(quiet); return; }
    scanTm = 1; sleep(wait).then(() => { if (scanTm !== 1) return; scanTm = 0; if (loopActive() && !cancelled && !scanP) loopScan(quiet); });
  }

  // before a page is refreshed (which would cut it off): wait for the scan under way, or the one that was put off for a moment
  async function scanIdle() {
    for (let i = 0; i < 200 && (scanP || scanTm === 1); i++) { if (scanP) await scanP; else await sleep(25); if (!loopActive() || cancelled) return; }
  }

  // the form key: used from memory; when it gets old a new one is fetched beside the turns (the first use reads it from the page)
  const lk = { v: '', at: 0, busy: null };
  async function loopKey(renew) {
    if (!lk.v) { const k = await getFormkey(false); if (k) { lk.v = k; lk.at = Date.now(); } return lk.v; }
    if (renew && !lk.busy && Date.now() - lk.at > 45000) {
      lk.busy = getFormkey(true).then(k => { if (k) { lk.v = k; lk.at = Date.now(); } }).catch(() => { /* keep the old key */ }).finally(() => { lk.busy = null; });
    }
    return lk.v;
  }
  // The session ended (Wilma showed its sign-in page): read a page, which signs in again when that is set up, and take a new form key
  async function loopRecover() {
    loginLost = false;
    try { await getDoc(url('selection/view')); } catch (_) { /* LOGIN: loginLost stays set */ }
    lk.v = ''; lk.at = 0;
    return !loginLost;
  }

  // Two tabs must not send the same pick at the same moment: a repeated pick might undo the first one (nobody knows whether Wilma toggles).
  // The exclusion comes from the browser's Web Locks: one lock per pick, shared by every tab of the site, released when the request is
  // finished or the tab goes away. Where Web Locks are missing, a record in localStorage does the same job a little less tightly.
  // Per pick one record "tab:time:state" (f = request in the air, d = Wilma accepted it, x = Wilma refused it). A tab may send when
  //  - no other tab has a request for it in the air (a record goes stale after 2 s; an old record without a state counts as "in the air" for 4 s), and
  //  - an accepted pick has been looked at by a scan that began after it (so it is known not to have taken effect), or 15 s have passed.
  const gateKey = target => 'wilmaKurssit.claim.' + target;
  const SKIP = {}; let othersAt = 0; // othersAt: when a record of another tab was last seen
  function gate(target, scanAt, check) {
    const me = tabId();
    try {
      const v = (localStorage.getItem(gateKey(target)) || '').split(':'), ts = parseInt(v[1], 10) || 0, now = Date.now(), st = v[2] || 'f';
      if (v[0] && v[0] !== me) othersAt = now;
      if (v[0] && v[0] !== me && st === 'f' && now - ts < (v[2] ? 2000 : 4000)) return false;
      if (st === 'd' && ts >= (scanAt || 0) && now - ts < 15000) return false;
      if (!check) localStorage.setItem(gateKey(target), me + ':' + now + ':f');
      return true;
    } catch (_) { return true; }
  }
  const multiTab = () => { const L = readLoop(); return L.mode === 'hybrid' || !!L.win || (state.ltabs || 1) >= 2 || Date.now() - othersAt < 10000; };
  async function gateTake(target, scanAt) { // the stored-record way: write the record, and with other tabs about look again 40 ms later (the later write stays, the other tab backs off; a write needs a few ms to reach the other tabs, more when the machine is busy)
    if (!gate(target, scanAt)) return false;
    if (!multiTab()) return true;
    await sleep(40);
    try { return (localStorage.getItem(gateKey(target)) || '').split(':')[0] === tabId(); } catch (_) { return true; }
  }
  const gateDone = (target, ok) => { try { localStorage.setItem(gateKey(target), tabId() + ':' + Date.now() + ':' + (ok ? 'd' : 'x')); } catch (_) { /* ignore */ } };
  // run `fn` (the pick) when no other tab has this pick in the air and no accepted pick of it still waits for a scan; resolves to fn's result or SKIP
  async function gateRun(target, scanAt, fn) {
    const lm = typeof navigator !== 'undefined' ? navigator.locks : null;
    if (lm && lm.request) {
      try { return await lm.request('wilmaKurssit.pick.' + target, { ifAvailable: true }, lock => (lock && gate(target, scanAt, true) ? fn() : SKIP)); }
      catch (_) { /* Web Locks cannot be used here: the stored record below */ }
    }
    return (await gateTake(target, scanAt)) ? fn() : SKIP;
  }

  const floorMs = () => (readLoop().unstable ? 5 : 300);
  // waits for `ms`, but notices at once-ish (every 120 ms) when the loop has been stopped
  async function loopWait(ms) {
    const until = Date.now() + ms;
    for (;;) {
      if (!loopActive() || cancelled) return false;
      const rem = until - Date.now(); if (rem <= 0) return true;
      await sleep(Math.min(rem, 120));
    }
  }
  const loopEndLog = () => { const w = readLoop().why; if (!w || w === 'stop' || w === 'cancel') log(tr().loopStopped); }; // other endings have said their own piece
  const keepsPage = () => readLoop().mode === 'fetch' || isDash(); // a page that is never reloaded needs its form key renewed now and then

  // One turn of a handler: send the picks that are still missing (from the latest scan), then see to it that a scan is under way when one is due.
  // Resolves to 'sent' or, when the loop is over, 'stop' | 'done'.
  async function loopStep(round, quiet, w, N) {
    const t = tr(); lastTick = Date.now();
    if (!lpFresh()) { // the first turn of a loop (or a scan that has gone stale): the picks wait for the scan, this once
      const st = await loopScan(quiet);
      if (st === 'stop' || st === 'done') return st;
      if (st === 'fail' || !loopActive() || cancelled) return 'sent';
    }
    const lp = lpFresh(); if (!lp) return 'sent';
    const rows = lp.rows.length, pend = lp.rows.filter(r => !r.s).length, todo = [...new Set(lp.rows.filter(r => !r.s && !r.x).map(r => r.g))];
    if (!pend) { if (readLoop().keep && performance.now() - llAt > 250) { llAt = performance.now(); log(t.loopWatch(rows)); } if (scanDue()) scanSoon(quiet); return 'sent'; }
    let key = '';
    if (todo.some(g => gate(g, lp.at, true))) { // the key is needed only when some pick may go out
      key = await loopKey(keepsPage());
      if (!key) { loopStop('key'); log(t.noKey, true); return 'stop'; }
    }
    let sent = 0, bad = 0, skipped = 0, acc = 0, limited = false, login = false, stale = false;
    await Promise.all(todo.map(async target => {
      const r = key ? await gateRun(target, lp.at, async () => {
        try { const x = await pickGroup(target, key); gateDone(target, x.ok); if (x.ok) await sleep(8); return x; } // the record settles before another tab gets the lock
        catch (_) { gateDone(target, false); return null; }
      }) : SKIP;
      if (r === SKIP) { skipped++; return; }
      if (!r) { bad++; return; }
      sent++;
      if (r.ok) acc++; else bad++;
      if (r.status === 429) limited = true;
      if (r.login) login = true; else if (!r.ok && !/täynnä|full/i.test(r.text || '')) stale = true;
    }));
    if (stale) lk.at = Math.min(lk.at, Date.now() - 40000); // an unexpected refusal: have the form key looked at again soon
    if (acc) scanSoon(quiet, true); else if (scanDue()) scanSoon(quiet);
    if (sent || bad || performance.now() - llAt > 250) { // a turn that sent something is always logged; the rest at most four times a second
      llAt = performance.now();
      evLog('TURN', `${N ? 'virtuaalivalitsija ' + w + '/' + N : 'kierros ' + round}: valitsematta ${pend}/${rows}, lähetetty ${sent}, virheitä ${bad}${skipped ? ', ohitettu ' + skipped + ' (toisen pyyntö kesken tai odottaa tarkistusta)' : ''}`);
      log(N ? t.fetchTurn(w, N, round, pend, rows, sent, bad) : t.loopRound(round, pend, rows, sent, bad));
    }
    if (limited) { loopStop('rate'); evLog('LIMIT', 'Wilma rajoitti pyyntöjä (429), silmukka pysäytettiin'); log(t.rate, true); return 'stop'; }
    if (login && !await loopRecover()) { loopStop('login'); log(t.login, true); return 'stop'; }
    return 'sent';
  }
  // light mode: no page reloads; N "virtual tabs" take turns inside this one tab
  async function fetchLoop() {
    let turn = 0, wrote = 0;
    await sleep(Math.random() * 120);
    while (loopActive() && !cancelled) {
      const L = readLoop(), N = Math.max(1, Math.min(6, +L.workers || 6)), t0 = Date.now();
      turn++; lastTick = t0;
      if (turn === 1 || t0 - wrote > 900) { wrote = t0; writeLoop({ ...readLoop(), rounds: turn }); schedStat(); } // the counter is written about once a second
      const st = await loopStep(turn, true, ((turn - 1) % N) + 1, N);
      if (st === 'stop' || st === 'done') return;
      const gap = state.gapMs > 0 ? Math.max(floorMs(), state.gapMs) : Math.max(floorMs(), (+L.delay || 2) * 1000 / N);
      if (!await loopWait(Math.max(0, t0 + gap - Date.now()))) break;
    }
    loopEndLog();
  }
  let lastTick = Date.now(), loopDog = 0;
  const TABKEY = 'wilmaKurssit.looptab';
  // the dashboard tab is never refreshed by the loop (it is the place you watch the console)
  const isDash = () => (full && onDash()) || /#wk-full-(dash|con|dev|exp)/.test(location.hash);
  function startDog() {
    if (loopDog) return;
    loopDog = setInterval(() => {
      if (!loopActive() || isDash()) return;
      let flagged = false; try { flagged = sessionStorage.getItem(TABKEY) === '1'; } catch (_) { /* ignore */ }
      if (!flagged && !/#wk-loop/.test(location.hash)) return;
      if (Date.now() - lastTick > Math.max(10000, (+readLoop().delay || 2) * 4000)) {
        lastTick = Date.now();
        if (/selection/.test(location.pathname)) refresh('vartija: välilehti oli hiljaa'); else location.href = url('selection/view') + '#wk-loop';
      }
    }, 3000);
  }
  // hybrid: the loop tabs share one schedule (each tab takes a fixed slot inside every handler gap, so the sends are evenly spread)
  const HYB = 'wilmaKurssit.hyb';
  function hybSlot() {
    const now = Date.now(), me = tabId(); let reg = {};
    try { reg = JSON.parse(localStorage.getItem(HYB) || '{}') || {}; } catch (_) { reg = {}; }
    reg[me] = now;
    for (const k of Object.keys(reg)) if (now - reg[k] > 15000) delete reg[k]; // tabs that went away
    try { localStorage.setItem(HYB, JSON.stringify(reg)); } catch (_) { /* ignore */ }
    const ids = Object.keys(reg).sort();
    return { i: Math.max(0, ids.indexOf(me)), n: Math.max(1, ids.length) };
  }
  // hybrid: this tab sends three virtual handlers in turn, then refreshes itself (the dashboard tab keeps going without refreshing)
  async function hybridRound() {
    const t = tr(), N = 3, L0 = readLoop(), round = L0.rounds || 0;
    lastTick = Date.now();
    const gap = state.gapMs > 0 ? Math.max(floorMs(), state.gapMs) : Math.max(floorMs(), (+L0.delay || 2) * 1000 / N);
    const slot = hybSlot(), off = slot.i * gap / slot.n, start = Date.now();
    evLog('ROUND', `kierros ${round}: välilehti ${slot.i + 1}/${slot.n}, aloitus +${Math.round(off)} ms, väli ${Math.round(gap)} ms`);
    if (!await loopWait(Math.max(0, start + off - Date.now()))) { loopEndLog(); return; }
    for (let w = 1; w <= N; w++) {
      if (!loopActive() || cancelled) { loopEndLog(); return; }
      const st = await loopStep(round, true, w, N);
      if (st === 'stop' || st === 'done') return;
      if (w < N && !await loopWait(Math.max(0, start + off + w * gap - Date.now()))) { loopEndLog(); return; }
    }
    if (!loopActive()) { loopEndLog(); return; }
    if (isDash()) {
      evLog('KEEP', 'kojelauta: ei päivitystä, kierrokset jatkuvat');
      if (!await loopWait(Math.max(0, start + off + N * gap - Date.now()))) { loopEndLog(); return; }
      writeLoop({ ...readLoop(), rounds: (readLoop().rounds || 0) + 1 });
      return hybridRound();
    }
    await scanIdle(); // the refresh must not cut a scan in half
    if (!loopActive()) { loopEndLog(); return; }
    log(t.hybridRefresh);
    refresh('hybridi: kierros valmis');
  }
  async function loopRun() {
    if (busy) return;
    if (readLoop().win && !/#wk-loop/.test(location.hash)) { evLog('TABS', 'tämä sivu vain seuraa, kierrokset ajetaan erillisessä ikkunassa'); return; }
    setBusy(true); lastTick = Date.now(); try { sessionStorage.setItem(TABKEY, '1'); } catch (_) { /* ignore */ }
    const t = tr();
    try {
      const L0 = readLoop(), round = (L0.rounds || 0) + 1;
      writeLoop({ ...L0, rounds: round });
      if (L0.mode === 'fetch') { await fetchLoop(); return; }
      if (L0.mode === 'hybrid') { await hybridRound(); return; }
      if ((state.ltabs || 1) >= 2) await sleep(Math.random() * 120); // several tabs: spread them a little
      if (!loopActive()) { log(t.loopOff); return; }
      const st = await loopStep(round, false, 0, 0);
      if (st === 'stop' || st === 'done') return;
      if (!await loopWait(Math.max(floorMs(), (+readLoop().delay || state.ldelay || 2) * 1000))) { loopEndLog(); return; } // the scan finishes during the wait
      await scanIdle(); // the refresh must not cut a scan in half
      if (!loopActive()) { loopEndLog(); return; }
      refresh('kierros valmis, sivu päivitetään');
    } catch (e) {
      log(String(e && e.message || e), true);
      if (loopActive()) setTimeout(() => { if (loopActive()) refresh('virhe, yritetään uudelleen'); }, 5000);
    } finally { setBusy(false); }
  }

  // ---------- bottom progress bar, light mode, developer settings ----------
  let lastScanErrors = [], progKey = '';
  const minDelay = () => (state.unstable ? 0.005 : 0.3);
  function paintProg() {
    const el = $('.pbar'); if (!el) return;
    const t = tr(), d = D[state.lang] || D.en, pc = (a, b) => (b ? Math.min(100, Math.round(100 * a / b)) : 0);
    let a = 0, b = 0, label = t.progNone;
    const rows = plan.filter(p => p.cands.length);
    if (rows.length) { a = rows.filter(p => p.cands.some(c => c.selected)).length; b = rows.length; label = t.prog(a, b, pc(a, b)); }
    else {
      const act = dashModel().rows.filter(r => !r.inactive);
      b = act.reduce((x, r) => x + r.need, 0); a = act.reduce((x, r) => x + Math.min(r.need, r.done + r.sel), 0);
      if (b) label = d.progReq(a, b, pc(a, b));
    }
    const key = label + '|' + pc(a, b); if (key === progKey && el.firstChild) return; progKey = key;
    el.classList.toggle('full100', b > 0 && a >= b);
    el.innerHTML = `<div class="pt"><span>${esc(label)}</span></div><div class="pb" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pc(a, b)}"><i style="width:${pc(a, b)}%"></i></div>`;
  }
  function applyLite() {
    shell.classList.toggle('lite', !!state.lite);
    shell.classList.toggle('help', !!state.help); const hb = root.querySelector('.helpbtn'); if (hb) hb.classList.toggle('on', !!state.help);
    const lc = $('.lite'); if (lc) lc.checked = !!state.lite;
    const i = $('.ldelay'); if (i) { i.min = String(minDelay()); i.step = '0.001'; i.value = state.ldelay; }
    progKey = ''; paintProg();
  }

  // ---------- live sync between every open Wilma tab (panel, full view, dashboard) ----------
  const AKEY = 'wilmaKurssit.at';
  const LOCAL_ONLY = new Set(['x', 'y', 'w', 'h', 'open', 'year', 'arm', 'fast', 'rt', 'at']); // position, size and one-shot timers stay per tab
  function syncInputs() {
    const set = (sel, v) => { const el = $(sel); if (el && root.activeElement !== el) el.value = v; };
    const chk = (sel, v) => { const el = $(sel); if (el && root.activeElement !== el) el.checked = !!v; };
    set('.list', state.list); set('.conc', state.conc); set('.ltabs', state.ltabs); set('.ldelay', state.ldelay); set('.lmax', state.lmax);
    chk('.lkeep', state.lkeep); chk('.always', state.always); chk('.wq', state.wq); chk('.rf', state.refresh); chk('.lite', state.lite);
    applyTheme(); applyLite(); paintLoop();
  }
  window.addEventListener('storage', e => {
    if (e.key === AKEY && e.newValue) {
      try { const v = JSON.parse(e.newValue).v || ''; const a = $('.at'); if (a && root.activeElement !== a) { a.value = v; state.at = v; } } catch (_) { /* ignore */ }
      return;
    }
    if (e.key !== KEY || !e.newValue) return;
    let n; try { n = JSON.parse(e.newValue); } catch (_) { return; }
    let changed = false, lang = false, per = false;
    for (const k of Object.keys(DEFAULTS)) {
      if (LOCAL_ONLY.has(k) || !(k in n) || JSON.stringify(state[k]) === JSON.stringify(n[k])) continue;
      state[k] = n[k]; changed = true; if (k === 'lang') lang = true; if (k === 'per') per = true;
    }
    if (!changed) return;
    if (lang) { buildUi(); return; }
    if (per) { periodSel = new Set(state.per); renderPeriods(); }
    syncInputs(); renderDash();
  });

  // ---------- readable save file (.txt) ----------
  const findPeriod = ({ year, label }) => {
    const L = norm(label), hit = z => z.periods.find(p => norm(p.label) === L || norm(p.short || '') === L);
    const z1 = years.find(z => year && norm(z.title) === norm(year) && hit(z)) || years.find(z => hit(z));
    const p = z1 && hit(z1); return p ? p.href : '';
  };
  function parseTxt(raw) {
    const out = { list: '', periods: [], filters: {}, codes: {} }, toks = []; let sec = '';
    for (const line0 of raw.split(/\r?\n/)) {
      const line = line0.trim(); if (!line || line[0] === '#') continue;
      const h = /^(jaksot|periods|perioder|kurssit|courses|kurser)\s*:\s*$/i.exec(line);
      if (h) { sec = /^(j|p)/i.test(h[1]) ? 'p' : 'c'; continue; }
      if (sec === 'p') {
        const t = line.replace(/^[-*•]\s*/, ''); if (!t) continue;
        const i = t.indexOf(' / '); out.periods.push(i >= 0 ? { year: t.slice(0, i).trim(), label: t.slice(i + 3).trim() } : { year: '', label: t });
      } else if (sec === 'c') {
        const parts = line.replace(/^[-*•]\s*/, '').split('|').map(x => x.trim()), tok = parseCodes(parts[0])[0]; if (!tok) continue;
        toks.push(tok);
        parts.slice(1).forEach(a => {
          const m = /^(rajaus|only|endast|valittu|chosen|vald)\s*:\s*(.*)$/i.exec(a); if (!m) return;
          if (/^(r|o|e)/i.test(m[1])) out.filters[tok] = m[2].trim();
          else { const g = /^(\S+)\s*(?:\((.*)\))?$/.exec(m[2].trim()); if (g) out.codes[norm(tok)] = { code: g[1], period: (g[2] || '').trim() }; }
        });
      }
    }
    if (!toks.length && !out.periods.length) throw new Error('format');
    out.list = toks.join(' '); return out;
  }

  // ---------- window modes (used by the browser extension) ----------
  const hostCss = () => {
    host.style.cssText = full ? 'position:fixed;inset:0;z-index:2147483646;' : 'position:fixed;z-index:2147483646;right:16px;bottom:72px;';
    if (!full && state.x != null && state.y != null) Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
  };
  function setFull(on, v) {
    full = !!on; shell.classList.toggle('full', full); hostCss(); applySize();
    if (full && v) { view = VIEWS.includes(v) ? v : 'sel'; paintView(); if (onDash()) { renderDash(); if (view === 'dash' && !Object.keys(state.seen || {}).length) setTimeout(() => !busy && actions.dscan(), 0); } }
    if (!full) { view = 'sel'; paintView(); }
    if (full) { $('.panel').hidden = false; $('.fab').hidden = true; } else { $('.panel').hidden = !state.open; $('.fab').hidden = state.open; }
  }
  const setHidden = h => { host.style.display = h ? 'none' : ''; };
  const openPanel = () => { state.open = true; save(); setHidden(false); if (!full) { $('.panel').hidden = false; $('.fab').hidden = true; } };

  // ---------- go ----------
  buildUi();
  startDog();
  if (state.cauto) setTimeout(autoLoginPage, 800);
  keepAliveTick(); setInterval(keepAliveTick, 60000);
  evLog('LOAD', (location.hash || 'sivu') + ' · tila ' + (state.lmode || 'reload') + (loopActive() ? ' · silmukka päällä' : ''));
  document.documentElement.appendChild(host);
  // a loop page that already has a fresh scan sends its picks before the course years have even been read
  if (loopActive() && /selection/.test(location.pathname) && lpFresh()) { loopRun(); setTimeout(() => { if (!years.length) reloadYears(); }, 40); } else reloadYears();
  wilmaQuick();

  window.__wilmaKurssit = { unload, stopLoop: () => { loopStop('stop'); cancelled = true; if (location.hash === '#wk-loop' && window.__wkCloseTab) setTimeout(window.__wkCloseTab, 500); }, setFull, setHidden, openPanel, state, tools: { parseCodes, matchCourse, parseTime, pool }, dbg: { tick: tick.info, lp: lpGet, scanEvery, memo: () => scanMemo.size } };
})();
