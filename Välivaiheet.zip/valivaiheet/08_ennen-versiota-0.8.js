// ==UserScript==
// @name         Wilma Kurssit (course picker)
// @namespace    local.wilma.kurssit
// @version      0.1.0
// @description  Paste course codes, find them in Wilma's kurssitarjotin and pick them all at once (optionally at an exact time)
// @match        https://*.inschool.fi/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

/*
 * USAGE (Chrome): open Wilma, F12 -> Console, type "allow pasting" if asked, paste this file, Enter.
 * Works from any Wilma page while you are logged in; it does not need the tray to be open.
 *
 * HOW IT TALKS TO WILMA (taken from the public repo drstuggels/kurssit, written in 2021):
 *   GET  <base>/selection/view          -> #own-schools: <h4> year titles, each followed by <ul> of period links
 *   GET  <base>/selection/<period>      -> course groups are <a> elements: text = course code, href = target id
 *   POST <base>/selection/postback      -> message=pick-group & target=<href> & formkey=<token>
 * Wilma may have changed since then, so use "Find courses" (dry run, sends nothing) first.
 *
 * Console API:  __wilmaKurssit.unload()
 */

(() => {
  'use strict';

  const ID = 'wk-host';
  const KEY = 'wilmaKurssit.v1';
  const DEFAULTS = { list: '', year: '', conc: 4, at: '', lang: /^fi/i.test(document.documentElement.lang || navigator.language) ? 'fi' : 'en', open: true, arm: false, always: false, wq: true, req: null, reqV: 0, manual: {}, seen: {}, ignore: {}, pickMode: false, opPer: 2, dopen: {}, per: [], choices: {}, filters: {}, refresh: true, fast: false, rt: 0, x: null, y: null };

  // Compulsory studies, from the lukio tuntijako (valtioneuvoston asetus 810/2018, used by the 2021 curriculum):
  // credits (op) / 2 = courses. Prefixes match the start of a course code (the longest prefix wins). Everything is editable.
  const DEFAULT_REQ = [
    { id: 'ai', name: 'Äidinkieli ja kirjallisuus', p: ['ÄI', 'S2'], need: 6 },
    { id: 'a', name: 'A-kieli (englanti ym.)', p: ['ENA', 'RAA', 'SAA', 'VEA', 'ESA', 'ITA', 'RUA'], need: 6 },
    { id: 'b1', name: 'B1-kieli (ruotsi)', p: ['RUB', 'RUB1'], need: 5 },
    { id: 'may', name: 'Matematiikan yhteiset opinnot', p: ['MAY'], need: 1 },
    { id: 'maa', name: 'Pitkä matematiikka', p: ['MAA'], need: 9, alt: 'mat' },
    { id: 'mab', name: 'Lyhyt matematiikka', p: ['MAB'], need: 5, alt: 'mat' },
    { id: 'bi', name: 'Biologia', p: ['BI'], need: 2 }, { id: 'ge', name: 'Maantiede', p: ['GE'], need: 1 },
    { id: 'fy', name: 'Fysiikka', p: ['FY'], need: 1 }, { id: 'ke', name: 'Kemia', p: ['KE'], need: 1 },
    { id: 'fi', name: 'Filosofia', p: ['FI'], need: 2 }, { id: 'ps', name: 'Psykologia', p: ['PS'], need: 1 },
    { id: 'hi', name: 'Historia', p: ['HI'], need: 3 }, { id: 'yh', name: 'Yhteiskuntaoppi', p: ['YH'], need: 3 },
    { id: 'uk', name: 'Uskonto / elämänkatsomustieto', p: ['UE', 'UO', 'UK', 'UI', 'UJ', 'ET'], need: 2 },
    { id: 'te', name: 'Terveystieto', p: ['TE'], need: 1 }, { id: 'li', name: 'Liikunta', p: ['LI'], need: 2 },
    { id: 'mk', name: 'Musiikki ja kuvataide', p: ['MU', 'KU'], need: 3 },
    { id: 'op', name: 'Opinto-ohjaus', p: ['OP'], need: 2 },
  ];


  if (window.__wilmaKurssit) { try { window.__wilmaKurssit.unload(); } catch (_) { /* ignore */ } }

  let state;
  try { state = { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch (_) { state = { ...DEFAULTS }; }
  if (!Array.isArray(state.req) || state.reqV !== 2) { state.req = JSON.parse(JSON.stringify(DEFAULT_REQ)); state.reqV = 2; }
  state.at = ''; // a start time is never restored: a stale one could fire (or wait) when you did not expect it
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify({ ...state, at: '' })); } catch (_) { /* ignore */ } };

  // ---------- text ----------
  const T = {
    fi: {
      tabSel: 'Valinta', tabDash: 'Dashboard', dashOpen: 'Dashboard',
      title: 'Wilma Kurssit', year: 'Lukuvuosi', reload: 'Hae uudelleen', list: 'Kurssit (koko koodi tai alkuosa)',
      ph: 'MAY01.1, ÄI05.2\nENA04\nFY01', find: 'Etsi kurssit', pick: 'Valitse kurssit', at: 'Kellonaika (valinnainen, hh:mm:ss)',
      conc: 'Samanaikaisia pyyntöjä', cancel: 'Peruuta', loadingYears: 'Haetaan lukuvuosia…', noYears: 'Lukuvuosia ei löytynyt valintasivulta (otsikko + jaksolista). Onko sivu muuttunut?',
      always: 'Valitse automaattisesti jokaisen latauksen jälkeen', wq: 'Kytke Wilman "Käytä pikavalintaa" päälle automaattisesti', arm: 'Valitse automaattisesti seuraavan latauksen jälkeen (kerran)', armHint: 'Päivitä Wilman valintasivu: 3 s kuluttua haetaan ja valitaan tallennetut kurssit. Peruuta pysäyttää.', autoIn: n => `Automaattinen valinta alkaa ${n} s kuluttua… (Peruuta pysäyttää)`,
      clearAll: 'Tyhjennä kaikki', allCleared: 'Kaikki tyhjennetty (lista, jaksot, valinnat ja tallennettu tila).',
      pfAll: 'Kaikki jaksot', pfTitle: 'Rajaa kurssi yhteen jaksoon', missingIn: 'Ei tässä jaksossa', refresh: 'Päivitä sivu', refreshHint: 'Kellonaikana sivu päivitetään ja valinta tehdään heti latauksen jälkeen', reloadAt: s => `Päivitetään sivu ${s} kuluttua… (Peruuta pysäyttää)`, more: 'Lisää',
      selSummary: 'Valittu', clear: 'tyhjennä', save: 'Tallenna tiedostoon', load: 'Lataa tiedostosta', saved: 'Tallennettu tiedostoon.',
      loaded: (a, b) => `Ladattu: ${a}/${b} jaksoa löytyi tältä sivulta.`, badFile: 'Tiedosto ei kelpaa.',
      periods: 'Jaksot (valitaan automaattisesti, voit muuttaa)', noPeriods: 'Valitse vähintään yksi jakso.', otherSchool: 'Muut',
      scanning: n => `Haetaan jaksoja (${n})…`, found: (a, b) => `${a}/${b} kurssia löytyi.`, missing: 'Ei löytynyt', choose: 'Valitse ryhmä',
      nothing: 'Ei kursseja, joita yrittää.', noKey: 'formkey-tunnistetta ei löytynyt. Oletko kirjautunut sisään?', waiting: s => `Odotetaan… ${s}`,
      sending: n => `Valitaan ${n} kurssia…`, done: (ok, bad) => `Valmis: ${ok} pyyntöä OK, ${bad} virhettä. Tarkista tulos Wilmasta!`,
      badTime: 'Kellonaika ei kelpaa (esim. 16:00 tai 16:00:00).', cancelled: 'Peruutettu.', status: 'Tila', course: 'Kurssi', period: 'Jakso',
      hint: 'Koko koodi (MAY01.1) tai vain alku (MAY01). Rajaa jaksoon: MAY01@1a. Wilma tarkistaa päällekkäisyydet, tämä työkalu ei.',
      dry: 'Ei vielä lähetetty mitään.', unload: 'Sulje', min: 'Pienennä', lang: 'EN',
      dbg: 'Vianetsintätiedot', dbgDone: 'Kopioitu leikepöydälle. Se ei sisällä salasanaa tai tunnisteita; tarkista silti ennen jakamista.', dbgShown: 'Kopiointi ei onnistunut, valitse teksti alta käsin.',
      fSel: 'valittu', fDone: 'suoritettu', fFull: 'täynnä', fOff: 'ei valittavissa', fClosed: 'päättynyt',
      skipClosed: 'ohitettu: ilmoittautuminen on päättynyt', skipSel: 'ohitettu: jo valittu',
    },
    en: {
      tabSel: 'Selection', tabDash: 'Dashboard', dashOpen: 'Dashboard',
      title: 'Wilma Kurssit', year: 'School year', reload: 'Reload', list: 'Courses (full code or the beginning of it)',
      ph: 'MAY01.1, ÄI05.2\nENA04\nFY01', find: 'Find courses', pick: 'Pick courses', at: 'Time (optional, hh:mm:ss)',
      conc: 'Parallel requests', cancel: 'Cancel', loadingYears: 'Loading school years…', noYears: 'No school years found on the selection page (heading + period list). Has the page changed?',
      always: 'Pick automatically after every page load', wq: 'Tick Wilma\'s own "Käytä pikavalintaa" (quick select) automatically', arm: 'Pick automatically after the next page load (once)', armHint: 'Refresh the Wilma selection page: after 3 s the saved courses are found and picked. Cancel stops it.', autoIn: n => `Automatic pick starts in ${n} s… (Cancel stops it)`,
      clearAll: 'Clear everything', allCleared: 'Everything cleared (list, periods, choices and saved state).',
      pfAll: 'All periods', pfTitle: 'Limit this course to one period', missingIn: 'Not in this period', refresh: 'Refresh page', refreshHint: 'At the set time the page is refreshed and the pick happens right after it loads', reloadAt: s => `Refreshing the page in ${s}… (Cancel stops it)`, more: 'More',
      selSummary: 'Selected', clear: 'clear', save: 'Save to file', load: 'Load from file', saved: 'Saved to a file.',
      loaded: (a, b) => `Loaded: ${a}/${b} periods found on this page.`, badFile: 'Invalid file.',
      periods: 'Periods (picked automatically, you can change them)', noPeriods: 'Tick at least one period.', otherSchool: 'Other',
      scanning: n => `Scanning periods (${n})…`, found: (a, b) => `${a}/${b} courses found.`, missing: 'Not found', choose: 'Choose group',
      nothing: 'No courses to pick.', noKey: 'Could not find the formkey token. Are you logged in?', waiting: s => `Waiting… ${s}`,
      sending: n => `Picking ${n} courses…`, done: (ok, bad) => `Done: ${ok} requests OK, ${bad} failed. Check the result in Wilma!`,
      badTime: 'Invalid time (e.g. 16:00 or 16:00:00).', cancelled: 'Cancelled.', status: 'Status', course: 'Course', period: 'Period',
      hint: 'Full code (MAY01.1) or just the start (MAY01). Limit to a period: MAY01@1a. Wilma checks overlaps; this tool does not.',
      dry: 'Nothing has been sent yet.', unload: 'Close', min: 'Minimize', lang: 'FI',
      dbg: 'Debug info', dbgDone: 'Copied to clipboard. It contains no password or tokens; still check it before sharing.', dbgShown: 'Could not copy; select the text below by hand.',
      fSel: 'selected', fDone: 'completed', fFull: 'full', fOff: 'unavailable', fClosed: 'closed',
      skipClosed: 'skipped: registration has ended', skipSel: 'skipped: already selected',
    },
  };
  const tr = () => T[state.lang] || T.en;

  const H = {
    fi: {
      head: 'Yläpalkki: FI/EN vaihtaa kielen, – pienentää paneelin kuplaksi (avaa klikkaamalla kuplaa), ✕ sulkee työkalun. Paneelia voi raahata otsikosta.',
      year: 'Valitse lukuvuosi ja koulu. Jaksot haetaan valitusta vuodesta. Voit valita jaksoja usealta vuodelta ja koululta yhtä aikaa, ne säilyvät vuotta vaihtaessa.',
      reload: 'Hakee lukuvuodet ja jaksot uudelleen Wilmasta, esim. jos sivu on muuttunut.',
      periods: 'Ruksatut jaksot ovat ne, joista kursseja etsitään ja joihin valinta tehdään. Avoimet jaksot ruksataan automaattisesti. "tyhjennä" poistaa kaikki rastit.',
      list: 'Kirjoita tai liitä kurssikoodit: koko koodi (MAY01.1) tai alku (MAY01). Erota välilyönnillä, pilkulla tai rivinvaihdolla. Rajaa jaksoon: MAY01@1a.',
      plan: 'Jokaiselle koodille näytetään löydetty ryhmä. Jos ryhmiä on monta, valitse oikea vasemmasta valikosta. Oikea valikko rajaa kurssin yhteen jaksoon.',
      at: 'Valinnainen kellonaika (hh:mm:ss), jolloin valinta tehdään. Tyhjänä valinta tehdään heti.',
      refresh: 'Päällä: sivu päivitetään asetettuna aikana ja valinta tehdään heti latauksen jälkeen. Pois: odotetaan ilman päivitystä. Välilehden pitää pysyä auki.',
      find: 'Hakee valittujen jaksojen kurssitarjottimet ja näyttää, mistä ryhmästä kukin koodi löytyy. Ei valitse vielä mitään.',
      pick: 'Lähettää valinnat Wilmaan (tai odottaa asetettuun kellonaikaan). Jo valitut ja päättyneet jaksot ohitetaan.',
      cancel: 'Pysäyttää käynnissä olevan haun, odotuksen tai automaattivalinnan.',
      save: 'Tallentaa listan, jaksot ja ryhmävalinnat JSON-tiedostoon, jotta voit suunnitella etukäteen.',
      load: 'Lataa aiemmin tallennetun tiedoston ja palauttaa listan, jaksot ja valinnat.',
      clearall: 'Tyhjentää kaiken: listan, jaksot, valinnat, ajastukset ja tallennetun tilan.',
      debug: 'Kokoaa vianetsintäraportin (ei salasanoja) leikepöydälle. Liitä se kehittäjälle, jos jokin ei toimi.',
      conc: 'Kuinka monta pyyntöä lähetetään yhtä aikaa (1–10). Pienempi on varovaisempi.',
      always: 'Päällä: kurssit haetaan ja valitaan automaattisesti 3 s jokaisen valintasivun latauksen jälkeen. Peruuta pysäyttää. Jo valitut ohitetaan.',
      arm: 'Sama kuin yllä, mutta vain seuraavalla latauksella. Sen jälkeen kytkeytyy pois.',
      wq: 'Ruksaa Wilman oman "Käytä pikavalintaa" -valinnan automaattisesti, kun sivu latautuu. Wilmassa sillä valitaan kurssi yhdellä klikkauksella.',
    },
    en: {
      head: 'Top bar: FI/EN switches the language, – shrinks the panel to a bubble (click the bubble to reopen), ✕ closes the tool. Drag the panel by its title.',
      year: 'Choose the school year and school. Periods are loaded from that year. You can tick periods from several years and schools at once; they stay when you change year.',
      reload: 'Loads the school years and periods from Wilma again, e.g. if the page changed.',
      periods: 'Ticked periods are where courses are searched and picked. Open periods are ticked automatically. "clear" removes all ticks.',
      list: 'Type or paste course codes: full code (MAY01.1) or the start (MAY01). Separate with spaces, commas or new lines. Limit to a period: MAY01@1a.',
      plan: 'Shows the group found for each code. If there are several, choose the right one in the left dropdown. The right dropdown limits the course to one period.',
      at: 'Optional time (hh:mm:ss) at which the pick happens. Empty means right away.',
      refresh: 'On: the page is refreshed at the set time and the pick happens right after it loads. Off: just waits, no refresh. Keep the tab open.',
      find: 'Fetches the course trays of the ticked periods and shows which group each code is in. Picks nothing yet.',
      pick: 'Sends the picks to Wilma (or waits for the set time). Already selected and closed periods are skipped.',
      cancel: 'Stops a running search, wait or automatic pick.',
      save: 'Saves the list, periods and group choices to a JSON file so you can plan ahead.',
      load: 'Loads a previously saved file and restores the list, periods and choices.',
      clearall: 'Clears everything: list, periods, choices, timers and saved state.',
      debug: 'Copies a debug report (no passwords) to the clipboard. Share it if something does not work.',
      conc: 'How many requests are sent at once (1–10). Lower is gentler.',
      always: 'On: courses are found and picked automatically 3 s after every selection page load. Cancel stops it. Already selected ones are skipped.',
      arm: 'Same as above, but only for the next page load. Then it switches itself off.',
      wq: 'Ticks Wilma\'s own "Käytä pikavalintaa" (quick select) checkbox automatically when the page loads. In Wilma it lets you pick a course with one click.',
    },
  };
  Object.assign(H.fi, {
    tabs: 'Valinta: kurssien valinta. Dashboard: yhteenveto suoritetuista, valituista ja puuttuvista pakollisista kursseista.',
    dashopen: 'Avaa dashboardin erilliseen välilehteen, jossa näet kaikki kurssit kerralla.',
    dscan: 'Hakee Wilmasta kaikkien lukuvuosien jaksot ja päivittää, mitkä kurssit on merkitty suoritetuiksi tai valituiksi.',
    dreset: 'Palauttaa pakollisten kurssien listan oletukseksi (tuntijako). Käsin tekemäsi poistot ja muutokset häviävät.',
    dadd: 'Lisää oman oppiaineen tai kurssiryhmän: nimi, koodin alku (esim. KE tai KEA, erotettuna pilkulla) ja montako kurssia vaaditaan.',
    dmanual: 'Wilma merkitsee suoritetuiksi vain ne, jotka näkyvät kurssitarjottimessa. Kirjoita tähän loput kurssikoodit (esim. ÄI01, ENA02), niin ne lasketaan suoritetuiksi.',
    dchip: 'Vihreä = suoritettu, sininen = valittu, harmaa = ei suoritettu. Klikkaa kurssia merkitäksesi sen suoritetuksi käsin (katkoviivareunus), klikkaa uudelleen poistaaksesi merkinnän. Hiiren oikea painike avaa valikon: kurssin voi ignoorata (musta, yliviivattu), jolloin sitä ei lasketa mukaan.',
    dopen: 'Jokainen oppiaine on avattava valikko: näytä tai piilota sen kurssit. Napeilla voit avata tai sulkea kaikki kerralla. Tila säilyy.',
    dpick: 'Uusien kurssien valintamoodi: piilottaa suoritetut ja valitut kurssit valittavista. Jäljelle jäävät pakolliset, joita et ole vielä valinnut (keltainen). Suoritetut ja valitut näkyvät sinisinä. Klikkaa keltaista kurssia lisätäksesi sen valintalistaan.',
    dfold: 'Avaa tai sulkee kaikki oppiainekortit kerralla.',
    dtools: 'Lisätyökalut: merkitse suoritetuksi koodeilla, lisää oma oppiaine, palauta oletuslista, muuta opintopisteitä per kurssi ja palauta ohitetut kurssit.',
    dop: 'Montako opintopistettä yksi Wilman kurssi on. Lukiossa 1 kurssi = 2 op, joten 150 op = 75 kurssia.',
    dlist: 'Lisää kaikki keltaiset (tarjolla olevat pakolliset) kurssit valintalistaan. Siirry sitten Valinta-välilehdelle.',
    dgo: 'Siirtyy Valinta-välilehdelle, jossa lista on valmiina.',
    tileop: 'Kaikkien suoritettujen ja valittujen kurssien opintopisteet yhteensä. Lukion oppimäärä vaatii vähintään 150 op (LOPS).',
    tilereq: 'Pakollisten opintojen opintopisteet: kertyneet / vaaditut. LOPS: 94 op (lyhyt matematiikka) tai 102 op (pitkä).',
    tilemiss: 'Pakollisia kursseja, joita ei ole suoritettu eikä valittu.',
    tilecnt: 'Suoritettuja / valittuja kursseja (ohitetut eivät lasketa).',
    ddel: '✕ poistaa koko oppiaineen pakollisten listalta. Rivin numerokenttä muuttaa vaadittujen kurssien määrää, esim. 0 poistaa vaatimuksen.',
  });
  Object.assign(H.en, {
    tabs: 'Selection: choosing courses. Dashboard: overview of completed, selected and missing compulsory courses.',
    dashopen: 'Opens the dashboard in its own tab so you see all courses at once.',
    dscan: 'Fetches the periods of all school years from Wilma and refreshes which courses are marked completed or selected.',
    dreset: 'Restores the compulsory list to the default (tuntijako). Your own removals and edits are lost.',
    dadd: 'Adds your own subject or course group: name, start of the code (e.g. KE or KEA, comma separated) and how many courses are required.',
    dmanual: 'Wilma only marks completed courses that appear in the course tray. Type the rest of the codes here (e.g. ÄI01, ENA02) and they count as completed.',
    dchip: 'Green = completed, blue = selected, grey = not taken. Click a course to mark it completed by hand (dotted outline), click again to remove the mark. Right-click opens a menu: a course can be ignored (black, struck through) so it is not counted.',
    dopen: 'Every subject is a dropdown: show or hide its courses. The buttons open or close all of them at once. The state is remembered.',
    dpick: 'New-course picking mode: hides completed and selected courses from the pickable ones. What is left are compulsory courses you have not selected yet (yellow). Completed and selected ones show in blue. Click a yellow course to add it to the pick list.',
    dfold: 'Opens or closes all subject cards at once.',
    dtools: 'More tools: mark completed by codes, add your own subject, restore the default list, change credits per course and restore ignored courses.',
    dop: 'How many credits one Wilma course is. In lukio 1 course = 2 op, so 150 op = 75 courses.',
    dlist: 'Adds all yellow (offered compulsory) courses to the pick list. Then go to the Selection tab.',
    dgo: 'Goes to the Selection tab, where the list is ready.',
    tileop: 'Credits of all completed and selected courses together. The lukio syllabus requires at least 150 op (LOPS).',
    tilereq: 'Credits of the compulsory studies: earned / required. LOPS: 94 op (short maths) or 102 op (long).',
    tilemiss: 'Compulsory courses that are neither completed nor selected.',
    tilecnt: 'Completed / selected courses (ignored ones are not counted).',
    ddel: '✕ removes the whole subject from the compulsory list. The number field on a row changes how many courses are required, e.g. 0 removes the requirement.',
  });
  const D = {
    fi: { head: 'Kurssiyhteenveto', done: 'Suoritettu', sel: 'Valittu', miss: 'Puuttuu', need: 'Pakollisia', scan: 'Päivitä tiedot', reset: 'Palauta oletuslista', add: 'Lisää oppiaine', addName: 'Nimi', addPref: 'Koodin alku (esim. KE,KEA)', addBtn: 'Lisää', manual: 'Merkitse suoritetuksi (koodit)', manualBtn: 'Merkitse', del: 'Poista pakollisista', alt: 'vaihtoehto, ei lasketa', other: 'Muut kurssit', empty: 'Ei tietoja vielä. Paina "Päivitä tiedot".', scanning: (a, b) => `Haetaan jaksoja ${a}/${b}…`, scanned: n => `Valmis: ${n} kurssia löytyi.`, nothing: 'ei kursseja', req: 'pakolliset', cnt: 'kpl',
      pick: 'Uusien kurssien valinta', pickOn: 'Valintamoodi päällä', fold: 'Avaa/sulje kaikki', tools: 'Työkalut', op: 'op / kurssi', ignored: 'Ohitetut', total: 'Opintopisteet yhteensä', reqOp: 'Pakolliset', cntT: 'Suoritettu / valittu', ign: 'Ohita kurssi (ei lasketa)', unign: 'Palauta ohitettu kurssi', mark: 'Merkitse suoritetuksi', unmark: 'Poista suoritusmerkintä',
      lopsOk: n => `✓ vastaa LOPSia (${n} op)`, lopsDiff: (a, b) => `⚠ oma lista ${a} op, LOPS ${b} op`,
      pickHelp: 'Keltainen: pakollinen, ei vielä valittu (klikkaa lisätäksesi valintalistaan). Sininen: suoritettu tai valittu.', todo: 'Valittavana', have: 'Suoritettu tai valittu', notOffered: n => `ei tarjolla (${n} puuttuu)`, addAll: n => `Lisää kaikki keltaiset listaan (${n})`, go: 'Siirry valintaan →', added: n => `${n} kurssia lisätty valintalistaan.`, done2: 'Valmiit oppiaineet', inList: 'listalla', yellowNone: 'Ei valittavia pakollisia kursseja.',
      chipTip: (c, st) => `${c} – ${st}`, stDone: 'suoritettu', stSel: 'valittu', stNone: 'ei suoritettu', stIgn: 'ohitettu', stManual: 'merkitty käsin', stTodo: 'pakollinen, ei valittu' },
    en: { head: 'Course overview', done: 'Completed', sel: 'Selected', miss: 'Missing', need: 'Required', scan: 'Refresh', reset: 'Restore defaults', add: 'Add subject', addName: 'Name', addPref: 'Code start (e.g. KE,KEA)', addBtn: 'Add', manual: 'Mark as completed (codes)', manualBtn: 'Mark', del: 'Remove from compulsory', alt: 'alternative, not counted', other: 'Other courses', empty: 'No data yet. Press "Refresh".', scanning: (a, b) => `Scanning periods ${a}/${b}…`, scanned: n => `Done: ${n} courses found.`, nothing: 'no courses', req: 'compulsory', cnt: 'pcs',
      pick: 'Pick new courses', pickOn: 'Picking mode on', fold: 'Open/close all', tools: 'Tools', op: 'op / course', ignored: 'Ignored', total: 'Total credits', reqOp: 'Compulsory', cntT: 'Completed / selected', ign: 'Ignore course (not counted)', unign: 'Restore ignored course', mark: 'Mark as completed', unmark: 'Remove completion mark',
      lopsOk: n => `✓ matches LOPS (${n} op)`, lopsDiff: (a, b) => `⚠ own list ${a} op, LOPS ${b} op`,
      pickHelp: 'Yellow: compulsory, not selected yet (click to add to the pick list). Blue: completed or selected.', todo: 'To pick', have: 'Completed or selected', notOffered: n => `not offered (${n} missing)`, addAll: n => `Add all yellow to the list (${n})`, go: 'Go to selection →', added: n => `${n} courses added to the pick list.`, done2: 'Finished subjects', inList: 'in list', yellowNone: 'No compulsory courses left to pick.',
      chipTip: (c, st) => `${c} – ${st}`, stDone: 'completed', stSel: 'selected', stNone: 'not completed', stIgn: 'ignored', stManual: 'marked by hand', stTodo: 'compulsory, not selected' },
  };
  const tipOf = k => (H[state.lang] || H.en)[k] || '';

  // ---------- pure helpers ----------
  const norm = s => String(s).normalize('NFC').trim().toLowerCase();

  // Split on whitespace, commas, semicolons and bullets. Codes such as ENA_7.2K or MAY01.1 stay intact.
  function parseCodes(text) {
    const seen = new Set(), out = [];
    for (let tok of String(text).split(/[\s,;|•]+/)) {
      tok = tok.replace(/^[("'\[]+|[)"'\].:]+$/g, ''); // strip wrapping punctuation, trailing "." or ":"
      if (!tok) continue;
      const k = norm(tok);
      if (!seen.has(k)) { seen.add(k); out.push(tok); }
    }
    return out;
  }

  // An exact code wins; then all groups of that course ("MAY01" -> MAY01.1, MAY01.2); then any code starting with the text.
  function matchCourse(token, index) {
    const t = norm(token), exact = [], course = [], prefix = [];
    for (const c of index) {
      const k = norm(c.code);
      if (k === t) exact.push(c);
      else if (!t.includes('.') && k.split('.')[0] === t) course.push(c);
      else if (k.startsWith(t)) prefix.push(c);
    }
    return exact.length ? exact : course.length ? course : prefix;
  }

  function parseTime(text, now = new Date()) {
    const m = /^\s*(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?\s*$/.exec(text || '');
    if (!m) return null;
    const [h, mi, s] = [+m[1], +m[2], +(m[3] || 0)];
    if (h > 23 || mi > 59 || s > 59) return null;
    const d = new Date(now); d.setHours(h, mi, s, 0);
    return d;
  }

  // ---------- talking to Wilma ----------
  const basePath = () => (/^\/![^/]+/.exec(location.pathname) || [''])[0];
  const url = p => location.origin + basePath() + '/' + p.replace(/^\//, '');
  const parseHtml = html => new DOMParser().parseFromString(html, 'text/html');

  async function getDoc(u) {
    const r = await fetch(u, { credentials: 'same-origin' });
    if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + u);
    return { doc: parseHtml(await r.text()), url: r.url || u };
  }

  // Period labels look like "1. periodi a Tapiolan lukio": the words every label of a year ends with, minus the
  // period designator ("a", "1.", "periodi"), are the school name.
  const DESIGNATOR = /^(\d+\.?|[a-z]|periodi|jakso|period)$/i;
  const isPeriodHref = h => /^(?=.*\d)[A-Za-z0-9_-]+$/.test(h || ''); // bare ids like 19221C2A_32086; menu links have no digits
  function schoolOf(labels) {
    if (labels.length < 2) return '';
    const w = labels.map(l => l.split(' ')), min = Math.min(...w.map(x => x.length));
    let n = 0;
    while (n < min && w.every(x => x[x.length - 1 - n] === w[0][w[0].length - 1 - n])) n++;
    const words = w[0].slice(w[0].length - n);
    while (words.length && DESIGNATOR.test(words[0])) words.shift();
    return words.join(' ');
  }

  // A year is an <h4> heading followed by a <ul> of period links. Every such pair on the page counts, so other schools'
  // years show up too (not only #own-schools). They are paired in document order: a real Wilma had 13 headings but 12 lists.
  async function loadYears() {
    const { doc, url: viewUrl } = await getDoc(url('selection/view'));
    const all = []; let cur = null, taken = true;
    doc.body.querySelectorAll('h4, ul').forEach(el => {
      if (el.tagName === 'H4') { cur = { title: el.textContent.replace(/\s+/g, ' ').trim(), periods: [], section: (el.closest('[id]') || {}).id || '' }; all.push(cur); taken = false; return; }
      if (!cur || taken) return;
      const links = [...el.querySelectorAll('a[href]')].filter(a => isPeriodHref(a.getAttribute('href')));
      if (!links.length) return;
      taken = true; // only the first period list after a heading belongs to it
      links.forEach(a => {
        const note = (a.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
        cur.periods.push({ label: a.textContent.replace(/\s+/g, ' ').trim(), href: a.getAttribute('href'), note, closed: /päättynyt/i.test(note) });
      });
    });
    const list = all.filter(y => y.periods.length);
    list.forEach(y => { y.school = schoolOf(y.periods.map(p => p.label)); });
    // a year with a single period cannot reveal its school, so it borrows one that other years ended with
    const known = [...new Set(list.map(y => y.school).filter(Boolean))].sort((a, b) => b.length - a.length);
    list.forEach(y => { if (!y.school) y.school = known.find(s => y.periods.every(p => p.label.endsWith(' ' + s))) || ''; });
    list.forEach(y => y.periods.forEach(p => {
      p.short = y.school && p.label.endsWith(' ' + y.school) ? (p.label.slice(0, -(y.school.length + 1)).trim() || p.label) : p.label;
    }));
    return { years: list, viewUrl };
  }

  const isCourseCode = s => !!s && s.length <= 40 && !/\s/.test(s) && /\d/.test(s);

  // What the tray markup says about one course group (seen on a real Wilma, Oct 2026):
  //   class "disa" = not selectable (title says "Ryhmä on jo täynnä." when full), "ksuor-on" = already completed,
  //   "k<id>-on" / "k<id>-off" = a state flag whose <id> is shared by several groups.
  function describe(a, code, target, p) {
    const cls = ' ' + (a.getAttribute('class') || '') + ' ';
    const title = (a.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
    const key = /\sk(?!suor)(\S+)-(on|off)\s/.exec(cls);
    const who = /Opettaja:\s*(.*?)(?:\s+(?:Ryhmä on|Tämä kurssi)|$)/.exec(title);
    return {
      code, target, period: p.short || p.label, closed: !!p.closed, title,
      teacher: who ? who[1].replace(/^[A-ZÅÄÖ]{2,4}\s+/, '').trim() : '',
      full: /täynnä/i.test(title), off: /\sdisa\s/.test(cls),
      done: /\sksuor-on\s/.test(cls) || /suoritettu/i.test(title),
      selected: !!key && key[2] === 'on', block: key ? key[1] : '',
    };
  }

  // Collect the course links (text = code, href = target) from every period page of the year.
  async function scanPeriods(periods, viewUrl, onProgress) {
    const errors = []; let done = 0;
    const perPeriod = await Promise.all(periods.map(async p => {
      const list = [];
      try {
        const { doc } = await getDoc(new URL(p.href, viewUrl).href);
        const seen = new Set();
        doc.querySelectorAll('a[href]').forEach(a => {
          const code = a.textContent.trim(), href = a.getAttribute('href');
          if (isCourseCode(code) && !seen.has(href)) { seen.add(href); list.push(describe(a, code, href, p)); }
        });
      } catch (e) { errors.push(String(e.message || e)); }
      onProgress && onProgress(++done, periods.length);
      return list;
    }));
    const index = perPeriod.flat(); // period order, so results do not depend on which request finished first
    if (errors.length) index.errors = errors;
    return index;
  }

  async function getFormkey() {
    const here = document.querySelector('input[name=formkey]');
    if (here && here.value) return here.value;
    for (const p of ['', 'selection/view']) {
      try {
        const { doc } = await getDoc(url(p));
        const el = doc.querySelector('input[name=formkey]');
        if (el && el.value) return el.value;
      } catch (_) { /* try next */ }
    }
    return null;
  }

  async function pickGroup(target, formkey) {
    const r = await fetch(url('selection/postback'), {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: new URLSearchParams({ message: 'pick-group', target, formkey }).toString(),
    });
    const text = await r.text();
    return { ok: r.ok, status: r.status, text: text.replace(/\s+/g, ' ').trim().slice(0, 140) };
  }

  // Run async jobs with a concurrency limit; returns results in input order.
  async function pool(items, limit, fn) {
    const res = new Array(items.length); let next = 0;
    await Promise.all(Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
      while (next < items.length) { const i = next++; res[i] = await fn(items[i], i); }
    }));
    return res;
  }

  // ---------- panel (Shadow DOM) ----------
  const host = document.createElement('div');
  host.id = ID;
  host.style.cssText = 'position:fixed;z-index:2147483646;right:16px;bottom:72px;';
  if (state.x != null && state.y != null) Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
  const root = host.attachShadow({ mode: 'open' });
  const CSS = `
    .wrap { --bg:#fff; --bg2:#f4f5f7; --fg:#1b1d21; --mut:#697079; --line:#e3e6ea; --pri:#1b6e3c; --prifg:#fff; --warn:#b26a00; --bad:#b3261e;
            font: 13px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: var(--fg); }
    @media (prefers-color-scheme: dark) { .wrap { --bg:#1e2024; --bg2:#2a2d33; --fg:#eceef1; --mut:#9aa1ab; --line:#3a3e45; --pri:#3fae6c; --prifg:#08130c; --warn:#e0a040; --bad:#ff8a80; } }
    [hidden] { display: none !important; }
    button, select, input, textarea { font: inherit; color: inherit; }
    button { cursor: pointer; }
    button:disabled { opacity: .45; cursor: default; }
    .fab { width: 46px; height: 46px; border-radius: 50%; border: 0; background: var(--pri); color: var(--prifg); font-size: 20px; box-shadow: 0 4px 14px rgba(0,0,0,.35); touch-action: none; }
    .panel { width: 344px; max-height: calc(100vh - 96px); display: flex; flex-direction: column; background: var(--bg); border: 1px solid var(--line);
             border-radius: 16px; box-shadow: 0 12px 40px rgba(0,0,0,.28); overflow: hidden; }
    .head { display: flex; justify-content: space-between; align-items: center; padding: 10px 10px 10px 16px; cursor: move; user-select: none; touch-action: none; border-bottom: 1px solid var(--line); }
    .head strong { font-size: 14px; }
    .head button { background: none; border: 0; color: var(--mut); font-size: 13px; padding: 2px 7px; border-radius: 6px; }
    .head button:hover { background: var(--bg2); }
    .body { padding: 12px 16px 14px; display: grid; gap: 12px; overflow: auto; }
    label.field { display: grid; gap: 4px; }
    .field > span, .lbl { color: var(--mut); font-size: 11px; font-weight: 600; letter-spacing: .02em; text-transform: uppercase; }
    select, input:not([type]), input[type=number], textarea { border: 1px solid var(--line); border-radius: 10px; padding: 7px 9px; background: var(--bg2); box-sizing: border-box; width: 100%; }
    select:focus, input:focus, textarea:focus { outline: 2px solid var(--pri); outline-offset: -1px; }
    textarea { height: 64px; resize: vertical; font-family: ui-monospace, Consolas, monospace; }
    .card { display: grid; gap: 8px; }
    .row { display: flex; gap: 8px; }
    .row > button { flex: 1; padding: 8px 10px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); }
    .row > button.main { background: var(--pri); border-color: var(--pri); color: var(--prifg); font-weight: 600; }
    .row > button.icon { flex: 0 0 38px; padding: 0; }
    .periods { display: flex; flex-wrap: wrap; gap: 6px; }
    .periods .lbl { flex: 1 0 calc(100% - 30px); }
    .chk { display: inline-flex; align-items: center; gap: 6px; padding: 3px 10px; border: 1px solid var(--line); border-radius: 999px; background: var(--bg2); font-size: 12px; cursor: pointer; }
    .chk input { width: auto; margin: 0; accent-color: var(--pri); }
    .chk i { color: var(--warn); font-style: normal; }
    .timebar { display: flex; gap: 10px; align-items: end; }
    .timebar .grow { flex: 1; }
    .timebar .chk { height: 32px; box-sizing: border-box; }
    table { border-collapse: collapse; width: 100%; font-size: 12px; }
    td, th { padding: 5px 4px; border-bottom: 1px solid var(--line); text-align: left; vertical-align: middle; }
    th { color: var(--mut); font-size: 11px; text-transform: uppercase; font-weight: 600; }
    td select { padding: 3px 6px; border-radius: 8px; }
    .cell { display: flex; gap: 6px; align-items: center; }
    .cell > select:first-child { flex: 1; min-width: 0; }
    .cell select.pf { width: auto; max-width: 44%; }
    .ok { color: var(--pri); font-weight: 600; } .bad { color: var(--bad); font-weight: 600; } .warn { color: var(--warn); font-weight: 600; }
    .log { min-height: 2.6em; max-height: 110px; overflow: auto; padding: 8px 10px; border-radius: 10px; background: var(--bg2); font-size: 12px; white-space: pre-wrap; word-break: break-word; }
    .hint { color: var(--mut); font-size: 11px; }
    details summary { cursor: pointer; color: var(--mut); font-size: 12px; padding: 2px 0; }
    .more { display: grid; gap: 10px; padding-top: 8px; }
    .wrap { --b-find:#1d5fbf; --b-findbg:#e6effb; --b-cancel:#b3261e; --b-cancelbg:#fbe9e7; --b-save:#0b7a75; --b-savebg:#e2f4f3; --b-load:#6a3fb5; --b-loadbg:#efe9fa; }
    @media (prefers-color-scheme: dark) { .wrap { --b-find:#8ab4f8; --b-findbg:#1f2c42; --b-cancel:#ff8a80; --b-cancelbg:#40201e; --b-save:#5fd3cc; --b-savebg:#18332f; --b-load:#c3a5f5; --b-loadbg:#2c2340; } }
    .row > button, .bq > button:first-child { font-weight: 600; }
    .bq > button.b-find:first-child { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .bq > button.b-cancel:first-child { background: var(--b-cancelbg); color: var(--b-cancel); border-color: var(--b-cancel); }
    .bq > button.b-save:first-child { background: var(--b-savebg); color: var(--b-save); border-color: var(--b-save); }
    .bq > button.b-load:first-child { background: var(--b-loadbg); color: var(--b-load); border-color: var(--b-load); }
    .bq > button.b-clear:first-child { background: transparent; color: var(--b-cancel); border: 1px dashed var(--b-cancel); }
    .bq > button.b-debug:first-child { background: transparent; color: var(--mut); border: 1px dashed var(--mut); font-weight: 500; }
    .bq { flex: 1; display: flex; gap: 4px; min-width: 0; }
    .bq > button:first-child { flex: 1; padding: 8px 10px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); min-width: 0; }
    .bq > button.b-pick:first-child { background: var(--pri); border-color: var(--pri); color: var(--prifg); }
    button.q { flex: 0 0 20px; width: 20px; height: 20px; align-self: center; padding: 0; border-radius: 50%; border: 1px solid var(--mut); background: transparent; color: var(--mut); font-size: 11px; font-weight: 700; line-height: 1; }
    button.q:hover, button.q.on { background: var(--pri); border-color: var(--pri); color: var(--prifg); }
    .tip { padding: 8px 10px; border-radius: 10px; background: var(--bg2); border-left: 3px solid var(--pri); font-size: 12px; color: var(--fg); }
    .qrow { display: flex; gap: 8px; align-items: center; justify-content: space-between; }
    .qrow .field { flex: 1; }
    .head .q { margin-left: 4px; }
    .head > span { display: inline-flex; align-items: center; }
    .o0{order:0}.o1{order:1}.o2{order:2}.o3{order:3}.o4{order:4}.o5{order:5}.o6{order:6}
    .col1, .col2 { display: contents; }
    .full .panel { position: fixed; inset: 0; width: auto; max-height: none; border-radius: 0; border: 0; box-shadow: none; }
    .full .head { cursor: default; padding: 14px 24px; } .full .head strong { font-size: 17px; }
    .full .body { grid-template-columns: minmax(340px, 440px) minmax(0, 1fr); align-items: start; gap: 24px; padding: 24px; font-size: 14px; }
    .full .col1, .full .col2 { display: grid; gap: 14px; }
    .full [data-act=min], .full .fab { display: none; }
    .full .log { max-height: 240px; }
    @media (max-width: 800px) { .full .body { grid-template-columns: 1fr; } .full .col1, .full .col2 { display: contents; } }
    .tabs { display: none; align-items: center; gap: 4px; margin-left: 16px; flex: 1; }
    .full .tabs { display: inline-flex; }
    .head .tab { padding: 5px 14px; border-radius: 8px; font-weight: 600; color: var(--mut); }
    .head .tab.on { background: var(--pri); color: var(--prifg); }
    .full [data-act=dashopen], .full [data-act=dashopen] + .q { display: none; }
    .head > span > button[data-act=dashopen] { color: var(--b-find); }
    .dash { display: none; padding: 20px 24px; overflow: auto; gap: 16px; flex: 1; }
    .full.view-dash .dash { display: grid; align-content: start; } .full.view-dash .body { display: none; }
    .dtiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; }
    .tile { padding: 12px 14px; border-radius: 12px; background: var(--bg2); }
    .tile b { display: block; font-size: 26px; line-height: 1.1; } .tile span { color: var(--mut); font-size: 12px; }
    .tile.d b { color: var(--pri); } .tile.s b { color: var(--b-find); } .tile.m b { color: var(--bad); }
    .dtools { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .dtools button.act { padding: 7px 12px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); font-weight: 600; }
    .dtools button.scan { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .dtools button.rst { background: transparent; color: var(--b-cancel); border: 1px dashed var(--b-cancel); }
    .dtools input { width: auto; min-width: 150px; flex: 0 1 220px; } .dtools input.nn { width: 60px; min-width: 0; flex: 0 0 60px; }
    .dgrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(330px, 1fr)); gap: 12px; }
    .dcard { border: 1px solid var(--line); border-radius: 12px; padding: 12px; display: grid; gap: 8px; align-content: start; }
    .dcard.off { opacity: .55; }
    .dcard.complete { border-color: var(--pri); }
    .dcard h4 { margin: 0; font-size: 14px; display: flex; gap: 8px; align-items: center; }
    .dcard h4 span { flex: 1; }
    .dcard h4 input { width: 54px; padding: 3px 6px; text-align: center; }
    .dcard h4 .x { background: none; border: 0; color: var(--mut); font-size: 14px; padding: 0 4px; }
    .dcard h4 .x:hover { color: var(--bad); }
    .bar { height: 8px; border-radius: 99px; background: var(--bg2); overflow: hidden; display: flex; }
    .bar i { display: block; height: 100%; } .bar .d { background: var(--pri); } .bar .s { background: var(--b-find); }
    .dnums { font-size: 12px; color: var(--mut); }
    .dchip { display: inline-block; padding: 2px 9px; margin: 2px 4px 2px 0; border-radius: 999px; border: 1px solid var(--line); background: var(--bg2); font-size: 12px; cursor: pointer; color: var(--fg); }
    .dchip.done { background: var(--pri); border-color: var(--pri); color: var(--prifg); }
    .dchip.sel { background: var(--b-findbg); border-color: var(--b-find); color: var(--b-find); }
    .dchip.man { outline: 2px dotted var(--warn); outline-offset: 1px; }
    .dlog { min-height: 2.6em; padding: 8px 10px; border-radius: 10px; background: var(--bg2); font-size: 12px; white-space: pre-wrap; }
    .dchip.ign { background: #1a1a1a; border-color: #000; color: #8a8a8a; text-decoration: line-through; }
    .dd > summary { cursor: pointer; color: var(--mut); font-size: 12px; padding: 2px 0 6px; }
    .ctx { position: fixed; z-index: 10; min-width: 190px; padding: 4px; border-radius: 10px; background: var(--bg); border: 1px solid var(--line); box-shadow: 0 8px 24px rgba(0,0,0,.3); display: grid; }
    .ctx { display: grid; } .ctx .ctxh { padding: 4px 10px; color: var(--mut); font-size: 11px; font-weight: 700; }
    .tile small { font-size: 13px; font-weight: 500; color: var(--mut); }
    .bar.big { height: 12px; }
    .dtop h3 { margin: 0; }
    .dtools .act.pick { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .dtools .act.pick.on { background: var(--warn); color: #fff; border-color: var(--warn); }
    .dtools.yel { padding: 8px 10px; border-radius: 10px; background: color-mix(in srgb, var(--warn) 14%, transparent); }
    .dtools .act.go { background: var(--pri); color: var(--prifg); border-color: var(--pri); }
    .dtoolbox, .dash details > summary { cursor: pointer; color: var(--mut); font-size: 13px; }
    .dtoolbox { display: grid; gap: 8px; }
    .dtoolbox > summary { padding: 4px 0; }
    .dcard { gap: 6px; }
    .dcard > summary { list-style: none; display: flex; gap: 8px; align-items: center; cursor: pointer; color: var(--fg); font-size: 14px; }
    .dcard > summary::-webkit-details-marker { display: none; }
    .dcard > summary::before { content: '▸'; color: var(--mut); }
    .dcard[open] > summary::before { content: '▾'; }
    .dcard .dname { flex: 1; font-weight: 600; }
    .dcard .dnums { color: var(--mut); font-size: 12px; }
    .dcard > summary input { width: 50px; padding: 2px 6px; text-align: center; }
    .dcard > summary .x { background: none; border: 0; color: var(--mut); padding: 0 4px; }
    .dcard > summary .x:hover { color: var(--bad); }
    .dbody { padding-top: 4px; }
    .dsub { font-size: 11px; font-weight: 700; color: var(--mut); text-transform: uppercase; letter-spacing: .02em; margin: 6px 0 2px; }
    .dchip.blue { background: var(--b-findbg); border-color: var(--b-find); color: var(--b-find); cursor: default; }
    .dchip.todo { background: color-mix(in srgb, var(--warn) 22%, var(--bg)); border-color: var(--warn); color: var(--fg); font-weight: 600; }
    .dchip.todo.inl { background: var(--warn); color: #fff; }
    .ctx button { text-align: left; padding: 7px 10px; border: 0; border-radius: 7px; background: none; }
    .ctx button:hover { background: var(--bg2); }
    .ctx b { padding: 4px 10px; color: var(--mut); font-size: 11px; }
    .dnote { color: var(--mut); font-size: 12px; }
    .lnk { background: none; border: 0; color: var(--pri); text-decoration: underline; padding: 0; font-size: 11px; }`;
  const sheetCleanup = (() => {
    try { const s = new CSSStyleSheet(); s.replaceSync(CSS); root.adoptedStyleSheets = [s]; return () => {}; }
    catch (_) { const el = document.createElement('style'); el.textContent = CSS; root.appendChild(el); return () => el.remove(); }
  })();
  const shell = document.createElement('div');
  shell.className = 'wrap';
  root.appendChild(shell);
  const $ = s => root.querySelector(s);

  const ACT = { find: 'find', pick: 'pick', cancel: 'cancel', save: 'save', load: 'load', clearall: 'clearall', debug: 'debug' };
  const q = k => `<button type="button" class="q" data-help="${k}" aria-label="?" title="?">?</button>`;
  const bq = (k, label, cls, extra = '') => `<span class="bq"><button data-act="${k}" class="${cls}"${extra}>${label}</button>${q(k)}</span>`;

  function buildUi() {
    const t = tr();
    shell.innerHTML = `
      <button class="fab" title="${t.title}" aria-label="${t.title}">\u{1F4D8}</button>
      <section class="panel">
        <header class="head" data-hb><strong>${t.title}</strong><nav class="tabs"><button data-act="vsel" class="tab">${t.tabSel}</button><button data-act="vdash" class="tab">${t.tabDash}</button>${q('tabs')}</nav><span><button data-act="dashopen" title="${t.dashOpen}">\u{1F4CA} ${t.dashOpen}</button>${q('dashopen')}<button data-act="lang">${t.lang}</button><button data-act="min" title="${t.min}" aria-label="${t.min}">\u2013</button><button data-act="unload" title="${t.unload}" aria-label="${t.unload}">\u2715</button>${q('head')}</span></header>
        <div class="body">
          <div class="col1">
            <div class="card o0">
              <div class="row" data-hb><select class="year" aria-label="${t.year}"></select>${q('year')}<button data-act="reload" class="icon" title="${t.reload}" aria-label="${t.reload}">\u21BB</button>${q('reload')}</div>
              <div class="periods" data-hb></div>
              <div class="sum hint"></div>
            </div>
            <div class="field o1" data-hb><div class="qrow"><span class="lbl">${t.list}</span>${q('list')}</div><textarea class="list" placeholder="${t.ph}" spellcheck="false"></textarea></div>
            <div class="timebar o3" data-hb>
              <label class="field grow"><span>${t.at}</span><input class="at" placeholder="16:00:00"></label>${q('at')}
              <label class="chk" title="${t.refreshHint}"><input type="checkbox" class="rf" data-opt="refresh"> ${t.refresh}</label>${q('refresh')}
            </div>
            <div class="row o4" data-hb>${bq('find', '\u{1F50D} ' + t.find, 'b-find')}${bq('pick', '\u2714 ' + t.pick, 'b-pick')}${bq('cancel', '\u2716 ' + t.cancel, 'b-cancel', ' disabled')}</div>
            <div class="log o5" aria-live="polite">${t.dry}</div>
          </div>
          <div class="col2">
            <div class="o2"><div class="qrow" data-hb><span class="lbl">${t.course} \u2192 ${t.period}</span>${q('plan')}</div><div class="plan"></div></div>
            <details class="o6"><summary>${t.more}</summary>
              <div class="more">
                <div class="row" data-hb>${bq('save', '\u{1F4BE} ' + t.save, 'b-save')}${bq('load', '\u{1F4C2} ' + t.load, 'b-load')}</div>
                <div class="row" data-hb>${bq('clearall', '\u{1F5D1} ' + t.clearAll, 'b-clear')}${bq('debug', '\u{1F41E} ' + t.dbg, 'b-debug')}</div>
                <div class="qrow" data-hb><label class="field"><span>${t.conc}</span><input class="conc" type="number" min="1" max="10"></label>${q('conc')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="wq" data-opt="wq"> ${t.wq}</label>${q('wq')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="always" data-opt="always"> ${t.always}</label>${q('always')}</div>
                <div class="qrow" data-hb><label class="chk" title="${t.armHint}"><input type="checkbox" class="arm" data-opt="arm"> ${t.arm}</label>${q('arm')}</div>
                <div class="hint">${t.hint}</div>
              </div>
            </details>
          </div>
          <input class="file" type="file" accept=".json,application/json" hidden>
        </div>
        <div class="dash"></div>
      </section>`;
    $('.list').value = state.list; $('.at').value = state.at; $('.conc').value = state.conc; $('.arm').checked = !!state.arm; $('.always').checked = !!state.always; $('.wq').checked = !!state.wq; $('.rf').checked = !!state.refresh;
    $('.panel').hidden = !state.open; $('.fab').hidden = state.open;
    fillYears(true); renderPlan(); renderDash(); applyTitles(); shell.classList.toggle('full', full); shell.classList.toggle('view-dash', view === 'dash'); paintTabs();
    makeDraggable($('.fab'), () => { state.open = true; save(); $('.panel').hidden = false; $('.fab').hidden = true; });
    makeDraggable($('.head'));
  }

  // ---------- state ----------
  let years = [], viewUrl = '', plan = [], busy = false, cancelled = false, periodSel = new Set(), savedChoices = new Map(), savedFilters = new Map(), restored = false, autoDone = false, full = false, wqTimer = 0, view = 'sel';
  const log = (msg, append) => { const el = $('.log'); el.textContent = append ? el.textContent + '\n' + msg : msg; el.scrollTop = el.scrollHeight; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const setBusy = b => { busy = b; cancelled = false; root.querySelectorAll('[data-act=find],[data-act=pick],[data-act=reload]').forEach(x => { x.disabled = b; }); $('[data-act=cancel]').disabled = !b; };

  // "MAA02@1a" (or the period dropdown of a row) limits a course to periods whose label contains "1a".
  const pnorm = s => norm(s).replace(/periodi|jakso|period|[\s.]/g, '');
  function makeRow(token, index, prev, onlyPrev) {
    const [code, tail] = token.split('@');
    const only = tail ? tail.trim() : onlyPrev;
    const all = matchCourse(code, index);
    const cands = only ? all.filter(c => pnorm(c.period).includes(pnorm(only))) : all;
    const i = cands.findIndex(c => c.target === prev.get(norm(token)));
    return { token, all, only, cands, choice: i >= 0 ? i : best(cands) };
  }

  // Lower rank = better default when a short code matches several groups.
  const rank = c => (c.selected ? -1 : 0) + (c.closed ? 8 : 0) + (c.done ? 4 : 0) + (c.full || c.off ? 2 : 0);
  const best = cands => cands.reduce((b, c, i) => (rank(c) < rank(cands[b]) ? i : b), 0);
  const flagsOf = c => { const t = tr(); return [c.selected && t.fSel, c.done && t.fDone, c.full && t.fFull, !c.full && c.off && t.fOff, c.closed && t.fClosed].filter(Boolean); };

  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const yearKey = y => y.school + '|' + y.title;
  const curYear = () => years[+$('.year').value];

  // Selected periods are kept across years and schools. The first time a year is shown, its open periods are ticked
  // automatically (all of them if none is open, so Find still works); after that your own ticks are left alone.
  const visited = new Set();
  // remember the period ticks and group choices, so they survive a page refresh
  const persist = () => { state.per = [...periodSel]; state.choices = Object.fromEntries(plan.filter(p => p.cands.length).map(p => [p.token, p.cands[p.choice].target]));
    state.filters = Object.fromEntries(plan.filter(p => p.only).map(p => [p.token, p.only])); save(); };
  const disarm = () => { state.arm = false; state.fast = false; state.rt = 0; save(); const a = $('.arm'); if (a) a.checked = false; };
  function autoPeriods() {
    const y = curYear();
    if (y && !visited.has(yearKey(y))) {
      visited.add(yearKey(y));
      const open = y.periods.filter(p => !p.closed);
      (open.length ? open : y.periods).forEach(p => periodSel.add(p.href));
      persist();
    }
    renderPeriods();
  }
  const selectedYears = () => years.filter(z => z.periods.some(p => periodSel.has(p.href)));
  function renderPeriods() {
    const y = curYear(), t = tr();
    const sum = selectedYears().map(z => `${z.school ? z.school + ' ' : ''}${z.title} (${z.periods.filter(p => periodSel.has(p.href)).length})`).join(', ');
    $('.sum').innerHTML = `${t.selSummary}: ${esc(sum || '–')} ${sum ? `<button data-act="clearper" class="lnk">${t.clear}</button>` : ''}`;
    $('.periods').innerHTML = y ? `<span class="lbl">${t.periods}</span>${q('periods')}` + y.periods.map((p, i) =>
      `<label class="chk" title="${esc(p.note)}"><input type="checkbox" data-per="${i}"${periodSel.has(p.href) ? ' checked' : ''}>${esc(p.short)}${p.closed ? ` <i>(${t.fClosed})</i>` : ''}</label>`).join('') : '';
    applyTitles($('.periods'));
  }

  // Years grouped by school. The remembered year wins; otherwise the first year that still has an open period.
  function fillYears(keep) {
    const sel = $('.year'), groups = new Map();
    years.forEach((y, i) => {
      const g = y.school || tr().otherSchool;
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(`<option value="${i}">${esc(y.title)}</option>`);
    });
    sel.innerHTML = [...groups].map(([g, opts]) => `<optgroup label="${esc(g)}">${opts.join('')}</optgroup>`).join('');
    let i = years.findIndex(y => yearKey(y) === state.year);
    if (i < 0) i = years.findIndex(y => y.title === state.year); // older saved format: title only
    if (i < 0) i = years.findIndex(y => y.periods.some(p => !p.closed));
    if (i < 0 && years.length) i = 0;
    if (i >= 0) sel.value = String(i);
    if (keep) renderPeriods(); else autoPeriods();
  }
  async function reloadYears() {
    log(tr().loadingYears);
    try {
      const r = await loadYears();
      years = r.years; viewUrl = r.viewUrl;
      if (!restored) { // first load after a refresh: bring back the saved periods and group choices
        restored = true;
        const known = new Set(years.flatMap(z => z.periods.map(p => p.href))), keep = (state.per || []).filter(h => known.has(h));
        if (keep.length) { periodSel = new Set(keep); years.forEach(z => visited.add(yearKey(z))); savedChoices = new Map(Object.entries(state.choices || {})); savedFilters = new Map(Object.entries(state.filters || {})); }
      }
      fillYears();
      log(years.length ? '' : tr().noYears);
      if (!autoDone) {
        autoDone = true;
        if (state.fast && state.rt && Date.now() - state.rt > 600000) disarm(); // a stale timed refresh is dropped
        if (!state.arm && state.always && state.list.trim() && years.length && /selection/.test(location.pathname)) setTimeout(() => actions.auto(), 0);
        if (state.arm && years.length && (state.fast || /selection/.test(location.pathname))) setTimeout(() => (state.fast && state.rt > Date.now() ? actions.resume() : actions.auto()), 0);
      }
    } catch (e) { log(String(e.message || e)); }
  }

  function renderPlan() {
    const t = tr(), box = $('.plan');
    if (!plan.length) { box.innerHTML = ''; return; }
    const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    box.innerHTML = `<table><tr><th>${t.course}</th><th>${t.status}</th></tr>${plan.map((p, i) => {
      if (!p.cands.length) return `<tr><td>${esc(p.token)}</td><td class="bad">${p.all.length ? t.missingIn : t.missing}</td></tr>`;
      const multiPeriod = new Set(p.cands.map(c => c.period)).size > 1;
      const label = (c, withTeacher) => [c.code, withTeacher && c.teacher, (multiPeriod || !withTeacher) && c.period, flagsOf(c).join(', ')].filter(Boolean).join(' \u00B7 ');
      const periodsAll = [...new Set(p.all.map(c => c.period))];
      const sel = periodsAll.find(x => p.only && pnorm(x).includes(pnorm(p.only))) || '';
      const pf = periodsAll.length > 1 ? `<select class="pf" data-pf="${i}" title="${t.pfTitle}"><option value="">${t.pfAll}</option>${periodsAll.map(x => `<option value="${esc(x)}"${x === sel ? ' selected' : ''}>${esc(x)}</option>`).join('')}</select>` : '';
      if (p.cands.length === 1) return `<tr><td>${esc(p.token)}</td><td class="${rank(p.cands[0]) > 1 ? 'warn' : 'ok'}" title="${esc(p.cands[0].title)}"><div class="cell"><span>${esc(label(p.cands[0], false))}</span>${pf}</div></td></tr>`;
      return `<tr><td>${esc(p.token)}</td><td><div class="cell"><select data-row="${i}" title="${t.choose}">${p.cands.map((c, j) =>
        `<option value="${j}" title="${esc(c.title)}"${j === p.choice ? ' selected' : ''}>${esc(label(c, true))}</option>`).join('')}</select>${pf}</div></td></tr>`;
    }).join('')}</table>`;
  }

  // Build the plan: scan every period of the chosen year and match the typed codes.
  async function find() {
    const t = tr();
    const tokens = parseCodes($('.list').value);
    if (!tokens.length) { plan = []; renderPlan(); log(t.nothing); return false; }
    if (!years.length) await reloadYears();
    const y = curYear();
    if (!y) { log(t.noYears); return false; }
    state.year = yearKey(y); save();
    const multi = selectedYears().length > 1; // periods of several schools/years: say which one each course is in
    const periods = years.flatMap(z => z.periods.filter(p => periodSel.has(p.href)).map(p => ({ ...p, short: multi ? [z.school, z.title, p.short].filter(Boolean).join(' · ') : p.short })));
    if (!periods.length) { log(t.noPeriods); return false; }
    log(t.scanning(periods.length));
    const index = await scanPeriods(periods, viewUrl, (a, b) => log(t.scanning(b) + ' ' + a + '/' + b));
    // keep the group the user already chose in a dropdown when the list is re-scanned
    const prev = new Map(plan.map(p => [norm(p.token), p.cands[p.choice] && p.cands[p.choice].target]));
    savedChoices.forEach((target, tok) => { if (!prev.has(norm(tok))) prev.set(norm(tok), target); }); // choices loaded from a file
    const prevOnly = new Map(plan.map(p => [norm(p.token), p.only]));
    savedFilters.forEach((v, k) => { if (!prevOnly.has(norm(k))) prevOnly.set(norm(k), v); });
    plan = tokens.map(token => makeRow(token, index, prev, prevOnly.get(norm(token)) || ''));
    renderPlan(); persist();
    const hit = plan.filter(p => p.cands.length).length;
    log(t.found(hit, plan.length) + (index.errors ? '\n' + index.errors.join('\n') : '') + (index.length ? '' : '\n(0 course links on those pages)'));
    return true;
  }

  async function waitUntil(when, skipLines, label) {
    const t = tr();
    while (Date.now() < when.getTime()) {
      if (cancelled) return false;
      const s = Math.ceil((when.getTime() - Date.now()) / 1000);
      log([...skipLines, (label || t.waiting)(`${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`)].join('\n'));
      await sleep(Math.min(100, Math.max(1, when.getTime() - Date.now())));
    }
    return !cancelled;
  }

  async function pick() {
    const t = tr();
    if (!await find()) return;
    const chosen = [...new Map(plan.filter(p => p.cands.length).map(p => [p.cands[p.choice].target, p.cands[p.choice]])).values()];
    const targets = [], skipLines = [];
    for (const c of chosen) {
      const why = c.closed ? t.skipClosed : c.selected ? t.skipSel : '';
      if (why) skipLines.push(`– ${c.code}  ${why}`); else targets.push(c);
    }
    if (!targets.length) { log([...skipLines, t.nothing].join('\n'), true); return; }
    const key = await getFormkey();
    if (!key) { log(t.noKey, true); return; }
    const when = state.at.trim() ? parseTime(state.at) : null;
    if (state.at.trim() && !when) { log(t.badTime, true); return; }
    if (when && state.refresh && when.getTime() > Date.now()) { // refresh the page at that time; the saved setup then picks right after the load
      state.arm = true; state.fast = true; state.rt = when.getTime(); persist();
      if (!(await waitUntil(when, skipLines, t.reloadAt))) { disarm(); log(t.cancelled, true); return; }
      location.reload(); return;
    }
    if (when && !(await waitUntil(when, skipLines))) { log(t.cancelled, true); return; }
    log([...skipLines, t.sending(targets.length)].join('\n'));
    const t0 = performance.now();
    const res = await pool(targets, state.conc, async c => {
      if (cancelled) return { ok: false, status: 0, text: t.cancelled };
      try { return await pickGroup(c.target, key); } catch (e) { return { ok: false, status: 0, text: String(e.message || e) }; }
    });
    res.forEach((r, i) => log(`${r.ok ? '✓' : '✗'} ${targets[i].code}  HTTP ${r.status}  ${r.text}`, true));
    const ok = res.filter(r => r.ok).length;
    log(t.done(ok, res.length - ok) + ` (${((performance.now() - t0) / 1000).toFixed(1)} s)`, true);
  }

  // Read-only structure report for checking the selectors against the real site. Sends no POST,
  // never prints the formkey value, and strips the "!slug" from paths.
  async function debug() {
    const t = tr(), out = [];
    const clean = (s, n = 260) => String(s).replace(/\s+/g, ' ').replace(/\/![^/"'\s]+/g, '/!SLUG')
      .replace(/Opettaja:[^"]*?(?=\s*(?:Ryhmä on|Tämä kurssi)|")/g, 'Opettaja: … ').replace(/Arvosana:\s*[^\s"]+/g, 'Arvosana: …').slice(0, n);
    const chain = el => { const r = []; for (let e = el, i = 0; e && i < 5; e = e.parentElement, i++) r.push(e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (typeof e.className === 'string' && e.className.trim() ? '.' + e.className.trim().split(/\s+/).join('.') : '')); return r.join(' < '); };
    const courseLinks = doc => [...doc.querySelectorAll('a[href]')].filter(a => isCourseCode(a.textContent.trim()));
    // Compact tag/class skeleton of an element (repeated siblings collapsed as *n), to see how the tray is nested.
    const skel = (el, d) => {
      const cls = typeof el.className === 'string' ? el.className.trim().split(/\s+/).filter(c => c && !/^k\S+-(on|off)$/.test(c)) : [];
      const name = el.tagName.toLowerCase() + (cls.length ? '.' + cls.join('.') : '');
      const kids = [...el.children];
      if (!kids.length) return name + (el.tagName !== 'A' && el.textContent.trim() ? '"' + el.textContent.trim().slice(0, 18) + '"' : '');
      if (d === 0) return name + '[…]';
      const groups = [];
      kids.forEach(k => { const s = skel(k, d - 1), last = groups[groups.length - 1]; if (last && last.s === s) last.n++; else groups.push({ s, n: 1 }); });
      return name + '[' + groups.map(g => g.s + (g.n > 1 ? '*' + g.n : '')).join(', ') + ']';
    };
    const stateCls = a => ' ' + (a.getAttribute('class') || '') + ' ';
    out.push('wilma-kurssit debug ' + new Date().toISOString(), 'page: ' + clean(location.pathname), 'formkey input on this page: ' + (document.querySelector('input[name=formkey]') ? 'yes' : 'no'));
    let view = null;
    try {
      view = await getDoc(url('selection/view'));
      const d = view.doc, own = d.querySelector('#own-schools');
      out.push('selection/view: OK (' + clean(view.url) + ')', '  title: ' + clean(d.title), '  #own-schools: ' + (own ? 'yes' : 'NO'),
        '  h4: ' + d.querySelectorAll('h4').length + ', ul: ' + d.querySelectorAll('ul').length + ', links containing "selection": ' + d.querySelectorAll('a[href*="selection"]').length,
        '  formkey input: ' + (d.querySelector('input[name=formkey]') ? 'yes' : 'no'));
      [...(own || d).querySelectorAll('a[href]')].slice(0, 4).forEach(a => out.push('  link: ' + clean(a.outerHTML)));
    } catch (e) { out.push('selection/view: FAILED ' + clean(e.message || e)); }
    const y = curYear() || years[0];
    const per0 = y && (y.periods.find(p => periodSel.has(p.href)) || y.periods[0]);
    out.push('parsed years: ' + years.length + '; schools: ' + ([...new Set(years.map(z => z.school || '(unknown)'))].join(' | ') || '-'),
      '  year containers (id x count): ' + [...years.reduce((m, z) => m.set(z.section || '(no id)', (m.get(z.section || '(no id)') || 0) + 1), new Map())].map(([k, n]) => k + 'x' + n).join(', '),
      '  selects on selection/view: ' + ([...(view ? view.doc : document).querySelectorAll('select')].slice(0, 6).map(s => (s.id || s.name || '?') + '(' + s.options.length + ')').join(', ') || 'none'));
    if (y) out.push('year "' + clean(y.title) + '": ' + y.periods.length + ' periods, ' + y.periods.filter(p => p.closed).length + ' closed');
    if (view && y && per0) {
      try {
        const { doc } = await getDoc(new URL(per0.href, view.url).href), links = courseLinks(doc);
        out.push('period page "' + clean(per0.label) + '": OK', '  all links: ' + doc.querySelectorAll('a[href]').length + ', course-like links: ' + links.length,
          '  formkey input: ' + (doc.querySelector('input[name=formkey]') ? 'yes' : 'no'));
        links.slice(0, 5).forEach(a => out.push('  course: ' + clean(a.outerHTML)));
        if (links[0]) out.push('  first course parents: ' + clean(chain(links[0])));
        // What is a "palkki"? Group the links by their class key and by their <li class="palkki"> container.
        const keyOf = a => { const m = /\sk(?!suor)(\S+)-(?:on|off)\s/.exec(stateCls(a)); return m ? m[1] : '(none)'; };
        const byKey = new Map();
        links.forEach(a => { const k = keyOf(a); if (!byKey.has(k)) byKey.set(k, []); byKey.get(k).push(a.textContent.trim()); });
        out.push('  distinct class keys: ' + byKey.size);
        [...byKey].sort((x, z) => z[1].length - x[1].length).slice(0, 14).forEach(([k, v]) => out.push('    key ' + k + ' (' + v.length + '): ' + v.slice(0, 12).join(' ')));
        const pat = new Map();
        links.forEach(a => {
          const p = (a.getAttribute('class') || '').trim().split(/\s+/).filter(Boolean).map(c => (/^k(?!suor)\S+-(on|off)$/.test(c) ? 'k*-' + c.slice(c.lastIndexOf('-') + 1) : c)).sort().join(' ') || '(no class)';
          pat.set(p, (pat.get(p) || 0) + 1);
        });
        out.push('  class patterns: ' + [...pat].map(([p, n]) => n + 'x "' + p + '"').join(' | '));
        const pal = [...doc.querySelectorAll('li.palkki')];
        out.push('  li.palkki: ' + pal.length + '; course links inside each (first 12): ' + pal.slice(0, 12).map(p => courseLinks(p).length).join(','));
        const sel = links.filter(a => /\sk(?!suor)\S+-on\s/.test(stateCls(a)));
        out.push('  selected-looking links (k*-on): ' + sel.length);
        sel.slice(0, 3).forEach(a => out.push('    ' + clean(a.outerHTML)));
        const top = doc.querySelector('ul.tray-topmost');
        out.push('  ul.tray-topmost: ' + (top ? top.children.length + ' items' : 'NOT FOUND'));
        if (top) [...top.children].slice(0, 2).forEach((li, i) => out.push('  tray item ' + i + ': ' + clean(skel(li, 6), 600)));
      } catch (e) { out.push('period page: FAILED ' + clean(e.message || e)); }
    } else out.push('period page: skipped (no year/period found)');
    const text = out.join('\n');
    log(text);
    let copied = false;
    try { await navigator.clipboard.writeText(text); copied = true; } catch (_) { /* fall through */ }
    log('\n' + (copied ? t.dbgDone : t.dbgShown), true);
  }

  // One-shot: after a refresh on a selection page, count down 3 s (Cancel stops it), then Find + Pick with the saved setup.
  async function autoRun() {
    const t = tr();
    if (!state.fast) for (let n = 3; n > 0; n--) { if (cancelled) { log(t.cancelled); return; } log(t.autoIn(n)); await sleep(1000); } // a timed refresh starts at once
    if (cancelled) { log(t.cancelled); return; }
    disarm(); // never fires twice
    await pick();
  }

  const run = fn => async () => { if (busy) return; setBusy(true); try { await fn(); } catch (e) { log(String(e && e.message || e), true); } finally { setBusy(false); } };

  // ---------- events ----------
  const actions = {
    find: run(find), pick: run(pick), reload: run(reloadYears), debug: run(debug),
    clearper: () => { periodSel.clear(); years.forEach(z => visited.add(yearKey(z))); plan = []; renderPlan(); renderPeriods(); persist(); },
    auto: run(autoRun), dscan: run(dashScan),
    vsel: () => setView('sel'), vdash: () => setView('dash'),
    dashopen: () => { window.open(location.origin + basePath() + '/selection/view#wk-full-dash', '_blank'); },
    resume: run(async () => { if (!(await waitUntil(new Date(state.rt), [], tr().reloadAt))) { disarm(); log(tr().cancelled); return; } location.reload(); }),
    clearall: () => { // wipe everything the tool remembers; language and window position stay
      cancelled = true; plan = []; savedChoices = new Map(); periodSel.clear(); years.forEach(z => visited.add(yearKey(z)));
      savedFilters = new Map(); state.list = ''; state.arm = false; state.fast = false; state.rt = 0; state.per = []; state.choices = {}; state.filters = {}; state.year = ''; state.manual = {}; state.ignore = {}; state.dopen = {}; state.seen = {}; state.req = JSON.parse(JSON.stringify(DEFAULT_REQ)); save(); renderDash();
      $('.list').value = ''; $('.at').value = ''; $('.arm').checked = false; $('.file').value = '';
      renderPlan(); renderPeriods(); log(tr().allCleared);
    },
    save: () => {
      const data = {
        v: 1, savedAt: new Date().toISOString(), list: $('.list').value,
        periods: years.flatMap(z => z.periods.filter(p => periodSel.has(p.href)).map(p => ({ href: p.href, school: z.school, year: z.title, label: p.short }))),
        choices: Object.fromEntries(plan.filter(p => p.cands.length).map(p => [p.token, p.cands[p.choice].target])),
        filters: Object.fromEntries(plan.filter(p => p.only).map(p => [p.token, p.only])),
      };
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      a.download = 'wilma-kurssit-' + new Date().toISOString().slice(0, 10) + '.json';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      log(tr().saved);
    },
    load: () => $('.file').click(),
    cancel: () => { cancelled = true; },
    min: () => { state.open = false; save(); $('.panel').hidden = true; $('.fab').hidden = false; },
    lang: () => { state.list = $('.list').value; state.lang = state.lang === 'fi' ? 'en' : 'fi'; save(); buildUi(); },
    unload: () => { if (full) { try { history.replaceState(null, '', location.pathname + location.search); } catch (_) { /* ignore */ } setFull(false); } else unload(); },
  };
  root.addEventListener('click', e => {
    const h = e.target.closest && e.target.closest('button.q');
    if (h) { toggleTip(h); return; }
    const had = root.querySelector('.ctx'); if (had) had.remove();
    const dd = e.target.closest && e.target.closest('button[data-dact]'); if (dd) { dashClick(dd); return; }
    const b = e.target.closest && e.target.closest('[data-act]'); if (b && actions[b.dataset.act]) actions[b.dataset.act]();
  });
  root.addEventListener('change', e => {
    const n = e.target; if (n.dataset && n.dataset.dact === 'op') { state.opPer = Math.max(1, Math.min(6, +n.value || 2)); save(); renderDash(); return; }
    if (n.dataset && n.dataset.dact === 'need') { const r = state.req.find(x => x.id === n.dataset.id); if (r) { r.need = Math.max(0, Math.min(40, +n.value || 0)); save(); renderDash(); } }
  });
  root.addEventListener('change', async e => {
    const input = e.target; // e.target is reset after the first await
    if (!input.classList.contains('file') || !input.files[0]) return;
    try {
      const d = JSON.parse(await input.files[0].text());
      if (d.v !== 1 || typeof d.list !== 'string' || !Array.isArray(d.periods)) throw new Error('format');
      $('.list').value = state.list = d.list; save();
      const known = new Set(years.flatMap(z => z.periods.map(p => p.href)));
      periodSel = new Set(d.periods.map(p => p.href).filter(h => known.has(h)));
      years.forEach(z => visited.add(yearKey(z)));
      savedChoices = new Map(Object.entries(d.choices || {})); savedFilters = new Map(Object.entries(d.filters || {}));
      const first = years.findIndex(z => z.periods.some(p => periodSel.has(p.href)));
      if (first >= 0) { $('.year').value = String(first); state.year = yearKey(years[first]); save(); }
      plan = []; renderPlan(); renderPeriods(); persist();
      log(tr().loaded(periodSel.size, d.periods.length));
    } catch (_) { log(tr().badFile); }
    input.value = '';
  });
  root.addEventListener('input', e => {
    const c = e.target.classList;
    if (c.contains('list')) state.list = e.target.value;
    else if (c.contains('at')) state.at = e.target.value;
    else if (c.contains('conc')) state.conc = Math.max(1, Math.min(10, +e.target.value || 1));
    else if (e.target.dataset && e.target.dataset.opt) state[e.target.dataset.opt] = e.target.checked;
    else if (e.target.dataset && e.target.dataset.pf != null) {
      const p = plan[+e.target.dataset.pf]; p.only = e.target.value;
      p.cands = p.only ? p.all.filter(c => pnorm(c.period).includes(pnorm(p.only))) : p.all; p.choice = best(p.cands);
      renderPlan(); persist(); return;
    }
    else if (c.contains('year')) { const y = curYear(); if (y) state.year = yearKey(y); plan = []; renderPlan(); autoPeriods(); }
    else if (e.target.dataset && e.target.dataset.per != null) { const p = curYear().periods[+e.target.dataset.per]; if (e.target.checked) periodSel.add(p.href); else periodSel.delete(p.href); persist(); return; }
    else if (e.target.dataset && e.target.dataset.row != null) { plan[+e.target.dataset.row].choice = +e.target.value; persist(); return; }
    save();
  });

  root.addEventListener('contextmenu', e => { const c = e.target.closest && e.target.closest('.dchip'); if (!c) return; e.preventDefault(); showCtx(e.clientX, e.clientY, c.dataset.base); });
  root.addEventListener('toggle', e => { const d = e.target; if (d && d.dataset && d.dataset.rid) { state.dopen[d.dataset.rid] = d.open; save(); } }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') root.querySelectorAll('.ctx').forEach(x => x.remove()); });

  // "?" next to a control: shows or hides its explanation right below the control's row
  function toggleTip(btn) {
    const block = btn.closest('[data-hb]'); if (!block) return;
    const next = block.nextElementSibling, key = btn.dataset.help;
    const same = next && next.classList.contains('tip') && next.dataset.key === key;
    root.querySelectorAll('.tip').forEach(x => x.remove());
    root.querySelectorAll('button.q.on').forEach(x => x.classList.remove('on'));
    if (same) return;
    const tip = document.createElement('div'); tip.className = 'tip'; tip.dataset.key = key; tip.textContent = tipOf(key);
    block.after(tip); btn.classList.add('on');
  }

  // Wilma's own "Käytä pikavalintaa" checkbox: tick it once per page load (not again, so you can still untick it)
  function wilmaQuick() {
    if (!state.wq) return;
    const label = i => [...(i.labels || [])].map(l => l.textContent).join(' ') + ' ' + ((i.parentElement && i.parentElement.textContent.length < 80) ? i.parentElement.textContent : '') + ' ' + ((i.nextSibling && i.nextSibling.textContent) || '');
    const find = () => [...document.querySelectorAll('input[type=checkbox]')].find(i => /pikavalin|quick\s*select/i.test(label(i)));
    let n = 0;
    const tick = () => { const c = find(); if (!c) return false; if (!c.checked) c.click(); return true; };
    if (tick()) return;
    const id = setInterval(() => { if (tick() || ++n > 30) clearInterval(id); }, 500);
    wqTimer = id;
  }

  function makeDraggable(handle, onClick) {
    handle.addEventListener('pointerdown', e => {
      if (full || e.button !== 0 || (e.target !== handle && e.target.closest('button'))) return;
      const r = host.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top, sx = e.clientX, sy = e.clientY;
      let moved = false;
      handle.setPointerCapture(e.pointerId);
      const move = ev => {
        if (!moved && Math.hypot(ev.clientX - sx, ev.clientY - sy) < 4) return;
        moved = true;
        state.x = Math.min(Math.max(0, ev.clientX - dx), innerWidth - 44); state.y = Math.min(Math.max(0, ev.clientY - dy), innerHeight - 44);
        Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
      };
      const up = () => { handle.removeEventListener('pointermove', move); handle.removeEventListener('pointerup', up); if (moved) save(); else if (onClick) onClick(); };
      handle.addEventListener('pointermove', move); handle.addEventListener('pointerup', up);
    });
  }

  function unload() {
    cancelled = true; clearInterval(wqTimer);
    sheetCleanup();
    host.remove();
    delete window.__wilmaKurssit;
  }

  // ---------- dashboard ----------
  const baseOf = code => String(code).split('.')[0].toUpperCase();
  const rowOf = (base, req) => { let hit = null, len = 0; for (const r of req) for (const p of r.p) { const u = String(p).toUpperCase().trim(); if (u && base.startsWith(u) && u.length > len) { hit = r; len = u.length; } } return hit; };

  function dashModel() {
    const all = new Map();
    for (const [b, v] of Object.entries(state.seen || {})) all.set(b, { base: b, d: !!v.d, s: !!v.s, o: !!v.o });
    for (const b of Object.keys(state.manual || {})) { const c = all.get(b) || { base: b, d: false, s: false, o: false }; c.m = true; all.set(b, c); }
    all.forEach(c => { c.ign = !!(state.ignore || {})[c.base]; c.done = !c.ign && (c.d || !!c.m); c.sel = !c.ign && c.s && !c.done; c.todo = !c.ign && !c.done && !c.sel && c.o; });
    const rows = state.req.map(r => ({ ...r, courses: [], done: 0, sel: 0 }));
    const other = [];
    [...all.values()].sort((a, b) => a.base.localeCompare(b.base, 'fi')).forEach(c => {
      const m = rowOf(c.base, state.req), r = m && rows.find(x => x.id === m.id);
      if (r) { r.courses.push(c); if (c.done) r.done++; else if (c.sel) r.sel++; } else other.push(c);
    });
    const groups = {};
    rows.forEach(r => { if (r.alt) (groups[r.alt] = groups[r.alt] || []).push(r); });
    Object.values(groups).forEach(g => { let top = g[0]; g.forEach(r => { if (r.done + r.sel > top.done + top.sel) top = r; }); g.forEach(r => { r.inactive = r !== top; }); });
    rows.forEach(r => { r.missing = r.inactive ? 0 : Math.max(0, r.need - r.done - r.sel); r.todoList = r.inactive ? [] : r.courses.filter(c => c.todo); r.have = r.courses.filter(c => c.done || c.sel); });
    return { rows, other, all: [...all.values()], any: all.size > 0 };
  }

  const inList = base => parseCodes(state.list).some(t => baseOf(t) === base);

  function renderDash() {
    const el = $('.dash'); if (!el) return;
    const d = D[state.lang] || D.en, m = dashModel(), pm = !!state.pickMode, op = Math.max(1, +state.opPer || 2);
    const act = m.rows.filter(r => !r.inactive);
    const need = act.reduce((a, r) => a + r.need, 0), gotC = act.reduce((a, r) => a + Math.min(r.need, r.done + r.sel), 0), miss = need - gotC;
    const nDone = m.all.filter(c => c.done).length, nSel = m.all.filter(c => c.sel).length, totalOp = (nDone + nSel) * op;
    const mathRow = act.find(r => r.alt === 'mat'), lops = mathRow ? (mathRow.id === 'maa' ? 102 : 94) : 0;
    const lopsTxt = lops ? (need * op === lops ? d.lopsOk(lops) : d.lopsDiff(need * op, lops)) : '';
    const pct = (a, b) => (b ? Math.min(100, Math.round(100 * a / b)) : 0);
    const stOf = c => c.ign ? d.stIgn : c.done ? d.stDone + (c.m ? ', ' + d.stManual : '') : c.sel ? d.stSel : c.todo ? d.stTodo : d.stNone;
    const chip = c => {
      const cls = c.ign ? ' ign' : pm ? (c.done || c.sel ? ' blue' : c.todo ? ' todo' + (inList(c.base) ? ' inl' : '') : '') : (c.done ? ' done' : c.sel ? ' sel' : '');
      return `<button class="dchip${cls}${c.m ? ' man' : ''}" data-dact="chip" data-base="${esc(c.base)}" title="${esc(d.chipTip(c.base, stOf(c)) + (pm && c.todo ? ' · ' + (inList(c.base) ? d.inList : '+') : ''))}">${esc(c.base)}</button>`;
    };
    const key = r => (pm ? 'p:' : 'n:') + r.id;
    const isOpen = r => (state.dopen[key(r)] != null ? state.dopen[key(r)] : pm);
    const bar = r => `<div class="bar"><i class="d" style="width:${pct(Math.min(r.done, r.need), r.need)}%"></i><i class="s" style="width:${pct(Math.min(Math.max(0, r.need - r.done), r.sel), r.need)}%"></i></div>`;
    const card = r => {
      const body = pm
        ? `<div class="dsub">${d.todo}</div><div>${r.todoList.length ? r.todoList.map(chip).join('') : `<span class="dnote">${r.missing ? d.notOffered(r.missing) : d.yellowNone}</span>`}</div>${r.have.length ? `<div class="dsub">${d.have}</div><div>${r.have.map(chip).join('')}</div>` : ''}`
        : `<div>${r.courses.length ? r.courses.map(chip).join('') : `<span class="dnote">${d.nothing}</span>`}</div>`;
      return `<details class="dcard${r.inactive ? ' off' : ''}${!r.inactive && r.need > 0 && !r.missing ? ' complete' : ''}" data-rid="${esc(key(r))}"${isOpen(r) ? ' open' : ''}>
        <summary><span class="dname">${esc(r.name)}${r.inactive ? ` <small class="dnote">(${d.alt})</small>` : ''}</span><span class="dnums" title="${d.done} ${r.done} · ${d.sel} ${r.sel} · ${d.miss} ${r.missing} / ${d.need} ${r.need}">${r.done + r.sel}/${r.need}</span>
          <input type="number" min="0" max="40" value="${r.need}" data-dact="need" data-id="${esc(r.id)}" aria-label="${d.need}" title="${d.need}"><button class="x" data-dact="del" data-id="${esc(r.id)}" title="${d.del}" aria-label="${d.del}">✕</button></summary>
        ${bar(r)}<div class="dbody">${body}</div></details>`;
    };
    const shown = pm ? act.filter(r => r.missing > 0 || r.todoList.length) : m.rows;
    const finished = pm ? m.rows.filter(r => !r.inactive && !shown.includes(r)) : [];
    const yellow = act.flatMap(r => r.todoList).filter(c => !inList(c.base));
    const ignored = m.all.filter(c => c.ign);
    el.innerHTML = `
      <div class="dtop"><h3>${d.head}</h3></div>
      <div class="dtiles">
        <div class="tile" title="${esc(tipOf('tileop'))}"><b>${totalOp}<small> / 150 op</small></b><span>${d.total} · ${d.done.toLowerCase()} ${nDone * op} + ${d.sel.toLowerCase()} ${nSel * op}</span></div>
        <div class="tile d" title="${esc(tipOf('tilereq'))}"><b>${gotC * op}<small> / ${need * op} op</small></b><span>${d.reqOp} · ${lopsTxt}</span></div>
        <div class="tile m" title="${esc(tipOf('tilemiss'))}"><b>${miss}</b><span>${d.miss} (${d.req})</span></div>
        <div class="tile s" title="${esc(tipOf('tilecnt'))}"><b>${nDone} / ${nSel}</b><span>${d.cntT}</span></div>
      </div>
      <div class="bar big" title="${esc(tipOf('tileop'))}"><i class="d" style="width:${pct(nDone * op, 150)}%"></i><i class="s" style="width:${pct(nSel * op, 150)}%"></i></div>
      <div class="dtools" data-hb>
        <button class="act pick${pm ? ' on' : ''}" data-dact="pickmode">\u{1F3AF} ${pm ? d.pickOn : d.pick}</button>${q('dpick')}
        <button class="act scan" data-act="dscan">↻ ${d.scan}</button>${q('dscan')}
        <button class="act" data-dact="fold">${d.fold}</button>${q('dfold')}
      </div>
      ${pm ? `<div class="dtools yel" data-hb><span class="dnote">${d.pickHelp}</span><button class="act" data-dact="addall"${yellow.length ? '' : ' disabled'}>${d.addAll(yellow.length)}</button>${q('dlist')}<button class="act go" data-dact="go">${d.go}</button>${q('dgo')}</div>` : ''}
      <details class="dtoolbox" data-rid="tools"${state.dopen.tools ? ' open' : ''}><summary title="${esc(tipOf('dtools'))}">⚙ ${d.tools}</summary>
        <div class="dtools" data-hb><input class="dmanual" placeholder="${d.manual}" spellcheck="false"><button class="act" data-dact="manual">${d.manualBtn}</button>${q('dmanual')}</div>
        <div class="dtools" data-hb><input class="dnname" placeholder="${d.addName}"><input class="dnpref" placeholder="${d.addPref}"><input class="dnneed nn" type="number" min="0" max="40" value="1" aria-label="${d.cnt}"><button class="act" data-dact="add">${d.addBtn}</button>${q('dadd')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.op} <input class="nn" type="number" min="1" max="6" value="${op}" data-dact="op"></label>${q('dop')}<button class="act rst" data-dact="reset">${d.reset}</button>${q('dreset')}</div>
        <div data-hb><span class="dnote">${d.ignored} (${ignored.length}): </span>${ignored.map(chip).join('') || '<span class="dnote">–</span>'} ${q('dchip')}</div>
      </details>
      <div class="dlog" aria-live="polite"${m.any ? ' hidden' : ''}>${m.any ? '' : d.empty}</div>
      <div class="dgrid">${shown.map(card).join('')}</div>
      ${finished.length ? `<details><summary>${d.done2} (${finished.length})</summary><div class="dgrid" style="padding-top:8px">${finished.map(card).join('')}</div></details>` : ''}
      ${pm ? '' : `<details><summary>${d.other} (${m.other.length})</summary><div style="padding-top:6px">${m.other.map(chip).join('') || `<span class="dnote">${d.nothing}</span>`}</div></details>`}`;
    applyTitles(el);
  }

  async function dashScan() {
    const d = D[state.lang] || D.en, dl = txt => { const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = txt; } };
    if (!years.length) await reloadYears();
    const ps = years.flatMap(y => y.periods); let n = 0; const fresh = {};
    dl(d.scanning(0, ps.length));
    await pool(ps, state.conc, async p => {
      const idx = await scanPeriods([p], viewUrl);
      idx.forEach(c => { const b = baseOf(c.code), r = fresh[b] || (fresh[b] = { d: 0, s: 0, o: 0 }); if (c.done) r.d = 1; if (c.selected) r.s = 1; if (!c.closed) r.o = 1; });
      dl(d.scanning(++n, ps.length));
    });
    const old = state.seen || {}, next = {};
    for (const b of Object.keys(old)) next[b] = { d: old[b].d ? 1 : 0, s: 0, o: 0 };
    for (const [b, v] of Object.entries(fresh)) next[b] = { d: (old[b] && old[b].d) || v.d ? 1 : 0, s: v.s, o: v.o };
    state.seen = next; save(); renderDash();
    const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = d.scanned(Object.keys(fresh).length); }
  }

  // "?" help text also as hover text on the control it belongs to
  function applyTitles(scope) {
    (scope || root).querySelectorAll('button.q').forEach(b => {
      const tip = tipOf(b.dataset.help); if (!tip) return;
      b.title = tip;
      let el = b.previousElementSibling;
      while (el && el.classList.contains('q')) el = el.previousElementSibling;
      if (el && !el.matches('input.nn, .dchip')) el.title = tip;
    });
  }

  // small right-click menu for a course chip
  function showCtx(x, y, base) {
    root.querySelectorAll('.ctx').forEach(e => e.remove());
    const d = D[state.lang] || D.en, ign = !!state.ignore[base], man = !!state.manual[base];
    const m = document.createElement('div'); m.className = 'ctx';
    m.style.left = Math.min(x, innerWidth - 230) + 'px'; m.style.top = Math.min(y, innerHeight - 100) + 'px';
    m.innerHTML = `<div class="ctxh">${esc(base)}</div><button data-dact="ign" data-base="${esc(base)}">${ign ? d.unign : d.ign}</button><button data-dact="mark" data-base="${esc(base)}">${man ? d.unmark : d.mark}</button>`;
    shell.appendChild(m);
  }

  const paintTabs = () => root.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', (b.dataset.act === 'vdash') === (view === 'dash')));
  function setView(v) {
    view = v; shell.classList.toggle('view-dash', v === 'dash'); paintTabs();
    try { history.replaceState(null, '', location.pathname + location.search + (v === 'dash' ? '#wk-full-dash' : '#wk-full')); } catch (_) { /* ignore */ }
    if (v === 'dash') { renderDash(); if (!Object.keys(state.seen || {}).length && !busy) actions.dscan(); }
  }

  function dashClick(b) {
    const k = b.dataset.dact, d = D[state.lang] || D.en, base = b.dataset.base;
    if (k === 'chip') {
      if (state.pickMode) {
        if (!b.classList.contains('todo')) return;
        const toks = parseCodes(state.list), i = toks.findIndex(t => baseOf(t) === base);
        if (i >= 0) toks.splice(i, 1); else toks.push(base);
        state.list = toks.join(' ');
      } else if (state.manual[base]) delete state.manual[base]; else state.manual[base] = 1;
    }
    else if (k === 'ign') { if (state.ignore[base]) delete state.ignore[base]; else state.ignore[base] = 1; }
    else if (k === 'mark') { if (state.manual[base]) delete state.manual[base]; else state.manual[base] = 1; }
    else if (k === 'pickmode') state.pickMode = !state.pickMode;
    else if (k === 'fold') { const pm = state.pickMode, ids = state.req.map(r => (pm ? 'p:' : 'n:') + r.id), anyOpen = ids.some(i => (state.dopen[i] != null ? state.dopen[i] : pm)); ids.forEach(i => { state.dopen[i] = !anyOpen; }); }
    else if (k === 'addall') {
      const m = dashModel(), toks = parseCodes(state.list); let n = 0;
      m.rows.filter(r => !r.inactive).flatMap(r => r.todoList).forEach(c => { if (!toks.some(t => baseOf(t) === c.base)) { toks.push(c.base); n++; } });
      state.list = toks.join(' '); const l = $('.list'); if (l) l.value = state.list; save(); renderDash(); const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = d.added(n); } return;
    }
    else if (k === 'go') { setView('sel'); return; }
    else if (k === 'del') state.req = state.req.filter(r => r.id !== b.dataset.id);
    else if (k === 'reset') state.req = JSON.parse(JSON.stringify(DEFAULT_REQ));
    else if (k === 'manual') { parseCodes($('.dmanual').value).forEach(c => { state.manual[baseOf(c)] = 1; }); }
    else if (k === 'add') {
      const name = $('.dnname').value.trim(), pref = $('.dnpref').value.split(/[\s,;]+/).filter(Boolean);
      if (!name || !pref.length) return;
      state.req.push({ id: 'u' + Date.now().toString(36), name, p: pref, need: Math.max(0, +$('.dnneed').value || 0) });
    } else return;
    const l = $('.list'); if (l) l.value = state.list;
    save(); renderDash();
  }

  // ---------- window modes (used by the browser extension) ----------
  const hostCss = () => {
    host.style.cssText = full ? 'position:fixed;inset:0;z-index:2147483646;' : 'position:fixed;z-index:2147483646;right:16px;bottom:72px;';
    if (!full && state.x != null && state.y != null) Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
  };
  function setFull(on, v) {
    full = !!on; shell.classList.toggle('full', full); hostCss();
    if (full && v) { view = v; shell.classList.toggle('view-dash', v === 'dash'); paintTabs(); if (v === 'dash') { renderDash(); if (!Object.keys(state.seen || {}).length) setTimeout(() => !busy && actions.dscan(), 0); } }
    if (!full) { view = 'sel'; shell.classList.remove('view-dash'); }
    if (full) { $('.panel').hidden = false; $('.fab').hidden = true; } else { $('.panel').hidden = !state.open; $('.fab').hidden = state.open; }
  }
  const setHidden = h => { host.style.display = h ? 'none' : ''; };
  const openPanel = () => { state.open = true; save(); setHidden(false); if (!full) { $('.panel').hidden = false; $('.fab').hidden = true; } };

  // ---------- go ----------
  buildUi();
  document.documentElement.appendChild(host);
  reloadYears();
  wilmaQuick();

  window.__wilmaKurssit = { unload, setFull, setHidden, openPanel, state, tools: { parseCodes, matchCourse, parseTime, pool } };
})();
