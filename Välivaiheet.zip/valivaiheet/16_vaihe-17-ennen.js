// ==UserScript==
// @name         Wilma Kurssit (course picker)
// @namespace    local.wilma.kurssit
// @version      0.1.0
// @description  Paste course codes, find them in Wilma's kurssitarjotin and pick them all at once (optionally at an exact time)
// @match        https://*.inschool.fi/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

/*
 * USAGE (Chrome): open Wilma, F12 -> Console, type "allow pasting" if asked, paste this file, Enter.
 * Works from any Wilma page while you are logged in; it does not need the tray to be open.
 *
 * HOW IT TALKS TO WILMA (taken from the public repo drstuggels/kurssit, written in 2021):
 *   GET  <base>/selection/view          -> #own-schools: <h4> year titles, each followed by <ul> of period links
 *   GET  <base>/selection/<period>      -> course groups are <a> elements: text = course code, href = target id
 *   POST <base>/selection/postback      -> message=pick-group & target=<href> & formkey=<token>
 * Wilma may have changed since then, so use "Find courses" (dry run, sends nothing) first.
 *
 * Console API:  __wilmaKurssit.unload()
 */

(() => {
  'use strict';

  const ID = 'wk-host';
  const KEY = 'wilmaKurssit.v1';
  const DEFAULTS = { list: '', year: '', conc: 4, at: '', lang: (l => (/^fi/i.test(l) ? 'fi' : /^sv/i.test(l) ? 'sv' : 'en'))(document.documentElement.lang || navigator.language), open: true, arm: false, always: false, wq: true, req: null, reqV: 0, manual: {}, seen: {}, summary: [], ltabs: 3, lkeep: false, auto: { home: '', others: [], want: '', other: '', maxper: 0, lock: true }, ldelay: 2, lmax: 30, unstable: false, lmode: 'reload', lworkers: 6, lite: false, help: false, w: 0, h: 0, gapMs: 0, cauto: false, cremember: false, cka: true, lwin: true, earned: {}, hops: {}, hopsAt: 0, theme: 'auto', ignore: {}, pickMode: false, opPer: 2, dopen: {}, per: [], choices: {}, filters: {}, refresh: true, fast: false, rt: 0, x: null, y: null };

  // Compulsory studies, from the lukio tuntijako (valtioneuvoston asetus 810/2018, used by the 2021 curriculum):
  // credits (op) / 2 = courses. Prefixes match the start of a course code (the longest prefix wins). Everything is editable.
  const DEFAULT_REQ = [
    { id: 'ai', name: 'Äidinkieli ja kirjallisuus', p: ['ÄI', 'S2'], need: 6 },
    { id: 'a', name: 'A-kieli (englanti ym.)', p: ['ENA', 'RAA', 'SAA', 'VEA', 'ESA', 'ITA', 'RUA'], need: 6 },
    { id: 'b1', name: 'B1-kieli (ruotsi)', p: ['RUB', 'RUB1'], need: 5 },
    { id: 'may', name: 'Matematiikan yhteiset opinnot', p: ['MAY'], need: 1 },
    { id: 'maa', name: 'Pitkä matematiikka', p: ['MAA'], need: 9, alt: 'mat' },
    { id: 'mab', name: 'Lyhyt matematiikka', p: ['MAB'], need: 5, alt: 'mat' },
    { id: 'bi', name: 'Biologia', p: ['BI'], need: 2 }, { id: 'ge', name: 'Maantiede', p: ['GE'], need: 1 },
    { id: 'fy', name: 'Fysiikka', p: ['FY'], need: 1 }, { id: 'ke', name: 'Kemia', p: ['KE'], need: 1 },
    { id: 'fi', name: 'Filosofia', p: ['FI'], need: 2 }, { id: 'ps', name: 'Psykologia', p: ['PS'], need: 1 },
    { id: 'hi', name: 'Historia', p: ['HI'], need: 3 }, { id: 'yh', name: 'Yhteiskuntaoppi', p: ['YH'], need: 3 },
    { id: 'uk', name: 'Uskonto / elämänkatsomustieto', p: ['UE', 'UO', 'UK', 'UI', 'UJ', 'ET'], need: 2 },
    { id: 'te', name: 'Terveystieto', p: ['TE'], need: 1 }, { id: 'li', name: 'Liikunta', p: ['LI'], need: 2 },
    { id: 'mk', name: 'Musiikki ja kuvataide', p: ['MU', 'KU'], need: 3 },
    { id: 'op', name: 'Opinto-ohjaus', p: ['OP'], need: 2 },
  ];


  // the extension's "off" mode: do not even build the panel (saves work on a slow computer) unless a full view was asked for
  try { if (localStorage.getItem('wilmaKurssit.off') === '1' && !/#wk-/.test(location.hash)) return; } catch (_) { /* ignore */ }
  if (window.__wilmaKurssit) { try { window.__wilmaKurssit.unload(); } catch (_) { /* ignore */ } }

  let state;
  try { state = { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch (_) { state = { ...DEFAULTS }; }
  if (!Array.isArray(state.req) || state.reqV !== 2) { state.req = JSON.parse(JSON.stringify(DEFAULT_REQ)); state.reqV = 2; }
  state.at = ''; // a start time is never restored: a stale one could fire (or wait) when you did not expect it
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify({ ...state, at: '' })); } catch (_) { /* ignore */ } };

  // ---------- text ----------
  const T = {
    fi: {
      tabSel: 'Valinta', tabDash: 'Dashboard', dashOpen: 'Dashboard',
      title: 'Wilma Kurssit', year: 'Lukuvuosi', reload: 'Hae uudelleen', list: 'Kurssit (koko koodi tai alkuosa)',
      ph: 'MAY01.1, ÄI05.2\nENA04\nFY01', find: 'Etsi kurssit', pick: 'Valitse kurssit', at: 'Kellonaika (valinnainen, hh:mm:ss)',
      conc: 'Samanaikaisia pyyntöjä', cancel: 'Peruuta', loadingYears: 'Haetaan lukuvuosia…', noYears: 'Lukuvuosia ei löytynyt valintasivulta (otsikko + jaksolista). Onko sivu muuttunut?',
      always: 'Valitse automaattisesti jokaisen latauksen jälkeen', wq: 'Kytke Wilman "Käytä pikavalintaa" päälle automaattisesti', arm: 'Valitse automaattisesti seuraavan latauksen jälkeen (kerran)', armHint: 'Päivitä Wilman valintasivu: 3 s kuluttua haetaan ja valitaan tallennetut kurssit. Peruuta pysäyttää.', autoIn: n => `Automaattinen valinta alkaa ${n} s kuluttua… (Peruuta pysäyttää)`,
      clearAll: 'Tyhjennä kaikki', allCleared: 'Kaikki tyhjennetty (lista, jaksot, valinnat ja tallennettu tila).',
      pfAll: 'Kaikki jaksot', pfTitle: 'Rajaa kurssi yhteen jaksoon', missingIn: 'Ei tässä jaksossa', refresh: 'Päivitä sivu', refreshHint: 'Kellonaikana sivu päivitetään ja valinta tehdään heti latauksen jälkeen', reloadAt: s => `Päivitetään sivu ${s} kuluttua… (Peruuta pysäyttää)`, more: 'Lisää',
      selSummary: 'Valittu', clear: 'tyhjennä', save: 'Tallenna tiedostoon', load: 'Lataa tiedostosta', saved: 'Tallennettu tiedostoon.',
      loaded: (a, b) => `Ladattu: ${a}/${b} jaksoa löytyi tältä sivulta.`, badFile: 'Tiedosto ei kelpaa.',
      periods: 'Jaksot (valitaan automaattisesti, voit muuttaa)', noPeriods: 'Valitse vähintään yksi jakso.', otherSchool: 'Muut',
      scanning: n => `Haetaan jaksoja (${n})…`, found: (a, b) => `${a}/${b} kurssia löytyi.`, missing: 'Ei löytynyt', choose: 'Valitse ryhmä',
      nothing: 'Ei kursseja, joita yrittää.', noKey: 'formkey-tunnistetta ei löytynyt. Oletko kirjautunut sisään?', waiting: s => `Odotetaan… ${s}`,
      sending: n => `Valitaan ${n} kurssia…`, done: (ok, bad) => `Valmis: ${ok} pyyntöä OK, ${bad} virhettä. Tarkista tulos Wilmasta!`,
      badTime: 'Kellonaika ei kelpaa (esim. 16:00 tai 16:00:00).', cancelled: 'Peruutettu.', status: 'Tila', course: 'Kurssi', period: 'Jakso',
      hint: 'Koko koodi (MAY01.1) tai vain alku (MAY01). Rajaa jaksoon: MAY01@1a. Wilma tarkistaa päällekkäisyydet, tämä työkalu ei.',
      dry: 'Ei vielä lähetetty mitään.', unload: 'Sulje', min: 'Pienennä', lang: 'SV',
      dbg: 'Vianetsintätiedot', dbgDone: 'Kopioitu leikepöydälle. Se ei sisällä salasanaa tai tunnisteita; tarkista silti ennen jakamista.', dbgShown: 'Kopiointi ei onnistunut, valitse teksti alta käsin.',
      fSel: 'valittu', fDone: 'suoritettu', fFull: 'täynnä', fOff: 'ei valittavissa', fClosed: 'päättynyt',
      skipClosed: 'ohitettu: ilmoittautuminen on päättynyt', skipSel: 'ohitettu: jo valittu',
    },
    en: {
      tabSel: 'Selection', tabDash: 'Dashboard', dashOpen: 'Dashboard',
      title: 'Wilma Kurssit', year: 'School year', reload: 'Reload', list: 'Courses (full code or the beginning of it)',
      ph: 'MAY01.1, ÄI05.2\nENA04\nFY01', find: 'Find courses', pick: 'Pick courses', at: 'Time (optional, hh:mm:ss)',
      conc: 'Parallel requests', cancel: 'Cancel', loadingYears: 'Loading school years…', noYears: 'No school years found on the selection page (heading + period list). Has the page changed?',
      always: 'Pick automatically after every page load', wq: 'Tick Wilma\'s own "Käytä pikavalintaa" (quick select) automatically', arm: 'Pick automatically after the next page load (once)', armHint: 'Refresh the Wilma selection page: after 3 s the saved courses are found and picked. Cancel stops it.', autoIn: n => `Automatic pick starts in ${n} s… (Cancel stops it)`,
      clearAll: 'Clear everything', allCleared: 'Everything cleared (list, periods, choices and saved state).',
      pfAll: 'All periods', pfTitle: 'Limit this course to one period', missingIn: 'Not in this period', refresh: 'Refresh page', refreshHint: 'At the set time the page is refreshed and the pick happens right after it loads', reloadAt: s => `Refreshing the page in ${s}… (Cancel stops it)`, more: 'More',
      selSummary: 'Selected', clear: 'clear', save: 'Save to file', load: 'Load from file', saved: 'Saved to a file.',
      loaded: (a, b) => `Loaded: ${a}/${b} periods found on this page.`, badFile: 'Invalid file.',
      periods: 'Periods (picked automatically, you can change them)', noPeriods: 'Tick at least one period.', otherSchool: 'Other',
      scanning: n => `Scanning periods (${n})…`, found: (a, b) => `${a}/${b} courses found.`, missing: 'Not found', choose: 'Choose group',
      nothing: 'No courses to pick.', noKey: 'Could not find the formkey token. Are you logged in?', waiting: s => `Waiting… ${s}`,
      sending: n => `Picking ${n} courses…`, done: (ok, bad) => `Done: ${ok} requests OK, ${bad} failed. Check the result in Wilma!`,
      badTime: 'Invalid time (e.g. 16:00 or 16:00:00).', cancelled: 'Cancelled.', status: 'Status', course: 'Course', period: 'Period',
      hint: 'Full code (MAY01.1) or just the start (MAY01). Limit to a period: MAY01@1a. Wilma checks overlaps; this tool does not.',
      dry: 'Nothing has been sent yet.', unload: 'Close', min: 'Minimize', lang: 'FI',
      dbg: 'Debug info', dbgDone: 'Copied to clipboard. It contains no password or tokens; still check it before sharing.', dbgShown: 'Could not copy; select the text below by hand.',
      fSel: 'selected', fDone: 'completed', fFull: 'full', fOff: 'unavailable', fClosed: 'closed',
      skipClosed: 'skipped: registration has ended', skipSel: 'skipped: already selected',
    },
    sv: {
      tabSel: 'Val', tabDash: 'Dashboard', dashOpen: 'Dashboard',
      title: 'Wilma Kurssit', year: 'Läsår', reload: 'Hämta igen', list: 'Kurser (hela koden eller början)',
      ph: 'MAY01.1, ÄI05.2\nENA04\nFY01', find: 'Sök kurser', pick: 'Välj kurser', at: 'Klockslag (valfritt, tt:mm:ss)',
      conc: 'Samtidiga förfrågningar', cancel: 'Avbryt', loadingYears: 'Hämtar läsår…', noYears: 'Inga läsår hittades på valsidan (rubrik + periodlista). Har sidan ändrats?',
      always: 'Välj automatiskt efter varje sidladdning', wq: 'Kryssa Wilmas egna "Käytä pikavalintaa" (snabbval) automatiskt', arm: 'Välj automatiskt efter nästa sidladdning (en gång)', armHint: 'Uppdatera Wilmas valsida: efter 3 s söks och väljs de sparade kurserna. Avbryt stoppar.', autoIn: n => `Automatiskt val startar om ${n} s… (Avbryt stoppar)`,
      clearAll: 'Töm allt', allCleared: 'Allt tömt (lista, perioder, val och sparat tillstånd).',
      pfAll: 'Alla perioder', pfTitle: 'Begränsa kursen till en period', missingIn: 'Finns inte i denna period', refresh: 'Uppdatera sidan', refreshHint: 'Vid det angivna klockslaget uppdateras sidan och valet görs direkt efter laddningen', reloadAt: s => `Uppdaterar sidan om ${s}… (Avbryt stoppar)`, more: 'Mer',
      selSummary: 'Valda', clear: 'töm', save: 'Spara till fil', load: 'Ladda från fil', saved: 'Sparat till fil.',
      loaded: (a, b) => `Laddat: ${a}/${b} perioder hittades på denna sida.`, badFile: 'Ogiltig fil.',
      periods: 'Perioder (väljs automatiskt, du kan ändra)', noPeriods: 'Kryssa minst en period.', otherSchool: 'Övriga',
      scanning: n => `Söker perioder (${n})…`, found: (a, b) => `${a}/${b} kurser hittades.`, missing: 'Hittades inte', choose: 'Välj grupp',
      nothing: 'Inga kurser att välja.', noKey: 'Hittade inte formkey-koden. Är du inloggad?', waiting: s => `Väntar… ${s}`,
      sending: n => `Väljer ${n} kurser…`, done: (ok, bad) => `Klart: ${ok} förfrågningar OK, ${bad} fel. Kontrollera resultatet i Wilma!`,
      badTime: 'Ogiltigt klockslag (t.ex. 16:00 eller 16:00:00).', cancelled: 'Avbrutet.', status: 'Status', course: 'Kurs', period: 'Period',
      hint: 'Hela koden (MAY01.1) eller bara början (MAY01). Begränsa till period: MAY01@1a. Wilma kontrollerar överlappningar, det här verktyget gör det inte.',
      dry: 'Inget har skickats ännu.', unload: 'Stäng', min: 'Minimera', lang: 'EN',
      dbg: 'Felsökningsinfo', dbgDone: 'Kopierat till urklipp. Det innehåller inget lösenord eller koder; kontrollera ändå innan du delar.', dbgShown: 'Kopieringen lyckades inte, markera texten nedan för hand.',
      fSel: 'vald', fDone: 'avklarad', fFull: 'full', fOff: 'ej valbar', fClosed: 'avslutad',
      skipClosed: 'hoppades över: anmälan har avslutats', skipSel: 'hoppades över: redan vald',
    },
  };
  const tr = () => T[state.lang] || T.en;

  const H = {
    fi: {
      head: 'Yläpalkki: FI/EN vaihtaa kielen, – pienentää paneelin kuplaksi (avaa klikkaamalla kuplaa), ✕ sulkee työkalun. Paneelia voi raahata otsikosta.',
      year: 'Valitse lukuvuosi ja koulu. Jaksot haetaan valitusta vuodesta. Voit valita jaksoja usealta vuodelta ja koululta yhtä aikaa, ne säilyvät vuotta vaihtaessa.',
      reload: 'Hakee lukuvuodet ja jaksot uudelleen Wilmasta, esim. jos sivu on muuttunut.',
      periods: 'Ruksatut jaksot ovat ne, joista kursseja etsitään ja joihin valinta tehdään. Avoimet jaksot ruksataan automaattisesti. "tyhjennä" poistaa kaikki rastit.',
      list: 'Kirjoita tai liitä kurssikoodit: koko koodi (MAY01.1) tai alku (MAY01). Erota välilyönnillä, pilkulla tai rivinvaihdolla. Rajaa jaksoon: MAY01@1a.',
      plan: 'Jokaiselle koodille näytetään löydetty ryhmä. Jos ryhmiä on monta, valitse oikea vasemmasta valikosta. Oikea valikko rajaa kurssin yhteen jaksoon.',
      at: 'Valinnainen kellonaika (hh:mm:ss), jolloin valinta tehdään. Tyhjänä valinta tehdään heti.',
      refresh: 'Päällä: sivu päivitetään asetettuna aikana ja valinta tehdään heti latauksen jälkeen. Pois: odotetaan ilman päivitystä. Välilehden pitää pysyä auki.',
      find: 'Hakee valittujen jaksojen kurssitarjottimet ja näyttää, mistä ryhmästä kukin koodi löytyy. Ei valitse vielä mitään.',
      pick: 'Lähettää valinnat Wilmaan (tai odottaa asetettuun kellonaikaan). Jo valitut ja päättyneet jaksot ohitetaan.',
      cancel: 'Pysäyttää käynnissä olevan haun, odotuksen tai automaattivalinnan.',
      save: 'Tallentaa listan, jaksot ja ryhmävalinnat helposti luettavaan tekstitiedostoon (.txt), jota voi myös muokata käsin. Näin voit suunnitella etukäteen.',
      load: 'Lataa aiemmin tallennetun tiedoston ja palauttaa listan, jaksot ja valinnat.',
      clearall: 'Tyhjentää kaiken: listan, jaksot, valinnat, ajastukset ja tallennetun tilan.',
      debug: 'Kokoaa vianetsintäraportin (ei salasanoja) leikepöydälle. Liitä se kehittäjälle, jos jokin ei toimi.',
      conc: 'Kuinka monta pyyntöä lähetetään yhtä aikaa (1–10). Pienempi on varovaisempi.',
      always: 'Päällä: kurssit haetaan ja valitaan automaattisesti 3 s jokaisen valintasivun latauksen jälkeen. Peruuta pysäyttää. Jo valitut ohitetaan.',
      arm: 'Sama kuin yllä, mutta vain seuraavalla latauksella. Sen jälkeen kytkeytyy pois.',
      wq: 'Ruksaa Wilman oman "Käytä pikavalintaa" -valinnan automaattisesti, kun sivu latautuu. Wilmassa sillä valitaan kurssi yhdellä klikkauksella.',
    },
    en: {
      head: 'Top bar: FI/EN switches the language, – shrinks the panel to a bubble (click the bubble to reopen), ✕ closes the tool. Drag the panel by its title.',
      year: 'Choose the school year and school. Periods are loaded from that year. You can tick periods from several years and schools at once; they stay when you change year.',
      reload: 'Loads the school years and periods from Wilma again, e.g. if the page changed.',
      periods: 'Ticked periods are where courses are searched and picked. Open periods are ticked automatically. "clear" removes all ticks.',
      list: 'Type or paste course codes: full code (MAY01.1) or the start (MAY01). Separate with spaces, commas or new lines. Limit to a period: MAY01@1a.',
      plan: 'Shows the group found for each code. If there are several, choose the right one in the left dropdown. The right dropdown limits the course to one period.',
      at: 'Optional time (hh:mm:ss) at which the pick happens. Empty means right away.',
      refresh: 'On: the page is refreshed at the set time and the pick happens right after it loads. Off: just waits, no refresh. Keep the tab open.',
      find: 'Fetches the course trays of the ticked periods and shows which group each code is in. Picks nothing yet.',
      pick: 'Sends the picks to Wilma (or waits for the set time). Already selected and closed periods are skipped.',
      cancel: 'Stops a running search, wait or automatic pick.',
      save: 'Saves the list, periods and group choices to an easy-to-read text file (.txt) that you can also edit by hand, so you can plan ahead.',
      load: 'Loads a previously saved file and restores the list, periods and choices.',
      clearall: 'Clears everything: list, periods, choices, timers and saved state.',
      debug: 'Copies a debug report (no passwords) to the clipboard. Share it if something does not work.',
      conc: 'How many requests are sent at once (1–10). Lower is gentler.',
      always: 'On: courses are found and picked automatically 3 s after every selection page load. Cancel stops it. Already selected ones are skipped.',
      arm: 'Same as above, but only for the next page load. Then it switches itself off.',
      wq: 'Ticks Wilma\'s own "Käytä pikavalintaa" (quick select) checkbox automatically when the page loads. In Wilma it lets you pick a course with one click.',
    },
  };
  Object.assign(H.fi, {
    tabs: 'Valinta: kurssien valinta. Dashboard: yhteenveto suoritetuista, valituista ja puuttuvista pakollisista kursseista.',
    dashopen: 'Avaa dashboardin erilliseen välilehteen, jossa näet kaikki kurssit kerralla.',
    dscan: 'Hakee Wilmasta kaikkien lukuvuosien jaksot ja päivittää, mitkä kurssit on merkitty suoritetuiksi tai valituiksi.',
    dreset: 'Palauttaa pakollisten kurssien listan oletukseksi (tuntijako). Käsin tekemäsi poistot ja muutokset häviävät.',
    dadd: 'Lisää oman oppiaineen tai kurssiryhmän: nimi, koodin alku (esim. KE tai KEA, erotettuna pilkulla) ja montako kurssia vaaditaan.',
    dmanual: 'Wilma merkitsee suoritetuiksi vain ne, jotka näkyvät kurssitarjottimessa. Kirjoita tähän loput kurssikoodit (esim. ÄI01, ENA02), niin ne lasketaan suoritetuiksi.',
    dchip: 'Vihreä = suoritettu, sininen = valittu, harmaa = ei suoritettu. Klikkaa kurssia merkitäksesi sen suoritetuksi käsin (katkoviivareunus), klikkaa uudelleen poistaaksesi merkinnän. Hiiren oikea painike avaa valikon: kurssin voi ignoorata (musta, yliviivattu), jolloin sitä ei lasketa mukaan.',
    dopen: 'Jokainen oppiaine on avattava valikko: näytä tai piilota sen kurssit. Napeilla voit avata tai sulkea kaikki kerralla. Tila säilyy.',
    dpick: 'Uusien kurssien valintamoodi: piilottaa suoritetut ja valitut kurssit valittavista. Jäljelle jäävät pakolliset, joita et ole vielä valinnut (keltainen). Suoritetut ja valitut näkyvät sinisinä. Klikkaa keltaista kurssia lisätäksesi sen valintalistaan.',
    dfold: 'Avaa tai sulkee kaikki oppiainekortit kerralla.',
    dtools: 'Lisätyökalut: merkitse suoritetuksi koodeilla, lisää oma oppiaine, palauta oletuslista, muuta opintopisteitä per kurssi ja palauta ohitetut kurssit.',
    dop: 'Montako opintopistettä yksi Wilman kurssi on. Lukiossa 1 kurssi = 2 op, joten 150 op = 75 kurssia.',
    dlist: 'Lisää kaikki keltaiset (tarjolla olevat pakolliset) kurssit valintalistaan. Siirry sitten Valinta-välilehdelle.',
    dgo: 'Siirtyy Valinta-välilehdelle, jossa lista on valmiina.',
    tileop: 'Kaikkien suoritettujen ja valittujen kurssien opintopisteet yhteensä. Lukion oppimäärä vaatii vähintään 150 op (LOPS).',
    tilereq: 'Pakollisten opintojen opintopisteet: kertyneet / vaaditut. LOPS: 94 op (lyhyt matematiikka) tai 102 op (pitkä).',
    tilemiss: 'Pakollisia kursseja, joita ei ole suoritettu eikä valittu.',
    tilecnt: 'Suoritettuja / valittuja kursseja (ohitetut eivät lasketa).',
    ddel: '✕ poistaa koko oppiaineen pakollisten listalta. Rivin numerokenttä muuttaa vaadittujen kurssien määrää, esim. 0 poistaa vaatimuksen.',
  });
  Object.assign(H.en, {
    tabs: 'Selection: choosing courses. Dashboard: overview of completed, selected and missing compulsory courses.',
    dashopen: 'Opens the dashboard in its own tab so you see all courses at once.',
    dscan: 'Fetches the periods of all school years from Wilma and refreshes which courses are marked completed or selected.',
    dreset: 'Restores the compulsory list to the default (tuntijako). Your own removals and edits are lost.',
    dadd: 'Adds your own subject or course group: name, start of the code (e.g. KE or KEA, comma separated) and how many courses are required.',
    dmanual: 'Wilma only marks completed courses that appear in the course tray. Type the rest of the codes here (e.g. ÄI01, ENA02) and they count as completed.',
    dchip: 'Green = completed, blue = selected, grey = not taken. Click a course to mark it completed by hand (dotted outline), click again to remove the mark. Right-click opens a menu: a course can be ignored (black, struck through) so it is not counted.',
    dopen: 'Every subject is a dropdown: show or hide its courses. The buttons open or close all of them at once. The state is remembered.',
    dpick: 'New-course picking mode: hides completed and selected courses from the pickable ones. What is left are compulsory courses you have not selected yet (yellow). Completed and selected ones show in blue. Click a yellow course to add it to the pick list.',
    dfold: 'Opens or closes all subject cards at once.',
    dtools: 'More tools: mark completed by codes, add your own subject, restore the default list, change credits per course and restore ignored courses.',
    dop: 'How many credits one Wilma course is. In lukio 1 course = 2 op, so 150 op = 75 courses.',
    dlist: 'Adds all yellow (offered compulsory) courses to the pick list. Then go to the Selection tab.',
    dgo: 'Goes to the Selection tab, where the list is ready.',
    tileop: 'Credits of all completed and selected courses together. The lukio syllabus requires at least 150 op (LOPS).',
    tilereq: 'Credits of the compulsory studies: earned / required. LOPS: 94 op (short maths) or 102 op (long).',
    tilemiss: 'Compulsory courses that are neither completed nor selected.',
    tilecnt: 'Completed / selected courses (ignored ones are not counted).',
    ddel: '✕ removes the whole subject from the compulsory list. The number field on a row changes how many courses are required, e.g. 0 removes the requirement.',
  });
  const D = {
    fi: { head: 'Kurssiyhteenveto', done: 'Suoritettu', sel: 'Valittu', miss: 'Puuttuu', need: 'Pakollisia', scan: 'Päivitä tiedot', reset: 'Palauta oletuslista', add: 'Lisää oppiaine', addName: 'Nimi', addPref: 'Koodin alku (esim. KE,KEA)', addBtn: 'Lisää', manual: 'Merkitse suoritetuksi (koodit)', manualBtn: 'Merkitse', del: 'Poista pakollisista', alt: 'vaihtoehto, ei lasketa', other: 'Muut kurssit', empty: 'Ei tietoja vielä. Paina "Päivitä tiedot".', scanning: (a, b) => `Haetaan jaksoja ${a}/${b}…`, scanned: n => `Valmis: ${n} kurssia löytyi.`, nothing: 'ei kursseja', req: 'pakolliset', cnt: 'kpl',
      pick: 'Uusien kurssien valinta', pickOn: 'Valintamoodi päällä', fold: 'Avaa/sulje kaikki', tools: 'Työkalut', op: 'op / kurssi', ignored: 'Ohitetut', total: 'Opintopisteet yhteensä', reqOp: 'Pakolliset', cntT: 'Suoritettu / valittu', ign: 'Ohita kurssi (ei lasketa)', unign: 'Palauta ohitettu kurssi', mark: 'Merkitse suoritetuksi', unmark: 'Poista suoritusmerkintä',
      lopsOk: n => `✓ vastaa LOPSia (${n} op)`, lopsDiff: (a, b) => `⚠ oma lista ${a} op, LOPS ${b} op`,
      pickHelp: 'Keltainen: pakollinen, ei vielä valittu (klikkaa lisätäksesi valintalistaan). Sininen: suoritettu tai valittu.', todo: 'Valittavana', have: 'Suoritettu tai valittu', notOffered: n => `ei tarjolla (${n} puuttuu)`, addAll: n => `Lisää kaikki keltaiset listaan (${n})`, go: 'Siirry valintaan →', added: n => `${n} kurssia lisätty valintalistaan.`, done2: 'Valmiit oppiaineet', inList: 'listalla', yellowNone: 'Ei valittavia pakollisia kursseja.',
      chipTip: (c, st) => `${c} – ${st}`, stDone: 'suoritettu', stSel: 'valittu', stNone: 'ei suoritettu', stIgn: 'ohitettu', stManual: 'merkitty käsin', stTodo: 'pakollinen, ei valittu' },
    en: { head: 'Course overview', done: 'Completed', sel: 'Selected', miss: 'Missing', need: 'Required', scan: 'Refresh', reset: 'Restore defaults', add: 'Add subject', addName: 'Name', addPref: 'Code start (e.g. KE,KEA)', addBtn: 'Add', manual: 'Mark as completed (codes)', manualBtn: 'Mark', del: 'Remove from compulsory', alt: 'alternative, not counted', other: 'Other courses', empty: 'No data yet. Press "Refresh".', scanning: (a, b) => `Scanning periods ${a}/${b}…`, scanned: n => `Done: ${n} courses found.`, nothing: 'no courses', req: 'compulsory', cnt: 'pcs',
      pick: 'Pick new courses', pickOn: 'Picking mode on', fold: 'Open/close all', tools: 'Tools', op: 'op / course', ignored: 'Ignored', total: 'Total credits', reqOp: 'Compulsory', cntT: 'Completed / selected', ign: 'Ignore course (not counted)', unign: 'Restore ignored course', mark: 'Mark as completed', unmark: 'Remove completion mark',
      lopsOk: n => `✓ matches LOPS (${n} op)`, lopsDiff: (a, b) => `⚠ own list ${a} op, LOPS ${b} op`,
      pickHelp: 'Yellow: compulsory, not selected yet (click to add to the pick list). Blue: completed or selected.', todo: 'To pick', have: 'Completed or selected', notOffered: n => `not offered (${n} missing)`, addAll: n => `Add all yellow to the list (${n})`, go: 'Go to selection →', added: n => `${n} courses added to the pick list.`, done2: 'Finished subjects', inList: 'in list', yellowNone: 'No compulsory courses left to pick.',
      chipTip: (c, st) => `${c} – ${st}`, stDone: 'completed', stSel: 'selected', stNone: 'not completed', stIgn: 'ignored', stManual: 'marked by hand', stTodo: 'compulsory, not selected' },
  };
  H.sv = {
    head: 'Överst: FI/SV/EN byter språk, – krymper panelen till en bubbla (klicka på bubblan för att öppna), ✕ stänger verktyget. Panelen kan dras i titeln.',
    year: 'Välj läsår och skola. Perioderna hämtas från det valda året. Du kan kryssa perioder från flera år och skolor samtidigt; de bevaras när du byter år.',
    reload: 'Hämtar läsår och perioder från Wilma på nytt, t.ex. om sidan ändrats.',
    periods: 'Kryssade perioder är de där kurser söks och väljs. Öppna perioder kryssas automatiskt. "töm" tar bort alla kryss.',
    list: 'Skriv eller klistra in kurskoder: hel kod (MAY01.1) eller början (MAY01). Avgränsa med mellanslag, kommatecken eller radbrytning. Begränsa till period: MAY01@1a.',
    plan: 'Visar den hittade gruppen för varje kod. Finns flera, välj rätt i den vänstra rullgardinsmenyn. Den högra begränsar kursen till en period.',
    at: 'Valfritt klockslag (tt:mm:ss) då valet görs. Tomt betyder genast.',
    refresh: 'På: sidan uppdateras vid angiven tid och valet görs direkt efter laddningen. Av: väntar utan uppdatering. Håll fliken öppen.',
    find: 'Hämtar kurserbjudandet för de kryssade perioderna och visar i vilken grupp varje kod finns. Väljer inget ännu.',
    pick: 'Skickar valen till Wilma (eller väntar till angiven tid). Redan valda och avslutade perioder hoppas över.',
    cancel: 'Stoppar en pågående sökning, väntan eller automatiskt val.',
    save: 'Sparar listan, perioderna och gruppvalen i en lättläst textfil (.txt) som du också kan redigera för hand, så att du kan planera i förväg.',
    load: 'Laddar en tidigare sparad fil och återställer lista, perioder och val.',
    clearall: 'Tömmer allt: lista, perioder, val, timers och sparat tillstånd.',
    debug: 'Samlar en felsökningsrapport (inga lösenord) i urklipp. Dela den om något inte fungerar.',
    conc: 'Hur många förfrågningar som skickas samtidigt (1–10). Lägre är försiktigare.',
    always: 'På: kurserna söks och väljs automatiskt 3 s efter varje laddning av valsidan. Avbryt stoppar. Redan valda hoppas över.',
    arm: 'Som ovan, men bara vid nästa laddning. Stängs sedan av.',
    wq: 'Kryssar Wilmas egen "Käytä pikavalintaa" (snabbval) automatiskt när sidan laddas. I Wilma kan man med den välja en kurs med ett klick.',
    tabs: 'Val: välja kurser. Dashboard: översikt över avklarade, valda och saknade obligatoriska kurser.',
    dashopen: 'Öppnar dashboarden i en egen flik så att du ser alla kurser på en gång.',
    dscan: 'Hämtar perioderna för alla läsår, dina avlagda kurser och din HOPS från Wilma.',
    dreset: 'Återställer listan över obligatoriska kurser till standard (timfördelning). Dina egna ändringar går förlorade.',
    dadd: 'Lägger till ett eget ämne eller en kursgrupp: namn, början av koden (t.ex. KE eller KEA, kommaseparerat) och hur många kurser som krävs.',
    dmanual: 'Wilma markerar bara avklarade kurser som syns i kurserbjudandet. Skriv övriga kurskoder här (t.ex. ÄI01, ENA02) så räknas de som avklarade.',
    dchip: 'Grön = avklarad, blå = vald, grå = inte avklarad. Klicka på en kurs för att markera den avklarad för hand (prickad kant). Högerklick: ignorera kursen (räknas inte). Kantfärg: lila = obligatorisk, rosa = valfri.',
    dopen: 'Varje ämne är en rullgardin: visa eller dölj dess kurser.',
    dpick: 'Läge för val av nya kurser: döljer avklarade och valda kurser bland de valbara. Kvar blir obligatoriska kurser du inte valt ännu (gula). Avklarade och valda syns blå. Klicka på en gul kurs för att lägga den i vallistan.',
    dfold: 'Öppnar eller stänger alla ämneskort på en gång.',
    dtools: 'Fler verktyg: markera avklarade med koder, lägg till eget ämne, återställ standardlistan, ändra poäng per kurs och återställ ignorerade kurser.',
    dop: 'Hur många studiepoäng en Wilma-kurs är. I gymnasiet är 1 kurs = 2 sp, så 150 sp = 75 kurser.',
    dlist: 'Lägger alla gula (erbjudna obligatoriska) kurser i vallistan. Gå sedan till fliken Val.',
    dgo: 'Går till fliken Val där listan är klar.',
    tileop: 'Studiepoäng för kurser som är avlagda enligt Wilma (Studier → Prestationer). Utöver dem visas poängen för valda kurser separat. Gymnasiets lärokurs kräver minst 150 sp.',
    tilereq: 'Studiepoäng för de obligatoriska studierna: avlagda / krävda. Timfördelningen: 94 sp (kort matematik) eller 102 sp (lång).',
    tilemiss: 'Obligatoriska kurser som varken är avlagda eller valda.',
    tilecnt: 'Avlagda / valda kurser (ignorerade räknas inte).',
    ddel: '✕ tar bort hela ämnet från listan över obligatoriska. Sifferfältet ändrar hur många kurser som krävs, t.ex. 0 tar bort kravet.',
    theme: 'Ljust eller mörkt tema. Följer systemet tills du själv byter.',
    dprest: 'Hämtar dina avlagda kurser och studiepoäng från Wilmas sida Studier → Prestationer. Då räknas avlagda poäng enligt Wilma, inte enligt gissning.',
    dhops: 'Hämtar din HOPS (Studier → HOPS) från Wilma: poängen för varje kurs och vilka valda kurser som ännu inte finns i den.',
    dhopscopy: 'Kopierar kurskoderna som är valda men inte i HOPS till urklipp.',
  };
  D.sv = { head: 'Kursöversikt', done: 'Avklarad', sel: 'Vald', miss: 'Saknas', need: 'Obligatoriska', scan: 'Uppdatera', reset: 'Återställ standard', add: 'Lägg till ämne', addName: 'Namn', addPref: 'Kodens början (t.ex. KE,KEA)', addBtn: 'Lägg till', manual: 'Markera som avklarad (koder)', manualBtn: 'Markera', del: 'Ta bort från obligatoriska', alt: 'alternativ, räknas inte', other: 'Övriga kurser', empty: 'Inga uppgifter ännu. Tryck "Uppdatera".', scanning: (a, b) => `Söker perioder ${a}/${b}…`, scanned: n => `Klart: ${n} kurser hittades.`, nothing: 'inga kurser', req: 'obligatoriska', cnt: 'st',
    pick: 'Välj nya kurser', pickOn: 'Valläge på', fold: 'Öppna/stäng alla', tools: 'Verktyg', op: 'sp / kurs', ignored: 'Ignorerade', total: 'Studiepoäng', reqOp: 'Obligatoriska', cntT: 'Avklarad / vald', ign: 'Ignorera kurs (räknas inte)', unign: 'Återställ ignorerad kurs', mark: 'Markera som avklarad', unmark: 'Ta bort markeringen',
    lopsOk: n => `✓ stämmer med läroplanen (${n} sp)`, lopsDiff: (a, b) => `⚠ egen lista ${a} sp, läroplan ${b} sp`,
    pickHelp: 'Gul: obligatorisk, inte vald ännu (klicka för att lägga i vallistan). Blå: avklarad eller vald.', todo: 'Att välja', have: 'Avklarad eller vald', notOffered: n => `inte erbjuden (${n} saknas)`, addAll: n => `Lägg alla gula i listan (${n})`, go: 'Gå till val →', added: n => `${n} kurser lades till i vallistan.`, done2: 'Färdiga ämnen', inList: 'i listan', yellowNone: 'Inga obligatoriska kurser kvar att välja.',
    chipTip: (c, st) => `${c} – ${st}`, stDone: 'avklarad', stSel: 'vald', stNone: 'inte avklarad', stIgn: 'ignorerad', stManual: 'markerad för hand', stTodo: 'obligatorisk, inte vald' };
  Object.assign(D.fi, { wsum: 'Wilman yhteenveto', calc: 'kurssien summa', man: 'Pakollinen', opt: 'Valinnainen', earned: 'Saadut op (Suoritukset)', planned: 'valittu', getDone: 'Hae suoritukset', getHops: 'Hae HOPS', hopsMissing: 'Valittu, mutta ei HOPSissa', copy: 'Kopioi lista', copied: 'Kopioitu leikepöydälle.',
    linkNone: n => `Linkkiä ei löytynyt: ${n}. Paina Vianetsintätiedot (Valinta-välilehti, Lisää) ja lähetä raportti.`, doneRes: (n, k) => `Suorituksia luettu: ${n} kurssia, joista ${k} op tiedossa.`, noRows: n => `Sivulta ${n} ei tunnistettu kursseja. Paina Vianetsintätiedot.`, hopsRes: n => `HOPSista luettu ${n} kurssia.`, estimate: 'op arvio', legend: 'Reunaväri: pakollinen / valinnainen', projected: 'jos valitut suoritetaan', prest: 'Suoritukset', hops: 'HOPS', inHops: 'HOPSissa' });
  Object.assign(D.en, { wsum: 'Wilma summary', calc: 'sum of courses', man: 'Compulsory', opt: 'Elective', earned: 'Earned op (Suoritukset)', planned: 'selected', getDone: 'Fetch completions', getHops: 'Fetch HOPS', hopsMissing: 'Selected but not in HOPS', copy: 'Copy list', copied: 'Copied to clipboard.',
    linkNone: n => `Link not found: ${n}. Press Debug info (Selection tab, More) and send the report.`, doneRes: (n, k) => `Completions read: ${n} courses, ${k} op known.`, noRows: n => `No courses recognised on the ${n} page. Press Debug info.`, hopsRes: n => `${n} courses read from HOPS.`, estimate: 'op estimated', legend: 'Edge colour: compulsory / elective', projected: 'if the selected are completed', prest: 'Completions', hops: 'HOPS', inHops: 'in HOPS' });
  Object.assign(D.sv, { wsum: 'Wilmas sammanfattning', calc: 'summa av kurser', man: 'Obligatorisk', opt: 'Valfri', earned: 'Avlagda sp (Prestationer)', planned: 'vald', getDone: 'Hämta prestationer', getHops: 'Hämta HOPS', hopsMissing: 'Vald men inte i HOPS', copy: 'Kopiera lista', copied: 'Kopierat till urklipp.',
    linkNone: n => `Länken hittades inte: ${n}. Tryck Felsökningsinfo (fliken Val, Mer) och skicka rapporten.`, doneRes: (n, k) => `Prestationer lästa: ${n} kurser, ${k} sp kända.`, noRows: n => `Inga kurser kändes igen på sidan ${n}. Tryck Felsökningsinfo.`, hopsRes: n => `${n} kurser lästa från HOPS.`, estimate: 'sp uppskattade', legend: 'Kantfärg: obligatorisk / valfri', projected: 'om de valda avklaras', prest: 'Prestationer', hops: 'HOPS', inHops: 'i HOPS' });
  Object.assign(H.fi, {
    theme: 'Vaalea tai tumma teema. Seuraa järjestelmää, kunnes vaihdat itse.',
    dprest: 'Hakee suoritetut kurssit ja opintopisteet Wilman sivulta Opinnot → Suoritukset. Silloin saadut op lasketaan Wilman mukaan, ei arvauksena.',
    dhops: 'Hakee HOPSisi (Opinnot → HOPS) Wilmasta: kurssikohtaiset opintopisteet ja se, mitkä valitut kurssit eivät ole vielä siinä.',
    dhopscopy: 'Kopioi leikepöydälle kurssikoodit, jotka on valittu mutta eivät ole HOPSissa.',
    tileop: 'Wilman mukaan suoritettujen kurssien opintopisteet (Opinnot → Suoritukset). Valittujen kurssien pisteet näytetään erikseen, eikä niitä lasketa saatuihin. Lukion oppimäärä vaatii vähintään 150 op.',
    dscan: 'Hakee Wilmasta kaikkien lukuvuosien jaksot, suoritukset ja HOPSin.',
    dchip: 'Vihreä = suoritettu, sininen = valittu, harmaa = ei suoritettu. Klikkaa kurssia merkitäksesi sen suoritetuksi käsin (katkoviivareunus). Oikea klikkaus: ohita kurssi (ei lasketa). Reunaväri: violetti = pakollinen, pinkki = valinnainen.',
  });
  Object.assign(H.en, {
    theme: 'Light or dark theme. Follows the system until you change it yourself.',
    dprest: 'Fetches your completed courses and credits from Wilma\'s Opinnot → Suoritukset page, so earned credits come from Wilma, not from a guess.',
    dhops: 'Fetches your HOPS (Opinnot → HOPS) from Wilma: the credits of each course and which selected courses are not in it yet.',
    dhopscopy: 'Copies the course codes that are selected but not in HOPS to the clipboard.',
    tileop: 'Credits of the courses completed according to Wilma (Opinnot → Suoritukset). Credits of selected courses are shown separately and are not counted as earned. The lukio syllabus requires at least 150 op.',
    dscan: 'Fetches the periods of all school years, your completions and your HOPS from Wilma.',
    dchip: 'Green = completed, blue = selected, grey = not taken. Click a course to mark it completed by hand (dotted outline). Right-click: ignore the course (not counted). Edge colour: purple = compulsory, pink = elective.',
  });
  Object.assign(T.fi, { loop: 'Yritä kunnes kaikki valittu', ltabs: 'Välilehtiä', ldelay: 'Odotus kierrosten välillä (s)', lmax: 'Enimmäisaika (min)',
    loopRound: (r, p, n, s, b) => `Kierros ${r}: ${p}/${n} kurssia vielä valitsematta, ${s} pyyntöä lähetetty${b ? ', ' + b + ' virhettä' : ''}. Päivitetään sivu…`,
    loopDone: n => `\u2705 Kaikki ${n} kurssia on valittu. Silmukka pysäytetty.`, loopOff: 'Silmukka ei ole käynnissä.', loopStopped: 'Silmukka pysäytetty.',
    openedTabs: n => `Avattu ${n} lisävälilehteä.`, noTabs: 'Selain esti lisävälilehtien avaamisen. Sallitse ponnahdusikkunat tälle sivulle tai käytä laajennusta.' });
  Object.assign(T.en, { loop: 'Retry until all selected', ltabs: 'Tabs', ldelay: 'Wait between rounds (s)', lmax: 'Time limit (min)',
    loopRound: (r, p, n, s, b) => `Round ${r}: ${p}/${n} courses still not selected, ${s} requests sent${b ? ', ' + b + ' failed' : ''}. Refreshing…`,
    loopDone: n => `\u2705 All ${n} courses are selected. Loop stopped.`, loopOff: 'The loop is not running.', loopStopped: 'Loop stopped.',
    openedTabs: n => `Opened ${n} more tabs.`, noTabs: 'The browser blocked opening more tabs. Allow pop-ups for this page or use the extension.' });
  Object.assign(T.sv, { loop: 'Försök tills allt är valt', ltabs: 'Flikar', ldelay: 'Väntan mellan rundor (s)', lmax: 'Tidsgräns (min)',
    loopRound: (r, p, n, s, b) => `Runda ${r}: ${p}/${n} kurser ännu inte valda, ${s} förfrågningar skickade${b ? ', ' + b + ' fel' : ''}. Uppdaterar sidan…`,
    loopDone: n => `\u2705 Alla ${n} kurser är valda. Slingan stoppad.`, loopOff: 'Slingan körs inte.', loopStopped: 'Slingan stoppad.',
    openedTabs: n => `Öppnade ${n} flikar till.`, noTabs: 'Webbläsaren blockerade fler flikar. Tillåt popup-fönster för sidan eller använd tillägget.' });
  Object.assign(T.fi, { loopStop: 'Pysäytä silmukka (kaikki välilehdet)', lkeep: 'Jatka onnistumisen jälkeenkin, kunnes pysäytän', loopWatch: n => `Kaikki ${n} kurssia valittu. Seurataan edelleen, kunnes pysäytät silmukan…` });
  Object.assign(T.en, { loopStop: 'Stop the loop (all tabs)', lkeep: 'Keep going after success, until I stop it', loopWatch: n => `All ${n} courses selected. Still watching until you stop the loop…` });
  Object.assign(T.sv, { loopStop: 'Stoppa slingan (alla flikar)', lkeep: 'Fortsätt efter lyckat val tills jag stoppar', loopWatch: n => `Alla ${n} kurser valda. Fortsätter bevaka tills du stoppar slingan…` });
  Object.assign(H.fi, { lkeep: 'Päällä: silmukka ei lopu, kun kaikki on valittu, vaan välilehdet jatkavat päivittämistä ja tarkistavat, että valinnat pysyvät, ja valitsevat uudelleen jos jokin katoaa. Pysäytät sen napista tai Peruuta-napista.' });
  Object.assign(H.en, { lkeep: 'On: the loop does not end when everything is selected. The tabs keep refreshing, check that the picks stay, and pick again if something disappears. You stop it with the button or Cancel.' });
  Object.assign(H.sv, { lkeep: 'På: slingan tar inte slut när allt är valt. Flikarna fortsätter uppdatera, kontrollerar att valen består och väljer igen om något försvinner. Du stoppar den med knappen eller Avbryt.' });
  Object.assign(H.fi, {
    loop: 'Päivittää sivun ja yrittää valita kurssit uudestaan ja uudestaan, kunnes kaikki listan kurssit on valittu (tai painat Peruuta). Ryhmät, joissa ei ole tilaa, yritetään uudelleen joka kierroksella. Jo valitut jätetään rauhaan. Kierroksia ajetaan useassa välilehdessä, jos asetat niitä enemmän kuin 1.',
    ltabs: 'Montako Wilma-välilehteä avataan ja ajetaan yhtä aikaa (1–10). Laajennus avaa ne itse; ilman laajennusta selain voi estää ne. Useampi välilehti ei lisää tilaa, mutta tihentää yrityksiä.',
    ldelay: 'Kuinka monta sekuntia odotetaan jokaisen kierroksen jälkeen ennen sivun päivitystä. Liian pieni arvo kuormittaa Wilmaa ja voi johtaa estoon.',
    lmax: 'Silmukka pysähtyy itsestään tämän ajan jälkeen.' });
  Object.assign(H.en, {
    loop: 'Refreshes the page and tries to pick the courses again and again until every course in the list is selected (or you press Cancel). Groups with no room are retried every round. Already selected ones are left alone. Runs in several tabs if you set more than 1.',
    ltabs: 'How many Wilma tabs are opened and run at once (1–10). The extension opens them itself; without it the browser may block them. More tabs do not create more room, but they make the attempts more frequent.',
    ldelay: 'How many seconds to wait after each round before the page is refreshed. A value that is too small loads Wilma heavily and may get you blocked.',
    lmax: 'The loop stops by itself after this time.' });
  Object.assign(H.sv, {
    loop: 'Uppdaterar sidan och försöker välja kurserna om och om igen tills alla kurser i listan är valda (eller du trycker Avbryt). Grupper utan plats försöks igen varje runda. Redan valda lämnas ifred. Körs i flera flikar om du anger fler än 1.',
    ltabs: 'Hur många Wilma-flikar som öppnas och körs samtidigt (1–10). Tillägget öppnar dem själv; utan det kan webbläsaren blockera dem. Fler flikar skapar inte mer plats men gör försöken tätare.',
    ldelay: 'Hur många sekunder man väntar efter varje runda innan sidan uppdateras. Ett för litet värde belastar Wilma hårt och kan leda till spärr.',
    lmax: 'Slingan stoppar sig själv efter denna tid.' });
  Object.assign(D.fi, { lsOn: 'Silmukka käynnissä', lsFetch: n => `kevyt, ${n} virtuaalivälilehteä`, lsReload: 'sivun päivitys', lsRound: 'kierros', lsLeft: 'aikaa jäljellä', lsOff: 'Silmukka pysäytetty', conCopy: 'Kopioi',
    why: { done: 'kaikki valittu', stop: 'pysäytetty', cancel: 'peruttu', rate: 'Wilma rajoitti pyyntöjä (429)', login: 'kirjautuminen vanhentui', nothing: 'lista on tyhjä', none: 'kursseja ei löytynyt', key: 'lomaketunnusta ei löytynyt' }, con: 'Konsoli: pyynnöt Wilmalle', conClear: 'Tyhjennä', conPause: 'Tauko', conResume: 'Jatka', conPost: 'vain valintapyynnöt (POST)', conEmpty: 'Ei vielä pyyntöjä. Ne näkyvät tässä heti, kun skripti hakee tai lähettää jotain Wilmalle (myös muista välilehdistä).', dev: 'Kehittäjäasetukset (epävakaat)', devWarn: '⚠ VAROITUS: Alle 0,3 sekunnin päivitysväli kuormittaa Wilmaa kovasti. Wilma voi rajoittaa pyyntöjäsi tai estää IP-osoitteesi (jolloin myös muut samassa verkossa voivat jäädä ulos), ja tunnuksesi voidaan lukita. Käytät tätä täysin omalla vastuullasi. Silmukka pysähtyy itse, jos Wilma vastaa 429.',
    devUnlock: 'Ymmärrän riskin: avaa 5–200 ms:n arvot', devDelay: 'Odotus yhtä virtuaalivälilehteä kohti (s)', devMode: 'Silmukan tapa', devReload: 'Päivitä sivu joka kierroksella (perinteinen)', devFetch: 'Kevyt: ei sivun päivityksiä, virtuaalivälilehdet vuorotellen',
    devWorkers: 'Virtuaalivälilehtiä (1–6)', devLite: 'Kevyt käyttöliittymä (ei animaatioita, harvempi piirto)', devNow: 'Nopeus nyt',
    legend: 'Värien selitykset', legBar: 'Palkit: vihreä = suoritettu, sininen = valittu (osuus pakollisista tai 150 op:sta).',
    legRows: [['done', 'Suoritettu'], ['sel', 'Valittu, ei vielä suoritettu'], ['', 'Ei suoritettu eikä valittu'], ['todo', 'Uusien kurssien tilassa: pakollinen, ei vielä valittu'], ['todo inl', 'Keltainen täytettynä: lisätty valintalistaan'], ['blue', 'Uusien kurssien tilassa: suoritettu tai valittu'], ['kvm', 'Violetti reuna: pakollinen kurssi (LOPS)'], ['kvv', 'Pinkki reuna: valinnainen kurssi'], ['man', 'Pisteviivareunus: merkitty suoritetuksi käsin'], ['ign', 'Musta ja yliviivattu: ohitettu, ei lasketa'], ['hp', 'Tähti: kurssi on HOPSissa']],
    progReq: (a, b, p) => `Pakolliset kurssit suoritettu tai valittu: ${a} / ${b} (${p} %)` });
  Object.assign(D.en, { lsOn: 'Loop running', lsFetch: n => `light, ${n} virtual tabs`, lsReload: 'page refresh', lsRound: 'round', lsLeft: 'time left', lsOff: 'Loop stopped', conCopy: 'Copy',
    why: { done: 'everything selected', stop: 'stopped', cancel: 'cancelled', rate: 'Wilma rate-limited (429)', login: 'login expired', nothing: 'list is empty', none: 'no courses found', key: 'form key not found' }, con: 'Console: requests to Wilma', conClear: 'Clear', conPause: 'Pause', conResume: 'Resume', conPost: 'only pick requests (POST)', conEmpty: 'No requests yet. They show up here as soon as the script fetches or sends anything to Wilma (also from other tabs).', dev: 'Developer options (unstable)', devWarn: '⚠ WARNING: A refresh interval below 0.3 seconds puts heavy load on Wilma. Wilma may rate-limit you or block your IP address (which can also lock out others on the same network), and your account can be locked. You use this entirely at your own risk. The loop stops by itself if Wilma answers 429.',
    devUnlock: 'I understand the risk: unlock 5–200 ms values', devDelay: 'Wait per virtual tab (s)', devMode: 'Loop style', devReload: 'Refresh the page every round (classic)', devFetch: 'Light: no page refreshes, virtual tabs take turns',
    devWorkers: 'Virtual tabs (1–6)', devLite: 'Light interface (no animations, fewer redraws)', devNow: 'Speed now',
    legend: 'Colour guide', legBar: 'Bars: green = completed, blue = selected (share of compulsory courses or of 150 op).',
    legRows: [['done', 'Completed'], ['sel', 'Selected, not completed yet'], ['', 'Not completed and not selected'], ['todo', 'New-courses mode: compulsory, not selected yet'], ['todo inl', 'Filled yellow: added to the pick list'], ['blue', 'New-courses mode: completed or selected'], ['kvm', 'Purple edge: compulsory course (LOPS)'], ['kvv', 'Pink edge: elective course'], ['man', 'Dotted outline: marked completed by hand'], ['ign', 'Black and struck through: ignored, not counted'], ['hp', 'Star: the course is in HOPS']],
    progReq: (a, b, p) => `Compulsory courses completed or selected: ${a} / ${b} (${p}%)` });
  Object.assign(D.sv, { lsOn: 'Slingan körs', lsFetch: n => `lätt, ${n} virtuella flikar`, lsReload: 'sidomladdning', lsRound: 'runda', lsLeft: 'tid kvar', lsOff: 'Slingan stoppad', conCopy: 'Kopiera',
    why: { done: 'allt valt', stop: 'stoppad', cancel: 'avbruten', rate: 'Wilma begränsade (429)', login: 'inloggningen gick ut', nothing: 'listan är tom', none: 'inga kurser hittades', key: 'formulärnyckel saknas' }, con: 'Konsol: förfrågningar till Wilma', conClear: 'Rensa', conPause: 'Paus', conResume: 'Fortsätt', conPost: 'bara valförfrågningar (POST)', conEmpty: 'Inga förfrågningar än. De visas här så fort skriptet hämtar eller skickar något till Wilma (även från andra flikar).', dev: 'Utvecklaralternativ (instabila)', devWarn: '⚠ VARNING: Ett uppdateringsintervall under 0,3 sekunder belastar Wilma hårt. Wilma kan begränsa dig eller blockera din IP-adress (vilket kan stänga ute andra i samma nätverk), och ditt konto kan låsas. Du använder detta helt på egen risk. Slingan stoppar sig själv om Wilma svarar 429.',
    devUnlock: 'Jag förstår risken: lås upp 5–200 ms', devDelay: 'Väntan per virtuell flik (s)', devMode: 'Slingans sätt', devReload: 'Uppdatera sidan varje runda (klassiskt)', devFetch: 'Lätt: inga sidomladdningar, virtuella flikar turas om',
    devWorkers: 'Virtuella flikar (1–6)', devLite: 'Lätt gränssnitt (inga animationer, färre omritningar)', devNow: 'Hastighet nu',
    legend: 'Färgförklaring', legBar: 'Staplar: grön = avklarad, blå = vald (andel av obligatoriska eller av 150 sp).',
    legRows: [['done', 'Avklarad'], ['sel', 'Vald, inte avklarad än'], ['', 'Inte avklarad och inte vald'], ['todo', 'Nya kurser-läge: obligatorisk, inte vald än'], ['todo inl', 'Fylld gul: tillagd i vallistan'], ['blue', 'Nya kurser-läge: avklarad eller vald'], ['kvm', 'Lila kant: obligatorisk kurs (LOPS)'], ['kvv', 'Rosa kant: valfri kurs'], ['man', 'Prickad kant: markerad avklarad för hand'], ['ign', 'Svart och överstruken: ignorerad, räknas inte'], ['hp', 'Stjärna: kursen finns i HOPS']],
    progReq: (a, b, p) => `Obligatoriska kurser avklarade eller valda: ${a} / ${b} (${p} %)` });
  Object.assign(T.fi, { login: '\u26D4 Kirjautuminen Wilmaan on vanhentunut. Kirjaudu uudelleen ja käynnistä silmukka.', rzTip: 'Vedä kulmasta muuttaaksesi kokoa, kaksoisklikkaa palauttaaksesi', loopRetry: 'Tietoja ei saatu haettua, yritetään uudelleen\u2026', helpTip: 'Näytä tai piilota ohjeet (?)', prog: (s, n, p) => `Valittu ${s} / ${n} kurssia (${p} %)`, progNone: 'Ei kurssilistaa', fetchTurn: (w, N, r, p, n, s, b) => `Virtuaalivälilehti ${w}/${N} (vuoro ${r}): ${p}/${n} kurssia vielä valitsematta, ${s} pyyntöä${b ? ', ' + b + ' virhettä' : ''}.`,
    rate: '⛔ Wilma rajoitti pyyntöjä (429). Silmukka pysäytettiin suojaksi. Odota hetki ja kasvata odotusaikaa.', lite: 'Kevyt tila', liteTip: 'Kevyt tila päälle/pois: ei animaatioita, harvempi piirto' });
  Object.assign(T.en, { login: '\u26D4 Your Wilma login has expired. Sign in again and restart the loop.', rzTip: 'Drag the corner to resize, double-click to reset', loopRetry: 'Could not fetch the data, trying again\u2026', helpTip: 'Show or hide the help (?) buttons', prog: (s, n, p) => `Selected ${s} / ${n} courses (${p}%)`, progNone: 'No course list', fetchTurn: (w, N, r, p, n, s, b) => `Virtual tab ${w}/${N} (turn ${r}): ${p}/${n} courses still not selected, ${s} requests${b ? ', ' + b + ' failed' : ''}.`,
    rate: '⛔ Wilma is limiting requests (429). The loop was stopped as a precaution. Wait a moment and increase the delay.', lite: 'Light mode', liteTip: 'Light mode on/off: no animations, fewer redraws' });
  Object.assign(T.sv, { login: '\u26D4 Din Wilma-inloggning har gått ut. Logga in igen och starta slingan på nytt.', rzTip: 'Dra i hörnet för att ändra storlek, dubbelklicka för att återställa', loopRetry: 'Kunde inte hämta data, försöker igen\u2026', helpTip: 'Visa eller dölj hjälpen (?)', prog: (s, n, p) => `Valda ${s} / ${n} kurser (${p} %)`, progNone: 'Ingen kurslista', fetchTurn: (w, N, r, p, n, s, b) => `Virtuell flik ${w}/${N} (tur ${r}): ${p}/${n} kurser ännu inte valda, ${s} förfrågningar${b ? ', ' + b + ' fel' : ''}.`,
    rate: '⛔ Wilma begränsar förfrågningar (429). Slingan stoppades som skydd. Vänta en stund och öka väntetiden.', lite: 'Lätt läge', liteTip: 'Lätt läge på/av: inga animationer, färre omritningar' });
  Object.assign(H.fi, { con: 'Näyttää jokaisen pyynnön, jonka skripti lähettää Wilmalle: kellonaika, kuka lähetti (\u25CF = tämä välilehti, \u25CB = toinen), GET = tietojen haku, POST = kurssin valintapyyntö, tilakoodi ja kesto. Vihreä = valintapyyntö, punainen = virhe (esim. HTTP 4xx/5xx tai Wilman srvError). Näet myös muiden välilehtien pyynnöt, kun tämä sivu on auki.', lite: 'Kevyt tila: poistaa animaatiot ja varjot ja piirtää näkymän harvemmin. Auta, jos selain tai tietokone laahaa. Täysin pois päältä laajennuksen saa kuvakkeen valikosta (Pois päältä).',
    devunlock: 'Ilman tätä rastia odotusaika on vähintään 0,3 s. Rastilla alarajaksi tulee 0,005 s (5 ms). Se voi johtaa estoon Wilmassa.', devdelay: 'Odotus yhtä virtuaalivälilehteä kohti. Kun virtuaalivälilehtiä on N, uusi yritys lähtee noin joka (odotus / N) sekunti.',
    devmode: 'Perinteinen päivittää koko Wilma-sivun joka kierroksella (raskas). Kevyt hakee vain tarvittavat tiedot ja lähettää valinnat ilman sivun uudelleenlatausta, joten se kuluttaa selaimessa paljon vähemmän.',
    devworkers: 'Virtuaalivälilehti = yksi vuorollaan toimiva "työläinen" samassa välilehdessä. Oikeaa headless-välilehteä selainlaajennus ei voi avata, tämä on lähin ja kevein vastine.', devlite: 'Sama kuin otsikon ⚡-nappi.',
    legend: 'Selitys kaikille dashboardin väreille ja merkeille.' });
  Object.assign(H.en, { con: 'Shows every request the script sends to Wilma: time, who sent it (\u25CF = this tab, \u25CB = another tab), GET = fetching data, POST = a course pick request, status code and duration. Green = pick request, red = error (e.g. HTTP 4xx/5xx or a Wilma srvError). Requests from other tabs show up here too while this page is open.', lite: 'Light mode: removes animations and shadows and redraws less often. Helps if the browser or computer is lagging. To switch the extension off completely use the toolbar icon menu (Off).',
    devunlock: 'Without this tick the wait is at least 0.3 s. With it the minimum becomes 0.005 s (5 ms). It can get you blocked by Wilma.', devdelay: 'Wait per virtual tab. With N virtual tabs a new attempt goes out about every (wait / N) seconds.',
    devmode: 'Classic reloads the whole Wilma page every round (heavy). Light fetches only what is needed and sends the picks without reloading the page, so it uses far less of the browser.',
    devworkers: 'A virtual tab is one "worker" taking its turn inside the same tab. A browser extension cannot open a real headless tab; this is the closest and lightest equivalent.', devlite: 'Same as the ⚡ button in the header.',
    legend: 'Explains every colour and mark on the dashboard.' });
  Object.assign(H.sv, { con: 'Visar varje förfrågan skriptet skickar till Wilma: tid, vem som skickade (\u25CF = denna flik, \u25CB = annan flik), GET = hämtning, POST = valförfrågan, statuskod och tid. Grön = valförfrågan, röd = fel (t.ex. HTTP 4xx/5xx eller Wilmas srvError). Förfrågningar från andra flikar visas också medan sidan är öppen.', lite: 'Lätt läge: tar bort animationer och skuggor och ritar om mer sällan. Hjälper om webbläsaren eller datorn laggar. För att stänga av tillägget helt, använd ikonens meny (Av).',
    devunlock: 'Utan denna ruta är väntan minst 0,3 s. Med den blir minimum 0,005 s (5 ms). Det kan ge spärr hos Wilma.', devdelay: 'Väntan per virtuell flik. Med N virtuella flikar går ett nytt försök ut ungefär varje (väntan / N) sekund.',
    devmode: 'Klassiskt laddar om hela Wilma-sidan varje runda (tungt). Lätt hämtar bara det som behövs och skickar valen utan omladdning, så det belastar webbläsaren mycket mindre.',
    devworkers: 'En virtuell flik är en "arbetare" som turas om i samma flik. Ett webbläsartillägg kan inte öppna en riktig headless-flik; detta är det närmaste och lättaste alternativet.', devlite: 'Samma som ⚡-knappen i huvudet.',
    legend: 'Förklarar alla färger och märken på dashboarden.' });
  Object.assign(D.fi, { aTitle: 'Automaattinen ryhmien kokoaja', aHelp: 'Valitse oma lukiosi ja kurssit, jotka haluat suorittaa. Skripti hakee kaikki ryhmät, välttää päällekkäiset palkit (sama aika) ja kokoaa parhaan järjestyksen. Voit ottaa kursseja myös muista lukioista: ne valitaan ensin (käsin tai lukittuna), loput kootaan automaattisesti.',
    aHome: 'Oma lukio ja lukuvuosi', aOthers: 'Muut lukiot, joista saa ottaa kursseja', aWant: 'Kurssit oman lukion tarjottimelta (koodi tai alku)', aFill: 'Lisää keltaiset + valintalista', aOther: 'Kurssit muista lukioista (valitaan ensin)',
    aMax: 'Enintään kursseja / jakso (0 = ei rajaa)', aLock: 'Pidä muiden lukioiden jo valitut ryhmät lukittuina (manuaalinen valinta ensin)', aBuild: 'Kokoa paras järjestys', aApply: 'Käytä valinnassa',
    aNoHome: 'Valitse oma lukio ja lukuvuosi.', aNoCourses: 'Lisää ainakin yksi kurssi.', aScanning: 'Haetaan ryhmiä…', aDone: (p, t) => `Valmis: ${p}/${t} kurssia sijoitettu. Tarkista tulos ja paina "Käytä valinnassa".`,
    aNoGroup: 'ei avointa ryhmää valituissa lukioissa (tai jo suoritettu)', aConflict: 'jokainen ryhmä on päällekkäin muiden valintojen kanssa', aColCourse: 'Kurssi', aColGroup: 'Ryhmä', aColPeriod: 'Jakso', aColTeacher: 'Opettaja', aFixed: 'lukittu', aFull: 'täynnä', aByPeriod: 'Kursseja jaksoittain', aApplied: n => `Siirretty valintaan: ${n} kurssia.` });
  Object.assign(D.en, { aTitle: 'Automatic group builder', aHelp: 'Pick your school and the courses you want to take. The script fetches every group, avoids overlapping bars (same time slot) and builds the best arrangement. You can take courses from other schools too: those are chosen first (by hand or locked), the rest is built automatically.',
    aHome: 'Home school and year', aOthers: 'Other schools you may take courses from', aWant: 'Courses from your school’s tray (code or start)', aFill: 'Add yellow + selection list', aOther: 'Courses from other schools (chosen first)',
    aMax: 'Max courses / period (0 = no limit)', aLock: 'Keep already chosen groups of other schools locked (manual choice first)', aBuild: 'Build best arrangement', aApply: 'Use in selection',
    aNoHome: 'Choose your school and year.', aNoCourses: 'Add at least one course.', aScanning: 'Fetching groups…', aDone: (p, t) => `Done: ${p}/${t} courses placed. Check the result and press "Use in selection".`,
    aNoGroup: 'no open group in the chosen schools (or already completed)', aConflict: 'every group overlaps with other choices', aColCourse: 'Course', aColGroup: 'Group', aColPeriod: 'Period', aColTeacher: 'Teacher', aFixed: 'locked', aFull: 'full', aByPeriod: 'Courses per period', aApplied: n => `Moved to selection: ${n} courses.` });
  Object.assign(D.sv, { aTitle: 'Automatisk gruppbyggare', aHelp: 'Välj din skola och de kurser du vill läsa. Skriptet hämtar alla grupper, undviker överlappande block (samma tid) och bygger det bästa upplägget. Du kan ta kurser från andra skolor också: de väljs först (för hand eller låsta), resten byggs automatiskt.',
    aHome: 'Egen skola och läsår', aOthers: 'Andra skolor du får ta kurser från', aWant: 'Kurser från din skolas tablå (kod eller början)', aFill: 'Lägg till gula + vallistan', aOther: 'Kurser från andra skolor (väljs först)',
    aMax: 'Högst kurser / period (0 = ingen gräns)', aLock: 'Håll redan valda grupper från andra skolor låsta (manuellt val först)', aBuild: 'Bygg bästa upplägg', aApply: 'Använd i valet',
    aNoHome: 'Välj din skola och ditt läsår.', aNoCourses: 'Lägg till minst en kurs.', aScanning: 'Hämtar grupper…', aDone: (p, t) => `Klart: ${p}/${t} kurser placerade. Kontrollera och tryck "Använd i valet".`,
    aNoGroup: 'ingen öppen grupp i de valda skolorna (eller redan avklarad)', aConflict: 'varje grupp överlappar med andra val', aColCourse: 'Kurs', aColGroup: 'Grupp', aColPeriod: 'Period', aColTeacher: 'Lärare', aFixed: 'låst', aFull: 'full', aByPeriod: 'Kurser per period', aApplied: n => `Flyttat till valet: ${n} kurser.` });
  Object.assign(H.fi, { ahome: 'Lukio ja lukuvuosi, jossa opiskelet. Sen jaksot haetaan ja kurssit kootaan sen tarjottimelta.', aothers: 'Valitse lukiot, joiden tarjottimelta voit ottaa yksittäisiä kursseja. Niiden jaksot haetaan mukaan.', awant: 'Kurssit, jotka haluat suorittaa oman lukiosi tarjottimelta. Koodi (MAA05) tai alku (MAA). Tyhjänä käytetään valintalistaa.',
    aother: 'Kurssit, jotka haluat ottaa muista lukioista. Ne sijoitetaan ensin, ja loput kootaan niiden ympärille. Voit valita ryhmän käsin Valinta-näkymässä ja lukita sen.', amax: 'Kuinka monta kurssia saa sijoittaa samaan jaksoon. 0 = ei rajaa. Pienempi arvo tasaa kuormaa.',
    abuild: 'Hakee kaikki ryhmät ja kokoaa järjestyksen: yksi ryhmä per kurssi, ei kahta ryhmää samassa palkissa (sama aika), vältetään täynnä olevia ryhmiä ja tasataan kuorma jaksojen kesken. Wilma tarkistaa päällekkäisyydet itse, tämä perustuu ryhmien palkkitunnisteisiin.', aapply: 'Siirtää kootun järjestyksen valintaan: kurssilista ja ryhmävalinnat. Sen jälkeen voit painaa Valitse tai Yritä kunnes.', cfgsave: 'Tallentaa kaikki asetukset (lista, jaksot, pakolliset kurssit, merkinnät, kieli, silmukan asetukset jne.) yhteen tiedostoon.', cfgload: 'Lataa aiemmin tallennetun asetustiedoston ja palauttaa kaikki asetukset.' });
  Object.assign(H.en, { ahome: 'The school and year you study in. Its periods are fetched and the courses are built from its tray.', aothers: 'Choose schools whose tray you may take single courses from. Their periods are included.', awant: 'Courses you want from your own school’s tray. Code (MAA05) or start (MAA). If empty the selection list is used.',
    aother: 'Courses you want from other schools. They are placed first and the rest is built around them. You can pick the group by hand in the Selection view and lock it.', amax: 'How many courses may be placed in the same period. 0 = no limit. A lower value evens out the load.',
    abuild: 'Fetches every group and builds the arrangement: one group per course, never two groups in the same bar (same time), avoiding full groups and balancing the load across periods. Wilma checks overlaps itself; this is based on the groups’ bar ids.', aapply: 'Moves the arrangement into the selection: the course list and group choices. Then you can press Pick or Retry until.', cfgsave: 'Saves all settings (list, periods, compulsory courses, marks, language, loop settings etc.) into one file.', cfgload: 'Loads a previously saved settings file and restores every setting.' });
  Object.assign(H.sv, { ahome: 'Skolan och läsåret du studerar i. Dess perioder hämtas och kurserna byggs från dess tablå.', aothers: 'Välj skolor du får ta enstaka kurser från. Deras perioder tas med.', awant: 'Kurser du vill ta från din egen skolas tablå. Kod (MAA05) eller början (MAA). Tomt = vallistan används.',
    aother: 'Kurser du vill ta från andra skolor. De placeras först och resten byggs runt dem. Du kan välja grupp för hand i Val-vyn och låsa den.', amax: 'Hur många kurser som får placeras i samma period. 0 = ingen gräns. Ett lägre värde jämnar ut belastningen.',
    abuild: 'Hämtar alla grupper och bygger upplägget: en grupp per kurs, aldrig två grupper i samma block (samma tid), undviker fulla grupper och jämnar ut belastningen mellan perioder. Wilma kontrollerar överlapp själv; detta bygger på gruppernas block-id.', aapply: 'Flyttar upplägget till valet: kurslistan och gruppvalen. Sedan kan du trycka Välj eller Försök tills.', cfgsave: 'Sparar alla inställningar (lista, perioder, obligatoriska kurser, markeringar, språk, slingans inställningar osv.) i en fil.', cfgload: 'Laddar en tidigare sparad inställningsfil och återställer alla inställningar.' });
  Object.assign(T.fi, { cfgsave: 'Kaikki asetukset', cfgload: 'Lataa asetukset', cfgSaved: 'Kaikki asetukset tallennettu tiedostoon.', cfgLoaded: 'Asetukset ladattu.' });
  Object.assign(T.en, { cfgsave: 'All settings', cfgload: 'Load settings', cfgSaved: 'All settings saved to a file.', cfgLoaded: 'Settings loaded.' });
  Object.assign(T.sv, { cfgsave: 'Alla inställningar', cfgload: 'Ladda inställningar', cfgSaved: 'Alla inställningar sparade i en fil.', cfgLoaded: 'Inställningar laddade.' });
  Object.assign(D.fi, { devHybrid: 'Hybridi: 2 lisävälilehteä, kussakin 3 virtuaalivalitsijaa, päivitys kierroksen jälkeen', lsHybrid: 'hybridi (3 + 3 + 3 valitsijaa, päivitys kierroksen jälkeen)', hybridRefresh: 'Hybridi: kierros valmis, päivitetään tämä välilehti.' });
  Object.assign(D.en, { devHybrid: 'Hybrid: 2 extra tabs, each with 3 virtual handlers, refresh after each round', lsHybrid: 'hybrid (3 + 3 + 3 handlers, refresh after each round)', hybridRefresh: 'Hybrid: round done, refreshing this tab.' });
  Object.assign(D.sv, { devHybrid: 'Hybrid: 2 extra flikar, var och en med 3 virtuella hanterare, uppdatering efter varje runda', lsHybrid: 'hybrid (3 + 3 + 3 hanterare, uppdatering efter varje runda)', hybridRefresh: 'Hybrid: runda klar, uppdaterar denna flik.' });
  Object.assign(H.fi, { devmode: H.fi.devmode + ' Hybridi: tämä ja 2 lisävälilehteä tekevät kukin 3 virtuaalipyyntöä kierroksessa, sen jälkeen välilehti päivittää itsensä ja sykli toistuu. Ainoa tila, jossa lisävälilehdet avataan kevyessä tilassa. Kojelautatabi jatkaa kierroksia mutta ei koskaan päivity.' });
  Object.assign(H.en, { devmode: H.en.devmode + ' Hybrid: this tab and 2 extra tabs each make 3 virtual requests per round, then the tab refreshes itself and the cycle repeats. The only light mode that opens extra tabs. The dashboard tab keeps going but never refreshes.' });
  Object.assign(H.sv, { devmode: H.sv.devmode + ' Hybrid: denna flik och 2 extra flikar gör var och en 3 virtuella förfrågningar per runda, sedan uppdaterar fliken sig själv och cykeln upprepas. Instrumentpanelens flik fortsätter men uppdateras aldrig.' });
  Object.assign(D.fi, { devGap: 'Väli käsittelijöiden välillä (ms, 0 = automaattinen)' });
  Object.assign(H.fi, { devgap: 'Suora aikaväli pyyntöjen välille. 0 = lasketaan viiveestä. Esim. 6000 tarkoittaa 6 sekuntia, 300 = 0,3 s. Alle 5 ms ei ole mahdollista.' });
  Object.assign(D.en, { devGap: 'Gap between handlers (ms, 0 = automatic)' });
  Object.assign(H.en, { devgap: 'Direct time gap between requests. 0 = computed from the delay. E.g. 6000 is 6 seconds, 300 is 0.3 s. Below 5 ms is not possible.' });
  Object.assign(D.sv, { devGap: 'Avstånd mellan hanterare (ms, 0 = automatiskt)' });
  Object.assign(H.sv, { devgap: 'Direkt tidsavstånd mellan förfrågningar. 0 = beräknas från väntetiden. T.ex. 6000 är 6 sekunder, 300 är 0,3 s. Under 5 ms går inte.' });
  Object.assign(T.fi, { lwin: 'Lisävälilehdet erilliseen ikkunaan (tämä sivu ei päivity)' });
  Object.assign(T.en, { lwin: 'Loop tabs in their own window (this page does not refresh)' });
  Object.assign(T.sv, { lwin: 'Loop-flikar i eget fönster (denna sida uppdateras inte)' });
  Object.assign(H.fi, { lwin: 'Päällä: kaikki silmukan välilehdet (hybridissä kolme) avautuvat omaan ikkunaansa ja kierrokset ajetaan siellä. Tämä sivu, jolla konsoli on, vain käynnistää ja seuraa silmukkaa eikä koskaan päivity. Pois: vanha tapa, jossa tämä sivu on yksi kierroksen välilehdistä.' });
  Object.assign(H.en, { lwin: 'On: all loop tabs (three in hybrid) open in their own window and the rounds run there. This page, with the console, only starts and watches the loop and never refreshes. Off: the old way, where this page is one of the round tabs.' });
  Object.assign(H.sv, { lwin: 'På: alla loop-flikar (tre i hybrid) öppnas i ett eget fönster och rundorna körs där. Denna sida med konsolen startar och följer bara loopen och uppdateras aldrig. Av: det gamla sättet, där denna sida är en av rundflikarna.' });
  Object.assign(T.fi, { authKeep: 'Pidä istunto auki (tarkistus 4 min välein)' });
  Object.assign(T.en, { authKeep: 'Keep the session alive (check every 4 min)' });
  Object.assign(T.sv, { authKeep: 'Håll sessionen igång (kontroll var 4:e min)' });
  Object.assign(T.fi, { authTitle: 'Tunnukset ja automaattinen kirjautuminen', authWarn: 'Tunnus ja salasana tallennetaan vain tähän selaimeen. Ne lähetetään vain Wilman omaan kirjautumislomakkeeseen. Ne eivät ole mukana asetustiedostossa. Vältä liian tiheitä yrityksiä.', authUser: 'Käyttäjätunnus', authPass: 'Salasana', authAuto: 'Kirjaudu automaattisesti uudelleen, kun istunto päättyy', authRemember: 'Muista tässä selaimessa (muuten vain tämä välilehti)', authClear: 'Poista tunnukset', authStatus: 'Tila',
    authWhere: (none, rem) => none ? 'ei tallennettu' : rem ? 'muistissa tässä selaimessa' : 'vain tässä välilehdessä', authAutoOn: on => on ? 'automaattinen kirjautuminen päällä' : 'automaattinen kirjautuminen pois' });
  Object.assign(T.en, { authTitle: 'Login and automatic sign-in', authWarn: 'The user name and password are kept only in this browser. They are sent only to Wilma\'s own sign-in form and are not part of the settings file. Avoid trying too often.', authUser: 'User name', authPass: 'Password', authAuto: 'Sign in again automatically when the session ends', authRemember: 'Remember in this browser (otherwise this tab only)', authClear: 'Clear credentials', authStatus: 'Status',
    authWhere: (none, rem) => none ? 'not saved' : rem ? 'remembered in this browser' : 'this tab only', authAutoOn: on => on ? 'automatic sign-in on' : 'automatic sign-in off' });
  Object.assign(T.sv, { authTitle: 'Inloggning och automatisk inloggning', authWarn: 'Användarnamn och lösenord sparas bara i den här webbläsaren. De skickas bara till Wilmas egna inloggningsformulär och ingår inte i inställningsfilen. Undvik för täta försök.', authUser: 'Användarnamn', authPass: 'Lösenord', authAuto: 'Logga in igen automatiskt när sessionen går ut', authRemember: 'Kom ihåg i den här webbläsaren (annars bara denna flik)', authClear: 'Ta bort uppgifter', authStatus: 'Status',
    authWhere: (none, rem) => none ? 'inte sparad' : rem ? 'sparad i den här webbläsaren' : 'bara i denna flik', authAutoOn: on => on ? 'automatisk inloggning på' : 'automatisk inloggning av' });
  Object.assign(H.fi, { authkeep: 'Wilma lopettaa passiivisen istunnon noin 20 minuutin jälkeen. Tämä lukee valintasivun 4 minuutin välein, jotta istunto pysyy auki. Jos istunto silti päättyy ja automaattinen kirjautuminen on päällä, kirjaudutaan uudelleen.' });
  Object.assign(H.en, { authkeep: 'Wilma ends an idle session after about 20 minutes. This reads the selection page every 4 minutes so the session stays open. If it still ends and automatic sign-in is on, it signs in again.' });
  Object.assign(H.sv, { authkeep: 'Wilma avslutar en inaktiv session efter cirka 20 minuter. Detta läser valsidan var 4:e minut så att sessionen hålls öppen. Om den ändå går ut och automatisk inloggning är på loggas man in igen.' });
  Object.assign(H.fi, { auth: 'Tunnus ja salasana tallennetaan vain tähän selaimeen. Oletuksena vain tähän välilehteen. Kun tämä on päällä ja Wilma vaatii uuden kirjautumisen, laajennus täyttää Wilman oman kirjautumislomakkeen ja lähettää sen. Kaksi epäonnistunutta yritystä peräkkäin pysäyttää automaattisen kirjautumisen 15 minuutiksi, ettei tili lukittuisi.', authauto: 'Päällä: silmukka ei pysähdy istunnon vanhetessa, vaan kirjautuu uudelleen. Pois: silmukka pysähtyy ja kertoo syyn.', authremember: 'Päällä: salasana säilyy selaimen muistissa myös uuden välilehden ja käynnistyksen jälkeen. Tallennettu salasana on luettavissa selaimen tallennuksesta, joten jaa tietokone vain luotettavien kanssa.' });
  Object.assign(H.en, { auth: 'The user name and password are kept only in this browser. By default only in this tab. When this is on and Wilma asks for a new sign-in, the extension fills Wilma\'s own sign-in form and sends it. Two failed attempts in a row stop the automatic sign-in for 15 minutes, so the account is not locked.', authauto: 'On: the loop does not stop when the session ends, it signs in again. Off: the loop stops and says why.', authremember: 'On: the password stays in the browser storage, also for new tabs and after a restart. A remembered password is readable from the browser storage, so only keep it on a computer you trust.' });
  Object.assign(H.sv, { auth: 'Användarnamn och lösenord sparas bara i den här webbläsaren. Som standard bara i denna flik. När detta är på och Wilma begär ny inloggning fyller tillägget i Wilmas egna inloggningsformulär och skickar det. Två misslyckade försök i rad stoppar automatisk inloggning i 15 minuter, så kontot inte låses.', authauto: 'På: slingan stannar inte när sessionen går ut, utan loggar in igen. Av: slingan stoppar och säger varför.', authremember: 'På: lösenordet finns kvar i webbläsarens lagring, även för nya flikar och efter omstart. Ett sparat lösenord går att läsa i webbläsarens lagring, så behåll det bara på en dator du litar på.' });
  const tipOf = k => (H[state.lang] || H.en)[k] || '';

  // ---------- pure helpers ----------
  const norm = s => String(s).normalize('NFC').trim().toLowerCase();

  // Split on whitespace, commas, semicolons and bullets. Codes such as ENA_7.2K or MAY01.1 stay intact.
  function parseCodes(text) {
    const seen = new Set(), out = [];
    for (let tok of String(text).split(/[\s,;|•]+/)) {
      tok = tok.replace(/^[("'\[]+|[)"'\].:]+$/g, ''); // strip wrapping punctuation, trailing "." or ":"
      if (!tok) continue;
      const k = norm(tok);
      if (!seen.has(k)) { seen.add(k); out.push(tok); }
    }
    return out;
  }

  // An exact code wins; then all groups of that course ("MAY01" -> MAY01.1, MAY01.2); then any code starting with the text.
  function matchCourse(token, index) {
    const t = norm(token), exact = [], course = [], prefix = [];
    for (const c of index) {
      const k = norm(c.code);
      if (k === t) exact.push(c);
      else if (!t.includes('.') && k.split('.')[0] === t) course.push(c);
      else if (k.startsWith(t)) prefix.push(c);
    }
    return exact.length ? exact : course.length ? course : prefix;
  }

  function parseTime(text, now = new Date()) {
    const m = /^\s*(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?\s*$/.exec(text || '');
    if (!m) return null;
    const [h, mi, s] = [+m[1], +m[2], +(m[3] || 0)];
    if (h > 23 || mi > 59 || s > 59) return null;
    const d = new Date(now); d.setHours(h, mi, s, 0);
    return d;
  }

  // ---------- talking to Wilma ----------
  const basePath = () => (/^\/![^/]+/.exec(location.pathname) || [''])[0];
  const url = p => location.origin + basePath() + '/' + p.replace(/^\//, '');
  const parseHtml = html => new DOMParser().parseFromString(html, 'text/html');

  // every request the script sends is logged (and shown in the dashboard's console, also from other tabs)
  let loginLost = false;
  const netBuf = []; let netTotal = 0, netPosts = 0, netBad = 0, netPaused = false, netOnlyPost = false, netTimer = 0, netBc = null;
  const tabId = () => { try { let id = sessionStorage.getItem('wilmaKurssit.tab'); if (!id) { id = Math.random().toString(36).slice(2); sessionStorage.setItem('wilmaKurssit.tab', id); } return id; } catch (_) { return 'x'; } };
  const shortUrl = u => String(u).replace(location.origin, '').replace(/\/![^/]+/, '');
  function netLog(m, u, status, t0, note) {
    const x = { t: Date.now(), id: tabId(), m, u: shortUrl(u), s: status, ms: Math.round(performance.now() - t0), n: note || '' };
    x.bad = status === 0 || status >= 400 || /^\u26A0/.test(x.n);
    pushNet(x, false);
    try { if (netBc) netBc.postMessage(x); } catch (_) { /* ignore */ }
  }
  // events: what the script decides (rounds, refreshes, stops, limits), shown in the same console as the requests
  function evLog(kind, text) {
    const x = { t: Date.now(), id: tabId(), m: 'EV', k: kind, u: shortUrl(location.href), s: '', ms: 0, n: text, bad: kind === 'LIMIT' || kind === 'LOGIN' };
    pushNet(x, false);
    try { if (netBc) netBc.postMessage(x); } catch (_) { /* ignore */ }
  }
  function refresh(why) { evLog('REFRESH', why); location.reload(); }
  function pushNet(x, remote) {
    if (netPaused || (remote && view !== 'dash')) return;
    netBuf.push(x); if (netBuf.length > 400) netBuf.splice(0, 150);
    if (x.m !== 'EV') netTotal++; if (x.m === 'POST') netPosts++; if (x.bad) netBad++;
    schedNet();
  }
  function schedNet() { if (netTimer || view !== 'dash') return; netTimer = setTimeout(() => { netTimer = 0; drawNet(); }, state.lite ? 1000 : 250); }
  function drawNet() {
    const pre = $('.ncon'); if (!pre) return;
    const d = D[state.lang] || D.en, me = tabId(), p2 = n => String(n).padStart(2, '0');
    const fmt = x => { const t = new Date(x.t); if (x.m === 'EV') return `${p2(t.getHours())}:${p2(t.getMinutes())}:${p2(t.getSeconds())}.${String(t.getMilliseconds()).padStart(3, '0')}  ${x.id === me ? '\u25CF' : '\u25CB'}${x.id.slice(0, 3)}  ${x.k.padEnd(8)}  ${x.n}`; return `${p2(t.getHours())}:${p2(t.getMinutes())}:${p2(t.getSeconds())}.${String(t.getMilliseconds()).padStart(3, '0')}  ${x.id === me ? '\u25CF' : '\u25CB'}${x.id.slice(0, 3)}  ${x.m.padEnd(4)}  ${x.s || 'ERR'}  ${String(x.ms).padStart(4)} ms  ${x.u}${x.n ? '  ' + x.n : ''}`; };
    const lines = netBuf.filter(x => !netOnlyPost || x.m === 'POST').slice(-150);
    const stick = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 12;
    pre.innerHTML = lines.map(x => `<div class="nl ${x.m === 'POST' ? 'np' : x.m === 'EV' ? 'ne' : 'ng'}${x.bad ? ' nb' : ''}">${esc(fmt(x))}</div>`).join('') || `<span class="dnote">${d.conEmpty}</span>`;
    if (stick) pre.scrollTop = pre.scrollHeight;
    const now = Date.now(); let n5 = 0; for (let i = netBuf.length - 1; i >= 0 && now - netBuf[i].t < 5000; i--) n5++;
    const c = $('.ncnt'); if (c) c.textContent = `${netTotal} \u00B7 POST ${netPosts} \u00B7 \u2717 ${netBad} \u00B7 ${(n5 / 5).toFixed(1)}/s`;
  }
  try { if (typeof BroadcastChannel !== 'undefined') { netBc = new BroadcastChannel('wilmaKurssit.net'); netBc.onmessage = e => { if (e.data && e.data.m) pushNet(e.data, true); }; } } catch (_) { /* ignore */ }

  // ---------- sign-in: your own user name and password, typed into Wilma's own login form when the session ends ----------
  // The password is kept only in this browser: for this tab only (default) or, if "remember" is ticked, in the browser's storage.
  // It is never part of the settings file and never sent anywhere except Wilma's login form.
  const CK = 'wilmaKurssit.cred', CS = 'wilmaKurssit.credS', AUTHK = 'wilmaKurssit.auth';
  function credGet() {
    let c = null;
    try { c = JSON.parse(sessionStorage.getItem(CS) || 'null'); } catch (_) { c = null; }
    if (!c) { try { c = JSON.parse(localStorage.getItem(CK) || 'null'); } catch (_) { c = null; } }
    return c && c.u && c.p ? c : null;
  }
  function saveCreds() {
    const u = ($('.cuser') || {}).value || '', p = ($('.cpass') || {}).value || '';
    try {
      sessionStorage.removeItem(CS); localStorage.removeItem(CK);
      if (u || p) (state.cremember ? localStorage : sessionStorage).setItem(state.cremember ? CK : CS, JSON.stringify({ u, p }));
    } catch (_) { /* ignore */ }
    loadCredsUI();
  }
  function loadCredsUI() {
    const c = credGet(), st = $('.cstat'); if (!st) return;
    const where = !c ? 'ei tallennettu' : (state.cremember ? 'muistissa tässä selaimessa' : 'vain tässä välilehdessä');
    const auto = state.cauto ? 'automaattinen kirjautuminen päällä' : 'automaattinen kirjautuminen pois';
    st.textContent = (tr().authWhere ? tr().authWhere(!c, !!state.cremember) : where) + ' · ' + (tr().authAutoOn ? tr().authAutoOn(!!state.cauto) : auto);
    const u = $('.cuser'), p = $('.cpass');
    if (u && c && root.activeElement !== u) u.value = c.u;
    if (p && c && root.activeElement !== p) p.value = c.p;
  }
  // Wilma ends an idle session after about 20 minutes. Every 4 minutes one tab (shared through localStorage) reads the selection page,
  // which keeps the session alive. If the session has already ended, the sign-in above takes over.
  const KA = 'wilmaKurssit.ka', KA_EVERY = 240000;
  async function keepAliveTick() {
    if (state.cka === false || state.off) return;
    const m = /^\/![^/]+/.exec(location.pathname) || [''];
    let last = 0; try { last = +localStorage.getItem(KA) || 0; } catch (_) { /* ignore */ }
    if (Date.now() - last < KA_EVERY) return;
    try { localStorage.setItem(KA, String(Date.now())); } catch (_) { /* ignore */ }
    try { await getDoc(location.origin + m[0] + '/selection/view'); evLog('LOGIN', 'istunto virkistetty'); }
    catch (_) { evLog('LOGIN', 'istunto on päättynyt, kirjautuminen tarvitaan'); }
  }
  // at most one automatic attempt every two minutes; after two failures in a row, wait 15 minutes (never lock the account)
  const authRec = () => { try { return JSON.parse(localStorage.getItem(AUTHK) || '{}') || {}; } catch (_) { return {}; } };
  const authWrite = o => { try { localStorage.setItem(AUTHK, JSON.stringify(o)); } catch (_) { /* ignore */ } };
  function authAllowed() {
    const a = authRec(), now = Date.now();
    if (now - (a.t || 0) < 120000) return false;
    if ((a.f || 0) >= 2 && now - (a.t || 0) < 900000) return false;
    return true;
  }
  function pickUserField(form) {
    const texts = [...form.querySelectorAll('input')].filter(i => /^(text|email|)$/i.test(i.getAttribute('type') || ''));
    return texts.find(i => /user|login|tunnus|kayttaja|uid|id/i.test(i.name || '')) || texts[0] || null;
  }
  // Wilma answered with its sign-in form: fill that form with the stored user name and password, and send it
  async function autoLogin(html, base) {
    const c = credGet(); if (!state.cauto || !c || !authAllowed()) return false;
    const pw = parseHtml(html).querySelector('input[type=password]'), form = pw && pw.form; if (!form) return false;
    const body = new URLSearchParams(); let userSet = false;
    const uf = pickUserField(form), uname = uf ? uf.name : '';
    form.querySelectorAll('input[name]').forEach(i => {
      const type = (i.getAttribute('type') || 'text').toLowerCase();
      if (type === 'password') body.set(i.name, c.p);
      else if (type === 'hidden' || (type === 'checkbox' && i.checked)) body.set(i.name, i.value);
      else if (!userSet && i.name === uname) { body.set(i.name, c.u); userSet = true; }
    });
    if (!userSet || !body.has(pw.name)) return false;
    const act = new URL(form.getAttribute('action') || base, base).href, method = (form.getAttribute('method') || 'post').toUpperCase();
    const a0 = authRec(); authWrite({ f: a0.f || 0, t: Date.now() }); // the attempt is recorded before it is sent
    evLog('LOGIN', 'automaattinen kirjautuminen: lähetetään Wilman kirjautumislomake');
    const t0 = performance.now(); let r, txt = '';
    try { r = await fetch(act, { method, body, credentials: 'same-origin' }); txt = await r.text(); } catch (_) { evLog('LOGIN', 'kirjautuminen: verkkovirhe'); return false; }
    const ok = r.ok && !/type=["']password["']/i.test(txt); // Wilma shows the sign-in form again when the login failed
    netLog(method, act, r.status, t0, ok ? 'kirjautuminen onnistui' : 'kirjautuminen ei onnistunut'); // the body is never logged
    if (ok) { authWrite({ f: 0, t: Date.now() }); loginLost = false; evLog('LOGIN', 'kirjautuminen onnistui, jatketaan'); return true; }
    const f = (a0.f || 0) + 1; authWrite({ f, t: Date.now() });
    evLog('LOGIN', 'kirjautuminen ei onnistunut' + (f >= 2 ? ' (kaksi kertaa peräkkäin: automaattinen yritys pysäytetty 15 minuutiksi, ettei tili lukittuisi)' : ''));
    return false;
  }
  // the page itself is the sign-in form (e.g. after the session ended): fill it and send it
  function autoLoginPage() {
    const c = credGet(); if (!state.cauto || !c || !authAllowed()) return;
    const pw = document.querySelector('input[type=password]'), form = pw && pw.form; if (!form) return;
    const uf = pickUserField(form); if (uf) uf.value = c.u; pw.value = c.p;
    authWrite({ f: authRec().f || 0, t: Date.now() });
    evLog('LOGIN', 'sivun kirjautumislomake täytetty automaattisesti');
    form.requestSubmit ? form.requestSubmit() : form.submit();
  }

  async function getDoc(u, retried) {
    const t0 = performance.now(); let r;
    try { r = await fetch(u, { credentials: 'same-origin' }); } catch (e) { netLog('GET', u, 0, t0, String(e && e.message || e)); throw e; }
    netLog('GET', u, r.status, t0, '');
    try { if (/\/login\b/i.test(new URL(r.url || u, location.href).pathname) && !/\/login\b/i.test(new URL(u, location.href).pathname)) { loginLost = true; throw new Error('LOGIN ' + u); } } catch (e) { if (loginLost) throw e; }
    if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + u);
    const html = await r.text();
    if (/type=["']password["']/i.test(html)) {
      if (!retried && await autoLogin(html, u)) return getDoc(u, true); // signed in again: read the page once more
      loginLost = true; throw new Error('LOGIN ' + u);
    } // Wilma served its sign-in form instead of the page
    return { doc: parseHtml(html), url: r.url || u };
  }

  // Period labels look like "1. periodi a Tapiolan lukio": the words every label of a year ends with, minus the
  // period designator ("a", "1.", "periodi"), are the school name.
  const DESIGNATOR = /^(\d+\.?|[a-z]|periodi|jakso|period)$/i;
  const isPeriodHref = h => /^(?=.*\d)[A-Za-z0-9_-]+$/.test(h || ''); // bare ids like 19221C2A_32086; menu links have no digits
  function schoolOf(labels) {
    if (labels.length < 2) return '';
    const w = labels.map(l => l.split(' ')), min = Math.min(...w.map(x => x.length));
    let n = 0;
    while (n < min && w.every(x => x[x.length - 1 - n] === w[0][w[0].length - 1 - n])) n++;
    const words = w[0].slice(w[0].length - n);
    while (words.length && DESIGNATOR.test(words[0])) words.shift();
    return words.join(' ');
  }

  // A year is an <h4> heading followed by a <ul> of period links. Every such pair on the page counts, so other schools'
  // years show up too (not only #own-schools). They are paired in document order: a real Wilma had 13 headings but 12 lists.
  async function loadYears() {
    const { doc, url: viewUrl } = await getDoc(url('selection/view'));
    const all = []; let cur = null, taken = true;
    doc.body.querySelectorAll('h4, ul').forEach(el => {
      if (el.tagName === 'H4') { cur = { title: el.textContent.replace(/\s+/g, ' ').trim(), periods: [], section: (el.closest('[id]') || {}).id || '' }; all.push(cur); taken = false; return; }
      if (!cur || taken) return;
      const links = [...el.querySelectorAll('a[href]')].filter(a => isPeriodHref(a.getAttribute('href')));
      if (!links.length) return;
      taken = true; // only the first period list after a heading belongs to it
      links.forEach(a => {
        const note = (a.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
        cur.periods.push({ label: a.textContent.replace(/\s+/g, ' ').trim(), href: a.getAttribute('href'), note, closed: /päättynyt/i.test(note) });
      });
    });
    const list = all.filter(y => y.periods.length);
    list.forEach(y => { y.school = schoolOf(y.periods.map(p => p.label)); });
    // a year with a single period cannot reveal its school, so it borrows one that other years ended with
    const known = [...new Set(list.map(y => y.school).filter(Boolean))].sort((a, b) => b.length - a.length);
    list.forEach(y => { if (!y.school) y.school = known.find(s => y.periods.every(p => p.label.endsWith(' ' + s))) || ''; });
    list.forEach(y => y.periods.forEach(p => {
      p.short = y.school && p.label.endsWith(' ' + y.school) ? (p.label.slice(0, -(y.school.length + 1)).trim() || p.label) : p.label;
    }));
    return { years: list, viewUrl };
  }

  const isCourseCode = s => !!s && s.length <= 40 && !/\s/.test(s) && /\d/.test(s);

  // What the tray markup says about one course group (seen on a real Wilma, Oct 2026):
  //   class "disa" = not selectable (title says "Ryhmä on jo täynnä." when full), "ksuor-on" = already completed,
  //   "k<id>-on" / "k<id>-off" = a state flag whose <id> is shared by several groups.
  function describe(a, code, target, p) {
    const cls = ' ' + (a.getAttribute('class') || '') + ' ';
    const title = (a.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
    const key = /\sk(?!suor)(\S+)-(on|off)\s/.exec(cls);
    const who = /Opettaja:\s*(.*?)(?:\s+(?:Ryhmä on|Tämä kurssi)|$)/.exec(title);
    return {
      code, target, period: p.short || p.label, closed: !!p.closed, title, school: p.school || '', year: p.year || '', ph: p.href,
      teacher: who ? who[1].replace(/^[A-ZÅÄÖ]{2,4}\s+/, '').trim() : '',
      full: /täynnä/i.test(title), off: /\sdisa\s/.test(cls),
      done: /\sksuor-on\s/.test(cls) || /suoritettu/i.test(title),
      selected: !!key && key[2] === 'on', block: key ? key[1] : '',
    };
  }

  // Collect the course links (text = code, href = target) from every period page of the year.
  async function scanPeriods(periods, viewUrl, onProgress) {
    const errors = []; let done = 0;
    const perPeriod = await Promise.all(periods.map(async p => {
      const list = [];
      try {
        const { doc } = await getDoc(new URL(p.href, viewUrl).href);
        const seen = new Set();
        doc.querySelectorAll('a[href]').forEach(a => {
          const code = a.textContent.trim(), href = a.getAttribute('href');
          if (isCourseCode(code) && !seen.has(href)) { seen.add(href); list.push(describe(a, code, href, p)); }
        });
      } catch (e) { errors.push(String(e.message || e)); }
      onProgress && onProgress(++done, periods.length);
      return list;
    }));
    const index = perPeriod.flat(); // period order, so results do not depend on which request finished first
    if (errors.length) index.errors = errors;
    return index;
  }

  async function getFormkey(fresh) {
    const here = fresh ? null : document.querySelector('input[name=formkey]');
    if (here && here.value) return here.value;
    for (const p of ['', 'selection/view']) {
      try {
        const { doc } = await getDoc(url(p));
        const el = doc.querySelector('input[name=formkey]');
        if (el && el.value) return el.value;
      } catch (_) { /* try next */ }
    }
    return null;
  }

  async function pickGroup(target, formkey) {
    const t0 = performance.now(), pu = url('selection/postback'); let r;
    try {
      r = await fetch(pu, {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams({ message: 'pick-group', target, formkey }).toString(),
      });
    } catch (e) { netLog('POST', pu + ' ' + target, 0, t0, String(e && e.message || e)); throw e; }
    const text = await r.text();
    // Wilma answers HTTP 200 even when it refuses: the body then holds srvError("title", "message")
    const e = /srvError\(\s*(["'])(.*?)\1\s*(?:,\s*(["'])(.*?)\3)?/.exec(text);
    netLog('POST', pu + ' ' + target, r.status, t0, e ? '\u26A0 ' + e[2] : r.ok ? 'OK' : '');
    return { ok: r.ok && !e, status: r.status, text: e ? '\u26A0 ' + e[2] + (e[4] ? ' \u2013 ' + e[4] : '') : text.replace(/\s+/g, ' ').trim().slice(0, 140) };
  }

  // Run async jobs with a concurrency limit; returns results in input order.
  async function pool(items, limit, fn) {
    const res = new Array(items.length); let next = 0;
    await Promise.all(Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
      while (next < items.length) { const i = next++; res[i] = await fn(items[i], i); }
    }));
    return res;
  }

  // ---------- panel (Shadow DOM) ----------
  const host = document.createElement('div');
  host.id = ID;
  host.style.cssText = 'position:fixed;z-index:2147483646;right:16px;bottom:72px;';
  if (state.x != null && state.y != null) Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
  const root = host.attachShadow({ mode: 'open' });
  const CSS = `
    .wrap { --bg:#fff; --bg2:#f4f5f7; --fg:#1b1d21; --mut:#697079; --line:#e3e6ea; --pri:#1b6e3c; --prifg:#fff; --warn:#b26a00; --bad:#b3261e;
            font: 13px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: var(--fg); }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --bg:#1e2024; --bg2:#2a2d33; --fg:#eceef1; --mut:#9aa1ab; --line:#3a3e45; --pri:#3fae6c; --prifg:#08130c; --warn:#e0a040; --bad:#ff8a80; } }
    .wrap.dark { --bg:#1e2024; --bg2:#2a2d33; --fg:#eceef1; --mut:#9aa1ab; --line:#3a3e45; --pri:#3fae6c; --prifg:#08130c; --warn:#e0a040; --bad:#ff8a80; }
    [hidden] { display: none !important; }
    button, select, input, textarea { font: inherit; color: inherit; }
    button { cursor: pointer; }
    button:disabled { opacity: .45; cursor: default; }
    .fab { width: 46px; height: 46px; border-radius: 50%; border: 0; background: var(--pri); color: var(--prifg); font-size: 20px; box-shadow: 0 4px 14px rgba(0,0,0,.35); touch-action: none; }
    .panel { width: 344px; max-height: calc(100vh - 96px); display: flex; flex-direction: column; background: var(--bg); border: 1px solid var(--line);
             border-radius: 16px; box-shadow: 0 12px 40px rgba(0,0,0,.28); overflow: hidden; }
    .head { display: flex; justify-content: space-between; align-items: center; padding: 10px 10px 10px 16px; cursor: move; user-select: none; touch-action: none; border-bottom: 1px solid var(--line); }
    .head strong { font-size: 14px; }
    .head button { background: none; border: 0; color: var(--mut); font-size: 13px; padding: 2px 7px; border-radius: 6px; }
    .head button:hover { background: var(--bg2); }
    .body { padding: 12px 16px 14px; display: grid; gap: 12px; overflow: auto; }
    label.field { display: grid; gap: 4px; }
    .field > span, .lbl { color: var(--mut); font-size: 11px; font-weight: 600; letter-spacing: .02em; text-transform: uppercase; }
    select, input:not([type]), input[type=number], textarea { border: 1px solid var(--line); border-radius: 10px; padding: 7px 9px; background: var(--bg2); box-sizing: border-box; width: 100%; }
    select:focus, input:focus, textarea:focus { outline: 2px solid var(--pri); outline-offset: -1px; }
    textarea { height: 64px; resize: vertical; font-family: ui-monospace, Consolas, monospace; }
    .card { display: grid; gap: 8px; }
    .row { display: flex; gap: 8px; }
    .row > button { flex: 1; padding: 8px 10px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); }
    .row > button.main { background: var(--pri); border-color: var(--pri); color: var(--prifg); font-weight: 600; }
    .row > button.icon { flex: 0 0 38px; padding: 0; }
    .periods { display: flex; flex-wrap: wrap; gap: 6px; }
    .periods .lbl { flex: 1 0 calc(100% - 30px); }
    .chk { display: inline-flex; align-items: center; gap: 6px; padding: 3px 10px; border: 1px solid var(--line); border-radius: 999px; background: var(--bg2); font-size: 12px; cursor: pointer; }
    .chk input { width: auto; margin: 0; accent-color: var(--pri); }
    .chk i { color: var(--warn); font-style: normal; }
    .timebar { display: flex; gap: 10px; align-items: end; }
    .timebar .grow { flex: 1; }
    .timebar .chk { height: 32px; box-sizing: border-box; }
    table { border-collapse: collapse; width: 100%; font-size: 12px; }
    td, th { padding: 5px 4px; border-bottom: 1px solid var(--line); text-align: left; vertical-align: middle; }
    th { color: var(--mut); font-size: 11px; text-transform: uppercase; font-weight: 600; }
    td select { padding: 3px 6px; border-radius: 8px; }
    .cell { display: flex; gap: 6px; align-items: center; }
    .cell > select:first-child { flex: 1; min-width: 0; }
    .cell select.pf { width: auto; max-width: 44%; }
    .ok { color: var(--pri); font-weight: 600; } .bad { color: var(--bad); font-weight: 600; } .warn { color: var(--warn); font-weight: 600; }
    .log { min-height: 2.6em; max-height: 110px; overflow: auto; padding: 8px 10px; border-radius: 10px; background: var(--bg2); font-size: 12px; white-space: pre-wrap; word-break: break-word; }
    .hint { color: var(--mut); font-size: 11px; }
    details summary { cursor: pointer; color: var(--mut); font-size: 12px; padding: 2px 0; }
    .more { display: grid; gap: 10px; padding-top: 8px; }
    .wrap { --b-find:#1d5fbf; --b-findbg:#e6effb; --b-cancel:#b3261e; --b-cancelbg:#fbe9e7; --b-save:#0b7a75; --b-savebg:#e2f4f3; --b-load:#6a3fb5; --b-loadbg:#efe9fa; }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --b-find:#8ab4f8; --b-findbg:#1f2c42; --b-cancel:#ff8a80; --b-cancelbg:#40201e; --b-save:#5fd3cc; --b-savebg:#18332f; --b-load:#c3a5f5; --b-loadbg:#2c2340; } }
    .wrap.dark { --b-find:#8ab4f8; --b-findbg:#1f2c42; --b-cancel:#ff8a80; --b-cancelbg:#40201e; --b-save:#5fd3cc; --b-savebg:#18332f; --b-load:#c3a5f5; --b-loadbg:#2c2340; }
    .row > button, .bq > button:first-child { font-weight: 600; }
    .bq > button.b-find:first-child { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .bq > button.b-loop:first-child { background: var(--warn); color: #fff; border-color: var(--warn); }
    .bq > button.b-loop.on:first-child { background: var(--bad); border-color: var(--bad); }
    .bq > button.b-cancel:first-child { background: var(--b-cancelbg); color: var(--b-cancel); border-color: var(--b-cancel); }
    .bq > button.b-save:first-child { background: var(--b-savebg); color: var(--b-save); border-color: var(--b-save); }
    .bq > button.b-load:first-child { background: var(--b-loadbg); color: var(--b-load); border-color: var(--b-load); }
    .bq > button.b-clear:first-child { background: transparent; color: var(--b-cancel); border: 1px dashed var(--b-cancel); }
    .bq > button.b-debug:first-child { background: transparent; color: var(--mut); border: 1px dashed var(--mut); font-weight: 500; }
    .bq { flex: 1; display: flex; gap: 4px; min-width: 0; }
    .bq > button:first-child { flex: 1; padding: 8px 10px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); min-width: 0; }
    .bq > button.b-pick:first-child { background: var(--pri); border-color: var(--pri); color: var(--prifg); }
    button.q { flex: 0 0 20px; width: 20px; height: 20px; align-self: center; padding: 0; border-radius: 50%; border: 1px solid var(--mut); background: transparent; color: var(--mut); font-size: 11px; font-weight: 700; line-height: 1; }
    button.q:hover, button.q.on { background: var(--pri); border-color: var(--pri); color: var(--prifg); }
    .tip { padding: 8px 10px; border-radius: 10px; background: var(--bg2); border-left: 3px solid var(--pri); font-size: 12px; color: var(--fg); }
    .qrow { display: flex; gap: 8px; align-items: center; justify-content: space-between; }
    .qrow .field { flex: 1; }
    .head .q { margin-left: 4px; }
    .head > span { display: inline-flex; align-items: center; }
    .o0{order:0}.o1{order:1}.o2{order:2}.o3{order:3}.o4{order:4}.o5{order:5}.o6{order:6}
    .col1, .col2 { display: contents; }
    .full .panel { position: fixed; inset: 0; width: auto; max-height: none; border-radius: 0; border: 0; box-shadow: none; }
    .full .head { cursor: default; padding: 14px 24px; } .full .head strong { font-size: 17px; }
    .full .body { grid-template-columns: minmax(340px, 440px) minmax(0, 1fr); align-items: start; gap: 24px; padding: 24px; font-size: 14px; }
    .full .col1, .full .col2 { display: grid; gap: 14px; }
    .full [data-act=min], .full .fab { display: none; }
    .full .log { max-height: 240px; }
    @media (max-width: 800px) { .full .body { grid-template-columns: 1fr; } .full .col1, .full .col2 { display: contents; } }
    .wrap { --c-man:#5b4bd5; --c-opt:#d6336c; }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --c-man:#a99bff; --c-opt:#ff7aa8; } }
    .wrap.dark { --c-man:#a99bff; --c-opt:#ff7aa8; }
    .kd { display: inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 6px; vertical-align: baseline; }
    .kd.km { background: var(--c-man); } .kd.kv { background: var(--c-opt); }
    .dchip.km { border-left: 5px solid var(--c-man); } .dchip.kv { border-left: 5px solid var(--c-opt); }
    .dchip.hp::after { content: ' ★'; font-size: 10px; opacity: .8; }
    .sw { display: inline-flex; align-items: center; gap: 4px; margin-right: 6px; cursor: pointer; font-size: 13px; user-select: none; }
    .sw input { position: absolute; opacity: 0; width: 0; height: 0; }
    .sw i { width: 34px; height: 18px; border-radius: 99px; background: var(--line); position: relative; transition: background .15s; }
    .sw i::after { content: ''; position: absolute; top: 2px; left: 2px; width: 14px; height: 14px; border-radius: 50%; background: var(--fg); transition: transform .15s; }
    .sw input:checked + i { background: var(--pri); } .sw input:checked + i::after { transform: translateX(16px); background: var(--prifg); }
    .sw input:focus-visible + i { outline: 2px solid var(--pri); outline-offset: 2px; }
    .tabs { display: none; align-items: center; gap: 4px; margin-left: 16px; flex: 1; }
    .full .tabs { display: inline-flex; }
    .head .tab { padding: 5px 14px; border-radius: 8px; font-weight: 600; color: var(--mut); }
    .head .tab.on { background: var(--pri); color: var(--prifg); }
    .full [data-act=dashopen], .full [data-act=dashopen] + .q { display: none; }
    .head > span > button[data-act=dashopen] { color: var(--b-find); }
    .panel { position: relative; }
    .rz { position: absolute; right: 0; bottom: 0; width: 20px; height: 20px; cursor: nwse-resize; touch-action: none; z-index: 3;
          background: linear-gradient(135deg, transparent 0 55%, var(--mut) 55% 62%, transparent 62% 72%, var(--mut) 72% 79%, transparent 79%); border-bottom-right-radius: 16px; opacity: .7; }
    .rz:hover { opacity: 1; }
    .full .rz { display: none; }
    .lstat { padding: 8px 12px; border-radius: 10px; border: 1px solid var(--line); background: var(--bg2); font-size: 12.5px; }
    .lstat.on { border-color: var(--b-loop, var(--warn)); background: color-mix(in srgb, var(--warn) 14%, var(--bg)); }
    .ncon { height: 240px; min-height: 90px; overflow: auto; resize: vertical; margin-top: 6px; padding: 8px 10px; background: #0f1115; color: #d6d9de; border: 1px solid var(--line); border-radius: 10px; font: 11.5px/1.5 ui-monospace, Consolas, monospace; white-space: pre; }
    .ncon .nl.ne { color: var(--warn); }
    .ncon .nl.np { color: #7ee2a0; } .ncon .nl.ng { color: #9aa1ab; } .ncon .nl.nb { color: #ff8a80; }
    .dtools button.act.on { background: var(--warn); color: #fff; }
    .wrap:not(.help) button.q { display: none; }
    .helpbtn.on { background: var(--pri) !important; color: var(--prifg) !important; }
    .pbar { flex: 0 0 auto; display: grid; gap: 3px; padding: 7px 16px 9px; border-top: 1px solid var(--line); background: var(--bg); font-size: 12px; }
    .pbar .pt { display: flex; justify-content: space-between; gap: 8px; color: var(--mut); font-weight: 600; }
    .pbar .pb { height: 8px; border-radius: 99px; background: var(--bg2); border: 1px solid var(--line); overflow: hidden; }
    .pbar .pb i { display: block; height: 100%; background: var(--b-find); transition: width .3s; }
    .pbar.full100 .pb i { background: var(--pri); }
    .full .pbar { padding: 9px 24px 12px; }
    .litebtn.on { background: var(--bg2) !important; color: var(--warn) !important; }
    .wrap.lite *, .wrap.lite *::before, .wrap.lite *::after { transition: none !important; animation: none !important; box-shadow: none !important; }
    .dtoolbox.dev .devwarn { margin: 6px 0; padding: 9px 11px; border-radius: 10px; border: 1px solid var(--b-cancel); background: color-mix(in srgb, var(--b-cancel) 12%, var(--bg)); font-size: 12px; }
    .dtoolbox.dev .dtools label.dnote { display: inline-flex; gap: 6px; align-items: center; }
    .dtoolbox.dev select { width: auto; }
    .dtoolbox.dev .dtools input[type=checkbox] { min-width: 0; width: auto; flex: none; margin: 0; }
    .legend .lrows { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 6px 14px; padding-top: 6px; }
    .legend .lrow { display: flex; align-items: center; gap: 8px; font-size: 12px; }
    .legend .dchip { cursor: default; margin: 0; flex: 0 0 auto; min-width: 46px; text-align: center; }
    .dash { display: none; padding: 20px 24px; overflow: auto; gap: 16px; flex: 1; }
    .full.view-dash .dash { display: grid; align-content: start; } .full.view-dash .body { display: none; }
    .dtiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; }
    .tile { padding: 12px 14px; border-radius: 12px; background: var(--bg2); }
    .tile b { display: block; font-size: 26px; line-height: 1.1; } .tile span { color: var(--mut); font-size: 12px; }
    .tile.d b { color: var(--pri); } .tile.s b { color: var(--b-find); } .tile.m b { color: var(--bad); }
    .dtools { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .dtools button.act { padding: 7px 12px; border: 1px solid var(--line); border-radius: 10px; background: var(--bg2); font-weight: 600; }
    .dtools button.scan { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .dtools button.rst { background: transparent; color: var(--b-cancel); border: 1px dashed var(--b-cancel); }
    .dtools input { width: auto; min-width: 150px; flex: 0 1 220px; } .dtools input.nn { width: 60px; min-width: 0; flex: 0 0 60px; }
    .dgrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(330px, 1fr)); gap: 12px; }
    .dcard { border: 1px solid var(--line); border-radius: 12px; padding: 12px; display: grid; gap: 8px; align-content: start; }
    .dcard.off { opacity: .55; }
    .dcard.complete { border-color: var(--pri); }
    .dcard h4 { margin: 0; font-size: 14px; display: flex; gap: 8px; align-items: center; }
    .dcard h4 span { flex: 1; }
    .dcard h4 input { width: 54px; padding: 3px 6px; text-align: center; }
    .dcard h4 .x { background: none; border: 0; color: var(--mut); font-size: 14px; padding: 0 4px; }
    .dcard h4 .x:hover { color: var(--bad); }
    .bar { height: 8px; border-radius: 99px; background: var(--bg2); overflow: hidden; display: flex; }
    .bar i { display: block; height: 100%; } .bar .d { background: var(--pri); } .bar .s { background: var(--b-find); }
    .dnums { font-size: 12px; color: var(--mut); }
    .dchip { display: inline-block; padding: 2px 9px; margin: 2px 4px 2px 0; border-radius: 999px; border: 1px solid var(--line); background: var(--bg2); font-size: 12px; cursor: pointer; color: var(--fg); }
    .dchip.done { background: var(--pri); border-color: var(--pri); color: var(--prifg); }
    .dchip.sel { background: var(--b-findbg); border-color: var(--b-find); color: var(--b-find); }
    .dchip.man { outline: 2px dotted var(--warn); outline-offset: 1px; }
    .dlog { min-height: 2.6em; padding: 8px 10px; border-radius: 10px; background: var(--bg2); font-size: 12px; white-space: pre-wrap; }
    .dchip.ign { background: #1a1a1a; border-color: #000; color: #8a8a8a; text-decoration: line-through; }
    .dd > summary { cursor: pointer; color: var(--mut); font-size: 12px; padding: 2px 0 6px; }
    .ctx { position: fixed; z-index: 10; min-width: 190px; padding: 4px; border-radius: 10px; background: var(--bg); border: 1px solid var(--line); box-shadow: 0 8px 24px rgba(0,0,0,.3); display: grid; }
    .ctx { display: grid; } .ctx .ctxh { padding: 4px 10px; color: var(--mut); font-size: 11px; font-weight: 700; }
    .tile small { font-size: 13px; font-weight: 500; color: var(--mut); }
    .bar.big { height: 12px; }
    .dtop h3 { margin: 0; }
    .dtools .act.pick { background: var(--b-findbg); color: var(--b-find); border-color: var(--b-find); }
    .dtools .act.pick.on { background: var(--warn); color: #fff; border-color: var(--warn); }
    .dtools.yel { padding: 8px 10px; border-radius: 10px; background: color-mix(in srgb, var(--warn) 14%, transparent); }
    .dtools .act.go { background: var(--pri); color: var(--prifg); border-color: var(--pri); }
    .dtoolbox, .dash details > summary { cursor: pointer; color: var(--mut); font-size: 13px; }
    .dtoolbox { display: grid; gap: 8px; }
    .dtoolbox > summary { padding: 4px 0; }
    .dcard { gap: 6px; }
    .dcard > summary { list-style: none; display: flex; gap: 8px; align-items: center; cursor: pointer; color: var(--fg); font-size: 14px; }
    .dcard > summary::-webkit-details-marker { display: none; }
    .dcard > summary::before { content: '▸'; color: var(--mut); }
    .dcard[open] > summary::before { content: '▾'; }
    .dcard .dname { flex: 1; font-weight: 600; }
    .dcard .dnums { color: var(--mut); font-size: 12px; }
    .dcard > summary input { width: 50px; padding: 2px 6px; text-align: center; }
    .dcard > summary .x { background: none; border: 0; color: var(--mut); padding: 0 4px; }
    .dcard > summary .x:hover { color: var(--bad); }
    .dbody { padding-top: 4px; }
    .dsub { font-size: 11px; font-weight: 700; color: var(--mut); text-transform: uppercase; letter-spacing: .02em; margin: 6px 0 2px; }
    .dchip.blue { background: var(--b-findbg); border-color: var(--b-find); color: var(--b-find); cursor: default; }
    .dchip.todo { background: color-mix(in srgb, var(--warn) 22%, var(--bg)); border-color: var(--warn); color: var(--fg); font-weight: 600; }
    .dchip.todo.inl { background: var(--warn); color: #fff; }
    .ctx button { text-align: left; padding: 7px 10px; border: 0; border-radius: 7px; background: none; }
    .ctx button:hover { background: var(--bg2); }
    .ctx b { padding: 4px 10px; color: var(--mut); font-size: 11px; }
    .dnote { color: var(--mut); font-size: 12px; }
    .lnk { background: none; border: 0; color: var(--pri); text-decoration: underline; padding: 0; font-size: 11px; }
    /* ---- modern skin (overrides) ---- */
    .wrap { --bg:#ffffff; --bg2:#f4f5f8; --fg:#12151a; --mut:#667085; --line:#e8eaf0; --pri:#12805a; --prifg:#fff;
            --sh1: 0 1px 2px rgba(16,24,40,.06); --sh2: 0 1px 2px rgba(16,24,40,.06), 0 16px 40px -12px rgba(16,24,40,.30), 0 32px 64px -24px rgba(16,24,40,.22);
            font-family: Inter, "Segoe UI Variable Text", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; letter-spacing: -.003em; -webkit-font-smoothing: antialiased; }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --bg:#15171c; --bg2:#1e2128; --fg:#eef0f4; --mut:#98a1b0; --line:#2b2f38; --pri:#34c38a; --prifg:#04130c; --sh1: 0 1px 2px rgba(0,0,0,.4); --sh2: 0 1px 2px rgba(0,0,0,.4), 0 16px 40px -12px rgba(0,0,0,.7), 0 32px 64px -24px rgba(0,0,0,.6); } }
    .wrap.dark { --bg:#15171c; --bg2:#1e2128; --fg:#eef0f4; --mut:#98a1b0; --line:#2b2f38; --pri:#34c38a; --prifg:#04130c; --sh1: 0 1px 2px rgba(0,0,0,.4); --sh2: 0 1px 2px rgba(0,0,0,.4), 0 16px 40px -12px rgba(0,0,0,.7), 0 32px 64px -24px rgba(0,0,0,.6); }
    .wrap * { scrollbar-width: thin; scrollbar-color: color-mix(in srgb, var(--mut) 45%, transparent) transparent; }
    @keyframes wkIn { from { opacity: 0; transform: translateY(6px) scale(.985); } to { opacity: 1; transform: none; } }
    .panel { width: 360px; border-radius: 20px; box-shadow: var(--sh2); animation: wkIn .18s ease-out; }
    .fab { width: 50px; height: 50px; background: linear-gradient(135deg, color-mix(in srgb, var(--pri) 80%, #fff), var(--pri)); box-shadow: var(--sh2); transition: transform .12s; }
    .fab:hover { transform: scale(1.06); }
    .head { padding: 12px 12px 12px 18px; }
    .head strong { font-size: 14.5px; font-weight: 700; letter-spacing: -.01em; }
    .head > span { gap: 2px; }
    .head button { width: 28px; height: 28px; padding: 0; display: inline-grid; place-items: center; border-radius: 9px; font-size: 14px; transition: background .12s, color .12s; }
    .head button:hover { background: var(--bg2); color: var(--fg); }
    .head [data-act=lang] { width: auto; padding: 0 8px; font-size: 11.5px; font-weight: 700; letter-spacing: .04em; }
    .tabs { background: var(--bg2); padding: 3px; border-radius: 12px; gap: 2px; flex: 0 0 auto; margin-left: 18px; }
    .head .tab { width: auto; height: auto; padding: 6px 16px; border-radius: 9px; font-size: 13px; }
    .head .tab:hover { background: transparent; color: var(--fg); }
    .head .tab.on { background: var(--bg); color: var(--fg); box-shadow: var(--sh1); }
    .full .head > strong { margin-right: 0; } .full .head { gap: 8px; }
    .sw { margin-right: 4px; } .sw i { width: 36px; height: 20px; } .sw i::after { width: 16px; height: 16px; } .sw input:checked + i::after { transform: translateX(16px); }
    .body { padding: 14px 18px 16px; gap: 14px; }
    .field > span, .lbl { text-transform: none; letter-spacing: 0; font-size: 12px; font-weight: 600; }
    select, input:not([type]), input[type=number], textarea { border-radius: 12px; padding: 8px 11px; border: 1px solid transparent; background: var(--bg2); transition: box-shadow .12s, border-color .12s; }
    select:hover, input:hover, textarea:hover { border-color: var(--line); }
    select:focus, input:focus, textarea:focus { outline: none; border-color: var(--pri); box-shadow: 0 0 0 3px color-mix(in srgb, var(--pri) 24%, transparent); }
    .chk { padding: 5px 12px; transition: background .12s, border-color .12s; }
    .chk:hover { border-color: color-mix(in srgb, var(--pri) 45%, var(--line)); }
    .chk:has(input:checked) { background: color-mix(in srgb, var(--pri) 12%, var(--bg)); border-color: color-mix(in srgb, var(--pri) 55%, var(--line)); }
    .bq > button:first-child, .row > button, .dtools button.act { min-height: 36px; border-radius: 12px; box-shadow: var(--sh1); transition: transform .08s, filter .12s, background .12s; }
    .bq > button:first-child:hover:not(:disabled), .row > button:hover:not(:disabled), .dtools button.act:hover:not(:disabled) { filter: brightness(1.05); }
    .bq > button:first-child:active:not(:disabled), .row > button:active:not(:disabled), .dtools button.act:active:not(:disabled) { transform: translateY(1px); }
    .bq > button.b-pick:first-child, .dtools .act.go { background: linear-gradient(180deg, color-mix(in srgb, var(--pri) 88%, #fff), var(--pri)); border-color: color-mix(in srgb, var(--pri) 85%, #000); box-shadow: inset 0 1px 0 rgba(255,255,255,.25), 0 6px 14px -6px color-mix(in srgb, var(--pri) 70%, transparent); }
    .bq > button.b-find:first-child, .dtools button.scan, .dtools .act.pick { border-color: color-mix(in srgb, var(--b-find) 40%, var(--line)); }
    .bq > button.b-save:first-child { border-color: color-mix(in srgb, var(--b-save) 40%, var(--line)); }
    .bq > button.b-load:first-child { border-color: color-mix(in srgb, var(--b-load) 40%, var(--line)); }
    .bq > button.b-cancel:first-child { border-color: color-mix(in srgb, var(--b-cancel) 40%, var(--line)); }
    .bq > button.b-loop:first-child { background: linear-gradient(180deg, color-mix(in srgb, var(--warn) 88%, #fff), var(--warn)); box-shadow: inset 0 1px 0 rgba(255,255,255,.25), 0 6px 14px -6px color-mix(in srgb, var(--warn) 70%, transparent); }
    .bq > button.b-loop.on:first-child { background: linear-gradient(180deg, color-mix(in srgb, var(--bad) 88%, #fff), var(--bad)); }
    .bq > button.b-clear:first-child, .bq > button.b-debug:first-child { box-shadow: none; }
    td, th { padding: 8px 6px; border-bottom-color: color-mix(in srgb, var(--line) 70%, transparent); }
    tr:last-child td { border-bottom: 0; }
    th { text-transform: none; letter-spacing: 0; font-size: 11.5px; }
    td select { background: var(--bg2); }
    .log, .dlog { border-radius: 12px; border: 1px solid var(--line); }
    .tip { border-left: 1px solid color-mix(in srgb, var(--pri) 30%, var(--line)); border: 1px solid color-mix(in srgb, var(--pri) 30%, var(--line)); background: color-mix(in srgb, var(--pri) 7%, var(--bg)); border-radius: 12px; }
    details:not(.dcard) > summary { list-style: none; } details:not(.dcard) > summary::-webkit-details-marker { display: none; }
    .pbar { padding: 10px 18px 12px; gap: 6px; }
    .pbar .pt { color: var(--fg); font-variant-numeric: tabular-nums; }
    .pbar .pb { height: 8px; border: 0; box-shadow: inset 0 0 0 1px var(--line); }
    .pbar .pb i { background: linear-gradient(90deg, var(--b-find), color-mix(in srgb, var(--b-find) 55%, var(--pri))); border-radius: 99px; }
    .pbar.full100 .pb i { background: linear-gradient(90deg, var(--pri), color-mix(in srgb, var(--pri) 60%, #9be7c4)); }
    .dtop h3 { font-size: 21px; font-weight: 700; letter-spacing: -.02em; }
    .tile { position: relative; overflow: hidden; border: 1px solid var(--line); background: var(--bg); border-radius: 16px; padding: 16px 18px 14px; box-shadow: var(--sh1); }
    .tile::before { content: ''; position: absolute; inset: 0 0 auto 0; height: 3px; background: var(--pri); }
    .tile.m::before { background: var(--bad); } .tile.s::before { background: var(--b-find); }
    .tile b { font-size: 30px; font-weight: 700; letter-spacing: -.02em; font-variant-numeric: tabular-nums; }
    .tile span { display: block; margin-top: 4px; }
    .dcard { border-radius: 16px; background: var(--bg); box-shadow: var(--sh1); padding: 14px; transition: border-color .15s, box-shadow .15s; }
    .dcard:hover { border-color: color-mix(in srgb, var(--pri) 35%, var(--line)); }
    .dcard.complete { border-color: color-mix(in srgb, var(--pri) 60%, var(--line)); background: color-mix(in srgb, var(--pri) 5%, var(--bg)); }
    .bar { height: 6px; background: var(--bg2); box-shadow: inset 0 0 0 1px var(--line); } .bar.big { height: 10px; }
    .bar .d { background: linear-gradient(90deg, var(--pri), color-mix(in srgb, var(--pri) 62%, #9be7c4)); }
    .bar .s { background: linear-gradient(90deg, var(--b-find), color-mix(in srgb, var(--b-find) 60%, #fff)); }
    .dchip { padding: 3px 10px; font-weight: 500; transition: transform .08s, box-shadow .12s; }
    .dchip:hover { transform: translateY(-1px); box-shadow: var(--sh1); }
    .lstat, .dtoolbox.dev .devwarn, .tip, .ncon { border-radius: 12px; }
    .full .panel { border-radius: 0; animation: none; }
    .full .body { padding: 28px 32px; gap: 28px; }
    .full .head { padding: 14px 28px; }
    .full .dash { padding: 28px 32px 36px; gap: 18px; }
    table, td, th { color: inherit; }
    .dtools { gap: 10px; }
    .dtools input:not([type=checkbox]) { height: 36px; box-sizing: border-box; padding: 0 12px; }
    .dtools input.nn { flex: 0 0 64px; width: 64px; text-align: center; padding: 0 6px; }
    .dtools input.dmanual, .dtools input.dnname { flex: 1 1 200px; }
    .dtools select { height: 36px; }
    .dtools label.dnote { display: inline-flex; gap: 8px; align-items: center; }
    .ncnt { margin-left: 10px; font-weight: 500; font-variant-numeric: tabular-nums; }
    details:not(.dcard) > summary { display: flex; align-items: center; gap: 8px; }
    details:not(.dcard) > summary::before { content: ''; flex: 0 0 auto; width: 6px; height: 6px; margin: 0 4px 0 2px; border-right: 2px solid currentColor; border-bottom: 2px solid currentColor; transform: rotate(-45deg); transition: transform .15s; }
    details[open]:not(.dcard) > summary::before { transform: rotate(45deg); }
    .dtoolbox { gap: 12px; }
    .dash { grid-template-columns: minmax(0, 1fr); grid-auto-rows: max-content; }
    .dtools textarea { flex: 1 1 320px; min-height: 56px; height: 56px; padding: 8px 12px; }
    .dtools label.grow { flex: 1 1 320px; display: grid; gap: 4px; }
    .ares { margin-top: 4px; } .ares td, .ares th { padding: 6px 8px; }
    .dtools input.dmanual { flex: 1 1 240px; max-width: 460px; }
    .dtools input.dnname, .dtools input.dnpref { flex: 1 1 200px; max-width: 280px; }
    .dlog { min-height: 0; line-height: 1.5; }
    .dtools input[type=checkbox] { min-width: 0; width: auto; flex: none; margin: 0; }
    .sw > span:first-child { display: none; }
    .head strong { white-space: nowrap; margin-right: 6px; }
    .full .dash > * { width: 100%; max-width: 1240px; margin-inline: auto; box-sizing: border-box; }
    .full .pbar { padding: 12px 32px 14px; }
    /* ---- lo-fi calm skin (overrides the modern skin) ---- */
    .wrap { --bg:#f7f2e8; --bg2:#efe7d7; --fg:#3f3a31; --mut:#8c8473; --line:#e4dac7; --pri:#7f9c7b; --prifg:#fbf8f1; --warn:#c4915a; --bad:#b56b55;
            --sh1: 0 1px 0 rgba(90,70,40,.06); --sh2: 0 1px 2px rgba(90,70,40,.08), 0 18px 40px -18px rgba(90,70,40,.28);
            --b-find:#6f8ea3; --b-findbg:#e7edf0; --b-cancel:#b56b55; --b-cancelbg:#f6e8e2; --b-save:#6c9a90; --b-savebg:#e4eee9; --b-load:#8a79a3; --b-loadbg:#ede8f2;
            --c-man:#8a7ab3; --c-opt:#c08585;
            font-family: "Nunito", "Quicksand", "Segoe UI", system-ui, sans-serif; font-weight: 450; line-height: 1.55; letter-spacing: .005em; }
    @media (prefers-color-scheme: dark) { .wrap:not(.light) { --bg:#25221e; --bg2:#2e2a25; --fg:#e7dfcf; --mut:#9d947f; --line:#3b362e; --pri:#8fae8a; --prifg:#1f2a1d; --warn:#d6a46c; --bad:#e09a85;
            --sh1: 0 1px 0 rgba(0,0,0,.25); --sh2: 0 1px 2px rgba(0,0,0,.3), 0 18px 40px -18px rgba(0,0,0,.6);
            --b-find:#9bb6c8; --b-findbg:#2a3238; --b-cancel:#e09a85; --b-cancelbg:#3a2c27; --b-save:#8fc2b6; --b-savebg:#263630; --b-load:#b6a6d1; --b-loadbg:#302a3a; --c-man:#b5a6dc; --c-opt:#dca5a5; } }
    .wrap.dark { --bg:#25221e; --bg2:#2e2a25; --fg:#e7dfcf; --mut:#9d947f; --line:#3b362e; --pri:#8fae8a; --prifg:#1f2a1d; --warn:#d6a46c; --bad:#e09a85;
            --sh1: 0 1px 0 rgba(0,0,0,.25); --sh2: 0 1px 2px rgba(0,0,0,.3), 0 18px 40px -18px rgba(0,0,0,.6);
            --b-find:#9bb6c8; --b-findbg:#2a3238; --b-cancel:#e09a85; --b-cancelbg:#3a2c27; --b-save:#8fc2b6; --b-savebg:#263630; --b-load:#b6a6d1; --b-loadbg:#302a3a; --c-man:#b5a6dc; --c-opt:#dca5a5; }
    .wrap.light { --bg:#f7f2e8; --bg2:#efe7d7; --fg:#3f3a31; --mut:#8c8473; --line:#e4dac7; --pri:#7f9c7b; --prifg:#fbf8f1; --warn:#c4915a; --bad:#b56b55; }
    .panel { border-radius: 22px; background-color: var(--bg); background-image: radial-gradient(rgba(110,90,60,.035) 1px, transparent 1px); background-size: 5px 5px; box-shadow: var(--sh2); animation: wkIn .35s ease-out; }
    .head { border-bottom-color: var(--line); padding: 14px 14px 12px 20px; }
    .head strong, .dtop h3, .full .head strong { font-family: Georgia, "Iowan Old Style", "Palatino Linotype", serif; font-weight: 400; font-size: 17px; letter-spacing: .01em; }
    .dtop h3 { font-size: 24px; }
    .tabs { background: transparent; padding: 0; gap: 4px; }
    .head .tab { background: transparent; color: var(--mut); border-radius: 999px; padding: 5px 14px; }
    .head .tab.on { background: var(--bg2); color: var(--fg); box-shadow: none; border: 1px solid var(--line); }
    .head button:hover { background: var(--bg2); }
    .body { gap: 16px; padding: 16px 20px 18px; }
    .field > span, .lbl { color: var(--mut); font-weight: 600; font-size: 11.5px; }
    select, input:not([type]), input[type=number], textarea { background: var(--bg2); border: 1px solid transparent; border-radius: 14px; font-family: inherit; }
    select:hover, input:hover, textarea:hover { border-color: var(--line); }
    select:focus, input:focus, textarea:focus { border-color: var(--line); box-shadow: 0 0 0 2px color-mix(in srgb, var(--pri) 35%, transparent); }
    textarea { font-family: ui-monospace, Consolas, monospace; font-size: 12.5px; }
    .chk { background: transparent; border-radius: 999px; border-color: var(--line); color: var(--fg); }
    .chk:has(input:checked) { background: color-mix(in srgb, var(--pri) 16%, transparent); border-color: color-mix(in srgb, var(--pri) 50%, var(--line)); }
    .bq > button:first-child, .row > button, .dtools button.act { border-radius: 14px; box-shadow: none; border-color: var(--line); background: var(--bg2); font-weight: 600; transition: background .25s, border-color .25s; }
    .bq > button:first-child:hover:not(:disabled), .row > button:hover:not(:disabled), .dtools button.act:hover:not(:disabled) { filter: none; background: color-mix(in srgb, var(--bg2) 75%, var(--pri) 25%); }
    .bq > button:first-child:active:not(:disabled), .row > button:active:not(:disabled), .dtools button.act:active:not(:disabled) { transform: none; }
    .bq > button.b-pick:first-child, .dtools .act.go { background: var(--pri); border-color: var(--pri); color: var(--prifg); box-shadow: none; }
    .bq > button.b-loop:first-child { background: color-mix(in srgb, var(--warn) 85%, var(--bg)); border-color: transparent; color: var(--prifg); box-shadow: none; }
    .bq > button.b-loop.on:first-child { background: color-mix(in srgb, var(--bad) 85%, var(--bg)); }
    .bq > button.b-find:first-child, .dtools button.scan { background: var(--b-findbg); border-color: transparent; }
    .bq > button.b-cancel:first-child { background: var(--b-cancelbg); border-color: transparent; }
    .bq > button.b-save:first-child { background: var(--b-savebg); border-color: transparent; }
    .bq > button.b-load:first-child { background: var(--b-loadbg); border-color: transparent; }
    .bq > button.b-clear:first-child, .bq > button.b-debug:first-child { background: transparent; border: 1px dashed var(--line); }
    .tip { background: transparent; border: 1px dashed var(--line); border-radius: 14px; font-style: italic; color: var(--mut); }
    .pbar { background: transparent; border-top: 1px solid var(--line); }
    .pbar .pb { border-radius: 99px; background: var(--bg2); box-shadow: none; border: 0; }
    .pbar .pb i { background: color-mix(in srgb, var(--pri) 80%, var(--bg)); }
    .pbar.full100 .pb i { background: var(--pri); }
    .tile { background: var(--bg2); border: 0; border-radius: 20px; box-shadow: none; padding: 18px 20px 16px; }
    .tile::before { height: 2px; opacity: .55; }
    .tile b { font-family: Georgia, serif; font-weight: 400; font-size: 30px; }
    .dcard { background: transparent; border: 1px solid var(--line); border-radius: 20px; box-shadow: none; }
    .dcard:hover { border-color: color-mix(in srgb, var(--pri) 40%, var(--line)); }
    .dcard.complete { background: color-mix(in srgb, var(--pri) 8%, transparent); border-color: color-mix(in srgb, var(--pri) 45%, var(--line)); }
    .dcard > summary .dname { font-family: Georgia, serif; font-weight: 400; font-size: 15px; }
    .bar { background: var(--bg2); box-shadow: none; height: 5px; }
    .bar .d { background: color-mix(in srgb, var(--pri) 85%, var(--bg)); }
    .bar .s { background: color-mix(in srgb, var(--b-find) 80%, var(--bg)); }
    .dchip { border-radius: 999px; font-weight: 500; box-shadow: none; }
    .dchip:hover { transform: none; box-shadow: none; }
    .dchip.done { background: color-mix(in srgb, var(--pri) 80%, var(--bg)); border-color: transparent; }
    .dtools.yel { background: color-mix(in srgb, var(--warn) 12%, transparent); border-radius: 16px; }
    .lstat { background: transparent; border: 1px dashed var(--line); border-radius: 16px; }
    .lstat.on { background: color-mix(in srgb, var(--warn) 10%, transparent); border-color: color-mix(in srgb, var(--warn) 45%, var(--line)); }
    .ncon { background: var(--bg2); color: var(--fg); border: 1px solid var(--line); border-radius: 16px; font-size: 11.5px; }
    .ncon .nl.ne { color: var(--warn); }
    .ncon .nl.np { color: color-mix(in srgb, var(--pri) 70%, var(--fg)); } .ncon .nl.ng { color: var(--mut); } .ncon .nl.nb { color: var(--bad); }
    .full .head { padding: 16px 30px; }
    .full .body { padding: 32px 36px; gap: 30px; }
    .full .dash { padding: 32px 36px 40px; gap: 22px; }
    .full .pbar { padding: 14px 36px 16px; }
    details:not(.dcard) > summary { color: var(--mut); font-family: inherit; }
    .dtop h3, .dash h3 { color: var(--fg); }
    .log, .dlog { background: var(--bg2); border: 0; border-radius: 16px; color: var(--fg); }
    .devwarn { background: color-mix(in srgb, var(--bad) 10%, transparent); border-style: dashed; }
    .dtoolbox.dev .devwarn { border-color: color-mix(in srgb, var(--bad) 60%, var(--line)); }
    .wrap .sw i { background: var(--line); }
    .wrap .sw input:checked + i { background: var(--pri); }
`;
  const sheetCleanup = (() => {
    try { const s = new CSSStyleSheet(); s.replaceSync(CSS); root.adoptedStyleSheets = [s]; return () => {}; }
    catch (_) { const el = document.createElement('style'); el.textContent = CSS; root.appendChild(el); return () => el.remove(); }
  })();
  const shell = document.createElement('div');
  shell.className = 'wrap';
  root.appendChild(shell);
  const $ = s => root.querySelector(s);

  const ACT = { find: 'find', pick: 'pick', cancel: 'cancel', save: 'save', load: 'load', clearall: 'clearall', debug: 'debug' };
  const q = k => `<button type="button" class="q" data-help="${k}" aria-label="?" title="?">?</button>`;
  const bq = (k, label, cls, extra = '') => `<span class="bq"><button data-act="${k}" class="${cls}"${extra}>${label}</button>${q(k)}</span>`;

  function buildUi() {
    const t = tr();
    shell.innerHTML = `
      <button class="fab" title="${t.title}" aria-label="${t.title}">\u{1F4D8}</button>
      <section class="panel">
        <header class="head" data-hb><strong>${t.title}</strong><nav class="tabs"><button data-act="vsel" class="tab">${t.tabSel}</button><button data-act="vdash" class="tab">${t.tabDash}</button></nav><span><label class="sw" data-hb-skip><span>\u2600</span><input type="checkbox" class="thm"><i></i><span>\u{1F319}</span></label><button data-act="dashopen" title="${t.dashOpen}" aria-label="${t.dashOpen}">\u{1F4CA}</button><button data-act="lang">${t.lang}</button><button data-act="help" class="helpbtn" title="${t.helpTip}" aria-label="${t.helpTip}">?</button><button data-act="min" title="${t.min}" aria-label="${t.min}">\u2013</button><button data-act="unload" title="${t.unload}" aria-label="${t.unload}">\u2715</button></span></header>
        <div class="body">
          <div class="col1">
            <div class="card o0">
              <div class="row" data-hb><select class="year" aria-label="${t.year}"></select>${q('year')}<button data-act="reload" class="icon" title="${t.reload}" aria-label="${t.reload}">\u21BB</button>${q('reload')}</div>
              <div class="periods" data-hb></div>
              <div class="sum hint"></div>
            </div>
            <div class="field o1" data-hb><div class="qrow"><span class="lbl">${t.list}</span>${q('list')}</div><textarea class="list" placeholder="${t.ph}" spellcheck="false"></textarea></div>
            <div class="timebar o3" data-hb>
              <label class="field grow"><span>${t.at}</span><input class="at" placeholder="16:00:00"></label>${q('at')}
              <label class="chk" title="${t.refreshHint}"><input type="checkbox" class="rf" data-opt="refresh"> ${t.refresh}</label>${q('refresh')}
            </div>
            <div class="row o4" data-hb>${bq('find', '\u{1F50D} ' + t.find, 'b-find')}${bq('pick', '\u2714 ' + t.pick, 'b-pick')}${bq('cancel', '\u2716 ' + t.cancel, 'b-cancel', ' disabled')}</div>
            <div class="row o4" data-hb>${bq('loop', '\u{1F501} ' + t.loop, 'b-loop')}</div>
            <div class="log o5" aria-live="polite">${t.dry}</div>
          </div>
          <div class="col2">
            <div class="o2"><div class="qrow" data-hb><span class="lbl">${t.course} \u2192 ${t.period}</span>${q('plan')}</div><div class="plan"></div></div>
            <details class="o6"><summary>${t.more}</summary>
              <div class="more">
                <div class="row" data-hb>${bq('save', '\u{1F4BE} ' + t.save, 'b-save')}${bq('load', '\u{1F4C2} ' + t.load, 'b-load')}</div>
                <div class="row" data-hb>${bq('cfgsave', '\u2699 ' + t.cfgsave, 'b-save')}${bq('cfgload', '\u{1F4E5} ' + t.cfgload, 'b-load')}</div>
                <div class="row" data-hb>${bq('clearall', '\u{1F5D1} ' + t.clearAll, 'b-clear')}${bq('debug', '\u{1F41E} ' + t.dbg, 'b-debug')}</div>
                <div class="qrow" data-hb><label class="field"><span>${t.conc}</span><input class="conc" type="number" min="1" max="10"></label>${q('conc')}</div>
                <div class="qrow" data-hb><label class="field"><span>${t.ltabs}</span><input class="ltabs" type="number" min="1" max="10"></label>${q('ltabs')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="lwin" data-opt="lwin"> ${t.lwin}</label>${q('lwin')}</div>
                <div class="qrow" data-hb><label class="field"><span>${t.ldelay}</span><input class="ldelay" type="number" min="0.3" max="60" step="0.1"></label>${q('ldelay')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="lkeep" data-opt="lkeep"> ${t.lkeep}</label>${q('lkeep')}</div>
                <div class="qrow" data-hb><label class="field"><span>${t.lmax}</span><input class="lmax" type="number" min="1" max="240"></label>${q('lmax')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="lite" data-opt="lite"> ${t.lite}</label>${q('lite')}</div>
                <details class="authbox" data-rid="auth"${state.dopen.auth ? ' open' : ''}><summary>\u{1F511} ${t.authTitle}</summary>
                  <div class="hint">${t.authWarn}</div>
                  <div class="qrow" data-hb><label class="field"><span>${t.authUser}</span><input class="cuser" autocomplete="username" spellcheck="false"></label></div>
                  <div class="qrow" data-hb><label class="field"><span>${t.authPass}</span><input class="cpass" type="password" autocomplete="current-password"></label>${q('auth')}</div>
                  <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="cauto" data-opt="cauto"> ${t.authAuto}</label>${q('authauto')}</div>
                  <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="cremember" data-opt="cremember"> ${t.authRemember}</label>${q('authremember')}</div>
                  <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="cka" data-opt="cka"> ${t.authKeep}</label>${q('authkeep')}</div>
                  <div class="row" data-hb><button type="button" class="b-clear" data-act="cclear">${t.authClear}</button></div>
                  <div class="hint">${t.authStatus}: <span class="cstat"></span></div>
                </details>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="wq" data-opt="wq"> ${t.wq}</label>${q('wq')}</div>
                <div class="qrow" data-hb><label class="chk"><input type="checkbox" class="always" data-opt="always"> ${t.always}</label>${q('always')}</div>
                <div class="qrow" data-hb><label class="chk" title="${t.armHint}"><input type="checkbox" class="arm" data-opt="arm"> ${t.arm}</label>${q('arm')}</div>
                <div class="hint">${t.hint}</div>
              </div>
            </details>
          </div>
          <input class="file" type="file" accept=".txt,.json,text/plain,application/json" hidden>
          <input class="cfile" type="file" accept=".json,application/json" hidden>
        </div>
        <div class="dash"></div>
        <footer class="pbar" aria-live="polite"></footer>
        <div class="rz" title="${t.rzTip}" aria-label="${t.rzTip}"></div>
      </section>`;
    $('.list').value = state.list; $('.at').value = state.at; $('.conc').value = state.conc; $('.ltabs').value = state.ltabs; $('.lkeep').checked = !!state.lkeep; paintLoop(); $('.ldelay').value = state.ldelay; $('.lmax').value = state.lmax; $('.arm').checked = !!state.arm; $('.always').checked = !!state.always; $('.wq').checked = !!state.wq; $('.rf').checked = !!state.refresh; $('.cauto').checked = !!state.cauto; $('.cremember').checked = !!state.cremember; $('.cka').checked = state.cka !== false; $('.lwin').checked = state.lwin !== false; loadCredsUI();
    $('.panel').hidden = !state.open; $('.fab').hidden = state.open;
    fillYears(true); renderPlan(); renderDash(); applyLite(); applyTitles(); applyTheme(); shell.classList.toggle('full', full); shell.classList.toggle('view-dash', view === 'dash'); paintTabs();
    makeDraggable($('.fab'), () => { state.open = true; save(); $('.panel').hidden = false; $('.fab').hidden = true; });
    makeDraggable($('.head'));
    applySize();
    const rz = $('.rz');
    rz.addEventListener('pointerdown', e => {
      if (full || e.button !== 0) return;
      e.preventDefault();
      const r = $('.panel').getBoundingClientRect(), hr = host.getBoundingClientRect();
      state.x = Math.round(hr.left); state.y = Math.round(hr.top); // anchor top-left so the panel grows right and down
      Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
      const sx = e.clientX, sy = e.clientY, w0 = r.width, h0 = r.height, x0 = state.x, y0 = state.y;
      rz.setPointerCapture(e.pointerId);
      const mv = ev => {
        state.w = Math.round(Math.max(300, Math.min(innerWidth - 8, w0 + ev.clientX - sx)));
        state.h = Math.round(Math.max(220, Math.min(innerHeight - 8, h0 + ev.clientY - sy)));
        state.x = Math.max(4, Math.min(x0, innerWidth - state.w - 4)); state.y = Math.max(4, Math.min(y0, innerHeight - state.h - 4)); // at the screen edge it grows the other way
        Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px' });
        applySize();
      };
      const up = () => { rz.removeEventListener('pointermove', mv); rz.removeEventListener('pointerup', up); save(); };
      rz.addEventListener('pointermove', mv); rz.addEventListener('pointerup', up);
    });
    rz.addEventListener('dblclick', () => { state.w = 0; state.h = 0; applySize(); save(); });
  }
  function applySize() {
    const p = $('.panel'); if (!p) return;
    if (full || !state.w) { p.style.width = ''; p.style.height = ''; p.style.maxHeight = ''; return; }
    p.style.width = state.w + 'px'; p.style.height = state.h ? state.h + 'px' : ''; p.style.maxHeight = state.h ? 'none' : '';
  }

  // ---------- state ----------
  let years = [], viewUrl = '', plan = [], busy = false, cancelled = false, periodSel = new Set(), savedChoices = new Map(), savedCodes = new Map(), savedFilters = new Map(), restored = false, autoDone = false, full = false, wqTimer = 0, view = 'sel';
  const log = (msg, append) => { const el = $('.log'); el.textContent = append ? el.textContent + '\n' + msg : msg; el.scrollTop = el.scrollHeight; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const setBusy = b => { busy = b; cancelled = false; root.querySelectorAll('[data-act=find],[data-act=pick],[data-act=reload]').forEach(x => { x.disabled = b; }); $('[data-act=cancel]').disabled = !b; };

  // "MAA02@1a" (or the period dropdown of a row) limits a course to periods whose label contains "1a".
  const pnorm = s => norm(s).replace(/periodi|jakso|period|[\s.]/g, '');
  function makeRow(token, index, prev, onlyPrev) {
    const [code, tail] = token.split('@');
    const only = tail ? tail.trim() : onlyPrev;
    const all = matchCourse(code, index);
    const cands = only ? all.filter(c => pnorm(c.period).includes(pnorm(only))) : all;
    const i = cands.findIndex(c => c.target === prev.get(norm(token)));
    return { token, all, only, cands, choice: i >= 0 ? i : best(cands) };
  }

  // Lower rank = better default when a short code matches several groups.
  const rank = c => (c.selected ? -1 : 0) + (c.closed ? 8 : 0) + (c.done ? 4 : 0) + (c.full || c.off ? 2 : 0);
  const best = cands => cands.reduce((b, c, i) => (rank(c) < rank(cands[b]) ? i : b), 0);
  const flagsOf = c => { const t = tr(); return [c.selected && t.fSel, c.done && t.fDone, c.full && t.fFull, !c.full && c.off && t.fOff, c.closed && t.fClosed].filter(Boolean); };

  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const yearKey = y => y.school + '|' + y.title;
  const curYear = () => years[+$('.year').value];

  // Selected periods are kept across years and schools. The first time a year is shown, its open periods are ticked
  // automatically (all of them if none is open, so Find still works); after that your own ticks are left alone.
  const visited = new Set();
  // remember the period ticks and group choices, so they survive a page refresh
  const persist = () => { state.per = [...periodSel]; state.choices = Object.fromEntries(plan.filter(p => p.cands.length).map(p => [p.token, p.cands[p.choice].target]));
    state.filters = Object.fromEntries(plan.filter(p => p.only).map(p => [p.token, p.only])); save(); };
  const disarm = () => { state.arm = false; state.fast = false; state.rt = 0; save(); const a = $('.arm'); if (a) a.checked = false; };
  function autoPeriods() {
    const y = curYear();
    if (y && !visited.has(yearKey(y))) {
      visited.add(yearKey(y));
      const open = y.periods.filter(p => !p.closed);
      (open.length ? open : y.periods).forEach(p => periodSel.add(p.href));
      persist();
    }
    renderPeriods();
  }
  const selectedYears = () => years.filter(z => z.periods.some(p => periodSel.has(p.href)));
  function renderPeriods() {
    const y = curYear(), t = tr();
    const sum = selectedYears().map(z => `${z.school ? z.school + ' ' : ''}${z.title} (${z.periods.filter(p => periodSel.has(p.href)).length})`).join(', ');
    $('.sum').innerHTML = `${t.selSummary}: ${esc(sum || '–')} ${sum ? `<button data-act="clearper" class="lnk">${t.clear}</button>` : ''}`;
    $('.periods').innerHTML = y ? `<span class="lbl">${t.periods}</span>${q('periods')}` + y.periods.map((p, i) =>
      `<label class="chk" title="${esc(p.note)}"><input type="checkbox" data-per="${i}"${periodSel.has(p.href) ? ' checked' : ''}>${esc(p.short)}${p.closed ? ` <i>(${t.fClosed})</i>` : ''}</label>`).join('') : '';
    applyTitles($('.periods'));
  }

  // Years grouped by school. The remembered year wins; otherwise the first year that still has an open period.
  function fillYears(keep) {
    const sel = $('.year'), groups = new Map();
    years.forEach((y, i) => {
      const g = y.school || tr().otherSchool;
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(`<option value="${i}">${esc(y.title)}</option>`);
    });
    sel.innerHTML = [...groups].map(([g, opts]) => `<optgroup label="${esc(g)}">${opts.join('')}</optgroup>`).join('');
    let i = years.findIndex(y => yearKey(y) === state.year);
    if (i < 0) i = years.findIndex(y => y.title === state.year); // older saved format: title only
    if (i < 0) i = years.findIndex(y => y.periods.some(p => !p.closed));
    if (i < 0 && years.length) i = 0;
    if (i >= 0) sel.value = String(i);
    if (keep) renderPeriods(); else autoPeriods();
  }
  async function reloadYears() {
    log(tr().loadingYears);
    try {
      const r = await loadYears();
      years = r.years; viewUrl = r.viewUrl;
      if (!restored) { // first load after a refresh: bring back the saved periods and group choices
        restored = true;
        const known = new Set(years.flatMap(z => z.periods.map(p => p.href))), keep = (state.per || []).filter(h => known.has(h));
        if (keep.length) { periodSel = new Set(keep); years.forEach(z => visited.add(yearKey(z))); savedChoices = new Map(Object.entries(state.choices || {})); savedFilters = new Map(Object.entries(state.filters || {})); }
      }
      fillYears();
      log(years.length ? '' : tr().noYears);
      if (!autoDone) {
        autoDone = true;
        if (state.fast && state.rt && Date.now() - state.rt > 600000) disarm(); // a stale timed refresh is dropped
        if (!state.arm && state.always && state.list.trim() && years.length && /selection/.test(location.pathname)) setTimeout(() => actions.auto(), 0);
        if (/#wk-loop/.test(location.hash) && !loopActive() && !readLoop().why) loopBegin(false);
        if (loopActive() && years.length && /selection/.test(location.pathname)) { setTimeout(loopRun, 0); return; }
        if (state.arm && years.length && (state.fast || /selection/.test(location.pathname))) setTimeout(() => (state.fast && state.rt > Date.now() ? actions.resume() : actions.auto()), 0);
      }
    } catch (e) { log(String(e.message || e)); if (loopActive()) setTimeout(() => { if (loopActive() && !busy) refresh('virhe, yritetään uudelleen'); }, Math.max(2000, (+readLoop().delay || 2) * 1000)); }
  }

  function renderPlan() {
    paintProg();
    const t = tr(), box = $('.plan');
    if (!plan.length) { box.innerHTML = ''; return; }
    const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const kd = p => { const r = rowOf(baseOf(String(p.token).split('@')[0]), state.req); return `<i class="kd k${r ? 'm' : 'v'}" title="${esc((D[state.lang] || D.en)[r ? 'man' : 'opt'])}"></i>`; };
    box.innerHTML = `<table><tr><th>${t.course}</th><th>${t.status}</th></tr>${plan.map((p, i) => {
      if (!p.cands.length) return `<tr><td>${kd(p)}${esc(p.token)}</td><td class="bad">${p.all.length ? t.missingIn : t.missing}</td></tr>`;
      const multiPeriod = new Set(p.cands.map(c => c.period)).size > 1;
      const label = (c, withTeacher) => [c.code, withTeacher && c.teacher, (multiPeriod || !withTeacher) && c.period, flagsOf(c).join(', ')].filter(Boolean).join(' \u00B7 ');
      const periodsAll = [...new Set(p.all.map(c => c.period))];
      const sel = periodsAll.find(x => p.only && pnorm(x).includes(pnorm(p.only))) || '';
      const pf = periodsAll.length > 1 ? `<select class="pf" data-pf="${i}" title="${t.pfTitle}"><option value="">${t.pfAll}</option>${periodsAll.map(x => `<option value="${esc(x)}"${x === sel ? ' selected' : ''}>${esc(x)}</option>`).join('')}</select>` : '';
      if (p.cands.length === 1) return `<tr><td>${kd(p)}${esc(p.token)}</td><td class="${rank(p.cands[0]) > 1 ? 'warn' : 'ok'}" title="${esc(p.cands[0].title)}"><div class="cell"><span>${esc(label(p.cands[0], false))}</span>${pf}</div></td></tr>`;
      return `<tr><td>${kd(p)}${esc(p.token)}</td><td><div class="cell"><select data-row="${i}" title="${t.choose}">${p.cands.map((c, j) =>
        `<option value="${j}" title="${esc(c.title)}"${j === p.choice ? ' selected' : ''}>${esc(label(c, true))}</option>`).join('')}</select>${pf}</div></td></tr>`;
    }).join('')}</table>`;
  }

  // Build the plan: scan every period of the chosen year and match the typed codes.
  async function find(quiet) {
    const t = tr();
    const tokens = parseCodes($('.list').value);
    if (!tokens.length) { plan = []; renderPlan(); log(t.nothing); return false; }
    if (!years.length) await reloadYears();
    const y = curYear();
    if (!y) { log(t.noYears); return false; }
    state.year = yearKey(y); save();
    const multi = selectedYears().length > 1; // periods of several schools/years: say which one each course is in
    const periods = years.flatMap(z => z.periods.filter(p => periodSel.has(p.href)).map(p => ({ ...p, short: multi ? [z.school, z.title, p.short].filter(Boolean).join(' · ') : p.short, school: z.school, year: z.title })));
    if (!periods.length) { log(t.noPeriods); return false; }
    if (!quiet) log(t.scanning(periods.length));
    const index = await scanPeriods(periods, viewUrl, quiet ? null : (a, b) => log(t.scanning(b) + ' ' + a + '/' + b));
    lastScanErrors = index.errors || [];
    // keep the group the user already chose in a dropdown when the list is re-scanned
    const prev = new Map(plan.map(p => [norm(p.token), p.cands[p.choice] && p.cands[p.choice].target]));
    savedChoices.forEach((target, tok) => { if (!prev.has(norm(tok))) prev.set(norm(tok), target); }); // choices loaded from a file
    const prevOnly = new Map(plan.map(p => [norm(p.token), p.only]));
    savedFilters.forEach((v, k) => { if (!prevOnly.has(norm(k))) prevOnly.set(norm(k), v); });
    plan = tokens.map(token => makeRow(token, index, prev, prevOnly.get(norm(token)) || ''));
    if (savedCodes.size) plan.forEach(p => { // group choices from a text file: by group code (and period, when the same code exists in several)
      const g = savedCodes.get(norm(p.token)); if (!g) return;
      let i = p.cands.findIndex(c => norm(c.code) === norm(g.code) && g.period && norm(c.period) === norm(g.period));
      if (i < 0) i = p.cands.findIndex(c => norm(c.code) === norm(g.code));
      if (i >= 0) { p.choice = i; savedCodes.delete(norm(p.token)); }
    });
    if (quiet) { paintProg(); return true; }
    renderPlan(); persist();
    const hit = plan.filter(p => p.cands.length).length;
    log(t.found(hit, plan.length) + (index.errors ? '\n' + index.errors.join('\n') : '') + (index.length ? '' : '\n(0 course links on those pages)'));
    return true;
  }

  async function waitUntil(when, skipLines, label) {
    const t = tr();
    while (Date.now() < when.getTime()) {
      if (cancelled) return false;
      const s = Math.ceil((when.getTime() - Date.now()) / 1000);
      log([...skipLines, (label || t.waiting)(`${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`)].join('\n'));
      await sleep(Math.min(100, Math.max(1, when.getTime() - Date.now())));
    }
    return !cancelled;
  }

  async function pick() {
    const t = tr();
    if (!await find()) return;
    const chosen = [...new Map(plan.filter(p => p.cands.length).map(p => [p.cands[p.choice].target, p.cands[p.choice]])).values()];
    const targets = [], skipLines = [];
    for (const c of chosen) {
      const why = c.closed ? t.skipClosed : c.selected ? t.skipSel : '';
      if (why) skipLines.push(`– ${c.code}  ${why}`); else targets.push(c);
    }
    if (!targets.length) { log([...skipLines, t.nothing].join('\n'), true); return; }
    const key = await getFormkey();
    if (!key) { log(t.noKey, true); return; }
    const when = state.at.trim() ? parseTime(state.at) : null;
    if (state.at.trim() && !when) { log(t.badTime, true); return; }
    if (when && state.refresh && when.getTime() > Date.now()) { // refresh the page at that time; the saved setup then picks right after the load
      state.arm = true; state.fast = true; state.rt = when.getTime(); persist();
      if (!(await waitUntil(when, skipLines, t.reloadAt))) { disarm(); log(t.cancelled, true); return; }
      refresh('ajastettu päivitys'); return;
    }
    if (when && !(await waitUntil(when, skipLines))) { log(t.cancelled, true); return; }
    log([...skipLines, t.sending(targets.length)].join('\n'));
    const t0 = performance.now();
    const res = await pool(targets, state.conc, async c => {
      if (cancelled) return { ok: false, status: 0, text: t.cancelled };
      try { return await pickGroup(c.target, key); } catch (e) { return { ok: false, status: 0, text: String(e.message || e) }; }
    });
    res.forEach((r, i) => log(`${r.ok ? '✓' : '✗'} ${targets[i].code}  HTTP ${r.status}  ${r.text}`, true));
    const ok = res.filter(r => r.ok).length;
    log(t.done(ok, res.length - ok) + ` (${((performance.now() - t0) / 1000).toFixed(1)} s)`, true);
  }

  // Read-only structure report for checking the selectors against the real site. Sends no POST,
  // never prints the formkey value, and strips the "!slug" from paths.
  async function debug() {
    const t = tr(), out = [];
    const clean = (s, n = 260) => String(s).replace(/\s+/g, ' ').replace(/\/![^/"'\s]+/g, '/!SLUG')
      .replace(/Opettaja:[^"]*?(?=\s*(?:Ryhmä on|Tämä kurssi)|")/g, 'Opettaja: … ').replace(/Arvosana:\s*[^\s"]+/g, 'Arvosana: …').slice(0, n);
    const chain = el => { const r = []; for (let e = el, i = 0; e && i < 5; e = e.parentElement, i++) r.push(e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (typeof e.className === 'string' && e.className.trim() ? '.' + e.className.trim().split(/\s+/).join('.') : '')); return r.join(' < '); };
    const courseLinks = doc => [...doc.querySelectorAll('a[href]')].filter(a => isCourseCode(a.textContent.trim()));
    // Compact tag/class skeleton of an element (repeated siblings collapsed as *n), to see how the tray is nested.
    const skel = (el, d) => {
      const cls = typeof el.className === 'string' ? el.className.trim().split(/\s+/).filter(c => c && !/^k\S+-(on|off)$/.test(c)) : [];
      const name = el.tagName.toLowerCase() + (cls.length ? '.' + cls.join('.') : '');
      const kids = [...el.children];
      if (!kids.length) return name + (el.tagName !== 'A' && el.textContent.trim() ? '"' + el.textContent.trim().slice(0, 18) + '"' : '');
      if (d === 0) return name + '[…]';
      const groups = [];
      kids.forEach(k => { const s = skel(k, d - 1), last = groups[groups.length - 1]; if (last && last.s === s) last.n++; else groups.push({ s, n: 1 }); });
      return name + '[' + groups.map(g => g.s + (g.n > 1 ? '*' + g.n : '')).join(', ') + ']';
    };
    const stateCls = a => ' ' + (a.getAttribute('class') || '') + ' ';
    out.push('wilma-kurssit debug ' + new Date().toISOString(), 'page: ' + clean(location.pathname), 'formkey input on this page: ' + (document.querySelector('input[name=formkey]') ? 'yes' : 'no'));
    let view = null;
    try {
      view = await getDoc(url('selection/view'));
      const d = view.doc, own = d.querySelector('#own-schools');
      out.push('selection/view: OK (' + clean(view.url) + ')', '  title: ' + clean(d.title), '  #own-schools: ' + (own ? 'yes' : 'NO'),
        '  h4: ' + d.querySelectorAll('h4').length + ', ul: ' + d.querySelectorAll('ul').length + ', links containing "selection": ' + d.querySelectorAll('a[href*="selection"]').length,
        '  formkey input: ' + (d.querySelector('input[name=formkey]') ? 'yes' : 'no'));
      [...(own || d).querySelectorAll('a[href]')].slice(0, 4).forEach(a => out.push('  link: ' + clean(a.outerHTML)));
    } catch (e) { out.push('selection/view: FAILED ' + clean(e.message || e)); }
    const y = curYear() || years[0];
    const per0 = y && (y.periods.find(p => periodSel.has(p.href)) || y.periods[0]);
    out.push('parsed years: ' + years.length + '; schools: ' + ([...new Set(years.map(z => z.school || '(unknown)'))].join(' | ') || '-'),
      '  year containers (id x count): ' + [...years.reduce((m, z) => m.set(z.section || '(no id)', (m.get(z.section || '(no id)') || 0) + 1), new Map())].map(([k, n]) => k + 'x' + n).join(', '),
      '  selects on selection/view: ' + ([...(view ? view.doc : document).querySelectorAll('select')].slice(0, 6).map(s => (s.id || s.name || '?') + '(' + s.options.length + ')').join(', ') || 'none'));
    if (y) out.push('year "' + clean(y.title) + '": ' + y.periods.length + ' periods, ' + y.periods.filter(p => p.closed).length + ' closed');
    if (view && y && per0) {
      try {
        const { doc } = await getDoc(new URL(per0.href, view.url).href), links = courseLinks(doc);
        out.push('period page "' + clean(per0.label) + '": OK', '  all links: ' + doc.querySelectorAll('a[href]').length + ', course-like links: ' + links.length,
          '  formkey input: ' + (doc.querySelector('input[name=formkey]') ? 'yes' : 'no'));
        links.slice(0, 5).forEach(a => out.push('  course: ' + clean(a.outerHTML)));
        if (links[0]) out.push('  first course parents: ' + clean(chain(links[0])));
        // What is a "palkki"? Group the links by their class key and by their <li class="palkki"> container.
        const keyOf = a => { const m = /\sk(?!suor)(\S+)-(?:on|off)\s/.exec(stateCls(a)); return m ? m[1] : '(none)'; };
        const byKey = new Map();
        links.forEach(a => { const k = keyOf(a); if (!byKey.has(k)) byKey.set(k, []); byKey.get(k).push(a.textContent.trim()); });
        out.push('  distinct class keys: ' + byKey.size);
        [...byKey].sort((x, z) => z[1].length - x[1].length).slice(0, 14).forEach(([k, v]) => out.push('    key ' + k + ' (' + v.length + '): ' + v.slice(0, 12).join(' ')));
        const pat = new Map();
        links.forEach(a => {
          const p = (a.getAttribute('class') || '').trim().split(/\s+/).filter(Boolean).map(c => (/^k(?!suor)\S+-(on|off)$/.test(c) ? 'k*-' + c.slice(c.lastIndexOf('-') + 1) : c)).sort().join(' ') || '(no class)';
          pat.set(p, (pat.get(p) || 0) + 1);
        });
        out.push('  class patterns: ' + [...pat].map(([p, n]) => n + 'x "' + p + '"').join(' | '));
        const pal = [...doc.querySelectorAll('li.palkki')];
        out.push('  li.palkki: ' + pal.length + '; course links inside each (first 12): ' + pal.slice(0, 12).map(p => courseLinks(p).length).join(','));
        const sel = links.filter(a => /\sk(?!suor)\S+-on\s/.test(stateCls(a)));
        out.push('  selected-looking links (k*-on): ' + sel.length);
        sel.slice(0, 3).forEach(a => out.push('    ' + clean(a.outerHTML)));
        const top = doc.querySelector('ul.tray-topmost');
        out.push('  ul.tray-topmost: ' + (top ? top.children.length + ' items' : 'NOT FOUND'));
        if (top) [...top.children].slice(0, 2).forEach((li, i) => out.push('  tray item ' + i + ': ' + clean(skel(li, 6), 600)));
      } catch (e) { out.push('period page: FAILED ' + clean(e.message || e)); }
    } else out.push('period page: skipped (no year/period found)');
    try {
      const links = await findLinks();
      out.push('nav links: suoritukset=' + clean(links.done || '-') + ' hops=' + clean(links.hops || '-'));
      for (const [name, u] of [['suoritukset', links.done], ['hops', links.hops]]) {
        if (!u) continue;
        try {
          const { doc } = await getDoc(u);
          out.push(name + ' page: OK title=' + clean(doc.title) + '; tables ' + doc.querySelectorAll('table').length + ', forms ' + doc.querySelectorAll('form').length + ', rows ' + doc.querySelectorAll('tr').length);
          [...doc.querySelectorAll('table')].slice(0, 3).forEach((tb, i) => {
            out.push('  table ' + i + ' head: ' + [...tb.querySelectorAll('th')].slice(0, 10).map(x => clean(x.textContent, 24)).join(' | '));
            [...tb.querySelectorAll('tr')].filter(r => !r.querySelector('th')).slice(0, 3).forEach(r => out.push('    row: ' + [...r.children].slice(0, 10).map(c => clean(c.textContent, 24)).join(' | ')));
          });
          out.push('  forms: ' + ([...doc.querySelectorAll('form')].slice(0, 3).map(f => clean(f.outerHTML, 220)).join(' || ') || '-'));
          out.push('  add/remove controls: ' + ([...doc.querySelectorAll('a[href],button,input[type=submit]')].filter(x => /lisää|lisaa|add|poista|tallenna|spara/i.test(x.textContent + (x.value || ''))).slice(0, 6).map(x => clean(x.outerHTML, 200)).join(' || ') || '-'));
          if (name === 'hops') [...doc.querySelectorAll('table')].filter(tb => CODE_RE.test(tb.textContent.replace(/\s+/g, ' ').trim())).filter((_, i) => i < 2 || i === 40).forEach((tb, i) => out.push('  course table ' + i + ' html: ' + clean(tb.outerHTML, 900)));
          out.push('  skeleton: ' + clean(skel(doc.body, 5), 500));
        } catch (e) { out.push(name + ' page: FAILED ' + clean(e.message || e)); }
      }
      out.push('link texts on this page: ' + [...document.querySelectorAll('a[href]')].map(a => a.textContent.replace(/\s+/g, ' ').trim()).filter(x => x && x.length < 24).slice(0, 60).join(' | '));
    } catch (e) { out.push('links: FAILED ' + clean(e.message || e)); }
    const text = out.join('\n');
    log(text);
    let copied = false;
    try { await navigator.clipboard.writeText(text); copied = true; } catch (_) { /* fall through */ }
    log('\n' + (copied ? t.dbgDone : t.dbgShown), true);
  }

  // One-shot: after a refresh on a selection page, count down 3 s (Cancel stops it), then Find + Pick with the saved setup.
  async function autoRun() {
    const t = tr();
    if (!state.fast) for (let n = 3; n > 0; n--) { if (cancelled) { log(t.cancelled); return; } log(t.autoIn(n)); await sleep(1000); } // a timed refresh starts at once
    if (cancelled) { log(t.cancelled); return; }
    disarm(); // never fires twice
    await pick();
  }

  const run = fn => async () => { if (busy) return; setBusy(true); try { await fn(); } catch (e) { log(String(e && e.message || e), true); } finally { setBusy(false); } };

  // ---------- events ----------
  const actions = {
    find: run(find), pick: run(pick), reload: run(reloadYears), debug: run(debug),
    clearper: () => { periodSel.clear(); years.forEach(z => visited.add(yearKey(z))); plan = []; renderPlan(); renderPeriods(); persist(); },
    auto: run(autoRun), dscan: run(dashScan),
    dprest: run(async () => { const e = $('.dlog'); const msg = await fetchDone(await findLinks()); renderDash(); const l = $('.dlog'); if (l) { l.hidden = false; l.textContent = msg; } }),
    dhops: run(async () => { const msg = await fetchHops(await findLinks()); renderDash(); const l = $('.dlog'); if (l) { l.hidden = false; l.textContent = msg; } }),
    vsel: () => setView('sel'), vdash: () => setView('dash'),
    dashopen: () => { window.open(location.origin + basePath() + '/selection/view#wk-full-dash', '_blank'); },
    resume: run(async () => { if (!(await waitUntil(new Date(state.rt), [], tr().reloadAt))) { disarm(); log(tr().cancelled); return; } refresh('ajastettu päivitys'); }),
    clearall: () => { // wipe everything the tool remembers; language and window position stay
      cancelled = true; plan = []; savedChoices = new Map(); savedCodes = new Map(); periodSel.clear(); years.forEach(z => visited.add(yearKey(z)));
      savedFilters = new Map(); state.list = ''; state.arm = false; state.fast = false; state.rt = 0; state.per = []; state.choices = {}; state.filters = {}; state.year = ''; state.manual = {}; state.ignore = {}; state.dopen = {}; state.seen = {}; state.req = JSON.parse(JSON.stringify(DEFAULT_REQ)); save(); renderDash();
      $('.list').value = ''; $('.at').value = ''; $('.arm').checked = false; $('.file').value = '';
      renderPlan(); renderPeriods(); log(tr().allCleared);
    },
    save: () => {
      const L = ({ fi: ['Jaksot', 'Kurssit', 'rajaus', 'valittu', 'Wilma-kurssivalinnat', 'Tallennettu', 'Voit muokata tätä tiedostoa käsin. Rivit, jotka alkavat #-merkillä, ohitetaan.', 'Kurssirivi: koodi | rajaus: jakso, johon haku rajataan | valittu: ryhmä (jakso)'],
        en: ['Periods', 'Courses', 'only', 'chosen', 'Wilma course selection', 'Saved', 'You can edit this file by hand. Lines starting with # are ignored.', 'Course line: code | only: period to limit the search to | chosen: group (period)'],
        sv: ['Perioder', 'Kurser', 'endast', 'vald', 'Wilma-kursval', 'Sparad', 'Du kan redigera filen för hand. Rader som börjar med # ignoreras.', 'Kursrad: kod | endast: period att begränsa till | vald: grupp (period)'] })[state.lang] || [];
      const d = new Date(), p2 = n => String(n).padStart(2, '0'), stamp = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
      const periods = years.flatMap(z => z.periods.filter(p => periodSel.has(p.href)).map(p => `  - ${z.title} / ${p.label}`));
      const byTok = new Map(plan.map(p => [norm(p.token), p]));
      const courses = parseCodes($('.list').value).map(tok => {
        const p = byTok.get(norm(tok)), c = p && p.cands[p.choice];
        return '  ' + [tok, p && p.only && !tok.includes('@') ? `${L[2]}: ${p.only}` : '', c && p.cands.length > 1 ? `${L[3]}: ${c.code} (${c.period})` : c ? `${L[3]}: ${c.code} (${c.period})` : ''].filter(Boolean).join('  |  ');
      });
      const txt = [`# ${L[4]}`, `# ${L[5]}: ${stamp} ${p2(d.getHours())}:${p2(d.getMinutes())}`, `# ${L[6]}`, `# ${L[7]}`, '', `${L[0]}:`, ...(periods.length ? periods : ['  -']), '', `${L[1]}:`, ...courses, ''].join('\r\n');
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob(['﻿' + txt], { type: 'text/plain;charset=utf-8' }));
      a.download = 'wilma-kurssit-' + stamp + '.txt';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      log(tr().saved);
    },
    cfgsave: () => {
      const d = new Date(), p2 = n => String(n).padStart(2, '0'), stamp = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
      state.list = $('.list').value;
      const out = {}; Object.keys(DEFAULTS).forEach(k => { if (!['at', 'x', 'y', 'w', 'h', 'open'].includes(k)) out[k] = state[k]; });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify({ kind: 'wilma-kurssit-config', v: 2, savedAt: d.toISOString(), state: out }, null, 2)], { type: 'application/json' }));
      a.download = 'wilma-kurssit-asetukset-' + stamp + '.json';
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      log(tr().cfgSaved);
    },
    cfgload: () => $('.cfile').click(),
    load: () => $('.file').click(),
    cancel: () => { cancelled = true; if (loopActive()) { loopStop('cancel'); if (window.__wkCloseExtra) window.__wkCloseExtra(); } },
    loop: () => { if (loopActive()) { loopStop('stop'); cancelled = true; if (window.__wkCloseExtra) window.__wkCloseExtra(); log(tr().loopStopped); return; } state.list = $('.list').value; save(); loopBegin(true); paintLoop(); loopRun(); },
    help: () => { state.help = !state.help; if (!state.help) root.querySelectorAll('.tip').forEach(x => x.remove()); save(); applyLite(); },
    cclear: () => { try { sessionStorage.removeItem(CS); localStorage.removeItem(CK); localStorage.removeItem(AUTHK); } catch (_) { /* ignore */ } $('.cuser').value = ''; $('.cpass').value = ''; loadCredsUI(); evLog('LOGIN', 'tunnukset poistettu'); },
    lite: () => { state.lite = !state.lite; save(); applyLite(); renderDash(); },
    min: () => { state.open = false; save(); $('.panel').hidden = true; $('.fab').hidden = false; },
    lang: () => { state.list = $('.list').value; state.lang = ({ fi: 'sv', sv: 'en', en: 'fi' })[state.lang] || 'fi'; save(); buildUi(); },
    unload: () => { if (full) { try { history.replaceState(null, '', location.pathname + location.search); } catch (_) { /* ignore */ } setFull(false); } else unload(); },
  };
  root.addEventListener('click', e => {
    const h = e.target.closest && e.target.closest('button.q');
    if (h) { toggleTip(h); return; }
    const had = root.querySelector('.ctx'); if (had) had.remove();
    const dd = e.target.closest && e.target.closest('button[data-dact]'); if (dd) { dashClick(dd); return; }
    const b = e.target.closest && e.target.closest('[data-act]'); if (b && actions[b.dataset.act]) actions[b.dataset.act]();
  });
  root.addEventListener('change', e => {
    const n = e.target;
    if (n.dataset && n.dataset.aopt) {
      const A = state.auto, k = n.dataset.aopt;
      if (k === 'maxper') A.maxper = Math.max(0, Math.min(12, Math.round(+n.value || 0))); else if (k === 'lock') A.lock = n.checked; else A[k] = n.value;
      save(); if (k === 'home' || k === 'lock') renderDash(); return; // text boxes are not redrawn, so a click on a button right after typing still lands
    }
    if (n.dataset && n.dataset.aoth) { const A = state.auto, o = new Set(A.others || []); if (n.checked) o.add(n.dataset.aoth); else o.delete(n.dataset.aoth); A.others = [...o]; save(); renderDash(); return; }
    if (n.dataset && n.dataset.dopt) {
      const k = n.dataset.dopt;
      if (k === 'unstable') { state.unstable = n.checked; if (!n.checked) state.ldelay = Math.max(0.3, state.ldelay); }
      else if (k === 'ldelay') state.ldelay = Math.max(minDelay(), Math.min(60, +n.value || 2));
      else if (k === 'lmode') state.lmode = ['fetch', 'hybrid'].includes(n.value) ? n.value : 'reload';
      else if (k === 'lworkers') state.lworkers = Math.max(1, Math.min(6, Math.round(+n.value || 6)));
      else if (k === 'gapms') state.gapMs = Math.max(0, Math.min(60000, Math.round(+n.value || 0)));
      else if (k === 'lite') state.lite = n.checked;
      else if (k === 'nonlypost') { netOnlyPost = n.checked; drawNet(); return; }
      save(); applyLite(); renderDash(); return;
    }
    if (n.dataset && n.dataset.dact === 'op') { state.opPer = Math.max(1, Math.min(6, +n.value || 2)); save(); renderDash(); return; }
    if (n.dataset && n.dataset.dact === 'need') { const r = state.req.find(x => x.id === n.dataset.id); if (r) { r.need = Math.max(0, Math.min(40, +n.value || 0)); save(); renderDash(); } }
  });
  root.addEventListener('change', async e => {
    const input = e.target; // e.target is reset after the first await
    if (input.classList && input.classList.contains('cfile') && input.files[0]) {
      try {
        const c = JSON.parse((await input.files[0].text()).replace(/^\uFEFF/, ''));
        if (c.kind !== 'wilma-kurssit-config' || !c.state || typeof c.state !== 'object') throw new Error('format');
        for (const k of Object.keys(DEFAULTS)) if (!['at', 'x', 'y', 'w', 'h', 'open'].includes(k) && k in c.state) state[k] = c.state[k];
        save(); periodSel = new Set(state.per || []); plan = []; buildUi(); log(tr().cfgLoaded);
      } catch (_) { log(tr().badFile); }
      input.value = ''; return;
    }
    if (!input.classList.contains('file') || !input.files[0]) return;
    try {
      const raw = (await input.files[0].text()).replace(/^﻿/, '');
      let d;
      if (/^\s*\{/.test(raw)) { // older .json files
        d = JSON.parse(raw);
        if (d.v !== 1 || typeof d.list !== 'string' || !Array.isArray(d.periods)) throw new Error('format');
      } else d = parseTxt(raw);
      $('.list').value = state.list = d.list; save();
      const known = new Set(years.flatMap(z => z.periods.map(p => p.href)));
      const hrefs = d.periods.map(p => p.href || findPeriod(p)).filter(Boolean);
      periodSel = new Set(hrefs.filter(h => known.has(h)));
      years.forEach(z => visited.add(yearKey(z)));
      savedChoices = new Map(Object.entries(d.choices || {})); savedFilters = new Map(Object.entries(d.filters || {}));
      savedCodes = new Map(Object.entries(d.codes || {}));
      const first = years.findIndex(z => z.periods.some(p => periodSel.has(p.href)));
      if (first >= 0) { $('.year').value = String(first); state.year = yearKey(years[first]); save(); }
      plan = []; renderPlan(); renderPeriods(); persist();
      log(tr().loaded(periodSel.size, d.periods.length));
    } catch (_) { log(tr().badFile); }
    input.value = '';
  });
  root.addEventListener('input', e => {
    if (e.target.classList && (e.target.classList.contains('cuser') || e.target.classList.contains('cpass'))) { saveCreds(); return; }
    const c = e.target.classList;
    if (c.contains('thm')) { state.theme = e.target.checked ? 'dark' : 'light'; applyTheme(); save(); return; }
    if (c.contains('list')) state.list = e.target.value;
    else if (c.contains('at')) { state.at = e.target.value; try { localStorage.setItem(AKEY, JSON.stringify({ v: state.at, t: Date.now() })); } catch (_) { /* ignore */ } }
    else if (c.contains('conc')) state.conc = Math.max(1, Math.min(10, +e.target.value || 1));
    else if (c.contains('ltabs')) state.ltabs = Math.max(1, Math.min(10, Math.round(+e.target.value || 1)));
    else if (c.contains('ldelay')) state.ldelay = Math.max(minDelay(), Math.min(60, +e.target.value || 2));
    else if (c.contains('lmax')) state.lmax = Math.max(1, Math.min(240, Math.round(+e.target.value || 30)));
    else if (e.target.dataset && e.target.dataset.opt) { state[e.target.dataset.opt] = e.target.checked; if (e.target.dataset.opt === 'lite') applyLite(); if (e.target.dataset.opt === 'cremember') saveCreds(); if (e.target.dataset.opt === 'cauto') loadCredsUI(); }
    else if (e.target.dataset && e.target.dataset.pf != null) {
      const p = plan[+e.target.dataset.pf]; p.only = e.target.value;
      p.cands = p.only ? p.all.filter(c => pnorm(c.period).includes(pnorm(p.only))) : p.all; p.choice = best(p.cands);
      renderPlan(); persist(); return;
    }
    else if (c.contains('year')) { const y = curYear(); if (y) state.year = yearKey(y); plan = []; renderPlan(); autoPeriods(); }
    else if (e.target.dataset && e.target.dataset.per != null) { const p = curYear().periods[+e.target.dataset.per]; if (e.target.checked) periodSel.add(p.href); else periodSel.delete(p.href); persist(); return; }
    else if (e.target.dataset && e.target.dataset.row != null) { plan[+e.target.dataset.row].choice = +e.target.value; persist(); return; }
    save();
  });

  root.addEventListener('contextmenu', e => { const c = e.target.closest && e.target.closest('.dchip'); if (!c) return; e.preventDefault(); showCtx(e.clientX, e.clientY, c.dataset.base); });
  root.addEventListener('toggle', e => { const d = e.target; if (d && d.dataset && d.dataset.rid) { state.dopen[d.dataset.rid] = d.open; save(); } }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') root.querySelectorAll('.ctx').forEach(x => x.remove()); });

  // "?" next to a control: shows or hides its explanation right below the control's row
  function toggleTip(btn) {
    const block = btn.closest('[data-hb]'); if (!block) return;
    const next = block.nextElementSibling, key = btn.dataset.help;
    const same = next && next.classList.contains('tip') && next.dataset.key === key;
    root.querySelectorAll('.tip').forEach(x => x.remove());
    root.querySelectorAll('button.q.on').forEach(x => x.classList.remove('on'));
    if (same) return;
    const tip = document.createElement('div'); tip.className = 'tip'; tip.dataset.key = key; tip.textContent = tipOf(key);
    block.after(tip); btn.classList.add('on');
  }

  // Wilma's own "Käytä pikavalintaa" checkbox: tick it once per page load (not again, so you can still untick it)
  function wilmaQuick() {
    if (!state.wq) return;
    const label = i => [...(i.labels || [])].map(l => l.textContent).join(' ') + ' ' + ((i.parentElement && i.parentElement.textContent.length < 80) ? i.parentElement.textContent : '') + ' ' + ((i.nextSibling && i.nextSibling.textContent) || '');
    const find = () => [...document.querySelectorAll('input[type=checkbox]')].find(i => /pikavalin|quick\s*select/i.test(label(i)));
    let n = 0;
    const tick = () => { const c = find(); if (!c) return false; if (!c.checked) c.click(); return true; };
    if (tick()) return;
    const id = setInterval(() => { if (tick() || ++n > 30) clearInterval(id); }, 500);
    wqTimer = id;
  }

  function makeDraggable(handle, onClick) {
    handle.addEventListener('pointerdown', e => {
      if (full || e.button !== 0 || (e.target !== handle && e.target.closest('button, label, input, select, a'))) return;
      const r = host.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top, sx = e.clientX, sy = e.clientY;
      let moved = false;
      handle.setPointerCapture(e.pointerId);
      const move = ev => {
        if (!moved && Math.hypot(ev.clientX - sx, ev.clientY - sy) < 4) return;
        moved = true;
        state.x = Math.min(Math.max(0, ev.clientX - dx), innerWidth - 44); state.y = Math.min(Math.max(0, ev.clientY - dy), innerHeight - 44);
        Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
      };
      const up = () => { handle.removeEventListener('pointermove', move); handle.removeEventListener('pointerup', up); if (moved) save(); else if (onClick) onClick(); };
      handle.addEventListener('pointermove', move); handle.addEventListener('pointerup', up);
    });
  }

  function unload() {
    cancelled = true; clearInterval(wqTimer); clearInterval(loopDog); clearTimeout(netTimer); try { if (netBc) netBc.close(); } catch (_) { /* ignore */ }
    sheetCleanup();
    host.remove();
    delete window.__wilmaKurssit;
  }

  function applyTheme() {
    const th = state.theme || 'auto';
    shell.classList.toggle('light', th === 'light'); shell.classList.toggle('dark', th === 'dark');
    const box = $('.thm'); if (box) box.checked = th === 'dark' || (th === 'auto' && !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches));
    const sw = $('.sw'); if (sw) sw.title = tipOf('theme');
  }

  // ---------- dashboard ----------
  const baseOf = code => String(code).split('.')[0].toUpperCase();
  const rowOf = (base, req) => { let hit = null, len = 0; for (const r of req) for (const p of r.p) { const u = String(p).toUpperCase().trim(); if (u && base.startsWith(u) && u.length > len) { hit = r; len = u.length; } } return hit; };

  function dashModel() {
    const all = new Map();
    for (const [b, v] of Object.entries(state.seen || {})) all.set(b, { base: b, d: !!v.d, s: !!v.s, o: !!v.o });
    for (const b of Object.keys(state.manual || {})) { const c = all.get(b) || { base: b, d: false, s: false, o: false }; c.m = true; all.set(b, c); }
    for (const b of Object.keys(state.earned || {})) { const c = all.get(b) || { base: b, d: false, s: false, o: false }; c.e = true; all.set(b, c); }
    const hasHops = Object.keys(state.hops || {}).length > 0;
    const hasEarned = Object.keys(state.earned || {}).length > 0; // completions read from Wilma win over the tray's flags
    all.forEach(c => { c.ign = !!(state.ignore || {})[c.base]; c.hp = !!(state.hops || {})[c.base]; c.done = !c.ign && ((hasEarned ? false : c.d) || !!c.m || !!c.e); c.sel = !c.ign && c.s && !c.done; c.todo = !c.ign && !c.done && !c.sel && c.o; });
    const rows = state.req.map(r => ({ ...r, courses: [], done: 0, sel: 0 }));
    const other = [];
    [...all.values()].sort((a, b) => a.base.localeCompare(b.base, 'fi', { numeric: true })).forEach(c => {
      const m = rowOf(c.base, state.req), r = m && rows.find(x => x.id === m.id);
      if (r) { r.courses.push(c); if (c.done) r.done++; else if (c.sel) r.sel++; } else other.push(c);
    });
    const groups = {};
    rows.forEach(r => { if (r.alt) (groups[r.alt] = groups[r.alt] || []).push(r); });
    Object.values(groups).forEach(g => { let top = g[0]; g.forEach(r => { if (r.done + r.sel > top.done + top.sel) top = r; }); g.forEach(r => { r.inactive = r !== top; }); });
    // courses numbered 1..need of a subject (ÄI01–ÄI06) are compulsory, higher numbers (ÄI07…) and everything else elective
    rows.forEach(r => r.courses.forEach(c => { const n = /(\d+)$/.exec(c.base); c.kind = (!c.ign && !r.inactive && n && +n[1] <= r.need) ? 'm' : 'v'; }));
    other.forEach(c => { c.kind = 'v'; });
    rows.forEach(r => { r.missing = r.inactive ? 0 : Math.max(0, r.need - r.done - r.sel); r.todoList = r.inactive ? [] : r.courses.filter(c => c.todo); r.have = r.courses.filter(c => c.done || c.sel); });
    return { rows, other, all: [...all.values()], any: all.size > 0, hasHops };
  }

  const inList = base => parseCodes(state.list).some(t => baseOf(t) === base);

  function loopStat(d) {
    const L = readLoop();
    if (loopActive()) {
      const left = Math.max(0, Math.round(((L.t0 || 0) + (L.max || 30) * 60000 - Date.now()) / 60000));
      return `<div class="lstat on" role="status">\u{1F501} <b>${d.lsOn}</b> \u00B7 ${L.mode === 'fetch' ? d.lsFetch(L.workers || 6) : L.mode === 'hybrid' ? d.lsHybrid : d.lsReload} \u00B7 ${d.lsRound} ${L.rounds || 0} \u00B7 ${L.delay || 2} s \u00B7 ${d.lsLeft} ${left} min${L.unstable ? ' \u00B7 \u26A0' : ''}</div>`;
    }
    return L.why ? `<div class="lstat" role="status">\u23F9 ${d.lsOff}: ${esc((d.why || {})[L.why] || L.why)}${L.rounds ? ' \u00B7 ' + d.lsRound + ' ' + L.rounds : ''}</div>` : '';
  }
  let statTimer = 0;
  const schedStat = () => { if (statTimer || view !== 'dash') return; statTimer = setTimeout(() => { statTimer = 0; renderDash(); }, 600); };
  function renderDash() {
    const el = $('.dash'); if (!el || view !== 'dash') return;
    paintProg();
    const d = D[state.lang] || D.en, m = dashModel(), pm = !!state.pickMode, op = Math.max(1, +state.opPer || 2);
    const act = m.rows.filter(r => !r.inactive);
    const reqEarned = act.reduce((a, r) => a + Math.min(r.need, r.done), 0);
    const need = act.reduce((a, r) => a + r.need, 0), gotC = act.reduce((a, r) => a + Math.min(r.need, r.done + r.sel), 0), miss = need - gotC;
    const opOf = c => { const e = (state.earned || {})[c.base], h = (state.hops || {})[c.base]; return e && e.op != null ? e.op : h && h.op != null ? h.op : null; };
    const doneC = m.all.filter(c => c.done), nDone = doneC.length, nSel = m.all.filter(c => c.sel).length;
    const calcOp = doneC.reduce((a, c) => a + (opOf(c) != null ? opOf(c) : op), 0);
    const sumRows = state.summary || [], sumTot = sumRows.find(r => /yhteensä|totalt|total/i.test(r[0]));
    const wilmaOp = sumRows.length ? (sumTot ? sumTot[1] : sumRows.reduce((a, r) => a + r[1], 0)) : null;
    const earnedOp = wilmaOp != null ? wilmaOp : calcOp;
    const estimated = doneC.some(c => opOf(c) == null) || m.all.some(c => c.sel && opOf(c) == null), plannedOp = m.all.filter(c => c.sel).reduce((a, c) => a + (opOf(c) != null ? opOf(c) : op), 0);
    const mathRow = act.find(r => r.alt === 'mat'), lops = mathRow ? (mathRow.id === 'maa' ? 102 : 94) : 0;
    const lopsTxt = lops ? (need * op === lops ? d.lopsOk(lops) : d.lopsDiff(need * op, lops)) : '';
    const pct = (a, b) => (b ? Math.min(100, Math.round(100 * a / b)) : 0);
    const stOf = c => c.ign ? d.stIgn : c.done ? d.stDone + (c.m ? ', ' + d.stManual : '') : c.sel ? d.stSel : c.todo ? d.stTodo : d.stNone;
    const chip = c => {
      const cls = c.ign ? ' ign' : pm ? (c.done || c.sel ? ' blue' : c.todo ? ' todo' + (inList(c.base) ? ' inl' : '') : '') : (c.done ? ' done' : c.sel ? ' sel' : '');
      return `<button class="dchip${cls}${c.m ? ' man' : ''} k${c.kind || 'v'}${c.hp ? ' hp' : ''}" data-dact="chip" data-base="${esc(c.base)}" title="${esc(d.chipTip(c.base, stOf(c)) + ' \u00b7 ' + ((c.kind || 'v') === 'm' ? d.man : d.opt) + (c.hp ? ' \u00b7 ' + d.inHops : '') + (pm && c.todo ? ' \u00b7 ' + (inList(c.base) ? d.inList : '+') : ''))}">${esc(c.base)}</button>`;
    };
    const key = r => (pm ? 'p:' : 'n:') + r.id;
    const isOpen = r => (state.dopen[key(r)] != null ? state.dopen[key(r)] : pm);
    const bar = r => `<div class="bar"><i class="d" style="width:${pct(Math.min(r.done, r.need), r.need)}%"></i><i class="s" style="width:${pct(Math.min(Math.max(0, r.need - r.done), r.sel), r.need)}%"></i></div>`;
    const card = r => {
      const body = pm
        ? `<div class="dsub">${d.todo}</div><div>${r.todoList.length ? r.todoList.map(chip).join('') : `<span class="dnote">${r.missing ? d.notOffered(r.missing) : d.yellowNone}</span>`}</div>${r.have.length ? `<div class="dsub">${d.have}</div><div>${r.have.map(chip).join('')}</div>` : ''}`
        : `<div>${r.courses.length ? r.courses.map(chip).join('') : `<span class="dnote">${d.nothing}</span>`}</div>`;
      return `<details class="dcard${r.inactive ? ' off' : ''}${!r.inactive && r.need > 0 && !r.missing ? ' complete' : ''}" data-rid="${esc(key(r))}"${isOpen(r) ? ' open' : ''}>
        <summary><span class="dname">${esc(r.name)}${r.inactive ? ` <small class="dnote">(${d.alt})</small>` : ''}</span><span class="dnums" title="${d.done} ${r.done} · ${d.sel} ${r.sel} · ${d.miss} ${r.missing} / ${d.need} ${r.need}">${r.done + r.sel}/${r.need}</span>
          <input type="number" min="0" max="40" value="${r.need}" data-dact="need" data-id="${esc(r.id)}" aria-label="${d.need}" title="${d.need}"><button class="x" data-dact="del" data-id="${esc(r.id)}" title="${d.del}" aria-label="${d.del}">✕</button></summary>
        ${bar(r)}<div class="dbody">${body}</div></details>`;
    };
    const shown = pm ? act.filter(r => r.missing > 0 || r.todoList.length) : m.rows;
    const finished = pm ? m.rows.filter(r => !r.inactive && !shown.includes(r)) : [];
    const yellow = act.flatMap(r => r.todoList).filter(c => !inList(c.base));
    const ignored = m.all.filter(c => c.ign);
    const hopsMissing = m.all.filter(c => c.sel && !c.hp);
    const html = `
      <div class="dtop"><h3>${d.head}</h3></div>
      ${loopStat(d)}
      <div class="dtiles">
        <div class="tile" title="${esc(tipOf('tileop'))}"><b>${earnedOp}<small> / 150 op</small></b><span>${d.earned}${wilmaOp == null && estimated ? ' \u00b7 ' + d.estimate : ''} \u00b7 +${plannedOp} ${d.planned} = ${earnedOp + plannedOp} ${d.projected}${wilmaOp != null ? `<br>${d.wsum}: ${sumRows.map(r => esc(r[0].replace(/^Lu21\s*/i, '')) + ' ' + r[1]).join(' \u00b7 ')}${calcOp !== wilmaOp ? ` \u00b7 ${d.calc} ${calcOp}` : ''}` : ''}</span></div>
        <div class="tile d" title="${esc(tipOf('tilereq'))}"><b>${reqEarned * op}<small> / ${need * op} op</small></b><span>${d.reqOp} · ${lopsTxt}</span></div>
        <div class="tile m" title="${esc(tipOf('tilemiss'))}"><b>${miss}</b><span>${d.miss} (${d.req})</span></div>
        <div class="tile s" title="${esc(tipOf('tilecnt'))}"><b>${nDone} / ${nSel}</b><span>${d.cntT}</span></div>
      </div>
      <div class="bar big" title="${esc(tipOf('tileop'))}"><i class="d" style="width:${pct(earnedOp, 150)}%"></i><i class="s" style="width:${pct(plannedOp, 150)}%"></i></div>
      <details class="legend" data-rid="legend"${state.dopen.legend ? ' open' : ''}><summary title="${esc(tipOf('legend'))}">\u{1F3A8} ${d.legend}</summary>
        <div class="lrows">${d.legRows.map(([c, l]) => `<div class="lrow"><span class="dchip ${c === 'kvm' ? 'km' : c === 'kvv' ? 'kv' : c}">\u00C4I01</span><span>${esc(l)}</span></div>`).join('')}</div><div class="dnote">${esc(d.legBar)}</div></details>
      <div class="dtools" data-hb>
        <button class="act pick${pm ? ' on' : ''}" data-dact="pickmode">\u{1F3AF} ${pm ? d.pickOn : d.pick}</button>${q('dpick')}
        <button class="act scan" data-act="dscan">↻ ${d.scan}</button>${q('dscan')}
        <button class="act" data-dact="fold">${d.fold}</button>${q('dfold')}
      </div>
      ${pm ? autoHtml(d) : ''}
      ${pm ? `<div class="dtools yel" data-hb><span class="dnote">${d.pickHelp}</span><button class="act" data-dact="addall"${yellow.length ? '' : ' disabled'}>${d.addAll(yellow.length)}</button>${q('dlist')}<button class="act go" data-dact="go">${d.go}</button>${q('dgo')}</div>` : ''}
      <details class="dtoolbox" data-rid="tools"${state.dopen.tools ? ' open' : ''}><summary title="${esc(tipOf('dtools'))}">⚙ ${d.tools}</summary>
        <div class="dtools" data-hb><button class="act" data-act="dprest">${d.getDone}</button>${q('dprest')}<button class="act" data-act="dhops">${d.getHops}</button>${q('dhops')}</div>
        <div class="dtools" data-hb><input class="dmanual" placeholder="${d.manual}" spellcheck="false"><button class="act" data-dact="manual">${d.manualBtn}</button>${q('dmanual')}</div>
        <div class="dtools" data-hb><input class="dnname" placeholder="${d.addName}"><input class="dnpref" placeholder="${d.addPref}"><input class="dnneed nn" type="number" min="0" max="40" value="1" aria-label="${d.cnt}"><button class="act" data-dact="add">${d.addBtn}</button>${q('dadd')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.op} <input class="nn" type="number" min="1" max="6" value="${op}" data-dact="op"></label>${q('dop')}<button class="act rst" data-dact="reset">${d.reset}</button>${q('dreset')}</div>
        <div data-hb><span class="dnote">${d.ignored} (${ignored.length}): </span>${ignored.map(chip).join('') || '<span class="dnote">–</span>'} ${q('dchip')}</div>
      </details>
      <details class="dtoolbox con" data-rid="net"${state.dopen.net !== false ? ' open' : ''}><summary title="${esc(tipOf('con'))}">\u{1F5A5} ${d.con} <small class="ncnt dnote"></small></summary>
        <div class="dtools" data-hb><button class="act" data-dact="nclear">${d.conClear}</button><button class="act" data-dact="ncopy">${d.conCopy}</button><button class="act${netPaused ? ' on' : ''}" data-dact="npause">${netPaused ? '\u25B6 ' + d.conResume : '\u23F8 ' + d.conPause}</button><label class="dnote"><input type="checkbox" data-dopt="nonlypost"${netOnlyPost ? ' checked' : ''}> ${d.conPost}</label>${q('con')}</div>
        <div class="ncon" tabindex="0" role="log"></div>
      </details>
      <details class="dtoolbox dev" data-rid="dev"${state.dopen.dev ? ' open' : ''}><summary title="${esc(tipOf('devunlock'))}">\u{1F9EA} ${d.dev}</summary>
        <div class="devwarn">${d.devWarn}</div>
        <div class="dtools" data-hb><label class="dnote"><input type="checkbox" data-dopt="unstable"${state.unstable ? ' checked' : ''}> ${d.devUnlock}</label>${q('devunlock')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.devDelay} <input class="nn" style="width:84px" type="number" min="${minDelay()}" max="60" step="0.001" value="${state.ldelay}" data-dopt="ldelay"></label>${q('devdelay')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.devGap} <input class="nn" style="width:96px" type="number" min="0" max="60000" step="1" value="${state.gapMs || 0}" data-dopt="gapms"></label>${q('devgap')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.devMode} <select data-dopt="lmode"><option value="reload"${state.lmode !== 'fetch' && state.lmode !== 'hybrid' ? ' selected' : ''}>${d.devReload}</option><option value="fetch"${state.lmode === 'fetch' ? ' selected' : ''}>${d.devFetch}</option><option value="hybrid"${state.lmode === 'hybrid' ? ' selected' : ''}>${d.devHybrid}</option></select></label>${q('devmode')}</div>
        <div class="dtools" data-hb><label class="dnote">${d.devWorkers} <input class="nn" type="number" min="1" max="6" value="${state.lworkers}" data-dopt="lworkers"></label>${q('devworkers')}</div>
        <div class="dtools" data-hb><label class="dnote"><input type="checkbox" data-dopt="lite"${state.lite ? ' checked' : ''}> ${d.devLite}</label>${q('devlite')}</div>
        <div class="dnote">${d.devNow}: ${Math.round(state.gapMs > 0 ? state.gapMs : Math.max(minDelay() * 1000, state.ldelay * 1000 / (state.lmode === 'fetch' ? Math.max(1, state.lworkers) : state.lmode === 'hybrid' ? 3 : 1)))} ms</div>
      </details>
      ${m.hasHops && hopsMissing.length ? `<div class="dtools yel" data-hb><b class="dnote">${d.hopsMissing}:</b> ${hopsMissing.map(chip).join('')}<button class="act" data-dact="hopscopy">${d.copy}</button>${q('dhopscopy')}</div>` : ''}
      <div class="dlog" aria-live="polite"${m.any ? ' hidden' : ''}>${m.any ? '' : d.empty}</div>
      <div class="dgrid">${shown.map(card).join('')}</div>
      ${finished.length ? `<details><summary>${d.done2} (${finished.length})</summary><div class="dgrid" style="padding-top:8px">${finished.map(card).join('')}</div></details>` : ''}
      ${pm ? '' : `<details><summary>${d.other} (${m.other.length})</summary><div style="padding-top:6px">${m.other.map(chip).join('') || `<span class="dnote">${d.nothing}</span>`}</div></details>`}`;
    if (html === el._h) { drawNet(); return; }
    el._h = html; el.innerHTML = html; applyTitles(el); drawNet();
  }

  // ---------- automatic group builder (dashboard, new-courses mode) ----------
  let autoRes = null, autoBusy = false;
  // Picks one group per course so that no two chosen groups share a bar (same time slot) - maximising placed courses first,
  // then group quality and an even load across periods. Depth-first with a node budget; the first dive is already a good answer.
  function solveGroups(items, used0, opt) {
    const used = new Set(used0), per = {}; let best = null, nodes = 0;
    const order = items.slice().sort((a, b) => a.opts.length - b.opts.length), cur = [];
    (function dfs(i, score, placed) {
      if (++nodes > opt.budget) return;
      if (best && placed + (order.length - i) < best.placed) return;
      if (i === order.length) { if (!best || placed > best.placed || (placed === best.placed && score > best.score)) best = { placed, score, sel: cur.slice() }; return; }
      const it = order[i];
      for (const o of it.opts) {
        if (o.key && used.has(o.key)) continue;
        if (opt.maxper && (per[o.c.ph] || 0) >= opt.maxper) continue;
        if (o.key) used.add(o.key); per[o.c.ph] = (per[o.c.ph] || 0) + 1; cur.push({ it, o });
        dfs(i + 1, score + o.sc - opt.bal * (per[o.c.ph] - 1), placed + 1);
        cur.pop(); per[o.c.ph]--; if (o.key) used.delete(o.key);
      }
      dfs(i + 1, score - 100, placed); // leave this course out
    })(0, 0, 0);
    return best ? best.sel : [];
  }
  const autoHome = () => {
    const A = state.auto, ok = k => years.some(z => yearKey(z) === k);
    if (A.home && ok(A.home)) return A.home;
    const sy = selectedYears()[0] || years.find(z => z.periods.some(p => !p.closed)) || years[0];
    return sy ? yearKey(sy) : '';
  };
  async function autoBuild() {
    if (autoBusy) return; autoBusy = true;
    const d = D[state.lang] || D.en, dl = txt => { const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = txt; } };
    try {
      if (!years.length) await reloadYears();
      const A = state.auto, home = years.find(z => yearKey(z) === autoHome());
      const others = (A.others || []).map(k => years.find(z => yearKey(z) === k)).filter(z => z && z !== home);
      if (!home) { dl(d.aNoHome); return; }
      const wantT = parseCodes(A.want || state.list), otherT = parseCodes(A.other).filter(t => !wantT.some(w => norm(w) === norm(t)));
      if (!wantT.length && !otherT.length) { dl(d.aNoCourses); return; }
      dl(d.aScanning);
      const open = z => { const o = z.periods.filter(p => !p.closed); return o.length ? o : z.periods; };
      const prevChoice = new Map(plan.filter(p => p.cands.length).map(p => [norm(p.token), p.cands[p.choice].target]));
      periodSel = new Set([home, ...others].flatMap(z => open(z).map(p => p.href)));
      state.list = [...wantT, ...otherT].join(' '); const l = $('.list'); if (l) l.value = state.list;
      if (!await find(true)) { dl(d.aNoHome); return; }
      const inY = (c, ys) => ys.some(z => c.year === z.title && c.school === z.school);
      const yOf = c => [home, ...others].find(z => c.year === z.title && c.school === z.school);
      const sc = c => { const z = yOf(c), pi = z ? z.periods.findIndex(p => p.href === c.ph) : 0; return (c.selected ? 30 : 0) - (c.full ? 60 : c.off ? 40 : 0) + Math.max(0, 6 - pi) * .5; };
      const rows = plan.map(p => {
        const isOther = otherT.some(t => norm(t) === norm(p.token));
        const pool = p.cands.filter(c => !c.closed && !c.done && inY(c, isOther ? others : [home]));
        return { p, isOther, pool, opts: pool.map(c => ({ c, key: c.block ? c.ph + '|' + c.block : '', sc: sc(c) })).sort((a, b) => b.sc - a.sc), c: null, fixed: false };
      });
      const maxper = Math.max(0, +A.maxper || 0), used = new Set(), opt = { budget: 300000, bal: 4, maxper };
      const take = (r, o, fixed) => { r.c = o.c; r.fixed = !!fixed; if (o.key) used.add(o.key); };
      // stage 1: other schools - a group already chosen by hand stays (when locked), the rest is solved first
      const oth = rows.filter(r => r.isOther), free = [];
      oth.forEach(r => { const t = A.lock !== false ? prevChoice.get(norm(r.p.token)) : null, o = t && r.opts.find(x => x.c.target === t); if (o && !(o.key && used.has(o.key))) take(r, o, true); else free.push(r); });
      solveGroups(free.map(r => ({ r, opts: r.opts })), used, opt).forEach(({ it, o }) => take(it.r, o, false));
      // stage 2: your own school, around those
      const mine = rows.filter(r => !r.isOther);
      solveGroups(mine.map(r => ({ r, opts: r.opts })), used, opt).forEach(({ it, o }) => take(it.r, o, false));
      rows.forEach(r => { if (r.c) r.p.choice = r.p.cands.indexOf(r.c); });
      autoRes = { rows: rows.map(r => ({ tok: r.p.token, other: r.isOther, c: r.c, fixed: r.fixed, why: r.c ? '' : (r.pool.length ? d.aConflict : d.aNoGroup) })) };
      autoRes.placed = autoRes.rows.filter(r => r.c).length; autoRes.total = rows.length;
      renderPlan(); persist(); renderDash();
      dl(d.aDone(autoRes.placed, autoRes.total));
    } catch (e) { dl(String(e && e.message || e)); } finally { autoBusy = false; }
  }
  function autoApply() {
    if (!autoRes) return; const d = D[state.lang] || D.en;
    const ok = new Set(autoRes.rows.filter(r => r.c).map(r => norm(r.tok)));
    plan = plan.filter(p => ok.has(norm(p.token)));
    state.list = plan.map(p => p.token).join(' '); const l = $('.list'); if (l) l.value = state.list;
    renderPlan(); persist(); save(); setView('sel'); log(d.aApplied(plan.length));
  }
  function autoHtml(d) {
    const A = state.auto, home = autoHome(), yn = z => `${z.school ? z.school + ' ' : ''}${z.title}`;
    const homeSel = `<select data-aopt="home">${years.map(z => `<option value="${esc(yearKey(z))}"${yearKey(z) === home ? ' selected' : ''}>${esc(yn(z))}</option>`).join('')}</select>`;
    const oth = years.filter(z => yearKey(z) !== home).map(z => `<label class="chk"><input type="checkbox" data-aoth="${esc(yearKey(z))}"${(A.others || []).includes(yearKey(z)) ? ' checked' : ''}> ${esc(yn(z))}</label>`).join('');
    const res = autoRes ? (() => {
      const per = {}; autoRes.rows.forEach(r => { if (r.c) per[r.c.period] = (per[r.c.period] || 0) + 1; });
      return `<table class="ares"><tr><th>${d.aColCourse}</th><th>${d.aColGroup}</th><th>${d.aColPeriod}</th><th>${d.aColTeacher}</th></tr>${autoRes.rows.map(r => r.c
        ? `<tr><td>${esc(r.tok)}</td><td>${esc(r.c.code)}${r.fixed ? ` <i class="dnote">${d.aFixed}</i>` : ''}${r.c.full ? ` <i class="dnote">${d.aFull}</i>` : ''}</td><td>${esc(r.c.period)}</td><td>${esc(r.c.teacher || '')}</td></tr>`
        : `<tr><td>${esc(r.tok)}</td><td colspan="3" class="bad">${esc(r.why)}</td></tr>`).join('')}</table>
        <div class="dnote">${d.aByPeriod}: ${Object.entries(per).map(([k, v]) => esc(k) + ' ' + v).join(' · ') || '–'}</div>`;
    })() : '';
    return `<details class="dtoolbox auto" data-rid="auto" open><summary>\u{1F9E9} ${d.aTitle}</summary>
      <div class="dnote">${d.aHelp}</div>
      <div class="dtools" data-hb><label class="dnote">${d.aHome} ${homeSel}</label>${q('ahome')}</div>
      ${oth ? `<div class="dtools" data-hb><span class="dnote">${d.aOthers}:</span>${oth}${q('aothers')}</div>` : ''}
      <div class="dtools" data-hb><label class="dnote grow">${d.aWant}<textarea data-aopt="want" rows="2" spellcheck="false">${esc(A.want || '')}</textarea></label><button class="act" data-dact="afill">${d.aFill}</button>${q('awant')}</div>
      <div class="dtools" data-hb><label class="dnote grow">${d.aOther}<textarea data-aopt="other" rows="2" spellcheck="false">${esc(A.other || '')}</textarea></label>${q('aother')}</div>
      <div class="dtools" data-hb><label class="dnote">${d.aMax} <input class="nn" type="number" min="0" max="12" value="${+A.maxper || 0}" data-aopt="maxper"></label>${q('amax')}<label class="dnote"><input type="checkbox" data-aopt="lock"${A.lock !== false ? ' checked' : ''}> ${d.aLock}</label></div>
      <div class="dtools" data-hb><button class="act go" data-dact="abuild">${d.aBuild}</button>${q('abuild')}<button class="act" data-dact="aapply"${autoRes && autoRes.placed ? '' : ' disabled'}>${d.aApply}</button>${q('aapply')}</div>
      ${res}</details>`;
  }

  // ---- Opinnot -> Suoritukset and Opinnot -> HOPS (links are found on the page, nothing is guessed) ----
  const CODE_RE = /^(?!LU\d)([A-ZÄÖÅ]{1,6}\d{1,3})(?:[._][0-9A-Za-z]+)?(?=\s|$|[,;:])/i;
  async function findLinks() {
    const found = {}, docs = [{ doc: document, url: location.href }];
    try { docs.push(await getDoc(url(''))); } catch (_) { /* ignore */ }
    for (const { doc, url: u } of docs) doc.querySelectorAll('a[href]').forEach(a => {
      const tx = a.textContent.replace(/\s+/g, ' ').trim(), h = a.getAttribute('href') || '';
      if (!h || h[0] === '#' || /^(javascript|mailto):/i.test(h) || tx.length > 40) return;
      try {
        if (!found.done && /^(opinto)?suoritukset$|^prestationer$|^avlagda\b/i.test(tx)) found.done = new URL(h, u).href;
        if (!found.hops && /^hops$/i.test(tx)) found.hops = new URL(h, u).href;
      } catch (_) { /* ignore */ }
    });
    // the menu is not on every page (e.g. not on the course tray): fall back to the known Wilma addresses
    if (!found.done) found.done = url('choices?view=gradebook');
    if (!found.hops) found.hops = url('choices');
    return found;
  }
  // Table rows that start (or contain a cell starting) with a course code; credits from the column headed "laajuus/op".
  function parseDone(doc) {
    const res = {};
    doc.querySelectorAll('table').forEach(tbl => {
      if ([...tbl.querySelectorAll('th')].length === 2 && /ects/i.test(tbl.querySelector('th:last-child') ? tbl.querySelector('th:last-child').textContent : '')) return; // the per-type summary, not courses
      const rows = [...tbl.querySelectorAll('tr')]; let opCol = -1, gCol = -1;
      const head = rows.find(r => r.querySelector('th'));
      if (head) [...head.children].forEach((c, i) => { const t = c.textContent.toLowerCase(); if (/laajuus|\bop\b|opintopist|\bsp\b|studiepo|credit/.test(t)) opCol = i; if (/arvosana|vitsord|grade/.test(t)) gCol = i; });
      rows.forEach(r => {
        if (r.querySelector('th')) return;
        const tx = [...r.children].map(c => c.textContent.replace(/\s+/g, ' ').trim());
        const m = tx.map(x => CODE_RE.exec(x)).find(Boolean); if (!m) return;
        const g = gCol >= 0 ? tx[gCol] || '' : '';
        if (/^4$|hyl|underk|ej godk/i.test(g)) return; // failed grade is not earned
        let op = null;
        if (opCol >= 0 && tx[opCol]) { const n = parseFloat(tx[opCol].replace(',', '.')); if (n > 0 && n < 20) op = n; }
        else { const o = tx.map(x => /^(\d+(?:[.,]\d+)?)\s*(?:op|sp)\.?$/i.exec(x)).find(Boolean); if (o) op = parseFloat(o[1].replace(',', '.')); }
        res[baseOf(m[0])] = { op, g };
      });
    });
    return res;
  }
  // HOPS: credits per course live here. Tables first (column "laajuus/op"), then any element whose text starts with a code
  // and mentions "<n> op".
  function parseHops(doc) {
    const res = parseDone(doc);
    // credits that hide in a tooltip/data attribute of a course's own table
    doc.querySelectorAll('table').forEach(tbl => {
      const m = CODE_RE.exec(tbl.textContent.replace(/\s+/g, ' ').trim()); if (!m) return;
      const b = baseOf(m[0]); if (res[b] && res[b].op != null) return;
      let op = null;
      [tbl, ...tbl.querySelectorAll('*')].some(el => [...el.attributes].some(at => {
        if (!/title|content|ects|credit|laajuus|\bop\b/i.test(at.name)) return false;
        const o = /(\d+(?:[.,]\d+)?)\s*(?:op\b|ects|sp\b)/i.exec(at.value) || (/^data-(ects|credits?|laajuus)$/i.test(at.name) ? /^(\d+(?:[.,]\d+)?)$/.exec(at.value) : null);
        if (o) { op = parseFloat(o[1].replace(',', '.')); return true; } return false;
      }));
      if (op != null) res[b] = { ...(res[b] || { g: '' }), op };
    });
    doc.querySelectorAll('tr, li, a, td, span, div').forEach(el => {
      if (el.children.length > 12) return;
      const tx = el.textContent.replace(/\s+/g, ' ').trim(), m = CODE_RE.exec(tx); if (!m || tx.length > 160) return;
      const b = baseOf(m[0]), o = /(\d+(?:[.,]\d+)?)\s*(?:op|sp)\b/i.exec(tx), op = o ? parseFloat(o[1].replace(',', '.')) : null;
      if (!res[b]) res[b] = { op, g: '' }; else if (res[b].op == null && op != null) res[b].op = op;
    });
    return res;
  }
  // "Suoritukset kurssityypeittäin | ECTS" summary table on the Suoritukset page
  function parseSummary(doc) {
    const out = [];
    doc.querySelectorAll('table').forEach(tbl => {
      const heads = [...tbl.querySelectorAll('th')].map(x => x.textContent.replace(/\s+/g, ' ').trim());
      if (!(heads.length === 2 && /ects|\bop\b|laajuus/i.test(heads[1]))) return;
      tbl.querySelectorAll('tr').forEach(r => {
        const c = [...r.children].map(x => x.textContent.replace(/\s+/g, ' ').trim());
        if (c.length >= 2 && c[0] && /^\d+(?:[.,]\d+)?$/.test(c[c.length - 1])) out.push([c[0], parseFloat(c[c.length - 1].replace(',', '.'))]);
      });
    });
    return out;
  }
  async function fetchDone(links) {
    const d = D[state.lang] || D.en; if (!links.done) return d.linkNone(d.prest);
    const { doc } = await getDoc(links.done), res = parseDone(doc), n = Object.keys(res).length;
    if (!n) return d.noRows(d.prest);
    state.earned = res; state.summary = parseSummary(doc); save();
    return d.doneRes(n, Object.values(res).reduce((a, v) => a + (v.op || 0), 0));
  }
  async function fetchHops(links) {
    const d = D[state.lang] || D.en; if (!links.hops) return d.linkNone(d.hops);
    const { doc } = await getDoc(links.hops), res = parseHops(doc), n = Object.keys(res).length;
    if (!n) return d.noRows(d.hops);
    state.hops = res; state.hopsAt = Date.now(); save();
    return d.hopsRes(n) + ' (' + Object.values(res).reduce((a, v) => a + (v.op || 0), 0) + ' op)';
  }

  async function dashScan() {
    const d = D[state.lang] || D.en, dl = txt => { const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = txt; } };
    if (!years.length) await reloadYears();
    const ps = years.flatMap(y => y.periods); let n = 0; const fresh = {};
    dl(d.scanning(0, ps.length));
    await pool(ps, state.conc, async p => {
      const idx = await scanPeriods([p], viewUrl);
      idx.forEach(c => { const b = baseOf(c.code), r = fresh[b] || (fresh[b] = { d: 0, s: 0, o: 0 }); if (c.done) r.d = 1; if (c.selected) r.s = 1; if (!c.closed) r.o = 1; });
      dl(d.scanning(++n, ps.length));
    });
    const old = state.seen || {}, next = {};
    for (const b of Object.keys(old)) next[b] = { d: old[b].d ? 1 : 0, s: 0, o: 0 };
    for (const [b, v] of Object.entries(fresh)) next[b] = { d: (old[b] && old[b].d) || v.d ? 1 : 0, s: v.s, o: v.o };
    state.seen = next; save();
    const msgs = [d.scanned(Object.keys(fresh).length)];
    try { const links = await findLinks(); for (const f of [fetchDone, fetchHops]) { try { msgs.push(await f(links)); } catch (e) { msgs.push(String(e.message || e)); } } } catch (e) { msgs.push(String(e.message || e)); }
    renderDash();
    const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = msgs.join('\n'); }
  }

  // "?" help text also as hover text on the control it belongs to
  function applyTitles(scope) {
    (scope || root).querySelectorAll('button.q').forEach(b => {
      const tip = tipOf(b.dataset.help); if (!tip) return;
      b.title = tip;
      let el = b.previousElementSibling;
      while (el && el.classList.contains('q')) el = el.previousElementSibling;
      if (el && !el.matches('input.nn, .dchip')) el.title = tip;
    });
  }

  // small right-click menu for a course chip
  function showCtx(x, y, base) {
    root.querySelectorAll('.ctx').forEach(e => e.remove());
    const d = D[state.lang] || D.en, ign = !!state.ignore[base], man = !!state.manual[base];
    const m = document.createElement('div'); m.className = 'ctx';
    m.style.left = Math.min(x, innerWidth - 230) + 'px'; m.style.top = Math.min(y, innerHeight - 100) + 'px';
    m.innerHTML = `<div class="ctxh">${esc(base)}</div><button data-dact="ign" data-base="${esc(base)}">${ign ? d.unign : d.ign}</button><button data-dact="mark" data-base="${esc(base)}">${man ? d.unmark : d.mark}</button>`;
    shell.appendChild(m);
  }

  const paintTabs = () => root.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', (b.dataset.act === 'vdash') === (view === 'dash')));
  function setView(v) {
    view = v; shell.classList.toggle('view-dash', v === 'dash'); paintTabs();
    try { history.replaceState(null, '', location.pathname + location.search + (v === 'dash' ? '#wk-full-dash' : '#wk-full')); } catch (_) { /* ignore */ }
    if (v === 'dash') { renderDash(); if (!Object.keys(state.seen || {}).length && !busy) actions.dscan(); }
  }

  function dashClick(b) {
    const k = b.dataset.dact, d = D[state.lang] || D.en, base = b.dataset.base;
    if (k === 'chip') {
      if (state.pickMode) {
        if (!b.classList.contains('todo')) return;
        const toks = parseCodes(state.list), i = toks.findIndex(t => baseOf(t) === base);
        if (i >= 0) toks.splice(i, 1); else toks.push(base);
        state.list = toks.join(' ');
      } else if (state.manual[base]) delete state.manual[base]; else state.manual[base] = 1;
    }
    else if (k === 'ign') { if (state.ignore[base]) delete state.ignore[base]; else state.ignore[base] = 1; }
    else if (k === 'mark') { if (state.manual[base]) delete state.manual[base]; else state.manual[base] = 1; }
    else if (k === 'abuild') { autoBuild(); return; }
    else if (k === 'aapply') { autoApply(); return; }
    else if (k === 'afill') { const m = dashModel(); state.auto.want = [...new Set([...parseCodes(state.auto.want), ...m.rows.filter(r => !r.inactive).flatMap(r => r.todoList.map(c => c.base)), ...parseCodes(state.list)])].join(' '); save(); renderDash(); return; }
    else if (k === 'ncopy') { const txt = [...root.querySelectorAll('.ncon .nl')].map(x => x.textContent).join('\n'); try { navigator.clipboard.writeText(txt); } catch (_) { /* ignore */ } const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = d.copied; } return; }
    else if (k === 'nclear') { netBuf.length = 0; netTotal = netPosts = netBad = 0; drawNet(); return; }
    else if (k === 'npause') { netPaused = !netPaused; renderDash(); return; }
    else if (k === 'pickmode') state.pickMode = !state.pickMode;
    else if (k === 'fold') { const pm = state.pickMode, ids = state.req.map(r => (pm ? 'p:' : 'n:') + r.id), anyOpen = ids.some(i => (state.dopen[i] != null ? state.dopen[i] : pm)); ids.forEach(i => { state.dopen[i] = !anyOpen; }); }
    else if (k === 'addall') {
      const m = dashModel(), toks = parseCodes(state.list); let n = 0;
      m.rows.filter(r => !r.inactive).flatMap(r => r.todoList).forEach(c => { if (!toks.some(t => baseOf(t) === c.base)) { toks.push(c.base); n++; } });
      state.list = toks.join(' '); const l = $('.list'); if (l) l.value = state.list; save(); renderDash(); const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = d.added(n); } return;
    }
    else if (k === 'go') { setView('sel'); return; }
    else if (k === 'hopscopy') { const txt = dashModel().all.filter(c => c.sel && !c.hp).map(c => c.base).join(' '); try { navigator.clipboard.writeText(txt); } catch (_) { /* ignore */ } const e = $('.dlog'); if (e) { e.hidden = false; e.textContent = d.copied + ' ' + txt; } return; }
    else if (k === 'del') state.req = state.req.filter(r => r.id !== b.dataset.id);
    else if (k === 'reset') state.req = JSON.parse(JSON.stringify(DEFAULT_REQ));
    else if (k === 'manual') { parseCodes($('.dmanual').value).forEach(c => { state.manual[baseOf(c)] = 1; }); }
    else if (k === 'add') {
      const name = $('.dnname').value.trim(), pref = $('.dnpref').value.split(/[\s,;]+/).filter(Boolean);
      if (!name || !pref.length) return;
      state.req.push({ id: 'u' + Date.now().toString(36), name, p: pref, need: Math.max(0, +$('.dnneed').value || 0) });
    } else return;
    const l = $('.list'); if (l) l.value = state.list;
    save(); renderDash();
  }

  // ---------- retry loop: refresh -> pick, in one or several tabs, until every course is selected ----------
  const LKEY = 'wilmaKurssit.loop';
  const readLoop = () => { try { return JSON.parse(localStorage.getItem(LKEY) || '{}'); } catch (_) { return {}; } };
  const writeLoop = o => { try { localStorage.setItem(LKEY, JSON.stringify(o)); } catch (_) { /* ignore */ } };
  const loopActive = () => { const L = readLoop(); return !!L.on && Date.now() < (L.t0 || 0) + (L.max || 30) * 60000; };
  const loopStop = why => { writeLoop({ ...readLoop(), on: false, why }); evLog('STOP', 'syy: ' + why); paintLoop(); schedStat(); };
  function paintLoop() {
    const b = root.querySelector('[data-act=loop]'); if (!b) return;
    const on = loopActive(), t = tr();
    b.textContent = (on ? '\u23F9 ' + t.loopStop : '\u{1F501} ' + t.loop);
    b.classList.toggle('on', on);
  }
  window.addEventListener('storage', e => { if (e.key === LKEY) { paintLoop(); if (!loopActive()) { cancelled = true; if (location.hash === '#wk-loop' && window.__wkCloseTab) setTimeout(window.__wkCloseTab, 800); } schedStat(); } });
  function openTabs(n, u, win) {
    if (window.__wkOpenTabs) { window.__wkOpenTabs(n, u, !!win); return true; }
    let ok = true; for (let i = 0; i < n; i++) { const w = window.open(u, '_blank'); if (!w) ok = false; }
    return ok;
  }
  function loopBegin(openMore) {
    loginLost = false; fkAt = 0;
    // "win": every loop tab, including the hybrid's three, runs in its own window; this page only starts and watches the loop
    const win = state.lwin !== false && state.lmode !== 'fetch' && (state.lmode === 'hybrid' || state.ltabs >= 2);
    if (!loopActive()) writeLoop({ on: true, t0: Date.now(), max: state.lmax, delay: Math.max(minDelay(), state.ldelay), keep: !!state.lkeep, rounds: 0, mode: state.lmode, workers: state.lworkers, unstable: !!state.unstable, win });
    const n = state.lmode === 'fetch' ? 0 : win ? (state.lmode === 'hybrid' ? 3 : state.ltabs) : state.lmode === 'hybrid' ? 2 : Math.max(0, state.ltabs - 1);
    if (openMore && n) {
      const ok = openTabs(n, location.origin + basePath() + '/selection/view#wk-loop', win);
      evLog('TABS', ok ? `avattu ${n} lisävälilehteä` : 'selain esti lisävälilehdet'); log(ok ? tr().openedTabs(n) : tr().noTabs, true);
    }
  }
  // two tabs must not send the same pick at the same moment (a repeated pick might undo the first one)
  function claim(target) {
    const k = 'wilmaKurssit.claim.' + target;
    let id = '';
    try { id = sessionStorage.getItem('wilmaKurssit.tab') || ''; if (!id) { id = Math.random().toString(36).slice(2); sessionStorage.setItem('wilmaKurssit.tab', id); } } catch (_) { /* ignore */ }
    try {
      const v = (localStorage.getItem(k) || '').split(':'), mine = id + ':' + Date.now();
      if (v[0] && v[0] !== id && Date.now() - parseInt(v[1], 10) < 4000) return false; // another tab sent this very recently
      localStorage.setItem(k, mine); return true;
    } catch (_) { return true; }
  }
  let fkAt = 0;
  const floorMs = () => (readLoop().unstable ? 5 : 300);
  async function loopWait(ms) {
    const until = Date.now() + ms;
    while (Date.now() < until) { if (!loopActive() || cancelled) return false; await sleep(Math.min(ms > 1500 ? 150 : 10, Math.max(1, until - Date.now()))); }
    return loopActive();
  }
  // One turn: scan (or reuse the round's scan), then send the picks still missing, all in parallel.
  // Returns 'sent' | 'watch' | 'done' | 'stop'.
  let roundSent = new Set();
  async function loopTurn(round, quiet, w, N, reuse) {
    const t = tr(); lastTick = Date.now();
    if (!reuse) { // a fresh scan: once per round, not once per virtual handler
      if (!parseCodes($('.list').value).length) { loopStop('nothing'); return 'stop'; }
      roundSent = new Set();
      const okFind = await find(quiet);
      if (loginLost) { loopStop('login'); log(t.login, true); return 'stop'; }
      if (!okFind) { evLog('SCAN', 'haku epäonnistui, yritetään uudelleen'); log(t.loopRetry); return 'sent'; } // transient failure: try again
      if (lastScanErrors.some(e => /HTTP 429/.test(e))) { loopStop('rate'); log(t.rate, true); return 'stop'; }
    }
    const rows = plan.filter(p => p.cands.length), pending = rows.filter(p => !p.cands.some(c => c.selected));
    if (!rows.length) { loopStop('none'); log(t.nothing, true); return 'stop'; }
    if (!pending.length && readLoop().keep) { log(t.loopWatch(rows.length)); return 'watch'; }
    if (!pending.length) {
      loopStop('done'); document.title = '✅ ' + document.title.replace(/^✅ /, '');
      log(t.loopDone(rows.length)); if (location.hash === '#wk-loop' && window.__wkCloseTab) setTimeout(window.__wkCloseTab, 4000);
      return 'done';
    }
    const freshKey = !!N && Date.now() - fkAt > 60000; // the light loop never reloads the page, so its form key is renewed every minute
    const key = await getFormkey(freshKey); if (freshKey && key) fkAt = Date.now();
    if (!key) { loopStop('key'); log(t.noKey, true); return 'stop'; }
    const targets = [...new Set(pending.map(p => p.cands[p.choice]).filter(c => !c.closed).map(c => c.target))].filter(x => !roundSent.has(x));
    let sent = 0, bad = 0, skipped = 0, limited = false;
    await Promise.all(targets.map(async target => {
      if (!claim(target)) { skipped++; return; } // another tab sent this very pick a moment ago
      try { const r = await pickGroup(target, key); sent++; if (r.ok) roundSent.add(target); else bad++; if (r.status === 429) limited = true; } catch (_) { bad++; }
    }));
    evLog('TURN', `${N ? 'virtuaalivalitsija ' + w + '/' + N : 'kierros ' + round}: valitsematta ${pending.length}/${rows.length}, lähetetty ${sent}, virheitä ${bad}${skipped ? ', toinen välilehti ohitti ' + skipped : ''}`);
    log(N ? t.fetchTurn(w, N, round, pending.length, rows.length, sent, bad) : t.loopRound(round, pending.length, rows.length, sent, bad));
    if (limited) { loopStop('rate'); evLog('LIMIT', 'Wilma rajoitti pyyntöjä (429), silmukka pysäytettiin'); log(t.rate, true); return 'stop'; }
    return 'sent';
  }
  // light mode: no page reloads; N "virtual tabs" take turns inside this one tab
  async function fetchLoop() {
    const t = tr(); let turn = 0;
    await sleep(Math.random() * 300);
    while (loopActive() && !cancelled) {
      const L = readLoop(), N = Math.max(1, Math.min(6, +L.workers || 6)), t0 = Date.now();
      turn++; lastTick = Date.now(); writeLoop({ ...L, rounds: turn }); schedStat();
      const st = await loopTurn(turn, true, ((turn - 1) % N) + 1, N, false);
      if (st === 'stop' || st === 'done') return;
      const gap = state.gapMs > 0 ? Math.max(floorMs(), state.gapMs) : Math.max(floorMs(), (+L.delay || 2) * 1000 / N);
      if (!await loopWait(Math.max(0, t0 + gap - Date.now()))) break;
    }
    log(t.loopStopped);
  }
  let lastTick = Date.now(), loopDog = 0;
  const TABKEY = 'wilmaKurssit.looptab';
  // the dashboard tab is never refreshed by the loop (it is the place you watch the console)
  const isDash = () => (full && view === 'dash') || /#wk-full-dash/.test(location.hash);
  function startDog() {
    if (loopDog) return;
    loopDog = setInterval(() => {
      if (!loopActive() || isDash()) return;
      let flagged = false; try { flagged = sessionStorage.getItem(TABKEY) === '1'; } catch (_) { /* ignore */ }
      if (!flagged && !/#wk-loop/.test(location.hash)) return;
      if (Date.now() - lastTick > Math.max(10000, (+readLoop().delay || 2) * 4000)) {
        lastTick = Date.now();
        if (/selection/.test(location.pathname)) refresh('vartija: välilehti oli hiljaa'); else location.href = url('selection/view') + '#wk-loop';
      }
    }, 3000);
  }
  // hybrid: the loop tabs share one schedule (each tab takes a fixed slot inside every handler gap, so the sends are evenly spread)
  const HYB = 'wilmaKurssit.hyb';
  function hybSlot() {
    const now = Date.now(), me = tabId(); let reg = {};
    try { reg = JSON.parse(localStorage.getItem(HYB) || '{}') || {}; } catch (_) { reg = {}; }
    reg[me] = now;
    for (const k of Object.keys(reg)) if (now - reg[k] > 15000) delete reg[k]; // tabs that went away
    try { localStorage.setItem(HYB, JSON.stringify(reg)); } catch (_) { /* ignore */ }
    const ids = Object.keys(reg).sort();
    return { i: Math.max(0, ids.indexOf(me)), n: Math.max(1, ids.length) };
  }
  // hybrid: this tab sends three virtual handlers in turn, then refreshes itself (the dashboard tab keeps going without refreshing)
  async function hybridRound() {
    const t = tr(), N = 3, L0 = readLoop(), round = L0.rounds || 0;
    lastTick = Date.now();
    const gap = state.gapMs > 0 ? Math.max(floorMs(), state.gapMs) : Math.max(floorMs(), (+L0.delay || 2) * 1000 / N);
    const slot = hybSlot(), off = slot.i * gap / slot.n, start = Date.now();
    evLog('ROUND', `kierros ${round}: välilehti ${slot.i + 1}/${slot.n}, aloitus +${Math.round(off)} ms, väli ${Math.round(gap)} ms`);
    if (!await loopWait(Math.max(0, start + off - Date.now()))) { log(t.loopStopped); return; }
    for (let w = 1; w <= N; w++) {
      if (!loopActive() || cancelled) { log(t.loopStopped); return; }
      const st = await loopTurn(round, true, w, N, w > 1); // handlers 2 and 3 reuse the round's scan
      if (st === 'stop' || st === 'done') return;
      if (w < N && !await loopWait(Math.max(0, start + off + w * gap - Date.now()))) { log(t.loopStopped); return; }
    }
    if (!loopActive()) { log(t.loopStopped); return; }
    if (isDash()) {
      evLog('KEEP', 'kojelauta: ei päivitystä, kierrokset jatkuvat');
      if (!await loopWait(Math.max(0, start + off + N * gap - Date.now()))) { log(t.loopStopped); return; }
      writeLoop({ ...readLoop(), rounds: (readLoop().rounds || 0) + 1 });
      return hybridRound();
    }
    log(t.hybridRefresh);
    refresh('hybridi: kierros valmis');
  }
  async function loopRun() {
    if (busy) return;
    if (readLoop().win && !/#wk-loop/.test(location.hash)) { evLog('TABS', 'tämä sivu vain seuraa, kierrokset ajetaan erillisessä ikkunassa'); return; }
    setBusy(true); lastTick = Date.now(); try { sessionStorage.setItem(TABKEY, '1'); } catch (_) { /* ignore */ }
    const t = tr();
    try {
      const L0 = readLoop(), round = (L0.rounds || 0) + 1;
      writeLoop({ ...L0, rounds: round });
      if (L0.mode === 'fetch') { await fetchLoop(); return; }
      if (L0.mode === 'hybrid') { await hybridRound(); return; }
      await sleep(Math.random() * 700); // spread the tabs a little
      if (!loopActive()) { log(t.loopOff); return; }
      const st = await loopTurn(round, false, 0, 0, false);
      if (st === 'stop' || st === 'done') return;
      if (!await loopWait(Math.max(floorMs(), (+readLoop().delay || state.ldelay || 2) * 1000))) { log(t.loopStopped); return; }
      refresh('kierros valmis, sivu päivitetään');
    } catch (e) {
      log(String(e && e.message || e), true);
      if (loopActive()) setTimeout(() => { if (loopActive()) refresh('virhe, yritetään uudelleen'); }, 5000);
    } finally { setBusy(false); }
  }


  // ---------- bottom progress bar, light mode, developer settings ----------
  let lastScanErrors = [], progKey = '';
  const minDelay = () => (state.unstable ? 0.005 : 0.3);
  function paintProg() {
    const el = $('.pbar'); if (!el) return;
    const t = tr(), d = D[state.lang] || D.en, pc = (a, b) => (b ? Math.min(100, Math.round(100 * a / b)) : 0);
    let a = 0, b = 0, label = t.progNone;
    const rows = plan.filter(p => p.cands.length);
    if (rows.length) { a = rows.filter(p => p.cands.some(c => c.selected)).length; b = rows.length; label = t.prog(a, b, pc(a, b)); }
    else {
      const act = dashModel().rows.filter(r => !r.inactive);
      b = act.reduce((x, r) => x + r.need, 0); a = act.reduce((x, r) => x + Math.min(r.need, r.done + r.sel), 0);
      if (b) label = d.progReq(a, b, pc(a, b));
    }
    const key = label + '|' + pc(a, b); if (key === progKey && el.firstChild) return; progKey = key;
    el.classList.toggle('full100', b > 0 && a >= b);
    el.innerHTML = `<div class="pt"><span>${esc(label)}</span></div><div class="pb" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pc(a, b)}"><i style="width:${pc(a, b)}%"></i></div>`;
  }
  function applyLite() {
    shell.classList.toggle('lite', !!state.lite);
    shell.classList.toggle('help', !!state.help); const hb = root.querySelector('.helpbtn'); if (hb) hb.classList.toggle('on', !!state.help);
    const lc = $('.lite'); if (lc) lc.checked = !!state.lite;
    const i = $('.ldelay'); if (i) { i.min = String(minDelay()); i.step = '0.001'; i.value = state.ldelay; }
    progKey = ''; paintProg();
  }

  // ---------- live sync between every open Wilma tab (panel, full view, dashboard) ----------
  const AKEY = 'wilmaKurssit.at';
  const LOCAL_ONLY = new Set(['x', 'y', 'w', 'h', 'open', 'year', 'arm', 'fast', 'rt', 'at']); // position, size and one-shot timers stay per tab
  function syncInputs() {
    const set = (sel, v) => { const el = $(sel); if (el && root.activeElement !== el) el.value = v; };
    const chk = (sel, v) => { const el = $(sel); if (el && root.activeElement !== el) el.checked = !!v; };
    set('.list', state.list); set('.conc', state.conc); set('.ltabs', state.ltabs); set('.ldelay', state.ldelay); set('.lmax', state.lmax);
    chk('.lkeep', state.lkeep); chk('.always', state.always); chk('.wq', state.wq); chk('.rf', state.refresh); chk('.lite', state.lite);
    applyTheme(); applyLite(); paintLoop();
  }
  window.addEventListener('storage', e => {
    if (e.key === AKEY && e.newValue) {
      try { const v = JSON.parse(e.newValue).v || ''; const a = $('.at'); if (a && root.activeElement !== a) { a.value = v; state.at = v; } } catch (_) { /* ignore */ }
      return;
    }
    if (e.key !== KEY || !e.newValue) return;
    let n; try { n = JSON.parse(e.newValue); } catch (_) { return; }
    let changed = false, lang = false, per = false;
    for (const k of Object.keys(DEFAULTS)) {
      if (LOCAL_ONLY.has(k) || !(k in n) || JSON.stringify(state[k]) === JSON.stringify(n[k])) continue;
      state[k] = n[k]; changed = true; if (k === 'lang') lang = true; if (k === 'per') per = true;
    }
    if (!changed) return;
    if (lang) { buildUi(); return; }
    if (per) { periodSel = new Set(state.per); renderPeriods(); }
    syncInputs(); renderDash();
  });

  // ---------- readable save file (.txt) ----------
  const findPeriod = ({ year, label }) => {
    const L = norm(label), hit = z => z.periods.find(p => norm(p.label) === L || norm(p.short || '') === L);
    const z1 = years.find(z => year && norm(z.title) === norm(year) && hit(z)) || years.find(z => hit(z));
    const p = z1 && hit(z1); return p ? p.href : '';
  };
  function parseTxt(raw) {
    const out = { list: '', periods: [], filters: {}, codes: {} }, toks = []; let sec = '';
    for (const line0 of raw.split(/\r?\n/)) {
      const line = line0.trim(); if (!line || line[0] === '#') continue;
      const h = /^(jaksot|periods|perioder|kurssit|courses|kurser)\s*:\s*$/i.exec(line);
      if (h) { sec = /^(j|p)/i.test(h[1]) ? 'p' : 'c'; continue; }
      if (sec === 'p') {
        const t = line.replace(/^[-*•]\s*/, ''); if (!t) continue;
        const i = t.indexOf(' / '); out.periods.push(i >= 0 ? { year: t.slice(0, i).trim(), label: t.slice(i + 3).trim() } : { year: '', label: t });
      } else if (sec === 'c') {
        const parts = line.replace(/^[-*•]\s*/, '').split('|').map(x => x.trim()), tok = parseCodes(parts[0])[0]; if (!tok) continue;
        toks.push(tok);
        parts.slice(1).forEach(a => {
          const m = /^(rajaus|only|endast|valittu|chosen|vald)\s*:\s*(.*)$/i.exec(a); if (!m) return;
          if (/^(r|o|e)/i.test(m[1])) out.filters[tok] = m[2].trim();
          else { const g = /^(\S+)\s*(?:\((.*)\))?$/.exec(m[2].trim()); if (g) out.codes[norm(tok)] = { code: g[1], period: (g[2] || '').trim() }; }
        });
      }
    }
    if (!toks.length && !out.periods.length) throw new Error('format');
    out.list = toks.join(' '); return out;
  }

  // ---------- window modes (used by the browser extension) ----------
  const hostCss = () => {
    host.style.cssText = full ? 'position:fixed;inset:0;z-index:2147483646;' : 'position:fixed;z-index:2147483646;right:16px;bottom:72px;';
    if (!full && state.x != null && state.y != null) Object.assign(host.style, { left: state.x + 'px', top: state.y + 'px', right: 'auto', bottom: 'auto' });
  };
  function setFull(on, v) {
    full = !!on; shell.classList.toggle('full', full); hostCss(); applySize();
    if (full && v) { view = v; shell.classList.toggle('view-dash', v === 'dash'); paintTabs(); if (v === 'dash') { renderDash(); if (!Object.keys(state.seen || {}).length) setTimeout(() => !busy && actions.dscan(), 0); } }
    if (!full) { view = 'sel'; shell.classList.remove('view-dash'); }
    if (full) { $('.panel').hidden = false; $('.fab').hidden = true; } else { $('.panel').hidden = !state.open; $('.fab').hidden = state.open; }
  }
  const setHidden = h => { host.style.display = h ? 'none' : ''; };
  const openPanel = () => { state.open = true; save(); setHidden(false); if (!full) { $('.panel').hidden = false; $('.fab').hidden = true; } };

  // ---------- go ----------
  buildUi();
  startDog();
  if (state.cauto) setTimeout(autoLoginPage, 800);
  keepAliveTick(); setInterval(keepAliveTick, 60000);
  evLog('LOAD', (location.hash || 'sivu') + ' · tila ' + (state.lmode || 'reload') + (loopActive() ? ' · silmukka päällä' : ''));
  document.documentElement.appendChild(host);
  reloadYears();
  wilmaQuick();

  window.__wilmaKurssit = { unload, stopLoop: () => { loopStop('stop'); cancelled = true; if (location.hash === '#wk-loop' && window.__wkCloseTab) setTimeout(window.__wkCloseTab, 500); }, setFull, setHidden, openPanel, state, tools: { parseCodes, matchCourse, parseTime, pool } };
})();
